# نظام رسائل الترحيب - تطبيق مُعافى
## Welcome Email System - Muaafa App

تم إنشاء نظام متكامل لإرسال رسائل ترحيب احترافية للعملاء الجدد فور تسجيلهم في التطبيق.

---

## 📧 الميزات الرئيسية

### 1. نظام القوالب (Email Templates)
```sql
✅ قوالب ثنائية اللغة (عربي/إنجليزي)
✅ متغيرات ديناميكية ({{user_name}})
✅ 5 قوالب جاهزة
✅ سهولة التعديل والإضافة
```

### 2. سجل الرسائل (Email Logs)
```sql
✅ تتبع كامل لكل رسالة
✅ 4 حالات: pending, sent, failed, bounced
✅ تتبع الفتح والنقر
✅ Metadata تفصيلية
```

### 3. إشعارات داخل التطبيق
```sql
✅ إشعار فوري للمستخدم
✅ رسالة ترحيب ودية
✅ توجيه للصفحة الرئيسية
```

---

## 📋 قاعدة البيانات

### جدول `email_templates`

```sql
CREATE TABLE email_templates (
  id uuid PRIMARY KEY,
  template_key text UNIQUE NOT NULL,  -- 'welcome_email', 'order_confirmation', etc.
  template_type text,                 -- 'welcome', 'verification', 'notification', 'marketing'

  -- المحتوى ثنائي اللغة
  subject_ar text NOT NULL,
  subject_en text NOT NULL,
  body_ar text NOT NULL,
  body_en text NOT NULL,

  -- المتغيرات المتاحة
  variables jsonb DEFAULT '{}',       -- {"user_name": "string", "order_number": "string"}

  is_active boolean DEFAULT true,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
```

### جدول `email_logs`

```sql
CREATE TABLE email_logs (
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  template_key text,

  -- معلومات الرسالة
  recipient_email text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,

  -- الحالة والتتبع
  status text,                        -- 'pending', 'sent', 'failed', 'bounced'
  error_message text,
  sent_at timestamptz,
  opened_at timestamptz,
  clicked_at timestamptz,

  -- بيانات إضافية
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);
```

---

## 🎨 القوالب المتاحة

### 1️⃣ رسالة الترحيب (welcome_email)

**الموضوع (عربي):**
```
أهلاً بك في مُعافى | رحلتك نحو صحة أذكى تبدأ الآن 🛡️
```

**الموضوع (إنجليزي):**
```
Welcome to Muaafa | Your Journey to Smarter Healthcare Starts Now 🛡️
```

**المحتوى:**
```
أهلاً بك {{user_name}}،

شكراً لانضمامك إلى مُعافى | MUAAFA، الشريك الرقمي الذي يضع صحتك
في مقدمة أولوياته. نحن هنا لنغير مفهوم الرعاية الصحية ونجعلها في
متناول يدك دائماً.

ماذا يمكنك أن تفعل الآن؟

✨ تحدث مع مساعدك الذكي: ابدأ أول دردشة صحية للحصول على
   إرشادات توعوية فورية.

💊 اكتشف الصيدلية الذكية: قارن أسعار الأدوية واطلب وصفاتك
   بضغطة زر.

📋 جهز ملفك الصحي: ارفع تقاريرك ووثق بيانات تأمينك لضمان
   تجربة سلسة.

نحن نعدك بالخصوصية التامة والابتكار المستمر. إذا كان لديك أي
استفسار، فريقنا جاهز لخدمتك.

دمت مُعافى،
فريق تطبيق مُعافى

---
تطبيق مُعافى | MUAAFA
المملكة العربية السعودية
support@muaafa.app
```

---

### 2️⃣ تأكيد البريد الإلكتروني (email_verification)

**الموضوع:** `تأكيد بريدك الإلكتروني - مُعافى`

**المتغيرات:**
- `{{user_name}}`
- `{{verification_link}}`

---

### 3️⃣ تأكيد الطلب (order_confirmation)

**الموضوع:** `تأكيد طلبك #{{order_number}} - مُعافى`

**المتغيرات:**
- `{{user_name}}`
- `{{order_number}}`
- `{{total_amount}}`
- `{{status}}`

**المحتوى:**
```
عزيزي {{user_name}},

تم استلام طلبك بنجاح!

رقم الطلب: {{order_number}}
المبلغ الإجمالي: {{total_amount}} ريال
الحالة: {{status}}

يمكنك تتبع طلبك من خلال التطبيق.

شكراً لثقتك بمُعافى!
```

---

### 4️⃣ الموافقة التأمينية (insurance_approved)

**الموضوع:** `تمت الموافقة على طلبك التأميني - مُعافى`

**المتغيرات:**
- `{{user_name}}`
- `{{coverage_percentage}}`
- `{{covered_amount}}`
- `{{patient_amount}}`

**المحتوى:**
```
عزيزي {{user_name}},

يسرنا إبلاغك بأنه تمت الموافقة على طلبك التأميني!

التفاصيل:
- التغطية التأمينية: {{coverage_percentage}}%
- المبلغ المغطى: {{covered_amount}} ريال
- المبلغ المتبقي: {{patient_amount}} ريال

يمكنك الآن المتابعة للدفع من خلال التطبيق.
```

---

### 5️⃣ إشعار التوصيل (delivery_notification)

**الموضوع:** `طلبك في الطريق إليك - مُعافى`

**المتغيرات:**
- `{{user_name}}`
- `{{driver_name}}`
- `{{driver_phone}}`
- `{{vehicle_type}}`
- `{{vehicle_plate}}`

**المحتوى:**
```
عزيزي {{user_name}},

طلبك الآن في الطريق إليك!

السائق: {{driver_name}}
رقم الجوال: {{driver_phone}}
نوع المركبة: {{vehicle_type}}
رقم اللوحة: {{vehicle_plate}}

يمكنك تتبع السائق مباشرة من خلال التطبيق.

نتمنى لك الشفاء العاجل!
```

---

## 🔧 Edge Function

### المسار
```
/supabase/functions/send-welcome-email/index.ts
```

### الاستخدام

```typescript
// من الواجهة الأمامية
const response = await fetch(
  `${SUPABASE_URL}/functions/v1/send-welcome-email`,
  {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      userId: user.id,
      language: 'ar', // أو 'en'
    }),
  }
);

const result = await response.json();
console.log(result);
// {
//   success: true,
//   message: 'Welcome email logged and notification sent',
//   email: {
//     to: 'user@example.com',
//     subject: 'أهلاً بك في مُعافى...'
//   }
// }
```

### الوظائف

1. **استرجاع بيانات المستخدم**
```typescript
const { data: userData } = await supabaseClient.auth.admin.getUserById(userId);
const user = userData.user;
const userName = user.user_metadata?.full_name || user.email?.split('@')[0];
```

2. **جلب القالب**
```typescript
const { data: template } = await supabaseClient
  .from('email_templates')
  .select('*')
  .eq('template_key', 'welcome_email')
  .eq('is_active', true)
  .maybeSingle();
```

3. **استبدال المتغيرات**
```typescript
let body = language === 'ar' ? template.body_ar : template.body_en;
body = body.replace(/{{user_name}}/g, userName);
```

4. **تسجيل الرسالة**
```typescript
await supabaseClient.from('email_logs').insert({
  user_id: userId,
  template_key: 'welcome_email',
  recipient_email: userEmail,
  subject: subject,
  body: body,
  status: 'pending',
});
```

5. **إنشاء إشعار داخل التطبيق**
```typescript
await supabaseClient.from('app_notifications').insert({
  user_id: userId,
  type: 'welcome',
  title: 'مرحباً بك في مُعافى!',
  body: 'نحن سعداء بانضمامك. ابدأ رحلتك الصحية الآن!',
  data: { screen: 'home' },
});
```

---

## 🔐 الأمان والصلاحيات

### RLS Policies

#### email_templates
```sql
✅ "Only admins can manage email templates"
   - فقط المسؤولون يمكنهم إضافة/تعديل القوالب
```

#### email_logs
```sql
✅ "Users can view own email logs"
   - المستخدمون يرون رسائلهم فقط

✅ "Admins can view all email logs"
   - المسؤولون يرون جميع الرسائل

✅ "System can create email logs"
   - النظام يمكنه تسجيل الرسائل
```

---

## 📊 الفهارس (Indexes)

```sql
-- أداء سريع لجلب رسائل المستخدم
CREATE INDEX idx_email_logs_user_status
  ON email_logs(user_id, status, created_at DESC);

-- أداء سريع لجلب رسائل قالب معين
CREATE INDEX idx_email_logs_template
  ON email_logs(template_key, created_at DESC);

-- أداء سريع للقوالب النشطة
CREATE INDEX idx_email_templates_active
  ON email_templates(template_key)
  WHERE is_active = true;
```

---

## 🚀 كيفية الاستخدام

### 1. استدعاء تلقائي عند التسجيل

يمكن استدعاء الـ Edge Function تلقائياً عند تسجيل مستخدم جديد:

```typescript
// في صفحة التسجيل
async function registerUser(email: string, password: string, fullName: string) {
  // 1. إنشاء الحساب
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName,
      },
    },
  });

  if (authError) throw authError;

  // 2. إرسال رسالة الترحيب
  if (authData.user) {
    await fetch(`${SUPABASE_URL}/functions/v1/send-welcome-email`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId: authData.user.id,
        language: 'ar',
      }),
    });
  }

  return authData;
}
```

---

### 2. استدعاء يدوي من لوحة التحكم

```typescript
// في لوحة تحكم المسؤول
async function resendWelcomeEmail(userId: string) {
  const response = await fetch(
    `${SUPABASE_URL}/functions/v1/send-welcome-email`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId,
        language: 'ar',
      }),
    }
  );

  return response.json();
}
```

---

### 3. إرسال رسائل أخرى

يمكن توسيع النظام لإرسال أي رسالة:

```typescript
// إرسال تأكيد الطلب
async function sendOrderConfirmation(userId: string, orderData: any) {
  const { data: template } = await supabase
    .from('email_templates')
    .select('*')
    .eq('template_key', 'order_confirmation')
    .maybeSingle();

  let body = template.body_ar;
  body = body.replace('{{user_name}}', orderData.customerName);
  body = body.replace('{{order_number}}', orderData.orderNumber);
  body = body.replace('{{total_amount}}', orderData.totalAmount.toString());
  body = body.replace('{{status}}', orderData.status);

  await supabase.from('email_logs').insert({
    user_id: userId,
    template_key: 'order_confirmation',
    recipient_email: orderData.customerEmail,
    subject: `تأكيد طلبك #${orderData.orderNumber} - مُعافى`,
    body: body,
    status: 'pending',
  });
}
```

---

## 📈 التقارير والإحصائيات

### عدد الرسائل المرسلة

```sql
SELECT
  template_key,
  status,
  COUNT(*) as count,
  DATE(created_at) as date
FROM email_logs
GROUP BY template_key, status, DATE(created_at)
ORDER BY date DESC, count DESC;
```

### معدل الفتح

```sql
SELECT
  template_key,
  COUNT(*) as total_sent,
  COUNT(opened_at) as total_opened,
  ROUND(COUNT(opened_at)::numeric / COUNT(*) * 100, 2) as open_rate
FROM email_logs
WHERE status = 'sent'
GROUP BY template_key;
```

### الرسائل الفاشلة

```sql
SELECT
  user_id,
  recipient_email,
  error_message,
  created_at
FROM email_logs
WHERE status = 'failed'
ORDER BY created_at DESC
LIMIT 50;
```

---

## 🎯 الخطوات التالية (اختياري)

### 1. دمج خدمة إرسال بريد إلكتروني
- **SendGrid**
- **AWS SES**
- **Mailgun**
- **Resend**

### 2. إضافة HTML Templates
```typescript
// بدلاً من النص العادي
body_html: `
<!DOCTYPE html>
<html>
  <head>
    <style>
      body { font-family: Arial, sans-serif; }
      .container { max-width: 600px; margin: 0 auto; }
      .header { background: #0ea5e9; color: white; padding: 20px; }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <h1>مرحباً {{user_name}}!</h1>
      </div>
      <div class="content">
        <!-- محتوى الرسالة -->
      </div>
    </div>
  </body>
</html>
`
```

### 3. إضافة جدولة الرسائل
```sql
CREATE TABLE scheduled_emails (
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id),
  template_key text,
  scheduled_at timestamptz NOT NULL,
  sent boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
```

---

## ✅ الخلاصة

تم إنشاء نظام متكامل لرسائل الترحيب يشمل:

```
✅ قاعدة بيانات محكمة (2 جداول)
✅ 5 قوالب جاهزة (عربي/إنجليزي)
✅ Edge Function لإرسال الرسائل
✅ تتبع كامل لحالة الرسائل
✅ إشعارات داخل التطبيق
✅ RLS Policies آمنة
✅ Performance Indexes
✅ دعم المتغيرات الديناميكية
✅ سهولة التوسع والإضافة
```

---

**النظام جاهز للاستخدام وقابل للتوسع! 🚀**

يمكن الآن إرسال رسائل ترحيب احترافية لجميع المستخدمين الجدد، وتتبع حالة كل رسالة، وتوسيع النظام لإرسال أي نوع من الرسائل في المستقبل.
