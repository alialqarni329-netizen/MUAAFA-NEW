# إعداد بوابات الدفع - RevenueCat

## نظرة عامة
لإضافة الدفع عبر Apple Pay و Google Pay للاشتراكات، نستخدم **RevenueCat** - أفضل حل لإدارة الاشتراكات في التطبيقات المحمولة.

## لماذا RevenueCat؟
- ✅ يدعم Apple Pay و Google Pay
- ✅ يدير الاشتراكات والفواتير تلقائياً
- ✅ يتتبع الإيرادات والتحليلات
- ✅ يتعامل مع التحقق من الإيصالات
- ✅ يدعم الفترات التجريبية

## متطلبات الإعداد

### 1. إنشاء حساب RevenueCat
1. اذهب إلى [RevenueCat](https://www.revenuecat.com/)
2. سجل حساب جديد
3. أنشئ مشروع جديد

### 2. إعداد المنتجات (Products)
في لوحة تحكم RevenueCat:
1. اذهب إلى Products
2. أنشئ المنتجات التالية:
   - **weekly_subscription** - اشتراك أسبوعي (25 ريال)
   - **monthly_subscription** - اشتراك شهري (89 ريال)
   - **yearly_subscription** - اشتراك سنوي (799 ريال)

### 3. ربط مع App Store Connect (iOS)
1. في App Store Connect، أنشئ التطبيق
2. أنشئ In-App Purchases للاشتراكات
3. احصل على Shared Secret من App Store Connect
4. أضف Shared Secret في RevenueCat

### 4. ربط مع Google Play Console (Android)
1. في Google Play Console، أنشئ التطبيق
2. أنشئ Subscriptions
3. احصل على Service Account Key
4. أضف Service Account Key في RevenueCat

### 5. تثبيت المكتبات

**ملاحظة مهمة:** RevenueCat يتطلب native code ولا يعمل في بيئة الويب الحالية.

لتثبيت RevenueCat، يجب عليك:

1. تصدير المشروع وفتحه محلياً في Cursor أو VS Code:
```bash
npm install react-native-purchases
```

2. إعداد RevenueCat في التطبيق:
```bash
npx expo install expo-dev-client
npx expo prebuild
```

### 6. كود التكامل

أنشئ ملف `lib/revenuecat.ts`:

```typescript
import Purchases, { PurchasesPackage } from 'react-native-purchases';

// مفاتيح RevenueCat
const REVENUECAT_API_KEY_IOS = 'your_ios_api_key';
const REVENUECAT_API_KEY_ANDROID = 'your_android_api_key';

export async function initRevenueCat(userId: string) {
  if (Platform.OS === 'ios') {
    await Purchases.configure({ apiKey: REVENUECAT_API_KEY_IOS, appUserID: userId });
  } else if (Platform.OS === 'android') {
    await Purchases.configure({ apiKey: REVENUECAT_API_KEY_ANDROID, appUserID: userId });
  }
}

export async function getSubscriptionPackages(): Promise<PurchasesPackage[]> {
  try {
    const offerings = await Purchases.getOfferings();
    if (offerings.current !== null) {
      return offerings.current.availablePackages;
    }
    return [];
  } catch (error) {
    console.error('Error getting packages:', error);
    return [];
  }
}

export async function purchasePackage(pkg: PurchasesPackage) {
  try {
    const { customerInfo } = await Purchases.purchasePackage(pkg);
    return customerInfo;
  } catch (error: any) {
    if (error.code === Purchases.PURCHASES_ERROR_CODE.PURCHASE_CANCELLED_ERROR) {
      // المستخدم ألغى عملية الشراء
      return null;
    }
    throw error;
  }
}

export async function restorePurchases() {
  try {
    const customerInfo = await Purchases.restorePurchases();
    return customerInfo;
  } catch (error) {
    console.error('Error restoring purchases:', error);
    throw error;
  }
}

export async function checkSubscriptionStatus() {
  try {
    const customerInfo = await Purchases.getCustomerInfo();
    const isActive = customerInfo.entitlements.active['premium'] !== undefined;
    return {
      isActive,
      expirationDate: customerInfo.entitlements.active['premium']?.expirationDate,
    };
  } catch (error) {
    console.error('Error checking subscription:', error);
    return { isActive: false };
  }
}
```

### 7. تحديث صفحة الاشتراك

```typescript
// في app/subscription.tsx
import { purchasePackage, getSubscriptionPackages } from '@/lib/revenuecat';

const handlePurchase = async (packageId: string) => {
  try {
    const packages = await getSubscriptionPackages();
    const selectedPackage = packages.find(p => p.identifier === packageId);

    if (selectedPackage) {
      const result = await purchasePackage(selectedPackage);
      if (result) {
        Alert.alert('نجح الاشتراك!', 'تم تفعيل اشتراكك بنجاح');
        // تحديث حالة الاشتراك في Supabase
      }
    }
  } catch (error) {
    Alert.alert('خطأ', 'حدث خطأ أثناء عملية الدفع');
  }
};
```

## خطوات الاختبار

### 1. Sandbox Testing (iOS)
- أنشئ Sandbox tester في App Store Connect
- استخدم هذا الحساب للاختبار

### 2. Test Purchases (Android)
- أضف License testers في Google Play Console
- استخدم هذه الحسابات للاختبار

## الأسعار المقترحة
- **تجربة مجانية**: 5 أيام (10 دقائق يومياً)
- **اشتراك أسبوعي**: 25 ريال
- **اشتراك شهري**: 89 ريال
- **اشتراك سنوي**: 799 ريال (وفر 33%)

## Webhooks - مزامنة مع Supabase

أنشئ webhook في RevenueCat لمزامنة حالة الاشتراك مع Supabase:

1. في RevenueCat Dashboard → Integrations → Webhooks
2. أضف URL: `https://your-project.supabase.co/functions/v1/revenuecat-webhook`
3. اختر Events: Purchase, Renewal, Cancellation

## ملاحظات مهمة

⚠️ **RevenueCat لا يعمل على الويب** - يتطلب تصدير المشروع وبناء نسخة native.

⚠️ **رسوم RevenueCat:**
- مجاني حتى $2,500 شهرياً
- 1% من الإيرادات فوق ذلك

⚠️ **رسوم المنصات:**
- Apple: 30% (15% للسنة الثانية وما بعد)
- Google: 15% للاشتراكات

## للمزيد من المعلومات
- [RevenueCat Documentation](https://www.revenuecat.com/docs)
- [Expo Dev Client](https://docs.expo.dev/develop/development-builds/introduction/)
