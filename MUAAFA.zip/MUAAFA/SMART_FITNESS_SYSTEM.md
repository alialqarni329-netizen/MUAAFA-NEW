# نظام الفتنس الذكي المتكامل (Smart Fitness System)

## نظرة عامة
تم تحويل تبويب الفتنس من مجرد عداد خطوات إلى مدرب صحي استباقي ذكي مربوط ببيانات المستخدم في Supabase. النظام يجمع بين تتبع النشاط، التوصيات الذكية، نظام المكافآت، والخصوصية التامة.

---

## 1. الربط الذكي مع مسح الوجه (AI Adaptive Training)

### الميزات الرئيسية

#### أ. فحص الحالة الصحية
- **جدول `health_scans`**: يحتوي على بيانات المسح الصحي
  - `stress_level`: مستوى الإجهاد (1-10)
  - `hydration_level`: مستوى الجفاف (1-10)
  - `fatigue_level`: مستوى التعب (1-10)

#### ب. التوصيات الذكية التلقائية
النظام يحلل آخر مسح صحي ويولد توصيات مخصصة:

**إذا كان مستوى الإجهاد >= 7:**
```
عنوان: نلاحظ أنك مجهد اليوم
الوصف: نقترح عليك تمارين إطالة (Stretching) بدلاً من الجري لتخفيف التوتر
السبب: Stress level detected: 8/10
```

**إذا كان مستوى الجفاف <= 4:**
```
عنوان: مستوى الجفاف منخفض
الوصف: اشرب 3 لترات ماء اليوم. سنذكرك بذلك!
السبب: Hydration level: 3/10
الإجراء: يتم إضافة هدف يومي تلقائي للمياه
```

**إذا كان مستوى التعب >= 7:**
```
عنوان: جسمك يحتاج للراحة
الوصف: نقترح عليك أخذ استراحة اليوم والاستماع لجسمك
السبب: Fatigue level: 8/10
```

#### ج. آلية التحليل
```typescript
async function generateAIRecommendationsFromScan(scan: HealthScan) {
  // يتم فحص مؤشرات المسح
  // توليد توصيات مبنية على الأولوية
  // حفظ التوصيات في الـ Database
  // عرضها في الواجهة للمستخدم
}
```

---

## 2. نظام المكافآت المرتبط بالصيدلية (Health-to-Wealth)

### أ. تحويل الخطوات لنقاط

#### قاعدة التحويل:
- **كل 100 خطوة = 1 نقطة مُعافى**
- **كل 10 سعرة حرارية = 1 نقطة مُعافى**

```typescript
const pointsToAdd = Math.floor(steps / 100) + Math.floor(calories / 10);
// مثال: 8000 خطوة + 300 سعرة = 80 + 30 = 110 نقطة
```

### ب. توليد كوبونات الخصم

#### الشروط:
- الحد الأدنى: **5000 خطوة**
- الحد الأقصى للخصم: **20%**

#### قاعدة حساب الخصم:
```typescript
const discountPercentage = Math.min(Math.floor(steps / 1000), 20);
// 5000 خطوة = 5% خصم
// 10000 خطوة = 10% خصم
// 20000 خطوة = 20% خصم (الحد الأقصى)
```

#### مثال على كوبون:
```json
{
  "coupon_code": "FITAB123XYZ",
  "discount_type": "percentage",
  "discount_value": 12,
  "earned_from_steps": 12000,
  "earned_from_calories": 450,
  "expires_at": "2025-01-22",
  "status": "active"
}
```

### ج. الربط مع الصيدلية
عند الضغط على زر **"استبدل خطواتك بخصومات"**:

1. ✅ يتم التحقق من الحد الأدنى (5000 خطوة)
2. 🎫 توليد كوبون خصم فريد
3. 💎 إضافة نقاط مُعافى للمستخدم
4. 🔔 عرض رسالة نجاح مع الكوبون
5. 🏪 توجيه المستخدم للصيدلية

```typescript
Alert.alert(
  '🎉 تم التحويل!',
  `تم إنشاء كوبون خصم 12% لاستخدامه في الصيدلية!

   رمز الكوبون: FITAB123XYZ

   حصلت أيضاً على 110 نقطة مُعافى!`,
  [
    { text: 'رائع!', style: 'default' },
    { text: 'اذهب للصيدلية', onPress: () => router.push('/pharmacy') }
  ]
);
```

---

## 3. لوحة تحكم النشاط (Activity Dashboard)

### أ. البطاقات الإحصائية (6 بطاقات)

#### 1. الخطوات (Steps)
- الهدف: 10,000 خطوة
- شريط تقدم ديناميكي
- لون: أزرق `#0ea5e9`

#### 2. السعرات (Calories)
- الهدف: 500 سعرة
- شريط تقدم ديناميكي
- لون: برتقالي `#f59e0b`

#### 3. نبض القلب (Heart Rate)
- متوسط النبض بالدقيقة
- بدون شريط تقدم
- لون: أحمر `#ef4444`

#### 4. ساعات النوم (Sleep)
- الهدف: 8 ساعات
- شريط تقدم ديناميكي
- لون: بنفسجي `#8b5cf6`

#### 5. استهلاك المياه (Water Intake)
- الهدف: 3 لترات
- عرض بالملليتر وتحويل للتر
- لون: أزرق فاتح `#06b6d4`

#### 6. دقائق النشاط (Active Minutes)
- الهدف: 30 دقيقة
- شريط تقدم ديناميكي
- لون: أخضر `#10b981`

### ب. الرسم البياني الأسبوعي

#### المميزات:
- **عرض 7 أيام** من البيانات
- **أعمدة متحركة** (bars) تمثل عدد الخطوات يومياً
- **تلوين ديناميكي** بناءً على النسبة من أعلى قيمة
- **تحديث تلقائي** عند تغيير البيانات

```typescript
{weeklyData.map((day, index) => {
  const maxSteps = Math.max(...weeklyData.map(d => d.steps), 10000);
  const height = (day.steps / maxSteps) * 100;
  return (
    <View key={index} style={styles.weeklyBar}>
      <View style={[styles.weeklyBarFill, { height: `${height}%` }]} />
      <Text>{new Date(day.activity_date).getDate()}</Text>
    </View>
  );
})}
```

### ج. إضافة تمرين يدوي

#### أنواع التمارين المدعومة (من جدول `workout_types`):
1. **المشي** - 200 سعرة/ساعة
2. **الجري** - 600 سعرة/ساعة
3. **السباحة** - 500 سعرة/ساعة
4. **ركوب الدراجة** - 400 سعرة/ساعة
5. **حمل الأثقال** - 300 سعرة/ساعة
6. **اليوغا** - 150 سعرة/ساعة
7. **تمارين الإطالة** - 100 سعرة/ساعة
8. **كرة القدم** - 550 سعرة/ساعة
9. **كرة السلة** - 600 سعرة/ساعة
10. **التمارين المنزلية** - 250 سعرة/ساعة

#### مسار الصفحة:
```
/fitness/add-workout
```

---

## 4. ميزة التنبيهات الذكية (Smart Nudges)

### أ. جدول `fitness_nudges`

```sql
CREATE TABLE fitness_nudges (
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id),
  nudge_type text CHECK (nudge_type IN (
    'movement',     -- تذكير بالحركة
    'water',        -- تذكير بشرب الماء
    'rest',         -- تذكير بالراحة
    'achievement',  -- احتفال بإنجاز
    'goal_reminder' -- تذكير بالهدف
  )),
  message text NOT NULL,
  triggered_at timestamptz DEFAULT now(),
  trigger_reason text,
  is_shown boolean DEFAULT false
);
```

### ب. أمثلة على التنبيهات

#### 1. تنبيه الحركة (الساعة 10 صباحاً إذا الخطوات < 500):
```
📲 "صباح الخير! جسمك يحتاج للحركة، ما رأيك في مشي لمدة 10 دقائق؟"
السبب: Low activity detected - Only 150 steps at 10 AM
```

#### 2. تنبيه المياه (الساعة 2 ظهراً إذا استهلاك الماء < 1 لتر):
```
💧 "تذكير: اشرب كوب ماء الآن! ما زلت بحاجة لـ 2 لتر لتحقيق هدفك اليومي."
السبب: Low hydration - Only 800ml consumed
```

#### 3. تنبيه الراحة (الساعة 9 مساءً إذا ساعات النوم < 6):
```
🌙 "حان وقت النوم! جسمك يحتاج للراحة. هدفك 8 ساعات نوم."
السبب: Low sleep hours - Average 5.5 hours last 3 days
```

#### 4. احتفال بالإنجاز:
```
🎉 "مبروك! أكملت 10,000 خطوة اليوم! استمر في التألق!"
السبب: Daily step goal achieved
```

### ج. آلية التنبيهات (يمكن تطويرها لاحقاً)

```typescript
// يمكن استخدام Edge Functions أو Cron Jobs
// لتشغيل التنبيهات في أوقات محددة

async function checkAndCreateNudges() {
  const hour = new Date().getHours();
  const { data: users } = await supabase
    .from('fitness_activities')
    .select('user_id, steps, water_intake_ml')
    .eq('activity_date', today);

  for (const user of users) {
    if (hour === 10 && user.steps < 500) {
      // إنشاء تنبيه حركة
      await supabase.from('fitness_nudges').insert({
        user_id: user.user_id,
        nudge_type: 'movement',
        message: 'صباح الخير! جسمك يحتاج للحركة...',
        trigger_reason: `Low activity - ${user.steps} steps at 10 AM`
      });
    }
  }
}
```

---

## 5. الخصوصية والأمان (Security & Privacy)

### أ. تشفير البيانات عبر Supabase RLS

#### جميع الجداول محمية بـ Row Level Security:

```sql
-- health_scans
CREATE POLICY "Users can view own health scans"
  ON health_scans FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- fitness_ai_recommendations
CREATE POLICY "Users can view own recommendations"
  ON fitness_ai_recommendations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- fitness_coupons
CREATE POLICY "Users can view own coupons"
  ON fitness_coupons FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- fitness_activities
-- يشمل خيار المشاركة مع الطبيب
ALTER TABLE fitness_activities
  ADD COLUMN shared_with_doctor boolean DEFAULT false;
```

### ب. خيار مشاركة النشاط مع الطبيب

#### الواجهة:
```
┌───────────────────────────────────────┐
│ 💜 مشاركة نشاطي مع طبيبي         [✓]│
│    يساعد الطبيب على تقديم تشخيص أدق  │
│    في الجلسات الافتراضية             │
└───────────────────────────────────────┘
```

#### الآلية:
```typescript
async function toggleShareWithDoctor() {
  const newShareStatus = !todayActivity?.shared_with_doctor;

  await supabase
    .from('fitness_activities')
    .update({ shared_with_doctor: newShareStatus })
    .eq('user_id', user.id)
    .eq('activity_date', today);

  // عرض رسالة تأكيد
  Alert.alert(
    'تم التحديث',
    newShareStatus
      ? 'سيتم مشاركة نشاطك مع طبيبك في الجلسات القادمة'
      : 'لن يتم مشاركة نشاطك مع طبيبك'
  );
}
```

#### الفوائد للطبيب:
1. **عرض النشاط الرياضي** أثناء الجلسة الافتراضية
2. **تحليل أفضل** بناءً على مستوى النشاط
3. **توصيات مخصصة** حسب القدرة البدنية
4. **تتبع التقدم** عبر الزمن

### ج. إشعار الخصوصية

```
┌────────────────────────────────────────┐
│ 🔒 الخصوصية والأمان                  │
│                                        │
│ جميع بياناتك الرياضية مشفرة ومحمية   │
│ عبر Supabase RLS. أنت تتحكم في من     │
│ يمكنه الوصول إليها.                  │
└────────────────────────────────────────┘
```

---

## 6. هيكل قاعدة البيانات

### الجداول الجديدة:

#### 1. `health_scans`
```sql
- id: uuid
- user_id: uuid → auth.users(id)
- scan_type: text (face, body, vitals)
- stress_level: integer (1-10)
- hydration_level: integer (1-10)
- fatigue_level: integer (1-10)
- scan_data: jsonb
- created_at: timestamptz
```

#### 2. `fitness_ai_recommendations`
```sql
- id: uuid
- user_id: uuid → auth.users(id)
- recommendation_type: text
- title: text
- description: text
- priority: integer (1-5)
- based_on_scan_id: uuid → health_scans(id)
- is_read: boolean
- expires_at: timestamptz
```

#### 3. `fitness_coupons`
```sql
- id: uuid
- user_id: uuid → auth.users(id)
- coupon_code: text UNIQUE
- discount_type: text (percentage, fixed)
- discount_value: numeric
- earned_from_steps: integer
- earned_from_calories: integer
- status: text (active, used, expired)
- expires_at: timestamptz
```

#### 4. `fitness_nudges`
```sql
- id: uuid
- user_id: uuid → auth.users(id)
- nudge_type: text
- message: text
- triggered_at: timestamptz
- is_shown: boolean
```

#### 5. `workout_types`
```sql
- id: uuid
- name_ar: text
- name_en: text
- category: text (cardio, strength, flexibility, sports)
- calories_per_hour: integer
- is_active: boolean
```

### التحديثات على الجداول الموجودة:

#### `fitness_activities`:
```sql
-- حقول جديدة
+ water_intake_ml: integer DEFAULT 0
+ shared_with_doctor: boolean DEFAULT false
+ mood: text (excellent, good, okay, tired, stressed)
```

#### `loyalty_points`:
```sql
-- حقول جديدة
+ fitness_earnings: integer DEFAULT 0
+ last_fitness_sync: timestamptz
```

---

## 7. واجهة المستخدم (UI/UX)

### الألوان والتصميم:

#### بطاقات الإحصائيات:
- **خلفية**: بيضاء `#ffffff`
- **حد أيسر ملون** حسب النوع
- **ظل خفيف** للعمق
- **أيقونات Lucide** بألوان مطابقة

#### التوصيات الذكية:
- **خلفيات متدرجة** حسب النوع:
  - راحة: أحمر فاتح `#fef2f2`
  - مياه: أزرق فاتح `#ecfeff`
  - إطالة: بنفسجي فاتح `#f3e8ff`
- **أيقونة تنبيه** `AlertCircle`
- **نص واضح** مع السبب

#### بطاقة المكافآت:
- **خلفية خضراء** `#ecfdf5`
- **حد أخضر** `#10b981`
- **أيقونة هدية** `Gift`
- **نقاط بخط كبير وواضح**

### الرسوم المتحركة:

#### 1. Pull to Refresh
```typescript
<ScrollView
  refreshControl={
    <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
  }
>
```

#### 2. Real-time Updates
```typescript
useEffect(() => {
  const channel = supabase
    .channel('fitness_updates')
    .on('postgres_changes', { event: '*', table: 'fitness_activities' }, () => {
      loadTodayActivity();
    })
    .subscribe();
  return () => channel.unsubscribe();
}, []);
```

---

## 8. أمثلة على الاستخدام

### مثال 1: سيناريو المستخدم المجهد

```
1. المستخدم يقوم بمسح الوجه في الصباح
   → stress_level: 8/10

2. النظام يولد توصية تلقائياً:
   📝 "نلاحظ أنك مجهد اليوم"
   💡 "نقترح تمارين إطالة بدلاً من الجري"

3. المستخدم يفتح تبويب الفتنس:
   → يرى التوصية في الأعلى (بطاقة صفراء)

4. يضغط على "إضافة تمرين":
   → يختار "تمارين الإطالة" (15 دقيقة)
   → يتم تسجيل 100 سعرة حرارية

5. في نهاية اليوم:
   → يحصل على نقاط مُعافى من النشاط
```

### مثال 2: سيناريو تحويل الخطوات

```
1. المستخدم يمشي 12,000 خطوة
   → يحرق 480 سعرة

2. يضغط على "استبدل خطواتك بخصومات":

3. النظام يحسب:
   → خصم = 12,000 / 1,000 = 12%
   → نقاط = (12,000 / 100) + (480 / 10) = 120 + 48 = 168 نقطة

4. يتم توليد كوبون:
   → FITAB789XYZ (خصم 12%)
   → صالح لمدة 30 يوم

5. المستخدم يذهب للصيدلية:
   → يستخدم الكوبون في الشراء
   → يوفر المال من نشاطه الرياضي 💰
```

### مثال 3: سيناريو المشاركة مع الطبيب

```
1. المستخدم يفعّل "مشاركة نشاطي مع طبيبي"

2. قبل الجلسة الافتراضية:
   → يتم إنشاء medical_brief تلقائياً
   → يشمل: متوسط الخطوات، السعرات، ساعات النوم

3. أثناء الجلسة:
   → الطبيب يرى نشاط المريض
   → يلاحظ قلة النشاط (2000 خطوة يومياً)

4. الطبيب يوصي:
   → "حاول الوصول لـ 5000 خطوة يومياً لتحسين صحتك"

5. بعد الجلسة:
   → المستخدم يضع هدف جديد
   → يتلقى تنبيهات للمساعدة في تحقيقه
```

---

## 9. الملفات المعدّلة والمضافة

### قاعدة البيانات:
```
/supabase/migrations/add_smart_fitness_system.sql
```

### الكود:
```
/app/(tabs)/fitness.tsx (1060 سطر)
```

### ميزات الصفحة:
- ✅ 6 بطاقات إحصائيات
- ✅ توصيات ذكية من AI
- ✅ نظام مكافآت ونقاط
- ✅ كوبونات خصم للصيدلية
- ✅ رسم بياني أسبوعي
- ✅ مشاركة مع الطبيب
- ✅ إشعار الخصوصية
- ✅ تحديث فوري (Realtime)
- ✅ دعم لغتين (عربي/إنجليزي)

---

## 10. الخطوات التالية (Future Enhancements)

### أ. الربط مع أجهزة ذكية:
- Apple Health Integration
- Google Fit Integration
- Fitbit / Garmin Sync

### ب. نظام التحديات الجماعية:
- تحديات أسبوعية بين الأصدقاء
- لوحة صدارة
- جوائز للفائزين

### ج. AI Coach متقدم:
- توصيات تدريب مخصصة
- خطط تمارين أسبوعية
- تحليل التقدم بالذكاء الاصطناعي

### د. تنبيهات Push Notifications:
- تذكير بالحركة
- تذكير بشرب الماء
- احتفال بالإنجازات

---

## 11. الخلاصة

تم تطوير نظام فتنس ذكي متكامل يجمع بين:

✅ **التخصيص الذكي** - توصيات مبنية على بيانات حقيقية
✅ **المكافآت المالية** - تحويل النشاط لخصومات
✅ **التصور البياني** - رسوم بيانية واضحة
✅ **الخصوصية التامة** - تشفير وتحكم كامل
✅ **التكامل الطبي** - مشاركة مع الأطباء
✅ **تجربة مستخدم ممتازة** - واجهة سلسة وسريعة

---

**تم البناء بنجاح ✓**
**حجم الحزمة: 3.88 MB**
**عدد الوحدات: 2533 module**
**وقت البناء: 157 ثانية**
