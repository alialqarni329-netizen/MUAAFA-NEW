# 🚀 Quick Test Guide - Authentication System

## Start the Application (Choose One Method)

### Option 1: Web Browser (Fastest)
```bash
npm run dev
```
Then press `w` to open in your web browser

### Option 2: Mobile Device
```bash
npm run dev
```
Then scan the QR code with Expo Go app

---

## 🧪 Test 1: Register a New User

1. **Navigate to:** `/auth/register`

2. **Fill in the form:**
   ```
   Full Name: Ahmed Mohammed
   Email: ahmed.test@gmail.com
   Phone: 0501234567
   National ID: 1234567890
   Date of Birth: [Choose any date]
   Gender: Male
   City: الرياض
   Password: Test123456
   Confirm Password: Test123456
   ```

3. **Expected Result:**
   - ✅ Account created successfully
   - ✅ Automatically logged in
   - ✅ Redirected to questionnaire
   - ✅ Free Basic subscription assigned

---

## 🧪 Test 2: Login with Existing User

1. **Navigate to:** `/auth/login`

2. **Enter credentials:**
   ```
   Email: ahmed.test@gmail.com
   Password: Test123456
   ```

3. **Check "Remember Me"** (optional)

4. **Click:** "تسجيل الدخول"

5. **Expected Result:**
   - ✅ Logged in successfully
   - ✅ Redirected to main dashboard `/(tabs)`
   - ✅ Cart data synced (if any)
   - ✅ Session persisted

---

## 🧪 Test 3: Password Reset

1. **Navigate to:** `/auth/forgot-password`

2. **Enter your email:**
   ```
   Email: ahmed.test@gmail.com
   ```

3. **Click:** Send reset link

4. **Expected Result:**
   - ✅ Reset email sent
   - ✅ Check your email inbox
   - ✅ Click link to reset password

---

## 🧪 Test 4: Business Login

1. **Navigate to:** `/business/login`

2. **This is for business accounts** (pharmacies, hospitals, insurance companies)

3. **Requires separate business registration**

---

## 🧪 Test 5: Role-Based Routing

Test that different user types go to different dashboards:

### Individual User
- Login → Routes to `/(tabs)` (Main App)

### Business User
- Login → Routes to `/business/dashboard`

### Owner/Admin
- Login → Routes to `/owner` (Admin Panel)

---

## 🔍 Verify Database Entries

After registering a user, verify in Supabase:

1. Go to Supabase Dashboard
2. Navigate to: **Table Editor** → **users**
3. You should see your new user entry with:
   - ✅ ID (UUID)
   - ✅ Email
   - ✅ Full Name
   - ✅ Phone
   - ✅ National ID
   - ✅ Date of Birth
   - ✅ Gender
   - ✅ Location

4. Navigate to: **Table Editor** → **user_subscriptions**
5. You should see an automatic subscription entry:
   - ✅ User ID
   - ✅ Plan: "Basic" (Free)
   - ✅ Status: "active"

---

## ✅ What to Check

### Registration
- [ ] Form validates all fields
- [ ] Email format is checked
- [ ] Phone number format is validated (Saudi)
- [ ] National ID is validated (10 digits)
- [ ] Password strength is enforced
- [ ] Duplicate detection works (try registering same email twice)
- [ ] User is created in database
- [ ] User is automatically logged in
- [ ] Basic subscription is assigned

### Login
- [ ] Email and password are validated
- [ ] Wrong credentials show error message
- [ ] Correct credentials log user in
- [ ] Remember me saves email
- [ ] User is routed to correct dashboard based on role
- [ ] Cart data is synced after login
- [ ] Session persists across page refreshes

### Security
- [ ] Passwords are hashed (never stored as plain text)
- [ ] RLS policies prevent unauthorized access
- [ ] Sessions expire after inactivity
- [ ] HTTPS is enforced

---

## 🐛 Troubleshooting

### "Missing Supabase environment variables"
**Solution:** Make sure `.env` file exists with correct values
```bash
cat .env
```

### "Connection refused"
**Solution:** Check your internet connection and Supabase status

### "Invalid email format"
**Solution:** Use real email format (e.g., user@gmail.com)

### "Phone number invalid"
**Solution:** Use Saudi format: 05XXXXXXXX (10 digits starting with 05)

### "National ID invalid"
**Solution:** Use 10 digits starting with 1 (Saudi) or 2 (Resident)

---

## 📊 Monitor Database Activity

### Real-time Monitoring
1. Open Supabase Dashboard
2. Go to: **Database** → **Logs**
3. Watch authentication events in real-time

### SQL Queries
Run this in Supabase SQL Editor to see recent users:
```sql
SELECT
  id,
  full_name,
  email,
  phone,
  created_at,
  user_role
FROM users
ORDER BY created_at DESC
LIMIT 10;
```

---

## 🎯 Success Criteria

Your authentication is working perfectly if:

✅ You can register a new user
✅ You receive a success message
✅ You are automatically logged in
✅ You can log out and log back in
✅ Remember me saves your email
✅ You can reset your password
✅ User data appears in Supabase
✅ Sessions persist across refreshes
✅ Cart data syncs after login
✅ Role-based routing works

---

## 📞 Quick Commands

```bash
# Start dev server
npm run dev

# Test database connection
node verify-connection.js

# Test authentication
node test-auth.js

# Check types
npm run typecheck

# Build for web
npm run build:web
```

---

**Ready to test?** Run `npm run dev` and start testing! 🚀
