# كيفية تشغيل التطبيق

## 🚀 التشغيل السريع

### 1. افتح Terminal في مجلد المشروع
```bash
cd /tmp/cc-agent/60337043/project
```

### 2. شغّل التطبيق
```bash
npm run dev
```

### 3. افتح المتصفح
```
http://localhost:8081
```

---

## 📱 الوصول للتطبيق

### على الكمبيوتر (Web):
```
✅ http://localhost:8081
```

### على الهاتف (Expo Go):
1. حمّل تطبيق Expo Go من:
   - iOS: App Store
   - Android: Play Store

2. امسح QR Code الذي يظهر في Terminal

---

## 🌐 نشر التطبيق على الإنترنت

### الطريقة 1: Vercel (مجاني)
```bash
# بناء المشروع
npm run build:web

# تنصيب Vercel
npm install -g vercel

# نشر
cd dist
vercel
```

### الطريقة 2: Netlify (مجاني)
```bash
# بناء المشروع
npm run build:web

# تنصيب Netlify
npm install -g netlify-cli

# نشر
netlify deploy --prod --dir=dist
```

### الطريقة 3: Firebase Hosting (مجاني)
```bash
# بناء المشروع
npm run build:web

# تنصيب Firebase
npm install -g firebase-tools

# تسجيل الدخول
firebase login

# إعداد
firebase init hosting

# نشر
firebase deploy
```

---

## 📊 المسارات المتاحة

بعد التشغيل، يمكنك الوصول إلى:

```
✅ / - الصفحة الرئيسية
✅ /auth/login - تسجيل الدخول
✅ /auth/register - إنشاء حساب
✅ /business/login - دخول المنشآت
✅ /business/register - تسجيل منشأة
✅ /business/dashboard - لوحة تحكم المنشأة
✅ /cart - السلة
✅ /checkout - الدفع
✅ /pharmacy/search - بحث العلاجات
✅ /test-routes - اختبار جميع المسارات
```

---

## 🔧 حل المشاكل

### المشكلة: Port 8081 مستخدم
```bash
# استخدم port آخر
npx expo start --port 8082
```

### المشكلة: Module not found
```bash
# إعادة تنصيب
rm -rf node_modules
npm install
```

### المشكلة: Cache
```bash
# مسح الـ cache
npx expo start --clear
```

---

## 📝 ملاحظات

- **Database:** متصل بـ Supabase تلقائياً
- **التطبيق:** يدعم Web + iOS + Android
- **اللغة:** واجهة عربية
- **الحالة:** ✅ جاهز للاستخدام

---

## 🎯 الخطوات التالية

1. شغّل التطبيق: `npm run dev`
2. افتح المتصفح: `http://localhost:8081`
3. جرب صفحة الاختبار: `/test-routes`
4. سجل دخول أو أنشئ حساب
5. استمتع! 🎉

---

**للدعم:** راجع الملفات:
- `NAVIGATION_FIX.md` - تفاصيل المسارات
- `ROUTES_TEST.md` - دليل الاختبار
- `QA_COMPREHENSIVE_REPORT.md` - التقرير الشامل
