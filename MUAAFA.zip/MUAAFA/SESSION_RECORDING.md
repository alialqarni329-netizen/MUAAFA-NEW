# نظام تسجيل الجلسات - MOODi Health

## نظرة عامة
تم تطبيق نظام شامل لتسجيل جميع الجلسات الطبية (فيديو، صوت، محادثة نصية) للحفاظ على الحقوق القانونية وضمان الجودة.

## الميزات الرئيسية

### 1. أنواع التسجيل
- **مكالمات الفيديو**: تسجيل كامل للصوت والفيديو
- **المكالمات الصوتية**: تسجيل الصوت فقط
- **المحادثات النصية**: حفظ جميع الرسائل تلقائياً

### 2. الموافقة على التسجيل
- يتم إعلام المستخدمين بأن الجلسة سيتم تسجيلها
- الموافقة إلزامية قبل بدء الجلسة
- رسالة تحذير واضحة في بداية كل جلسة

### 3. الأمان والخصوصية
- ✅ تشفير التسجيلات
- ✅ تخزين آمن في Supabase Storage
- ✅ صلاحيات RLS مفعلة
- ✅ الوصول فقط للمستخدم المالك
- ✅ إمكانية حذف التسجيلات

## البنية التقنية

### قاعدة البيانات

#### جدول `session_recordings`
```sql
- id: uuid (معرف فريد)
- session_id: uuid (ربط مع الجلسة)
- recording_url: text (رابط التسجيل)
- recording_type: enum (video, audio, chat)
- duration_seconds: integer (المدة)
- file_size: bigint (حجم الملف)
- storage_path: text (المسار في التخزين)
- status: enum (processing, completed, failed)
- started_at: timestamptz (وقت البدء)
- completed_at: timestamptz (وقت الانتهاء)
```

#### تحديثات جدول `sessions`
```sql
- has_recording: boolean (هل يوجد تسجيل)
- recording_consent: boolean (الموافقة على التسجيل)
```

## التكامل التقني

### 1. للمحادثات النصية
المحادثات النصية يتم حفظها تلقائياً في جدول `chat_messages` ولا تحتاج معالجة خاصة.

### 2. للمكالمات الصوتية والفيديو

#### استخدام WebRTC للتسجيل

```typescript
// مثال لتسجيل مكالمة فيديو
import { MediaRecorder } from 'react-native-webrtc';

async function startRecording(sessionId: string) {
  try {
    // طلب الموافقة
    const consent = await getUserConsent();
    if (!consent) return;

    // بدء التسجيل
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    });

    const recorder = new MediaRecorder(stream);
    const chunks: Blob[] = [];

    recorder.ondataavailable = (event) => {
      chunks.push(event.data);
    };

    recorder.onstop = async () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      await uploadRecording(sessionId, blob);
    };

    recorder.start();

    // حفظ معلومات البدء في قاعدة البيانات
    await supabase.from('session_recordings').insert({
      session_id: sessionId,
      recording_type: 'video',
      status: 'processing',
      started_at: new Date().toISOString(),
    });

    return recorder;
  } catch (error) {
    console.error('Recording error:', error);
  }
}

async function stopRecording(recorder: MediaRecorder, recordingId: string) {
  recorder.stop();

  // تحديث حالة التسجيل
  await supabase
    .from('session_recordings')
    .update({
      status: 'completed',
      completed_at: new Date().toISOString(),
    })
    .eq('id', recordingId);
}
```

### 3. رفع التسجيلات لـ Supabase Storage

```typescript
async function uploadRecording(sessionId: string, blob: Blob) {
  try {
    const fileName = `${sessionId}-${Date.now()}.webm`;
    const filePath = `recordings/${fileName}`;

    // رفع الملف
    const { data, error } = await supabase.storage
      .from('session-recordings')
      .upload(filePath, blob, {
        contentType: 'video/webm',
        cacheControl: '3600',
      });

    if (error) throw error;

    // الحصول على الرابط العام
    const { data: urlData } = supabase.storage
      .from('session-recordings')
      .getPublicUrl(filePath);

    // تحديث قاعدة البيانات
    await supabase
      .from('session_recordings')
      .update({
        recording_url: urlData.publicUrl,
        storage_path: filePath,
        file_size: blob.size,
        status: 'completed',
        completed_at: new Date().toISOString(),
      })
      .eq('session_id', sessionId);

    // تحديث جدول الجلسات
    await supabase
      .from('sessions')
      .update({ has_recording: true })
      .eq('id', sessionId);

    return urlData.publicUrl;
  } catch (error) {
    console.error('Upload error:', error);

    // تحديث الحالة للفشل
    await supabase
      .from('session_recordings')
      .update({ status: 'failed' })
      .eq('session_id', sessionId);
  }
}
```

## إعداد Supabase Storage

### 1. إنشاء Bucket للتسجيلات

في لوحة تحكم Supabase:

1. اذهب إلى Storage
2. أنشئ bucket جديد باسم `session-recordings`
3. اختر "Private" للخصوصية
4. فعّل "Restrict file upload size" → 500 MB

### 2. إعداد السياسات الأمنية

```sql
-- سياسة: المستخدمون يمكنهم رفع تسجيلاتهم
CREATE POLICY "Users can upload their recordings"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'session-recordings' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- سياسة: المستخدمون يمكنهم تنزيل تسجيلاتهم
CREATE POLICY "Users can download their recordings"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'session-recordings' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- سياسة: المستخدمون يمكنهم حذف تسجيلاتهم
CREATE POLICY "Users can delete their recordings"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'session-recordings' AND
  auth.uid()::text = (storage.foldername(name))[1]
);
```

## واجهة المستخدم

### 1. إشعار الموافقة

```typescript
async function showRecordingConsent() {
  return Alert.alert(
    'تسجيل الجلسة',
    'سيتم تسجيل هذه الجلسة للحفاظ على حقوق الطرفين وضمان الجودة. هل توافق؟',
    [
      {
        text: 'لا أوافق',
        style: 'cancel',
        onPress: () => false,
      },
      {
        text: 'أوافق',
        onPress: () => true,
      },
    ]
  );
}
```

### 2. عرض التسجيلات

```typescript
async function getSessionRecordings(sessionId: string) {
  const { data, error } = await supabase
    .from('session_recordings')
    .select('*')
    .eq('session_id', sessionId)
    .eq('status', 'completed');

  return data;
}
```

## الامتثال القانوني

### 1. الإشعار
- ✅ إشعار واضح قبل بدء التسجيل
- ✅ الحصول على الموافقة الصريحة
- ✅ إمكانية رفض التسجيل

### 2. الحفظ
- ✅ تخزين آمن ومشفر
- ✅ وصول محدود للمالكين فقط
- ✅ سجل تاريخي للوصول

### 3. الحذف
- ✅ إمكانية حذف التسجيلات
- ✅ حذف دائم بدون استرجاع
- ✅ إشعار المستخدم بالحذف

## المكتبات المطلوبة

### للويب
```bash
npm install recordrtc webrtc-adapter
```

### للموبايل (React Native)
```bash
npm install react-native-webrtc
npx expo install expo-av
```

## أفضل الممارسات

1. **التشفير**: استخدم HTTPS لجميع عمليات النقل
2. **الضغط**: ضغط الملفات قبل الرفع
3. **الجودة**: استخدم إعدادات جودة متوازنة
4. **التخزين**: احذف التسجيلات القديمة تلقائياً بعد فترة
5. **النسخ الاحتياطي**: احتفظ بنسخ احتياطية للتسجيلات المهمة

## المراقبة والتحليلات

```typescript
// تتبع إحصائيات التسجيل
async function getRecordingStats() {
  const { data, error } = await supabase
    .from('session_recordings')
    .select('recording_type, status, duration_seconds')
    .then(data => {
      return {
        totalRecordings: data.length,
        totalDuration: data.reduce((sum, r) => sum + r.duration_seconds, 0),
        byType: {
          video: data.filter(r => r.recording_type === 'video').length,
          audio: data.filter(r => r.recording_type === 'audio').length,
          chat: data.filter(r => r.recording_type === 'chat').length,
        },
        byStatus: {
          completed: data.filter(r => r.status === 'completed').length,
          processing: data.filter(r => r.status === 'processing').length,
          failed: data.filter(r => r.status === 'failed').length,
        }
      };
    });
}
```

## ملاحظات مهمة

⚠️ **تسجيل الفيديو والصوت يتطلب:**
- صلاحيات الكاميرا والميكروفون
- اتصال إنترنت مستقر
- مساحة تخزين كافية

⚠️ **الاعتبارات القانونية:**
- تأكد من الامتثال لقوانين الخصوصية المحلية
- احصل على موافقة صريحة من جميع الأطراف
- احتفظ بالتسجيلات للمدة القانونية المطلوبة فقط

⚠️ **التكلفة:**
- تسجيلات الفيديو تستهلك مساحة تخزين كبيرة
- احسب التكاليف بناءً على حجم التخزين المتوقع
- استخدم ضغط الفيديو لتقليل الحجم

## الدعم الفني

للمزيد من المعلومات:
- [Supabase Storage Documentation](https://supabase.com/docs/guides/storage)
- [WebRTC API](https://developer.mozilla.org/en-US/docs/Web/API/WebRTC_API)
- [React Native WebRTC](https://github.com/react-native-webrtc/react-native-webrtc)
