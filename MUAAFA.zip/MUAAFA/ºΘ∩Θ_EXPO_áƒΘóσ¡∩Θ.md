# 🚀 دليل النشر من داخل Expo Dashboard

## 📱 مشروعك جاهز ومهيأ بالفعل!

**معرف المشروع:** `d117af0f-3a43-49fd-a80f-330a31f44178`
**اسم الحساب:** `muaafa-health`

---

## 🎯 الخطوات المفصلة من داخل Expo

### ═══════════════════════════════════════
### الخطوة 1️⃣: الدخول لموقع Expo
### ═══════════════════════════════════════

1. **افتح المتصفح واذهب إلى:**
   ```
   https://expo.dev
   ```

2. **اضغط على "Sign In" في أعلى اليمين**

3. **سجل الدخول باستخدام:**
   - بريدك الإلكتروني
   - أو حساب GitHub
   - أو حساب Google

4. **إذا لم يكن لديك حساب:**
   - اضغط "Sign Up"
   - اختر طريقة التسجيل (Email أو GitHub أو Google)
   - أكمل التسجيل

---

### ═══════════════════════════════════════
### الخطوة 2️⃣: الوصول لمشروعك
### ═══════════════════════════════════════

**بعد تسجيل الدخول، ستصل إلى Dashboard الرئيسي:**

**الطريقة 1 - البحث عن المشروع:**
```
1. في الصفحة الرئيسية، ابحث عن "Projects"
2. اضغط على "muaafa-health" (إذا ظهر)
```

**الطريقة 2 - الرابط المباشر:**
```
https://expo.dev/accounts/muaafa-health/projects/muaafa-health
```

**إذا لم يظهر المشروع:**
```
معناه المشروع لم يُربط بعد - تابع الخطوة 3
```

---

### ═══════════════════════════════════════
### الخطوة 3️⃣: ربط المشروع (إذا لزم الأمر)
### ═══════════════════════════════════════

**إذا لم يظهر المشروع، اتبع هذه الخطوات من Terminal:**

```bash
# 1. تسجيل الدخول من Terminal
npx eas-cli login
# أدخل نفس البريد وكلمة المرور

# 2. التحقق من تسجيل الدخول
npx eas-cli whoami
# يجب أن يظهر اسم حسابك

# 3. ربط المشروع (إذا لم يكن مربوطاً)
npx eas-cli init
# سيسألك: اضغط Enter للموافقة
```

**الآن ارجع لـ Expo Dashboard وسترى المشروع!**

---

### ═══════════════════════════════════════
### الخطوة 4️⃣: بناء التطبيق (Build)
### ═══════════════════════════════════════

**من داخل صفحة المشروع في Expo Dashboard:**

#### أ) إنشاء Build جديد:

```
1. في صفحة المشروع، اضغط على تبويب "Builds"
   (في القائمة الجانبية اليسرى)

2. اضغط على زر "Create a build" أو "New Build"

3. ستظهر لك 3 خيارات:
   ┌─────────────────────────────────────┐
   │ Platform:                           │
   │ ○ Android                           │
   │ ○ iOS                               │
   │ ○ All                               │
   └─────────────────────────────────────┘

   اختر: Android ✅

4. ستظهر لك Build Profiles:
   ┌─────────────────────────────────────┐
   │ Profile:                            │
   │ ○ development (للتطوير)            │
   │ ● preview (للتجربة) ← اختر هذا     │
   │ ○ production (للنشر الرسمي)        │
   └─────────────────────────────────────┘

   اختر: preview ✅ (للتجربة أولاً)

5. اضغط "Build" أو "Start Build"
```

#### ب) ماذا سيحدث:

```
⏳ سيبدأ البناء تلقائياً في السحابة
⏱️ سيأخذ 15-20 دقيقة تقريباً
📊 يمكنك متابعة التقدم من نفس الصفحة

ستشاهد:
- عداد الوقت
- حالة البناء (queued → in progress → finished)
- Logs مباشرة
```

#### ج) عند انتهاء البناء:

```
✅ ستظهر رسالة "Build finished successfully"

ستجد:
📥 زر "Download" - لتحميل APK
🔗 رابط مباشر للـ APK
📱 QR Code - يمكن مسحه بالهاتف مباشرة
```

---

### ═══════════════════════════════════════
### الخطوة 5️⃣: تحميل وتثبيت APK
### ═══════════════════════════════════════

#### الطريقة 1 - من الكمبيوتر:

```
1. اضغط "Download" من صفحة Build
2. سيتم تحميل ملف .apk
3. انقل الملف لهاتفك عبر:
   - USB Cable
   - Google Drive
   - WhatsApp
   - Telegram
4. افتح الملف على الهاتف
5. اسمح بـ "تثبيت من مصادر غير معروفة"
6. اضغط "Install"
```

#### الطريقة 2 - مباشرة على الهاتف:

```
1. من Expo Dashboard، اضغط على Build
2. انسخ الرابط المباشر للـ APK
3. افتح الرابط على هاتف أندرويد
4. اضغط "Download"
5. اضغط "Install"
```

#### الطريقة 3 - QR Code:

```
1. في صفحة Build، ستجد QR Code
2. افتح كاميرا الهاتف
3. وجه الكاميرا على QR Code
4. اضغط على الرابط الذي يظهر
5. حمل وثبت
```

---

### ═══════════════════════════════════════
### الخطوة 6️⃣: إضافة Environment Variables
### ═══════════════════════════════════════

**مهم جداً! يجب إضافة المتغيرات قبل البناء:**

#### من Expo Dashboard:

```
1. في صفحة المشروع، اذهب لـ "Secrets"
   (في القائمة الجانبية)

2. اضغط "Create a secret"

3. أضف كل متغير على حدة:

   Name: EXPO_PUBLIC_SUPABASE_URL
   Value: https://xxxxx.supabase.co
   ↓ اضغط "Save"

   Name: EXPO_PUBLIC_SUPABASE_ANON_KEY
   Value: eyJxxx...
   ↓ اضغط "Save"
```

#### أو من Terminal (أسهل):

```bash
# أضف كل متغير:
npx eas-cli secret:create --name EXPO_PUBLIC_SUPABASE_URL --value "https://xxxxx.supabase.co"
npx eas-cli secret:create --name EXPO_PUBLIC_SUPABASE_ANON_KEY --value "eyJxxx..."

# للميزات المتقدمة (اختياري):
npx eas-cli secret:create --name OPENAI_API_KEY --value "sk-xxx"
npx eas-cli secret:create --name ZOOM_ACCOUNT_ID --value "xxx"
npx eas-cli secret:create --name ZOOM_CLIENT_ID --value "xxx"
npx eas-cli secret:create --name ZOOM_CLIENT_SECRET --value "xxx"

# للتحقق من جميع Secrets:
npx eas-cli secret:list
```

**⚠️ مهم:** أضف Secrets قبل إنشاء Build جديد!

---

### ═══════════════════════════════════════
### الخطوة 7️⃣: مشاركة التطبيق مع الآخرين
### ═══════════════════════════════════════

#### من Expo Dashboard:

```
1. اذهب لصفحة Build
2. انسخ رابط الـ APK
3. شارك الرابط عبر:
   ✅ WhatsApp
   ✅ Telegram
   ✅ Email
   ✅ أي وسيلة أخرى
```

#### نصيحة:

```
رابط APK يبقى نشطاً لمدة 30 يوم
بعدها يمكنك إنشاء Build جديد
```

---

### ═══════════════════════════════════════
### الخطوة 8️⃣: النشر على Play Store (اختياري)
### ═══════════════════════════════════════

**بعد التجربة والتأكد، يمكنك النشر رسمياً:**

#### من Expo Dashboard:

```
1. أنشئ Build Production:
   - Platform: Android
   - Profile: production ✅

2. بعد انتهاء البناء، اضغط "Submit to store"

3. اختر:
   ┌─────────────────────────────────────┐
   │ Store:                              │
   │ ● Google Play Store                 │
   └─────────────────────────────────────┘

4. املأ المعلومات المطلوبة:
   - App Name
   - Package Name (جاهز: com.muaafa.health)
   - Version Code

5. اضغط "Submit"
```

#### المتطلبات:

```
✅ حساب Google Play Developer ($25)
✅ Service Account JSON (من Google Cloud)
✅ App Information كاملة
✅ Screenshots
✅ Privacy Policy
```

**راجع DEPLOYMENT_GUIDE_AR.md للتفاصيل الكاملة**

---

### ═══════════════════════════════════════
### الخطوة 9️⃣: متابعة حالة البناء
### ═══════════════════════════════════════

#### من Expo Dashboard:

```
صفحة Builds تعرض لك:

┌─────────────────────────────────────────────┐
│ Build #1234                                 │
│ ━━━━━━━━━━━━━━━━━━━━━ 75%                  │
│                                             │
│ Status: In progress                         │
│ Platform: Android                           │
│ Profile: preview                            │
│ Started: 2 minutes ago                      │
│ ETA: 13 minutes                             │
│                                             │
│ [View logs] [Cancel]                        │
└─────────────────────────────────────────────┘
```

**إذا فشل البناء:**
```
1. اضغط "View logs"
2. اقرأ الخطأ
3. عادة يكون السبب:
   - Environment Variables ناقصة
   - مشكلة في الأيقونات
   - خطأ في الكود
```

---

### ═══════════════════════════════════════
### الخطوة 🔟: إنشاء Updates سريعة (بدون Build)
### ═══════════════════════════════════════

**للتحديثات الصغيرة بدون إعادة البناء:**

#### من Terminal:

```bash
# 1. عمل تعديلات على الكود
# 2. نشر Update مباشرة:
npx eas-cli update --branch preview --message "تحديث واجهة المستخدم"

# الآن كل من لديه التطبيق سيحصل على التحديث تلقائياً!
```

#### من Expo Dashboard:

```
1. اذهب لـ "Updates" (في القائمة الجانبية)
2. اضغط "Create update"
3. اختر Branch: preview
4. أضف رسالة التحديث
5. اضغط "Publish"
```

**⚡ ميزة رهيبة:** يصل التحديث خلال ثوانٍ بدون إعادة التثبيت!

---

## 📊 شرح واجهة Expo Dashboard

### القائمة الجانبية:

```
┌──────────────────────────────────┐
│ 🏠 Overview                      │ ← صفحة عامة عن المشروع
│ 🏗️ Builds                        │ ← إنشاء ومتابعة Builds
│ 🚀 Updates                       │ ← نشر تحديثات سريعة
│ 📊 Analytics                     │ ← إحصائيات الاستخدام
│ 🔐 Secrets                       │ ← Environment Variables
│ ⚙️ Settings                      │ ← إعدادات المشروع
│ 👥 Collaborators                 │ ← إضافة مطورين آخرين
└──────────────────────────────────┘
```

---

## ❓ حل المشاكل الشائعة

### مشكلة 1: "Project not found"

```bash
# الحل:
npx eas-cli init
# سيربط المشروع بحسابك
```

---

### مشكلة 2: "Build failed"

**السبب الأكثر شيوعاً:** الأيقونات مفقودة

```
الحل:
1. أضف الأيقونات في:
   assets/images/icon.png
   assets/images/splash.png
   assets/images/adaptive-icon.png

2. أو عدل app.json وأزل مسارات الأيقونات مؤقتاً
```

---

### مشكلة 3: "Invalid credentials"

```bash
# الحل:
npx eas-cli logout
npx eas-cli login
# سجل دخول من جديد
```

---

### مشكلة 4: التطبيق لا يعمل بعد التثبيت

**السبب:** Environment Variables ناقصة

```
الحل:
1. أضف Secrets في Expo Dashboard
2. أنشئ Build جديد
3. حمل APK الجديد
```

---

## 🎯 ملخص سريع - الخطوات الرئيسية

```
1️⃣ سجل دخول في expo.dev

2️⃣ من Terminal:
   npx eas-cli login
   npx eas-cli secret:create --name EXPO_PUBLIC_SUPABASE_URL --value "قيمتك"
   npx eas-cli secret:create --name EXPO_PUBLIC_SUPABASE_ANON_KEY --value "قيمتك"

3️⃣ من Expo Dashboard:
   - اذهب لـ Builds
   - اضغط "Create a build"
   - اختر Android → preview
   - اضغط "Build"

4️⃣ انتظر 15-20 دقيقة

5️⃣ اضغط "Download" وثبت على هاتفك ✅
```

---

## 💡 نصائح مهمة

### للتجربة السريعة:
```
✅ استخدم profile: preview
✅ سيعطيك APK مباشرة
✅ لا تحتاج Play Store
```

### للنشر الرسمي:
```
✅ استخدم profile: production
✅ احصل على AAB (أصغر حجماً)
✅ ارفع على Play Store
```

### لتوفير الوقت:
```
✅ أضف جميع Secrets أولاً
✅ تأكد من الأيقونات موجودة
✅ راجع app.json
```

---

## 🔗 روابط مفيدة

```
Expo Dashboard:
https://expo.dev

مشروعك المباشر:
https://expo.dev/accounts/muaafa-health/projects/muaafa-health

Expo Docs:
https://docs.expo.dev/build/introduction/

EAS Build Docs:
https://docs.expo.dev/build/setup/
```

---

## 📞 محتاج مساعدة؟

### إذا علقت في أي خطوة:

1. **التقط Screenshot من الشاشة**
2. **اسألني مباشرة**
3. **سأساعدك خطوة بخطوة**

---

## ✅ Checklist سريع

قبل البناء:
- [ ] سجلت دخول في expo.dev
- [ ] ربطت المشروع (eas init)
- [ ] أضفت Secrets
- [ ] تأكدت من app.json

أثناء البناء:
- [ ] اخترت Android
- [ ] اخترت profile: preview
- [ ] ضغطت Build
- [ ] أتابع التقدم

بعد البناء:
- [ ] حملت APK
- [ ] ثبته على الهاتف
- [ ] جربت التطبيق
- [ ] شاركت مع الآخرين

---

## 🎉 مستعد للبداية؟

**ابدأ الآن:**

```bash
# 1. سجل دخول
npx eas-cli login

# 2. أضف Secrets (ضروري!)
npx eas-cli secret:create --name EXPO_PUBLIC_SUPABASE_URL --value "قيمتك"
npx eas-cli secret:create --name EXPO_PUBLIC_SUPABASE_ANON_KEY --value "قيمتك"

# 3. افتح Expo Dashboard
```

**ثم اتبع الخطوات من الخطوة 4 أعلاه!**

---

**أي سؤال؟ أنا هنا! 🚀**
