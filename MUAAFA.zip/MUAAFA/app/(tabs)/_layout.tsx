import { Tabs } from 'expo-router';
import { Bot, Calendar, ShoppingBag, Wallet, Activity, FileText, Settings, ShoppingCart, Crown } from 'lucide-react-native';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { GlobalFAB } from '@/components/GlobalFAB';

export default function TabLayout() {
  const { t } = useLanguage();

  return (
    <>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: '#0ea5e9',
          tabBarInactiveTintColor: '#94a3b8',
          tabBarStyle: {
            backgroundColor: '#ffffff',
            borderTopWidth: 1,
            borderTopColor: '#e2e8f0',
            height: 65,
            paddingBottom: 10,
            paddingTop: 10,
            justifyContent: 'space-around',
          },
          tabBarLabelStyle: {
            fontSize: 10,
            fontWeight: '600',
          },
        }}>
        <Tabs.Screen
          name="index"
          options={{
            title: 'الطبيب الذكي',
            tabBarIcon: ({ size, color }) => (
              <Bot size={20} color={color} strokeWidth={2} />
            ),
          }}
        />
        <Tabs.Screen
          name="fitness"
          options={{
            title: 'الرياضة',
            tabBarIcon: ({ size, color }) => (
              <Activity size={20} color={color} strokeWidth={2} />
            ),
          }}
        />
        <Tabs.Screen
          name="pharmacies"
          options={{
            title: 'الصيدليات',
            tabBarIcon: ({ size, color }) => (
              <ShoppingBag size={20} color={color} strokeWidth={2} />
            ),
          }}
        />
        <Tabs.Screen
          name="reports"
          options={{
            title: 'المحفظة الرقمية',
            tabBarIcon: ({ size, color }) => (
              <Wallet size={20} color={color} strokeWidth={2} />
            ),
          }}
        />
        <Tabs.Screen
          name="sessions"
          options={{
            title: 'الجلسات',
            tabBarIcon: ({ size, color }) => (
              <Calendar size={20} color={color} strokeWidth={2} />
            ),
          }}
        />
        <Tabs.Screen
          name="settings"
          options={{
            title: 'الإعدادات',
            tabBarIcon: ({ size, color }) => (
              <Settings size={20} color={color} strokeWidth={2} />
            ),
          }}
        />
        <Tabs.Screen
          name="history"
          options={{
            href: null,
          }}
        />
      </Tabs>
      <GlobalFAB />
    </>
  );
}
