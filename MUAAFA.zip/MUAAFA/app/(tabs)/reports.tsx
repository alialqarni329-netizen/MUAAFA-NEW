import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, Modal } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import {
  Wallet,
  Shield,
  CreditCard,
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  MapPin,
  Plus,
  Sparkles,
  FolderOpen,
  Upload,
  TrendingUp,
  Building2,
  Construction,
  Eye,
} from 'lucide-react-native';

interface InsuranceDetails {
  id: string;
  insurance_company: string;
  policy_number: string;
  insurance_category: string;
  end_date: string;
  is_active: boolean;
  coverage_details: any;
}

interface InsuranceRequest {
  id: string;
  request_type: string;
  status: string;
  request_date: string;
  approval_number: string;
  rejection_reason: string;
  coverage_amount: number;
}

interface MedicalDocument {
  id: string;
  document_type: string;
  document_name: string;
  upload_date: string;
  ai_summary: string;
  folder: string;
}

export default function HealthWalletScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [insuranceDetails, setInsuranceDetails] = useState<InsuranceDetails | null>(null);
  const [requests, setRequests] = useState<InsuranceRequest[]>([]);
  const [documents, setDocuments] = useState<MedicalDocument[]>([]);
  const [showFacilities, setShowFacilities] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'insurance' | 'requests' | 'documents'>('insurance');
  const [showDevelopmentModal, setShowDevelopmentModal] = useState(false);

  useEffect(() => {
    checkFirstVisit();
    loadData();
  }, []);

  async function checkFirstVisit() {
    try {
      const hasVisited = await AsyncStorage.getItem('reports_visited');
      if (!hasVisited) {
        setShowDevelopmentModal(true);
      }
    } catch (error) {
      console.error('Error checking first visit:', error);
    }
  }

  async function handleContinue() {
    try {
      await AsyncStorage.setItem('reports_visited', 'true');
      setShowDevelopmentModal(false);
    } catch (error) {
      console.error('Error saving visit:', error);
    }
  }

  async function loadData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const [insuranceData, requestsData, documentsData] = await Promise.all([
        supabase
          .from('insurance_details')
          .select('*')
          .eq('user_id', user.id)
          .eq('is_active', true)
          .maybeSingle(),
        supabase
          .from('insurance_requests')
          .select('*')
          .eq('user_id', user.id)
          .order('request_date', { ascending: false })
          .limit(10),
        supabase
          .from('medical_documents')
          .select('*')
          .eq('user_id', user.id)
          .order('upload_date', { ascending: false })
          .limit(20),
      ]);

      if (insuranceData.data) setInsuranceDetails(insuranceData.data);
      if (requestsData.data) setRequests(requestsData.data);
      if (documentsData.data) setDocuments(documentsData.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'approved':
        return '#10b981';
      case 'rejected':
        return '#ef4444';
      case 'under_review':
        return '#f59e0b';
      case 'appealed':
        return '#8b5cf6';
      default:
        return '#64748b';
    }
  }

  function getStatusText(status: string) {
    const statusMap: Record<string, Record<string, string>> = {
      ar: {
        submitted: 'تم الرفع',
        under_review: 'قيد المراجعة',
        approved: 'تمت الموافقة',
        rejected: 'مرفوض',
        appealed: 'قيد الاعتراض',
      },
      en: {
        submitted: 'Submitted',
        under_review: 'Under Review',
        approved: 'Approved',
        rejected: 'Rejected',
        appealed: 'Appealed',
      },
    };
    return statusMap[language]?.[status] || status;
  }

  async function handleSimplifyReport(documentId: string, reportText: string) {
    try {
      const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/simplify-medical-report`;
      const { data: { session } } = await supabase.auth.getSession();

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          documentId,
          reportText,
          language,
        }),
      });

      if (response.ok) {
        const result = await response.json();
        Alert.alert(
          language === 'ar' ? 'ملخص التقرير' : 'Report Summary',
          result.summary,
          [{ text: language === 'ar' ? 'حسناً' : 'OK' }]
        );
      }
    } catch (error) {
      console.error('Error simplifying report:', error);
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Modal
        visible={showDevelopmentModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowDevelopmentModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalIconContainer}>
              <Construction size={64} color="#0ea5e9" strokeWidth={2} />
            </View>

            <Text style={styles.modalTitle}>
              {language === 'ar' ? 'قيد التجهيز' : 'Under Development'}
            </Text>

            <Text style={styles.modalDescription}>
              {language === 'ar'
                ? 'المحفظة الصحية والتأمين قيد التطوير والتحسين. يمكنك تصفح النموذج الأولي واستكشاف الميزات المتاحة.'
                : 'Health Wallet and Insurance are under development. You can browse the prototype and explore available features.'}
            </Text>

            <View style={styles.modalFeatures}>
              <View style={styles.featureItem}>
                <Eye size={20} color="#0ea5e9" strokeWidth={2} />
                <Text style={styles.featureText}>
                  {language === 'ar' ? 'تصفح النموذج الأولي' : 'Browse prototype'}
                </Text>
              </View>
              <View style={styles.featureItem}>
                <FileText size={20} color="#0ea5e9" strokeWidth={2} />
                <Text style={styles.featureText}>
                  {language === 'ar' ? 'استكشف إدارة التقارير' : 'Explore report management'}
                </Text>
              </View>
            </View>

            <TouchableOpacity style={styles.continueButton} onPress={handleContinue}>
              <Text style={styles.continueButtonText}>
                {language === 'ar' ? 'متابعة للنموذج' : 'Continue to Prototype'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <View style={styles.header}>
        <Wallet size={32} color="#0ea5e9" strokeWidth={2} />
        <View style={styles.headerTextContainer}>
          <Text style={styles.headerTitle}>
            {language === 'ar' ? 'المحفظة الصحية' : 'Health Wallet'}
          </Text>
          <Text style={styles.headerSubtitle}>
            {language === 'ar' ? 'التقارير، التأمين، والموافقات' : 'Reports, Insurance, & Approvals'}
          </Text>
        </View>
      </View>

      {insuranceDetails && (
        <View style={styles.insuranceCard}>
          <View style={styles.insuranceCardHeader}>
            <View style={styles.insuranceCompanyBadge}>
              <Shield size={20} color="#ffffff" strokeWidth={2} />
            </View>
            <View style={styles.insuranceCardInfo}>
              <Text style={styles.insuranceCompany}>{insuranceDetails.insurance_company}</Text>
              <Text style={styles.policyNumber}>
                {language === 'ar' ? 'رقم البوليصة:' : 'Policy No:'} {insuranceDetails.policy_number}
              </Text>
            </View>
            <View style={styles.categoryBadge}>
              <Text style={styles.categoryText}>{insuranceDetails.insurance_category}</Text>
            </View>
          </View>

          <View style={styles.insuranceCardFooter}>
            <View style={styles.expiryInfo}>
              <Clock size={16} color="#ffffff" strokeWidth={2} />
              <Text style={styles.expiryText}>
                {language === 'ar' ? 'ينتهي في:' : 'Expires:'} {new Date(insuranceDetails.end_date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
              </Text>
            </View>
            <TouchableOpacity
              style={styles.facilitiesButton}
              onPress={() => setShowFacilities(true)}
            >
              <Building2 size={16} color="#ffffff" strokeWidth={2} />
              <Text style={styles.facilitiesButtonText}>
                {language === 'ar' ? 'شبكة الفروع' : 'Network'}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.walletGradient} />
        </View>
      )}

      {!insuranceDetails && (
        <TouchableOpacity
          style={styles.addInsuranceCard}
          onPress={() => router.push('/reports/insurance' as any)}
        >
          <Plus size={24} color="#0ea5e9" strokeWidth={2} />
          <Text style={styles.addInsuranceText}>
            {language === 'ar' ? 'إضافة بطاقة تأمين' : 'Add Insurance Card'}
          </Text>
        </TouchableOpacity>
      )}

      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'insurance' && styles.tabActive]}
          onPress={() => setSelectedTab('insurance')}
        >
          <Shield size={20} color={selectedTab === 'insurance' ? '#0ea5e9' : '#64748b'} strokeWidth={2} />
          <Text style={[styles.tabText, selectedTab === 'insurance' && styles.tabTextActive]}>
            {language === 'ar' ? 'الموافقات' : 'Approvals'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, selectedTab === 'documents' && styles.tabActive]}
          onPress={() => setSelectedTab('documents')}
        >
          <FolderOpen size={20} color={selectedTab === 'documents' ? '#0ea5e9' : '#64748b'} strokeWidth={2} />
          <Text style={[styles.tabText, selectedTab === 'documents' && styles.tabTextActive]}>
            {language === 'ar' ? 'الأرشيف' : 'Archive'}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {selectedTab === 'insurance' && (
          <View>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>
                {language === 'ar' ? 'تتبع الموافقات الطبية' : 'Track Medical Approvals'}
              </Text>
              <TouchableOpacity
                style={styles.newRequestButton}
                onPress={() => router.push('/reports/submit' as any)}
              >
                <Plus size={16} color="#ffffff" strokeWidth={2} />
                <Text style={styles.newRequestButtonText}>
                  {language === 'ar' ? 'طلب جديد' : 'New Request'}
                </Text>
              </TouchableOpacity>
            </View>

            {requests.length === 0 ? (
              <View style={styles.emptyState}>
                <AlertCircle size={48} color="#cbd5e1" strokeWidth={2} />
                <Text style={styles.emptyStateText}>
                  {language === 'ar' ? 'لا توجد طلبات حالياً' : 'No requests yet'}
                </Text>
              </View>
            ) : (
              requests.map((request) => (
                <View key={request.id} style={styles.requestCard}>
                  <View style={styles.requestHeader}>
                    <View style={styles.requestInfo}>
                      <Text style={styles.requestType}>
                        {request.request_type === 'appointment'
                          ? language === 'ar' ? 'جلسة طبية' : 'Medical Appointment'
                          : language === 'ar' ? 'دواء' : 'Medication'}
                      </Text>
                      <Text style={styles.requestDate}>
                        {new Date(request.request_date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
                      </Text>
                    </View>
                    <View style={[styles.statusBadge, { backgroundColor: getStatusColor(request.status) }]}>
                      <Text style={styles.statusText}>{getStatusText(request.status)}</Text>
                    </View>
                  </View>

                  <View style={styles.timelineContainer}>
                    <View style={[styles.timelineStep, request.status !== 'submitted' && styles.timelineStepCompleted]}>
                      <View style={[styles.timelineDot, request.status !== 'submitted' && styles.timelineDotCompleted]} />
                      <Text style={styles.timelineText}>
                        {language === 'ar' ? 'تم الرفع' : 'Submitted'}
                      </Text>
                    </View>
                    <View style={styles.timelineLine} />
                    <View style={[styles.timelineStep, (request.status === 'approved' || request.status === 'rejected') && styles.timelineStepCompleted]}>
                      <View style={[styles.timelineDot, (request.status === 'approved' || request.status === 'rejected') && styles.timelineDotCompleted]} />
                      <Text style={styles.timelineText}>
                        {language === 'ar' ? 'قيد المراجعة' : 'Under Review'}
                      </Text>
                    </View>
                    <View style={styles.timelineLine} />
                    <View style={[styles.timelineStep, request.status === 'approved' && styles.timelineStepCompleted]}>
                      <View style={[styles.timelineDot, request.status === 'approved' && styles.timelineDotCompleted]} />
                      <Text style={styles.timelineText}>
                        {language === 'ar' ? 'تمت الموافقة' : 'Approved'}
                      </Text>
                    </View>
                  </View>

                  {request.status === 'approved' && request.approval_number && (
                    <View style={styles.approvalBanner}>
                      <CheckCircle size={20} color="#10b981" strokeWidth={2} />
                      <Text style={styles.approvalText}>
                        {language === 'ar' ? 'رقم الموافقة:' : 'Approval No:'} {request.approval_number}
                      </Text>
                    </View>
                  )}

                  {request.status === 'rejected' && (
                    <View style={styles.rejectionBanner}>
                      <XCircle size={20} color="#ef4444" strokeWidth={2} />
                      <View style={styles.rejectionContent}>
                        <Text style={styles.rejectionText}>
                          {request.rejection_reason || (language === 'ar' ? 'تم رفض الطلب' : 'Request rejected')}
                        </Text>
                        <TouchableOpacity
                          style={styles.appealButton}
                          onPress={() => router.push(`/reports/appeal?requestId=${request.id}` as any)}
                        >
                          <Text style={styles.appealButtonText}>
                            {language === 'ar' ? 'تقديم اعتراض' : 'File Appeal'}
                          </Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  )}
                </View>
              ))
            )}
          </View>
        )}

        {selectedTab === 'documents' && (
          <View>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>
                {language === 'ar' ? 'أرشيف المستندات الطبية' : 'Medical Documents Archive'}
              </Text>
              <TouchableOpacity
                style={styles.newRequestButton}
                onPress={() => router.push('/reports/submit' as any)}
              >
                <Upload size={16} color="#ffffff" strokeWidth={2} />
                <Text style={styles.newRequestButtonText}>
                  {language === 'ar' ? 'رفع مستند' : 'Upload'}
                </Text>
              </TouchableOpacity>
            </View>

            <View style={styles.foldersGrid}>
              {['report', 'xray', 'bill', 'approval', 'prescription'].map((folderType) => (
                <TouchableOpacity
                  key={folderType}
                  style={styles.folderCard}
                  onPress={() => router.push(`/reports/history?type=${folderType}` as any)}
                >
                  <FolderOpen size={32} color="#0ea5e9" strokeWidth={2} />
                  <Text style={styles.folderName}>
                    {folderType === 'report' && (language === 'ar' ? 'تقارير طبية' : 'Medical Reports')}
                    {folderType === 'xray' && (language === 'ar' ? 'أشعة' : 'X-Rays')}
                    {folderType === 'bill' && (language === 'ar' ? 'فواتير' : 'Bills')}
                    {folderType === 'approval' && (language === 'ar' ? 'موافقات' : 'Approvals')}
                    {folderType === 'prescription' && (language === 'ar' ? 'روشتات' : 'Prescriptions')}
                  </Text>
                  <Text style={styles.folderCount}>
                    {documents.filter((d) => d.document_type === folderType).length} {language === 'ar' ? 'مستند' : 'docs'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {documents.length > 0 && (
              <View style={styles.recentSection}>
                <Text style={styles.recentTitle}>
                  {language === 'ar' ? 'المستندات الأخيرة' : 'Recent Documents'}
                </Text>
                {documents.slice(0, 5).map((doc) => (
                  <View key={doc.id} style={styles.documentCard}>
                    <FileText size={24} color="#0ea5e9" strokeWidth={2} />
                    <View style={styles.documentInfo}>
                      <Text style={styles.documentName}>{doc.document_name}</Text>
                      <Text style={styles.documentDate}>
                        {new Date(doc.upload_date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
                      </Text>
                    </View>
                    {doc.ai_summary ? (
                      <TouchableOpacity
                        style={styles.aiButton}
                        onPress={() => Alert.alert(language === 'ar' ? 'ملخص AI' : 'AI Summary', doc.ai_summary)}
                      >
                        <Sparkles size={16} color="#8b5cf6" strokeWidth={2} />
                      </TouchableOpacity>
                    ) : (
                      <TouchableOpacity
                        style={styles.simplifyButton}
                        onPress={() => handleSimplifyReport(doc.id, 'Sample report text')}
                      >
                        <Sparkles size={16} color="#f59e0b" strokeWidth={2} />
                        <Text style={styles.simplifyButtonText}>
                          {language === 'ar' ? 'تبسيط' : 'Simplify'}
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                ))}
              </View>
            )}
          </View>
        )}

        <View style={styles.disclaimerCard}>
          <AlertCircle size={20} color="#f59e0b" strokeWidth={2} />
          <Text style={styles.disclaimerText}>
            {language === 'ar'
              ? 'مُعافى وسيط لتسهيل متابعة الموافقات، والقرار النهائي يعود لشركة التأمين حسب شروط بوليصتك.'
              : 'Muafa is an intermediary to facilitate approval tracking. Final decisions are made by the insurance company according to your policy terms.'}
          </Text>
        </View>
      </ScrollView>

      <Modal visible={showFacilities} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {language === 'ar' ? 'شبكة الفروع المغطاة' : 'Covered Facilities Network'}
              </Text>
              <TouchableOpacity onPress={() => setShowFacilities(false)}>
                <XCircle size={24} color="#64748b" strokeWidth={2} />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.modalBody}>
              <Text style={styles.modalDescription}>
                {language === 'ar'
                  ? 'قائمة المستشفيات والعيادات المغطاة ضمن فئة تأمينك'
                  : 'List of hospitals and clinics covered under your insurance category'}
              </Text>
              <TouchableOpacity
                style={styles.viewFullNetworkButton}
                onPress={() => {
                  setShowFacilities(false);
                  router.push('/reports/health-approvals' as any);
                }}
              >
                <MapPin size={20} color="#ffffff" strokeWidth={2} />
                <Text style={styles.viewFullNetworkButtonText}>
                  {language === 'ar' ? 'عرض الخريطة الكاملة' : 'View Full Map'}
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  headerTextContainer: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  insuranceCard: {
    backgroundColor: '#0ea5e9',
    borderRadius: 20,
    padding: 24,
    margin: 16,
    position: 'relative',
    overflow: 'hidden',
  },
  insuranceCardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  insuranceCompanyBadge: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  insuranceCardInfo: {
    flex: 1,
    marginHorizontal: 12,
  },
  insuranceCompany: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'right',
    marginBottom: 4,
  },
  policyNumber: {
    fontSize: 14,
    color: '#e0f2fe',
    textAlign: 'right',
  },
  categoryBadge: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  categoryText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  insuranceCardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  expiryInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  expiryText: {
    fontSize: 12,
    color: '#e0f2fe',
  },
  facilitiesButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  facilitiesButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
  },
  walletGradient: {
    position: 'absolute',
    top: -50,
    right: -50,
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  addInsuranceCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    margin: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    borderStyle: 'dashed',
  },
  addInsuranceText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 4,
    gap: 4,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: 8,
  },
  tabActive: {
    backgroundColor: '#f0f9ff',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  tabTextActive: {
    color: '#0ea5e9',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  newRequestButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  newRequestButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 48,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 12,
  },
  requestCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  requestInfo: {
    flex: 1,
  },
  requestType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  requestDate: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
  },
  timelineContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 16,
  },
  timelineStep: {
    alignItems: 'center',
    flex: 1,
  },
  timelineStepCompleted: {
    opacity: 1,
  },
  timelineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#cbd5e1',
    marginBottom: 8,
  },
  timelineDotCompleted: {
    backgroundColor: '#10b981',
  },
  timelineText: {
    fontSize: 10,
    color: '#64748b',
    textAlign: 'center',
  },
  timelineLine: {
    flex: 1,
    height: 2,
    backgroundColor: '#e2e8f0',
    marginBottom: 20,
  },
  approvalBanner: {
    backgroundColor: '#f0fdf4',
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  approvalText: {
    fontSize: 14,
    color: '#166534',
    fontWeight: '600',
  },
  rejectionBanner: {
    backgroundColor: '#fef2f2',
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  rejectionContent: {
    flex: 1,
  },
  rejectionText: {
    fontSize: 14,
    color: '#991b1b',
    marginBottom: 8,
    textAlign: 'right',
  },
  appealButton: {
    backgroundColor: '#8b5cf6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    alignSelf: 'flex-end',
  },
  appealButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
  },
  foldersGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  folderCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    width: '48%',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  folderName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    marginTop: 8,
    textAlign: 'center',
  },
  folderCount: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  recentSection: {
    marginTop: 24,
  },
  recentTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  documentCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  documentInfo: {
    flex: 1,
  },
  documentName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  documentDate: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  aiButton: {
    padding: 8,
  },
  simplifyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#fef3c7',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 6,
  },
  simplifyButtonText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#92400e',
  },
  disclaimerCard: {
    backgroundColor: '#fffbeb',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginTop: 24,
    borderWidth: 1,
    borderColor: '#fde68a',
  },
  disclaimerText: {
    flex: 1,
    fontSize: 12,
    color: '#92400e',
    textAlign: 'right',
    lineHeight: 18,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  modalBody: {
    padding: 20,
  },
  modalDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
    marginBottom: 16,
  },
  viewFullNetworkButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  viewFullNetworkButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  modalIconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#dbeafe',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalFeatures: {
    width: '100%',
    gap: 12,
    marginBottom: 24,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#f0f9ff',
    padding: 16,
    borderRadius: 12,
  },
  featureText: {
    fontSize: 15,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'right',
    flex: 1,
  },
  continueButton: {
    backgroundColor: '#0ea5e9',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    width: '100%',
  },
  continueButtonText: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
  },
});
