import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MessageCircle, Send, Bot, User, AlertCircle, Paperclip, X } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  created_at: string;
  severity_level?: string;
  suggested_action?: string;
  app_features_mentioned?: string[];
}

interface Conversation {
  id: string;
  title: string;
  last_message_at: string;
}

export default function AIDoctorScreen() {
  const { t, language } = useLanguage();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversation, setCurrentConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [attachedImages, setAttachedImages] = useState<string[]>([]);
  const scrollViewRef = useRef<ScrollView>(null);
  const isSendingRef = useRef(false);
  const historyLoadedRef = useRef<string | null>(null);

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    if (!currentConversation) return;
    if (historyLoadedRef.current === currentConversation) return;
    historyLoadedRef.current = currentConversation;
    loadMessages(currentConversation);
  }, [currentConversation]);

  const loadConversations = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('chat_conversations')
        .select('*')
        .eq('user_id', user.id)
        .order('last_message_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setConversations(data || []);

      if (data && data.length > 0 && !currentConversation) {
        setCurrentConversation(data[0].id);
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
    }
  };

  const loadMessages = async (conversationId: string) => {
    try {
      setIsLoading(true);
      const { data: rows, error } = await supabase
        .from('chat_messages')
        .select('id, sender_type, content, created_at, severity_level, suggested_action, app_features_mentioned')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true })
        .limit(100);

      if (error) throw error;

      const mapped: Message[] = (rows || []).map(row => ({
        id: row.id,
        role: row.sender_type === 'ai' ? 'assistant' : 'user',
        content: row.content,
        created_at: row.created_at,
        severity_level: row.severity_level,
        suggested_action: row.suggested_action,
        app_features_mentioned: row.app_features_mentioned,
      }));

      console.log('[HISTORY] loaded', mapped.length);
      setMessages(prev => (prev.length > 0 ? prev : mapped));
      setTimeout(() => scrollViewRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createNewConversation = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await supabase
        .from('chat_conversations')
        .insert({
          user_id: user.id,
          title: language === 'ar' ? 'محادثة جديدة' : 'New Conversation',
          language: language,
        })
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Error creating conversation:', error);
      return null;
    }
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 0.8,
    });

    if (!result.canceled && result.assets) {
      const imageUris = result.assets.map(asset => asset.uri);
      setAttachedImages(prev => [...prev, ...imageUris]);
    }
  };

  const removeImage = (index: number) => {
    setAttachedImages(prev => prev.filter((_, i) => i !== index));
  };

  const uploadImages = async (userId: string, conversationId: string): Promise<string[]> => {
    const uploadedUrls: string[] = [];

    for (const imageUri of attachedImages) {
      try {
        const response = await fetch(imageUri);
        const blob = await response.blob();
        const fileExt = imageUri.split('.').pop() || 'jpg';
        const fileName = `${userId}/${conversationId}/${Date.now()}.${fileExt}`;

        const { data, error } = await supabase.storage
          .from('chat-images')
          .upload(fileName, blob, {
            contentType: `image/${fileExt}`,
            cacheControl: '3600',
          });

        if (error) throw error;

        const { data: { publicUrl } } = supabase.storage
          .from('chat-images')
          .getPublicUrl(data.path);

        uploadedUrls.push(publicUrl);
      } catch (error) {
        console.error('Error uploading image:', error);
      }
    }

    return uploadedUrls;
  };

  const sendMessage = async () => {
    if ((!inputText.trim() && attachedImages.length === 0) || isSending) return;
    if (isSendingRef.current) return;
    isSendingRef.current = true;

    const currentText = inputText.trim();
    const imagesToUpload = [...attachedImages];
    setInputText('');
    setAttachedImages([]);
    setIsSending(true);

    const tempUserId = 'temp-user-' + Date.now();
    const tempLoadingId = 'temp-loading-' + Date.now();

    setMessages(prev => [...prev, {
      id: tempUserId,
      role: 'user',
      content: currentText || (language === 'ar' ? '[صور مرفقة]' : '[Images attached]'),
      created_at: new Date().toISOString(),
    }, {
      id: tempLoadingId,
      role: 'assistant',
      content: language === 'ar' ? '🤔 جاري التفكير...' : '🤔 Thinking...',
      created_at: new Date().toISOString(),
    }]);
    setTimeout(() => scrollViewRef.current?.scrollToEnd({ animated: true }), 100);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      let conversationId = currentConversation;
      const isNewConversation = !conversationId;

      if (!conversationId) {
        conversationId = await createNewConversation();
        if (!conversationId) throw new Error('Failed to create conversation');
        setCurrentConversation(conversationId);
      }

      let imageUrls: string[] = [];
      if (imagesToUpload.length > 0) {
        setAttachedImages(imagesToUpload);
        imageUrls = await uploadImages(user.id, conversationId);
        setAttachedImages([]);
      }

      let fullMessage = currentText;
      if (imageUrls.length > 0) {
        const imagesText = imageUrls.map((url, idx) =>
          `${language === 'ar' ? 'صورة' : 'Image'} ${idx + 1}: ${url}`
        ).join('\n');
        fullMessage = currentText
          ? `${currentText}\n\n${imagesText}`
          : imagesText;
      }

      setMessages(prev => prev.map(m =>
        m.id === tempUserId ? { ...m, content: fullMessage } : m
      ));

      const messagesForAI = messages
        .filter(m => m.role !== 'system' && !m.id.startsWith('temp-'))
        .map(m => ({ role: m.role, content: m.content }));
      messagesForAI.push({ role: 'user', content: fullMessage });

      console.log('[SEND] before invoke', { conversationId, currentText: fullMessage });

      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      if (!session?.access_token) throw new Error('No active session');

      const { data: responseData, error: functionError } = await supabase.functions.invoke('health-chatbot-fast', {
        body: {
          messages: messagesForAI,
          conversationId,
          userId: user.id,
          isNewConversation,
        },
        headers: { Authorization: `Bearer ${session.access_token}` },
      });

      if (functionError) {
        console.error('[SEND] function error', functionError);
        const errorMsg = functionError.message?.includes('OpenAI API key not configured')
          ? (language === 'ar'
              ? '⚠️ خطأ: مفتاح OpenAI API غير مُهيأ. يرجى إضافة OPENAI_API_KEY في إعدادات Supabase.'
              : '⚠️ Error: OpenAI API key not configured. Please add OPENAI_API_KEY in Supabase settings.')
          : (language === 'ar' ? '⚠️ حدث خطأ، حاول مرة أخرى.' : '⚠️ Error occurred, please try again.');

        setMessages(prev => prev.filter(m => m.id !== tempLoadingId).concat({
          id: 'error-' + Date.now(),
          role: 'assistant',
          content: errorMsg,
          created_at: new Date().toISOString(),
        }));
        return;
      }

      if (!responseData) {
        setMessages(prev => prev.filter(m => m.id !== tempLoadingId).concat({
          id: 'error-' + Date.now(),
          role: 'assistant',
          content: language === 'ar' ? '⚠️ لم يتم استلام رد من الذكاء الاصطناعي' : '⚠️ No response from AI',
          created_at: new Date().toISOString(),
        }));
        return;
      }

      const aiReply = responseData.reply || responseData.message;

      setMessages(prev => {
        const filtered = prev.filter(m => m.id !== tempLoadingId);
        const newMessages: Message[] = [{
          id: 'ai-' + Date.now(),
          role: 'assistant',
          content: aiReply,
          created_at: new Date().toISOString(),
          severity_level: responseData.analysis?.severity_level || 'none',
          suggested_action: responseData.analysis?.suggested_action,
          app_features_mentioned: responseData.analysis?.app_features_mentioned || [],
        }];

        if (isNewConversation && responseData.welcomeMessage) {
          newMessages.unshift({
            id: 'welcome-' + Date.now(),
            role: 'assistant',
            content: responseData.welcomeMessage,
            created_at: new Date().toISOString(),
          });
        }

        return [...filtered, ...newMessages];
      });

      setTimeout(() => scrollViewRef.current?.scrollToEnd({ animated: true }), 100);

      (async () => {
        try {
          console.log('[LEGACY SAVE] user payload', {
            conversation_id: conversationId,
            sender_type: 'user',
            content: fullMessage,
          });

          const { error: userInsertError } = await supabase
            .from('chat_messages')
            .insert({
              conversation_id: conversationId,
              sender_type: 'user',
              content: fullMessage,
            });

          if (userInsertError) {
            console.error('[LEGACY SAVE ERROR] user', userInsertError);
          } else {
            console.log('[LEGACY SAVE] user OK');
          }

          if (isNewConversation && responseData.welcomeMessage) {
            console.log('[LEGACY SAVE] welcome payload', {
              conversation_id: conversationId,
              sender_type: 'ai',
              content: responseData.welcomeMessage,
            });

            const { error: welcomeError } = await supabase
              .from('chat_messages')
              .insert({
                conversation_id: conversationId,
                sender_type: 'ai',
                content: responseData.welcomeMessage,
              });

            if (welcomeError) {
              console.error('[LEGACY SAVE ERROR] welcome', welcomeError);
            } else {
              console.log('[LEGACY SAVE] welcome OK');
            }
          }

          console.log('[LEGACY SAVE] ai payload', {
            conversation_id: conversationId,
            sender_type: 'ai',
            content: responseData.message,
            severity_level: responseData.analysis?.severity_level ?? null,
            suggested_action: responseData.analysis?.suggested_action ?? null,
            app_features_mentioned: responseData.analysis?.app_features_mentioned ?? [],
          });

          const { error: aiInsertError } = await supabase
            .from('chat_messages')
            .insert({
              conversation_id: conversationId,
              sender_type: 'ai',
              content: responseData.message,
              severity_level: responseData.analysis?.severity_level ?? null,
              suggested_action: responseData.analysis?.suggested_action ?? null,
              app_features_mentioned: responseData.analysis?.app_features_mentioned ?? [],
            });

          if (aiInsertError) {
            console.error('[LEGACY SAVE ERROR] ai', aiInsertError);
          } else {
            console.log('[LEGACY SAVE] ai OK');
          }

          if (isNewConversation) {
            const titlePreview = fullMessage.substring(0, 50);
            await supabase
              .from('chat_conversations')
              .update({ title: titlePreview })
              .eq('id', conversationId);
            await loadConversations();
          }
        } catch (dbError) {
          console.error('[LEGACY SAVE ERROR] fatal', dbError);
        }
      })();

    } catch (error: any) {
      console.error('[SEND] critical error', error);
      setMessages(prev => prev.filter(m => m.id !== tempLoadingId).concat({
        id: 'error-' + Date.now(),
        role: 'assistant',
        content: error.message || (language === 'ar'
          ? '⚠️ حدث خطأ غير متوقع، حاول مرة أخرى.'
          : '⚠️ Unexpected error occurred, please try again.'),
        created_at: new Date().toISOString(),
      }));
    } finally {
      setIsSending(false);
      isSendingRef.current = false;
    }
  };

  const startNewChat = async () => {
    const newId = await createNewConversation();
    if (newId) {
      historyLoadedRef.current = null;
      setCurrentConversation(newId);
      setMessages([]);
      await loadConversations();
    }
  };

  const renderMessage = (message: Message) => {
    const isUser = message.role === 'user';

    return (
      <View
        key={message.id}
        style={[
          styles.messageContainer,
          isUser ? styles.userMessageContainer : styles.assistantMessageContainer,
        ]}
      >
        <View style={styles.messageHeader}>
          {isUser ? (
            <User size={20} color="#fff" />
          ) : (
            <Bot size={20} color="#0891b2" />
          )}
        </View>
        <View
          style={[
            styles.messageBubble,
            isUser ? styles.userBubble : styles.assistantBubble,
          ]}
        >
          <Text
            style={[
              styles.messageText,
              isUser ? styles.userMessageText : styles.assistantMessageText,
            ]}
          >
            {message.content}
          </Text>

          {message.severity_level && message.severity_level !== 'none' && (
            <View style={[
              styles.severityBadge,
              message.severity_level === 'mild' && styles.severity_mild,
              message.severity_level === 'moderate' && styles.severity_moderate,
              message.severity_level === 'severe' && styles.severity_severe,
              message.severity_level === 'emergency' && styles.severity_emergency,
            ]}>
              <AlertCircle size={14} color="#fff" />
              <Text style={styles.severityText}>
                {message.severity_level === 'emergency' && (language === 'ar' ? 'طوارئ' : 'Emergency')}
                {message.severity_level === 'severe' && (language === 'ar' ? 'حاد' : 'Severe')}
                {message.severity_level === 'moderate' && (language === 'ar' ? 'متوسط' : 'Moderate')}
                {message.severity_level === 'mild' && (language === 'ar' ? 'خفيف' : 'Mild')}
              </Text>
            </View>
          )}

          {message.suggested_action && (
            <View style={styles.actionSuggestion}>
              <Text style={styles.actionText}>{message.suggested_action}</Text>
            </View>
          )}
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Bot size={32} color="#0891b2" />
          <View style={styles.headerTextContainer}>
            <Text style={styles.headerTitle}>
              {language === 'ar' ? 'الطبيب الذكي' : 'AI Doctor'}
            </Text>
            <Text style={styles.headerSubtitle}>
              {language === 'ar' ? 'مُعافى' : 'Muaafa'}
            </Text>
          </View>
        </View>
        <TouchableOpacity style={styles.newChatButton} onPress={startNewChat}>
          <MessageCircle size={24} color="#0891b2" />
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        style={styles.chatContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={100}
      >
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#0891b2" />
          </View>
        ) : messages.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Bot size={64} color="#cbd5e1" />
            <Text style={styles.emptyTitle}>
              {language === 'ar' ? 'مرحباً بك في الطبيب الذكي' : 'Welcome to AI Doctor'}
            </Text>
            <Text style={styles.emptyDescription}>
              {language === 'ar'
                ? 'ابدأ محادثة جديدة واسأل عن أي استفسار صحي'
                : 'Start a new conversation and ask any health question'}
            </Text>
          </View>
        ) : (
          <ScrollView
            ref={scrollViewRef}
            style={styles.messagesContainer}
            contentContainerStyle={styles.messagesContent}
            showsVerticalScrollIndicator={false}
          >
            {messages.map(renderMessage)}
            {isSending && (
              <View style={styles.typingIndicator}>
                <ActivityIndicator size="small" color="#0891b2" />
                <Text style={styles.typingText}>
                  {language === 'ar' ? 'جاري الكتابة...' : 'Typing...'}
                </Text>
              </View>
            )}
          </ScrollView>
        )}

        <View style={styles.inputWrapper}>
          {attachedImages.length > 0 && (
            <ScrollView
              horizontal
              style={styles.imagesPreview}
              showsHorizontalScrollIndicator={false}
            >
              {attachedImages.map((uri, index) => (
                <View key={index} style={styles.imagePreviewContainer}>
                  <Image source={{ uri }} style={styles.imagePreview} />
                  <TouchableOpacity
                    style={styles.removeImageButton}
                    onPress={() => removeImage(index)}
                  >
                    <X size={16} color="#fff" />
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          )}

          <View style={styles.inputContainer}>
            <TouchableOpacity
              style={styles.attachButton}
              onPress={pickImage}
              disabled={isSending}
            >
              <Paperclip size={20} color="#64748b" />
            </TouchableOpacity>

            <TextInput
              style={styles.input}
              value={inputText}
              onChangeText={setInputText}
              placeholder={
                language === 'ar'
                  ? 'اكتب استفسارك الصحي هنا...'
                  : 'Type your health question here...'
              }
              placeholderTextColor="#94a3b8"
              multiline
              maxLength={500}
              editable={!isSending}
            />

            <TouchableOpacity
              style={[styles.sendButton, (!inputText.trim() || isSending) && styles.sendButtonDisabled]}
              onPress={sendMessage}
              disabled={!inputText.trim() || isSending}
            >
              {isSending ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <Send size={20} color="#fff" />
              )}
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerTextContainer: {
    gap: 2,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
  },
  newChatButton: {
    padding: 8,
  },
  chatContainer: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
    gap: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1e293b',
    textAlign: 'center',
  },
  emptyDescription: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
    gap: 16,
  },
  messageContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8,
  },
  userMessageContainer: {
    justifyContent: 'flex-end',
  },
  assistantMessageContainer: {
    justifyContent: 'flex-start',
  },
  messageHeader: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0891b2',
  },
  messageBubble: {
    maxWidth: '75%',
    padding: 12,
    borderRadius: 16,
    gap: 8,
  },
  userBubble: {
    backgroundColor: '#0891b2',
    borderBottomRightRadius: 4,
  },
  assistantBubble: {
    backgroundColor: '#fff',
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  messageText: {
    fontSize: 16,
    lineHeight: 24,
  },
  userMessageText: {
    color: '#fff',
  },
  assistantMessageText: {
    color: '#1e293b',
  },
  severityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    marginTop: 4,
  },
  severity_mild: {
    backgroundColor: '#22c55e',
  },
  severity_moderate: {
    backgroundColor: '#f59e0b',
  },
  severity_severe: {
    backgroundColor: '#ef4444',
  },
  severity_emergency: {
    backgroundColor: '#dc2626',
  },
  severityText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  actionSuggestion: {
    backgroundColor: '#fef3c7',
    padding: 8,
    borderRadius: 8,
    marginTop: 4,
  },
  actionText: {
    color: '#92400e',
    fontSize: 14,
    lineHeight: 20,
  },
  typingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  typingText: {
    fontSize: 14,
    color: '#64748b',
    fontStyle: 'italic',
  },
  inputWrapper: {
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  imagesPreview: {
    padding: 12,
    paddingTop: 8,
  },
  imagePreviewContainer: {
    position: 'relative',
    marginRight: 8,
  },
  imagePreview: {
    width: 80,
    height: 80,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
  },
  removeImageButton: {
    position: 'absolute',
    top: -6,
    right: -6,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#ef4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 16,
    gap: 12,
  },
  attachButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    backgroundColor: '#f1f5f9',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#1e293b',
    maxHeight: 100,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#0891b2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: '#cbd5e1',
  },
});
