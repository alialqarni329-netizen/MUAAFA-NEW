import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import {
  Activity, Footprints, Flame, Heart, Moon, TrendingUp, Plus,
  Droplet, Sparkles, Gift, AlertCircle, BarChart3, Share2, Zap, Target
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface TodayActivity {
  steps: number;
  calories_burned: number;
  heart_rate_avg: number;
  sleep_hours: number;
  distance_km: number;
  active_minutes: number;
  water_intake_ml: number;
  mood?: string;
  shared_with_doctor?: boolean;
}

interface HealthScan {
  id: string;
  stress_level: number;
  hydration_level: number;
  fatigue_level: number;
  created_at: string;
}

interface AIRecommendation {
  id: string;
  recommendation_type: string;
  title: string;
  description: string;
  reason: string;
  priority: number;
}

interface LoyaltyPoints {
  points: number;
  fitness_earnings: number;
}

export default function FitnessTabScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [todayActivity, setTodayActivity] = useState<TodayActivity | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [latestScan, setLatestScan] = useState<HealthScan | null>(null);
  const [aiRecommendations, setAIRecommendations] = useState<AIRecommendation[]>([]);
  const [loyaltyPoints, setLoyaltyPoints] = useState<LoyaltyPoints | null>(null);
  const [weeklyData, setWeeklyData] = useState<any[]>([]);

  useEffect(() => {
    loadAllData();
    setupRealtimeUpdates();
  }, []);

  function setupRealtimeUpdates() {
    const channel = supabase
      .channel('fitness_updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'fitness_activities' }, () => {
        loadTodayActivity();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'fitness_ai_recommendations' }, () => {
        loadAIRecommendations();
      })
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }

  async function loadAllData() {
    await Promise.all([
      loadTodayActivity(),
      loadLatestHealthScan(),
      loadAIRecommendations(),
      loadLoyaltyPoints(),
      loadWeeklyData(),
    ]);
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadAllData();
    setRefreshing(false);
  }

  async function loadTodayActivity() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const today = new Date().toISOString().split('T')[0];

      const { data, error } = await supabase
        .from('fitness_activities')
        .select('*')
        .eq('user_id', user.id)
        .eq('activity_date', today)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      setTodayActivity(data || {
        steps: 0,
        calories_burned: 0,
        heart_rate_avg: 0,
        sleep_hours: 0,
        distance_km: 0,
        active_minutes: 0,
        water_intake_ml: 0,
      });
    } catch (error: any) {
      console.error('Error loading activity:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadLatestHealthScan() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('health_scans')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      setLatestScan(data);

      if (data) {
        await generateAIRecommendationsFromScan(data);
      }
    } catch (error) {
      console.error('Error loading health scan:', error);
    }
  }

  async function generateAIRecommendationsFromScan(scan: HealthScan) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const recommendations = [];

      if (scan.stress_level >= 7) {
        recommendations.push({
          user_id: user.id,
          recommendation_type: 'stretching',
          title: language === 'ar' ? 'نلاحظ أنك مجهد اليوم' : 'We notice you are stressed today',
          description: language === 'ar'
            ? 'نقترح عليك تمارين إطالة (Stretching) بدلاً من الجري لتخفيف التوتر'
            : 'We suggest stretching exercises instead of running to reduce stress',
          reason: `Stress level detected: ${scan.stress_level}/10`,
          priority: 5,
          based_on_scan_id: scan.id,
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        });
      }

      if (scan.hydration_level <= 4) {
        recommendations.push({
          user_id: user.id,
          recommendation_type: 'hydration',
          title: language === 'ar' ? 'مستوى الجفاف منخفض' : 'Low hydration level',
          description: language === 'ar'
            ? 'اشرب 3 لترات ماء اليوم. سنذكرك بذلك!'
            : 'Drink 3 liters of water today. We will remind you!',
          reason: `Hydration level: ${scan.hydration_level}/10`,
          priority: 4,
          based_on_scan_id: scan.id,
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        });
      }

      if (scan.fatigue_level >= 7) {
        recommendations.push({
          user_id: user.id,
          recommendation_type: 'rest',
          title: language === 'ar' ? 'جسمك يحتاج للراحة' : 'Your body needs rest',
          description: language === 'ar'
            ? 'نقترح عليك أخذ استراحة اليوم والاستماع لجسمك'
            : 'We suggest taking a break today and listening to your body',
          reason: `Fatigue level: ${scan.fatigue_level}/10`,
          priority: 5,
          based_on_scan_id: scan.id,
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        });
      }

      if (recommendations.length > 0) {
        await supabase.from('fitness_ai_recommendations').insert(recommendations);
      }
    } catch (error) {
      console.error('Error generating AI recommendations:', error);
    }
  }

  async function loadAIRecommendations() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('fitness_ai_recommendations')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_read', false)
        .gte('expires_at', new Date().toISOString())
        .order('priority', { ascending: false })
        .limit(3);

      if (error) throw error;
      setAIRecommendations(data || []);
    } catch (error) {
      console.error('Error loading AI recommendations:', error);
    }
  }

  async function loadLoyaltyPoints() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('loyalty_points')
        .select('points, fitness_earnings')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      setLoyaltyPoints(data || { points: 0, fitness_earnings: 0 });
    } catch (error) {
      console.error('Error loading loyalty points:', error);
    }
  }

  async function loadWeeklyData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const { data, error } = await supabase
        .from('fitness_activities')
        .select('activity_date, steps, calories_burned, heart_rate_avg')
        .eq('user_id', user.id)
        .gte('activity_date', sevenDaysAgo.toISOString().split('T')[0])
        .order('activity_date', { ascending: true });

      if (error) throw error;
      setWeeklyData(data || []);
    } catch (error) {
      console.error('Error loading weekly data:', error);
    }
  }

  async function convertStepsToCoupon() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const steps = todayActivity?.steps || 0;
      const calories = todayActivity?.calories_burned || 0;

      if (steps < 5000) {
        Alert.alert(
          language === 'ar' ? 'عذراً!' : 'Sorry!',
          language === 'ar'
            ? 'تحتاج إلى 5000 خطوة على الأقل لاستبدال خطواتك بخصم'
            : 'You need at least 5000 steps to convert to a discount'
        );
        return;
      }

      const discountPercentage = Math.min(Math.floor(steps / 1000), 20);
      const couponCode = `FIT${Date.now().toString(36).toUpperCase()}`;

      const { error } = await supabase.from('fitness_coupons').insert({
        user_id: user.id,
        coupon_code: couponCode,
        discount_type: 'percentage',
        discount_value: discountPercentage,
        earned_from_steps: steps,
        earned_from_calories: calories,
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      });

      if (error) throw error;

      const pointsToAdd = Math.floor(steps / 100) + Math.floor(calories / 10);

      const { error: rpcError } = await supabase.rpc('increment', {
        table_name: 'loyalty_points',
        row_id: user.id,
        x: pointsToAdd
      });

      if (rpcError) {
        await supabase.from('loyalty_points').upsert({
          user_id: user.id,
          points: pointsToAdd,
          fitness_earnings: pointsToAdd,
          total_earned: pointsToAdd,
          last_fitness_sync: new Date().toISOString(),
        }, { onConflict: 'user_id' });
      }

      Alert.alert(
        language === 'ar' ? '🎉 تم التحويل!' : '🎉 Converted!',
        language === 'ar'
          ? `تم إنشاء كوبون خصم ${discountPercentage}% لاستخدامه في الصيدلية!\n\nرمز الكوبون: ${couponCode}\n\nحصلت أيضاً على ${pointsToAdd} نقطة مُعافى!`
          : `${discountPercentage}% discount coupon created for pharmacy use!\n\nCoupon Code: ${couponCode}\n\nYou also earned ${pointsToAdd} Muafa Points!`,
        [
          { text: language === 'ar' ? 'رائع!' : 'Great!', style: 'default' },
          {
            text: language === 'ar' ? 'اذهب للصيدلية' : 'Go to Pharmacy',
            onPress: () => router.push('/pharmacy')
          }
        ]
      );

      await loadLoyaltyPoints();
    } catch (error) {
      console.error('Error converting steps to coupon:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'تعذر إنشاء الكوبون' : 'Failed to create coupon'
      );
    }
  }

  async function toggleShareWithDoctor() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const today = new Date().toISOString().split('T')[0];
      const newShareStatus = !(todayActivity?.shared_with_doctor || false);

      const { error } = await supabase
        .from('fitness_activities')
        .update({ shared_with_doctor: newShareStatus })
        .eq('user_id', user.id)
        .eq('activity_date', today);

      if (error) throw error;

      setTodayActivity(prev => prev ? { ...prev, shared_with_doctor: newShareStatus } : null);

      Alert.alert(
        language === 'ar' ? 'تم التحديث' : 'Updated',
        newShareStatus
          ? (language === 'ar' ? 'سيتم مشاركة نشاطك مع طبيبك في الجلسات القادمة' : 'Your activity will be shared with your doctor in upcoming sessions')
          : (language === 'ar' ? 'لن يتم مشاركة نشاطك مع طبيبك' : 'Your activity will not be shared with your doctor')
      );
    } catch (error) {
      console.error('Error toggling share with doctor:', error);
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>
          {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>
          {language === 'ar' ? 'الرياضة' : 'Sports'}
        </Text>
        <Text style={styles.subtitle}>
          {language === 'ar' ? 'نشاطك اليومي' : 'Your Daily Activity'}
        </Text>
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {aiRecommendations.length > 0 && (
          <View style={styles.aiSection}>
            <View style={styles.aiHeader}>
              <Sparkles size={20} color="#f59e0b" strokeWidth={2} />
              <Text style={styles.aiTitle}>
                {language === 'ar' ? 'توصيات ذكية لك' : 'Smart Recommendations for You'}
              </Text>
            </View>
            {aiRecommendations.map((rec) => (
              <View
                key={rec.id}
                style={[
                  styles.aiCard,
                  rec.recommendation_type === 'rest' && styles.aiCardRest,
                  rec.recommendation_type === 'hydration' && styles.aiCardHydration,
                  rec.recommendation_type === 'stretching' && styles.aiCardStretching,
                ]}
              >
                <View style={styles.aiCardHeader}>
                  <AlertCircle size={18} color="#f59e0b" strokeWidth={2} />
                  <Text style={styles.aiCardTitle}>{rec.title}</Text>
                </View>
                <Text style={styles.aiCardDescription}>{rec.description}</Text>
                <Text style={styles.aiCardReason}>{rec.reason}</Text>
              </View>
            ))}
          </View>
        )}

        {loyaltyPoints && loyaltyPoints.fitness_earnings > 0 && (
          <View style={styles.rewardsCard}>
            <View style={styles.rewardsHeader}>
              <Gift size={24} color="#10b981" strokeWidth={2} />
              <View style={styles.rewardsInfo}>
                <Text style={styles.rewardsTitle}>
                  {language === 'ar' ? 'نقاط مُعافى من الفتنس' : 'Muafa Points from Fitness'}
                </Text>
                <Text style={styles.rewardsPoints}>{loyaltyPoints.fitness_earnings}</Text>
              </View>
            </View>
            <Text style={styles.rewardsDescription}>
              {language === 'ar'
                ? 'ربحت هذه النقاط من نشاطك الرياضي! استخدمها للحصول على خصومات.'
                : 'You earned these points from your fitness activity! Use them for discounts.'}
            </Text>
          </View>
        )}
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, styles.stepsCard]}>
            <View style={styles.statIcon}>
              <Footprints size={24} color="#0ea5e9" strokeWidth={2} />
            </View>
            <Text style={styles.statValue}>{todayActivity?.steps || 0}</Text>
            <Text style={styles.statLabel}>خطوة</Text>
            <View style={styles.statProgress}>
              <View
                style={[
                  styles.statProgressBar,
                  { width: `${Math.min(((todayActivity?.steps || 0) / 10000) * 100, 100)}%`, backgroundColor: '#0ea5e9' },
                ]}
              />
            </View>
            <Text style={styles.statGoal}>الهدف: 10,000</Text>
          </View>

          <View style={[styles.statCard, styles.caloriesCard]}>
            <View style={styles.statIcon}>
              <Flame size={24} color="#f59e0b" strokeWidth={2} />
            </View>
            <Text style={styles.statValue}>{todayActivity?.calories_burned || 0}</Text>
            <Text style={styles.statLabel}>سعرة</Text>
            <View style={styles.statProgress}>
              <View
                style={[
                  styles.statProgressBar,
                  { width: `${Math.min(((todayActivity?.calories_burned || 0) / 500) * 100, 100)}%`, backgroundColor: '#f59e0b' },
                ]}
              />
            </View>
            <Text style={styles.statGoal}>الهدف: 500</Text>
          </View>

          <View style={[styles.statCard, styles.heartCard]}>
            <View style={styles.statIcon}>
              <Heart size={24} color="#ef4444" strokeWidth={2} />
            </View>
            <Text style={styles.statValue}>{todayActivity?.heart_rate_avg || 0}</Text>
            <Text style={styles.statLabel}>نبضة/دقيقة</Text>
            <Text style={styles.statSubLabel}>متوسط نبض القلب</Text>
          </View>

          <View style={[styles.statCard, styles.sleepCard]}>
            <View style={styles.statIcon}>
              <Moon size={24} color="#8b5cf6" strokeWidth={2} />
            </View>
            <Text style={styles.statValue}>{todayActivity?.sleep_hours || 0}</Text>
            <Text style={styles.statLabel}>ساعة نوم</Text>
            <View style={styles.statProgress}>
              <View
                style={[
                  styles.statProgressBar,
                  { width: `${Math.min(((todayActivity?.sleep_hours || 0) / 8) * 100, 100)}%`, backgroundColor: '#8b5cf6' },
                ]}
              />
            </View>
            <Text style={styles.statGoal}>الهدف: 8 ساعات</Text>
          </View>
          <View style={[styles.statCard, styles.waterCard]}>
            <View style={styles.statIcon}>
              <Droplet size={24} color="#0ea5e9" strokeWidth={2} />
            </View>
            <Text style={styles.statValue}>
              {Math.floor((todayActivity?.water_intake_ml || 0) / 1000)}
            </Text>
            <Text style={styles.statLabel}>
              {language === 'ar' ? 'لتر ماء' : 'Liters Water'}
            </Text>
            <View style={styles.statProgress}>
              <View
                style={[
                  styles.statProgressBar,
                  { width: `${Math.min(((todayActivity?.water_intake_ml || 0) / 3000) * 100, 100)}%`, backgroundColor: '#0ea5e9' },
                ]}
              />
            </View>
            <Text style={styles.statGoal}>
              {language === 'ar' ? 'الهدف: 3 لترات' : 'Goal: 3 Liters'}
            </Text>
          </View>

          <View style={[styles.statCard, styles.activeCard]}>
            <View style={styles.statIcon}>
              <Zap size={24} color="#10b981" strokeWidth={2} />
            </View>
            <Text style={styles.statValue}>{todayActivity?.active_minutes || 0}</Text>
            <Text style={styles.statLabel}>
              {language === 'ar' ? 'دقيقة نشاط' : 'Active Minutes'}
            </Text>
            <View style={styles.statProgress}>
              <View
                style={[
                  styles.statProgressBar,
                  { width: `${Math.min(((todayActivity?.active_minutes || 0) / 30) * 100, 100)}%`, backgroundColor: '#10b981' },
                ]}
              />
            </View>
            <Text style={styles.statGoal}>
              {language === 'ar' ? 'الهدف: 30 دقيقة' : 'Goal: 30 Minutes'}
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={styles.convertButton}
          onPress={convertStepsToCoupon}
          disabled={(todayActivity?.steps || 0) < 5000}
        >
          <Gift size={20} color="#ffffff" strokeWidth={2} />
          <Text style={styles.convertButtonText}>
            {language === 'ar' ? 'استبدل خطواتك بخصومات' : 'Convert Steps to Discounts'}
          </Text>
        </TouchableOpacity>

        {weeklyData.length > 0 && (
          <View style={styles.weeklyCard}>
            <View style={styles.weeklyHeader}>
              <BarChart3 size={20} color="#0ea5e9" strokeWidth={2} />
              <Text style={styles.weeklyTitle}>
                {language === 'ar' ? 'نشاطك الأسبوعي' : 'Your Weekly Activity'}
              </Text>
            </View>
            <View style={styles.weeklyChart}>
              {weeklyData.map((day, index) => {
                const maxSteps = Math.max(...weeklyData.map(d => d.steps), 10000);
                const height = (day.steps / maxSteps) * 100;
                return (
                  <View key={index} style={styles.weeklyBar}>
                    <View style={[styles.weeklyBarFill, { height: `${height}%` }]} />
                    <Text style={styles.weeklyBarLabel}>
                      {new Date(day.activity_date).getDate()}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        <View style={styles.actionsGrid}>
          <TouchableOpacity
            style={[styles.actionButton, styles.actionButtonPrimary]}
            onPress={() => router.push('/fitness/add-workout')}>
            <Plus size={20} color="#ffffff" strokeWidth={2} />
            <Text style={styles.actionButtonText}>
              {language === 'ar' ? 'إضافة تمرين' : 'Add Workout'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.actionButtonPrimary]}
            onPress={() => router.push('/fitness/create-goal')}>
            <Target size={20} color="#ffffff" strokeWidth={2} />
            <Text style={styles.actionButtonText}>
              {language === 'ar' ? 'إنشاء هدف' : 'Create Goal'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.actionButtonFull, styles.actionButtonSecondary]}
            onPress={() => router.push('/fitness/my-data')}>
            <TrendingUp size={20} color="#0ea5e9" strokeWidth={2} />
            <Text style={[styles.actionButtonText, styles.actionButtonTextSecondary]}>
              {language === 'ar' ? 'تماريني وأهدافي' : 'My Data'}
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.shareWithDoctorCard}
          onPress={toggleShareWithDoctor}
        >
          <Share2 size={20} color="#8b5cf6" strokeWidth={2} />
          <View style={styles.shareWithDoctorInfo}>
            <Text style={styles.shareWithDoctorTitle}>
              {language === 'ar' ? 'مشاركة نشاطي مع طبيبي' : 'Share My Activity with Doctor'}
            </Text>
            <Text style={styles.shareWithDoctorDescription}>
              {language === 'ar'
                ? 'يساعد الطبيب على تقديم تشخيص أدق في الجلسات الافتراضية'
                : 'Helps doctor provide more accurate diagnosis in virtual sessions'}
            </Text>
          </View>
          <View
            style={[
              styles.shareToggle,
              (todayActivity?.shared_with_doctor) && styles.shareToggleActive
            ]}
          >
            <Text style={styles.shareToggleText}>
              {(todayActivity?.shared_with_doctor) ? '✓' : ''}
            </Text>
          </View>
        </TouchableOpacity>

        <View style={styles.securityNotice}>
          <Text style={styles.securityTitle}>
            {language === 'ar' ? '🔒 الخصوصية والأمان' : '🔒 Privacy & Security'}
          </Text>
          <Text style={styles.securityText}>
            {language === 'ar'
              ? 'جميع بياناتك الرياضية مشفرة ومحمية بأعلى معايير الأمان. أنت تتحكم في من يمكنه الوصول إليها.'
              : 'All your fitness data is encrypted and protected with the highest security standards. You control who can access it.'}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#64748b',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  stepsCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#0ea5e9',
  },
  caloriesCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#f59e0b',
  },
  heartCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#ef4444',
  },
  sleepCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#8b5cf6',
  },
  waterCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#06b6d4',
  },
  activeCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#10b981',
  },
  statIcon: {
    marginBottom: 12,
  },
  statValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  statLabel: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  statSubLabel: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
    marginTop: 4,
  },
  statProgress: {
    height: 6,
    backgroundColor: '#f1f5f9',
    borderRadius: 3,
    marginTop: 8,
    overflow: 'hidden',
  },
  statProgressBar: {
    height: '100%',
    borderRadius: 3,
  },
  statGoal: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
    marginTop: 4,
  },
  addWorkoutButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  addWorkoutText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  goalsButton: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: '#0ea5e9',
  },
  goalsButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  infoCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
  },
  infoText: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 22,
  },
  connectCard: {
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    padding: 16,
  },
  connectTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  connectText: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  aiSection: {
    gap: 12,
  },
  aiHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  aiTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  aiCard: {
    backgroundColor: '#fffbeb',
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#f59e0b',
  },
  aiCardRest: {
    backgroundColor: '#fef2f2',
    borderLeftColor: '#ef4444',
  },
  aiCardHydration: {
    backgroundColor: '#ecfeff',
    borderLeftColor: '#06b6d4',
  },
  aiCardStretching: {
    backgroundColor: '#f3e8ff',
    borderLeftColor: '#8b5cf6',
  },
  aiCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  aiCardTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
  },
  aiCardDescription: {
    fontSize: 14,
    color: '#0f172a',
    lineHeight: 20,
    marginBottom: 6,
  },
  aiCardReason: {
    fontSize: 12,
    color: '#64748b',
    fontStyle: 'italic',
  },
  rewardsCard: {
    backgroundColor: '#ecfdf5',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#10b981',
  },
  rewardsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  rewardsInfo: {
    flex: 1,
  },
  rewardsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#064e3b',
    marginBottom: 4,
  },
  rewardsPoints: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#10b981',
  },
  rewardsDescription: {
    fontSize: 13,
    color: '#065f46',
    lineHeight: 18,
  },
  convertButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  convertButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  weeklyCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  weeklyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  weeklyTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  weeklyChart: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 120,
    gap: 8,
  },
  weeklyBar: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  weeklyBarFill: {
    width: '100%',
    backgroundColor: '#0ea5e9',
    borderRadius: 4,
    minHeight: 10,
  },
  weeklyBarLabel: {
    fontSize: 10,
    color: '#64748b',
    marginTop: 4,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    minWidth: '47%',
    borderRadius: 12,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  actionButtonPrimary: {
    backgroundColor: '#10b981',
  },
  actionButtonFull: {
    minWidth: '100%',
  },
  actionButtonSecondary: {
    backgroundColor: '#eff6ff',
    borderWidth: 1,
    borderColor: '#0ea5e9',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  actionButtonTextSecondary: {
    color: '#0ea5e9',
  },
  shareWithDoctorCard: {
    backgroundColor: '#faf5ff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: '#8b5cf6',
  },
  shareWithDoctorInfo: {
    flex: 1,
  },
  shareWithDoctorTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  shareWithDoctorDescription: {
    fontSize: 12,
    color: '#64748b',
    lineHeight: 16,
  },
  shareToggle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#8b5cf6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  shareToggleActive: {
    backgroundColor: '#8b5cf6',
  },
  shareToggleText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  securityNotice: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  securityTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
  },
  securityText: {
    fontSize: 13,
    color: '#64748b',
    lineHeight: 19,
  },
});
