import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  ActivityIndicator,
  Modal,
  Image,
  Platform,
} from 'react-native';
import { useState, useEffect } from 'react';
import {
  MessageCircle,
  Video,
  FileImage,
  Search,
  X,
  CheckSquare,
  Square,
  Trash2,
  Download,
  Eye,
  Edit3,
  FileText,
  Calendar,
  Clock,
  User,
  Filter,
  ChevronRight,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'expo-router';

interface HistoryItem {
  id: string;
  type: 'chat' | 'session' | 'image';
  title: string;
  subtitle?: string;
  date: string;
  time?: string;
  preview?: string;
  imageUrl?: string;
  status?: 'completed' | 'pending' | 'cancelled' | 'archived';
  category?: string;
  doctorName?: string;
  metadata?: any;
  created_at: string;
}

type FilterType = 'all' | 'chat' | 'session' | 'image';

export default function HistoryScreen() {
  const { language } = useLanguage();
  const router = useRouter();
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState<HistoryItem | null>(null);

  useEffect(() => {
    loadHistory();
  }, []);

  useEffect(() => {
    filterAndSearch();
  }, [activeFilter, searchQuery, historyItems]);

  async function loadHistory() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      const items: HistoryItem[] = [];

      const { data: conversations } = await supabase
        .from('chat_conversations')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (conversations) {
        conversations.forEach((conv) => {
          items.push({
            id: conv.id,
            type: 'chat',
            title: conv.title || (language === 'ar' ? 'محادثة صحية' : 'Health Chat'),
            subtitle: language === 'ar' ? 'استشارة مع الذكاء الاصطناعي' : 'AI Health Consultation',
            date: new Date(conv.created_at).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US'),
            time: new Date(conv.created_at).toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
              hour: '2-digit',
              minute: '2-digit',
            }),
            status: 'completed',
            preview: conv.summary || '',
            created_at: conv.created_at,
            metadata: conv,
          });
        });
      }

      const { data: appointments } = await supabase
        .from('appointments')
        .select(`
          *,
          doctor:doctor_id (
            full_name,
            specialty
          )
        `)
        .eq('patient_id', user.id)
        .order('appointment_date', { ascending: false });

      if (appointments) {
        appointments.forEach((apt: any) => {
          const appointmentDate = new Date(apt.appointment_date);
          items.push({
            id: apt.id,
            type: 'session',
            title: language === 'ar' ? 'جلسة عن بُعد' : 'Virtual Session',
            subtitle: apt.doctor?.full_name || (language === 'ar' ? 'طبيب مختص' : 'Specialist'),
            doctorName: apt.doctor?.full_name,
            date: appointmentDate.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US'),
            time: appointmentDate.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
              hour: '2-digit',
              minute: '2-digit',
            }),
            status: apt.status as any,
            preview: apt.doctor?.specialty || '',
            created_at: apt.appointment_date,
            metadata: apt,
          });
        });
      }

      const { data: images } = await supabase
        .from('uploaded_images')
        .select('*')
        .eq('user_id', user.id)
        .order('uploaded_at', { ascending: false });

      if (images) {
        images.forEach((img) => {
          items.push({
            id: img.id,
            type: 'image',
            title: img.description || (language === 'ar' ? 'صورة طبية' : 'Medical Image'),
            subtitle: img.image_type || (language === 'ar' ? 'صورة مرفوعة' : 'Uploaded Image'),
            category: img.image_type,
            date: new Date(img.uploaded_at).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US'),
            time: new Date(img.uploaded_at).toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
              hour: '2-digit',
              minute: '2-digit',
            }),
            imageUrl: img.image_url,
            status: img.analysis_status === 'completed' ? 'completed' : 'pending',
            preview: img.notes || '',
            created_at: img.uploaded_at,
            metadata: img,
          });
        });
      }

      const { data: medicalImages } = await supabase
        .from('image_analysis')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (medicalImages) {
        medicalImages.forEach((img) => {
          items.push({
            id: `analysis-${img.id}`,
            type: 'image',
            title: language === 'ar' ? 'تحليل صورة طبية' : 'Medical Image Analysis',
            subtitle: img.body_part || (language === 'ar' ? 'تحليل بالذكاء الاصطناعي' : 'AI Analysis'),
            category: 'analysis',
            date: new Date(img.created_at).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US'),
            time: new Date(img.created_at).toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
              hour: '2-digit',
              minute: '2-digit',
            }),
            status: 'completed',
            preview: img.analysis_text || '',
            created_at: img.created_at,
            metadata: img,
          });
        });
      }

      const { data: medicalDocs } = await supabase
        .from('medical_documents')
        .select('*')
        .eq('user_id', user.id)
        .order('uploaded_at', { ascending: false });

      if (medicalDocs) {
        medicalDocs.forEach((doc) => {
          items.push({
            id: `doc-${doc.id}`,
            type: 'image',
            title: doc.document_name || (language === 'ar' ? 'مستند طبي' : 'Medical Document'),
            subtitle: doc.document_type || (language === 'ar' ? 'وثيقة' : 'Document'),
            category: doc.document_type,
            date: new Date(doc.uploaded_at).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US'),
            time: new Date(doc.uploaded_at).toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
              hour: '2-digit',
              minute: '2-digit',
            }),
            imageUrl: doc.file_url,
            status: 'archived',
            preview: doc.notes || '',
            created_at: doc.uploaded_at,
            metadata: doc,
          });
        });
      }

      items.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      setHistoryItems(items);
    } catch (error) {
      console.error('Error loading history:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'حدث خطأ أثناء تحميل السجلات' : 'Error loading history'
      );
    } finally {
      setLoading(false);
    }
  }

  function filterAndSearch() {
    let filtered = historyItems;

    if (activeFilter !== 'all') {
      filtered = filtered.filter((item) => item.type === activeFilter);
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(query) ||
          item.subtitle?.toLowerCase().includes(query) ||
          item.preview?.toLowerCase().includes(query) ||
          item.doctorName?.toLowerCase().includes(query) ||
          item.category?.toLowerCase().includes(query)
      );
    }

    setFilteredItems(filtered);
  }

  function toggleEditMode() {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setEditMode(!editMode);
    setSelectedItems(new Set());
  }

  function toggleItemSelection(id: string) {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    const newSelected = new Set(selectedItems);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedItems(newSelected);
  }

  async function deleteSelectedItems() {
    if (selectedItems.size === 0) return;

    Alert.alert(
      language === 'ar' ? 'تأكيد الحذف' : 'Confirm Deletion',
      language === 'ar'
        ? `هل تريد حذف ${selectedItems.size} عنصر؟ لا يمكن التراجع عن هذا الإجراء.`
        : `Delete ${selectedItems.size} item(s)? This action cannot be undone.`,
      [
        { text: language === 'ar' ? 'إلغاء' : 'Cancel', style: 'cancel' },
        {
          text: language === 'ar' ? 'حذف' : 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              const {
                data: { user },
              } = await supabase.auth.getUser();
              if (!user) return;

              for (const id of selectedItems) {
                const item = historyItems.find((i) => i.id === id);
                if (!item) continue;

                if (item.type === 'chat') {
                  await supabase.from('chat_conversations').delete().eq('id', id).eq('user_id', user.id);
                } else if (item.type === 'session') {
                  await supabase.from('appointments').delete().eq('id', id).eq('patient_id', user.id);
                } else if (item.type === 'image') {
                  if (id.startsWith('analysis-')) {
                    const actualId = id.replace('analysis-', '');
                    await supabase.from('image_analysis').delete().eq('id', actualId).eq('user_id', user.id);
                  } else if (id.startsWith('doc-')) {
                    const actualId = id.replace('doc-', '');
                    await supabase.from('medical_documents').delete().eq('id', actualId).eq('user_id', user.id);
                  } else {
                    await supabase.from('uploaded_images').delete().eq('id', id).eq('user_id', user.id);
                  }
                }
              }

              setSelectedItems(new Set());
              setEditMode(false);
              await loadHistory();

              Alert.alert(
                language === 'ar' ? 'تم الحذف' : 'Deleted',
                language === 'ar' ? 'تم حذف العناصر بنجاح' : 'Items deleted successfully'
              );
            } catch (error) {
              console.error('Error deleting items:', error);
              Alert.alert(
                language === 'ar' ? 'خطأ' : 'Error',
                language === 'ar' ? 'حدث خطأ أثناء الحذف' : 'Error deleting items'
              );
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  }

  async function clearAllHistory() {
    Alert.alert(
      language === 'ar' ? 'مسح جميع السجلات' : 'Clear All History',
      language === 'ar'
        ? 'هل تريد حذف جميع السجلات نهائياً؟ لا يمكن التراجع عن هذا الإجراء!'
        : 'Delete all records permanently? This action cannot be undone!',
      [
        { text: language === 'ar' ? 'إلغاء' : 'Cancel', style: 'cancel' },
        {
          text: language === 'ar' ? 'مسح الكل' : 'Clear All',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              const {
                data: { user },
              } = await supabase.auth.getUser();
              if (!user) return;

              await Promise.all([
                supabase.from('chat_conversations').delete().eq('user_id', user.id),
                supabase.from('uploaded_images').delete().eq('user_id', user.id),
                supabase.from('image_analysis').delete().eq('user_id', user.id),
                supabase.from('medical_documents').delete().eq('user_id', user.id),
              ]);

              setEditMode(false);
              setSelectedItems(new Set());
              await loadHistory();

              Alert.alert(
                language === 'ar' ? 'تم المسح' : 'Cleared',
                language === 'ar' ? 'تم مسح جميع السجلات' : 'All history cleared'
              );
            } catch (error) {
              console.error('Error clearing history:', error);
              Alert.alert(
                language === 'ar' ? 'خطأ' : 'Error',
                language === 'ar' ? 'حدث خطأ أثناء المسح' : 'Error clearing history'
              );
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  }

  function handleItemPress(item: HistoryItem) {
    if (editMode) {
      toggleItemSelection(item.id);
      return;
    }

    if (item.type === 'image' && item.imageUrl) {
      setSelectedImage(item);
      setShowImageModal(true);
    } else if (item.type === 'session') {
      Alert.alert(
        item.title,
        `${language === 'ar' ? 'الطبيب' : 'Doctor'}: ${item.doctorName}\n${language === 'ar' ? 'التاريخ' : 'Date'}: ${item.date} ${item.time}\n${language === 'ar' ? 'الحالة' : 'Status'}: ${getStatusText(item.status)}`
      );
    } else if (item.type === 'chat') {
      Alert.alert(item.title, item.preview || (language === 'ar' ? 'محادثة صحية' : 'Health chat'));
    }
  }

  function getStatusText(status?: string) {
    switch (status) {
      case 'completed':
        return language === 'ar' ? 'مكتملة' : 'Completed';
      case 'pending':
        return language === 'ar' ? 'قيد الانتظار' : 'Pending';
      case 'cancelled':
        return language === 'ar' ? 'ملغاة' : 'Cancelled';
      case 'archived':
        return language === 'ar' ? 'مؤرشف' : 'Archived';
      default:
        return '';
    }
  }

  function getStatusColor(status?: string) {
    switch (status) {
      case 'completed':
        return '#10b981';
      case 'pending':
        return '#f59e0b';
      case 'cancelled':
        return '#ef4444';
      case 'archived':
        return '#64748b';
      default:
        return '#94a3b8';
    }
  }

  function getTypeIcon(type: string) {
    switch (type) {
      case 'chat':
        return <MessageCircle size={22} color="#0ea5e9" strokeWidth={2} />;
      case 'session':
        return <Video size={22} color="#8b5cf6" strokeWidth={2} />;
      case 'image':
        return <FileImage size={22} color="#10b981" strokeWidth={2} />;
      default:
        return null;
    }
  }

  function renderImageModal() {
    if (!selectedImage) return null;

    return (
      <Modal visible={showImageModal} animationType="fade" transparent onRequestClose={() => setShowImageModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.imageModalContainer}>
            <View style={styles.imageModalHeader}>
              <Text style={styles.imageModalTitle}>{selectedImage.title}</Text>
              <TouchableOpacity onPress={() => setShowImageModal(false)}>
                <X size={24} color="#64748b" strokeWidth={2} />
              </TouchableOpacity>
            </View>

            {selectedImage.imageUrl && (
              <Image source={{ uri: selectedImage.imageUrl }} style={styles.modalImage} resizeMode="contain" />
            )}

            <View style={styles.imageModalInfo}>
              <Text style={styles.imageModalSubtitle}>{selectedImage.subtitle}</Text>
              <Text style={styles.imageModalDate}>
                {selectedImage.date} - {selectedImage.time}
              </Text>
              {selectedImage.preview && <Text style={styles.imageModalPreview}>{selectedImage.preview}</Text>}
            </View>

            <View style={styles.imageModalActions}>
              <TouchableOpacity style={styles.imageModalButton}>
                <Download size={20} color="#0ea5e9" strokeWidth={2} />
                <Text style={styles.imageModalButtonText}>{language === 'ar' ? 'تحميل' : 'Download'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>{language === 'ar' ? 'جاري التحميل...' : 'Loading...'}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Text style={styles.headerTitle}>{language === 'ar' ? 'السجلات الصحية' : 'Health Records'}</Text>
          <TouchableOpacity style={styles.editButton} onPress={toggleEditMode}>
            {editMode ? (
              <X size={20} color="#ffffff" strokeWidth={2} />
            ) : (
              <Edit3 size={20} color="#ffffff" strokeWidth={2} />
            )}
          </TouchableOpacity>
        </View>
        <Text style={styles.headerSubtitle}>
          {language === 'ar' ? 'مركز الأرشفة الصحي الخاص بك' : 'Your Health Archive Center'}
        </Text>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Search size={20} color="#94a3b8" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder={language === 'ar' ? 'ابحث في السجلات...' : 'Search records...'}
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery !== '' && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <X size={20} color="#94a3b8" strokeWidth={2} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll}>
        <View style={styles.filterContainer}>
          {[
            { key: 'all', label: language === 'ar' ? 'الكل' : 'All' },
            { key: 'chat', label: language === 'ar' ? 'المحادثات' : 'Chats' },
            { key: 'session', label: language === 'ar' ? 'الجلسات' : 'Sessions' },
            { key: 'image', label: language === 'ar' ? 'الصور' : 'Images' },
          ].map((filter) => (
            <TouchableOpacity
              key={filter.key}
              style={[styles.filterButton, activeFilter === filter.key && styles.filterButtonActive]}
              onPress={() => {
                if (Platform.OS !== 'web') {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }
                setActiveFilter(filter.key as FilterType);
              }}
            >
              <Text style={[styles.filterButtonText, activeFilter === filter.key && styles.filterButtonTextActive]}>
                {filter.label}
              </Text>
              <View
                style={[styles.filterBadge, activeFilter === filter.key && styles.filterBadgeActive]}
              >
                <Text style={[styles.filterBadgeText, activeFilter === filter.key && styles.filterBadgeTextActive]}>
                  {filter.key === 'all'
                    ? historyItems.length
                    : historyItems.filter((i) => i.type === filter.key).length}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {filteredItems.length === 0 ? (
          <View style={styles.emptyState}>
            <FileText size={64} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyStateTitle}>
              {searchQuery
                ? language === 'ar'
                  ? 'لا توجد نتائج'
                  : 'No results found'
                : language === 'ar'
                  ? 'لا توجد سجلات'
                  : 'No records yet'}
            </Text>
            <Text style={styles.emptyStateText}>
              {searchQuery
                ? language === 'ar'
                  ? 'جرب البحث بكلمات مختلفة'
                  : 'Try searching with different keywords'
                : language === 'ar'
                  ? 'ستظهر سجلاتك الصحية هنا'
                  : 'Your health records will appear here'}
            </Text>
          </View>
        ) : (
          filteredItems.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={[styles.historyCard, editMode && selectedItems.has(item.id) && styles.historyCardSelected]}
              onPress={() => handleItemPress(item)}
              activeOpacity={0.7}
            >
              {editMode && (
                <View style={styles.checkboxContainer}>
                  {selectedItems.has(item.id) ? (
                    <CheckSquare size={24} color="#0ea5e9" strokeWidth={2} />
                  ) : (
                    <Square size={24} color="#cbd5e1" strokeWidth={2} />
                  )}
                </View>
              )}

              <View style={styles.cardIcon}>{getTypeIcon(item.type)}</View>

              <View style={styles.cardContent}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardTitle} numberOfLines={1}>
                    {item.title}
                  </Text>
                  {item.status && (
                    <View style={[styles.statusBadge, { backgroundColor: `${getStatusColor(item.status)}15` }]}>
                      <View
                        style={[
                          styles.statusDot,
                          {
                            backgroundColor: getStatusColor(item.status),
                          },
                        ]}
                      />
                      <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>
                        {getStatusText(item.status)}
                      </Text>
                    </View>
                  )}
                </View>

                {item.subtitle && (
                  <View style={styles.cardSubtitle}>
                    <User size={14} color="#64748b" strokeWidth={2} />
                    <Text style={styles.cardSubtitleText} numberOfLines={1}>
                      {item.subtitle}
                    </Text>
                  </View>
                )}

                {item.preview && (
                  <Text style={styles.cardPreview} numberOfLines={2}>
                    {item.preview}
                  </Text>
                )}

                <View style={styles.cardFooter}>
                  <View style={styles.cardDate}>
                    <Calendar size={14} color="#94a3b8" strokeWidth={2} />
                    <Text style={styles.cardDateText}>{item.date}</Text>
                  </View>
                  {item.time && (
                    <View style={styles.cardTime}>
                      <Clock size={14} color="#94a3b8" strokeWidth={2} />
                      <Text style={styles.cardTimeText}>{item.time}</Text>
                    </View>
                  )}
                </View>
              </View>

              {!editMode && <ChevronRight size={20} color="#cbd5e1" strokeWidth={2} />}
            </TouchableOpacity>
          ))
        )}
      </ScrollView>

      {editMode && (
        <View style={styles.bulkActionsBar}>
          <View style={styles.bulkActionsContent}>
            <Text style={styles.bulkActionsText}>
              {language === 'ar'
                ? `${selectedItems.size} عنصر محدد`
                : `${selectedItems.size} item(s) selected`}
            </Text>
            <View style={styles.bulkActionsButtons}>
              {selectedItems.size > 0 && (
                <TouchableOpacity style={styles.bulkDeleteButton} onPress={deleteSelectedItems}>
                  <Trash2 size={18} color="#ffffff" strokeWidth={2} />
                  <Text style={styles.bulkDeleteButtonText}>{language === 'ar' ? 'حذف المحدد' : 'Delete'}</Text>
                </TouchableOpacity>
              )}
              {historyItems.length > 0 && (
                <TouchableOpacity style={styles.bulkClearButton} onPress={clearAllHistory}>
                  <Text style={styles.bulkClearButtonText}>{language === 'ar' ? 'مسح الكل' : 'Clear All'}</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </View>
      )}

      {renderImageModal()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    backgroundColor: '#0ea5e9',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#e0f2fe',
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  filterScroll: {
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 12,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  filterButtonActive: {
    backgroundColor: '#0ea5e9',
    borderColor: '#0ea5e9',
  },
  filterButtonText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#64748b',
  },
  filterButtonTextActive: {
    color: '#ffffff',
  },
  filterBadge: {
    backgroundColor: '#e2e8f0',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    minWidth: 24,
    alignItems: 'center',
  },
  filterBadgeActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  filterBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#64748b',
  },
  filterBadgeTextActive: {
    color: '#ffffff',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  historyCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  historyCardSelected: {
    borderColor: '#0ea5e9',
    backgroundColor: '#eff6ff',
  },
  checkboxContainer: {
    marginRight: 8,
  },
  cardIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
  },
  cardSubtitle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  cardSubtitleText: {
    fontSize: 14,
    color: '#64748b',
    flex: 1,
  },
  cardPreview: {
    fontSize: 13,
    color: '#94a3b8',
    lineHeight: 18,
    marginBottom: 8,
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  cardDate: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  cardDateText: {
    fontSize: 12,
    color: '#94a3b8',
  },
  cardTime: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  cardTimeText: {
    fontSize: 12,
    color: '#94a3b8',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 20,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 15,
    color: '#64748b',
    textAlign: 'center',
  },
  bulkActionsBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    paddingHorizontal: 20,
    paddingVertical: 16,
    paddingBottom: 32,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 8,
  },
  bulkActionsContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bulkActionsText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0f172a',
  },
  bulkActionsButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  bulkDeleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#ef4444',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  bulkDeleteButtonText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  bulkClearButton: {
    backgroundColor: '#f1f5f9',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  bulkClearButtonText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#64748b',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageModalContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    width: '90%',
    maxHeight: '80%',
    overflow: 'hidden',
  },
  imageModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  imageModalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
  },
  modalImage: {
    width: '100%',
    height: 300,
    backgroundColor: '#f8fafc',
  },
  imageModalInfo: {
    padding: 20,
  },
  imageModalSubtitle: {
    fontSize: 15,
    color: '#64748b',
    marginBottom: 8,
  },
  imageModalDate: {
    fontSize: 13,
    color: '#94a3b8',
    marginBottom: 12,
  },
  imageModalPreview: {
    fontSize: 14,
    color: '#0f172a',
    lineHeight: 22,
  },
  imageModalActions: {
    flexDirection: 'row',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  imageModalButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#eff6ff',
    paddingVertical: 14,
    borderRadius: 12,
  },
  imageModalButtonText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0ea5e9',
  },
});
