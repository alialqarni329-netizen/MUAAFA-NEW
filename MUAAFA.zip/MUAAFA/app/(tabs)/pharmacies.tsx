import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  Pill,
  Camera,
  ScanBarcode,
  Package,
  TrendingUp,
  Zap,
  MessageCircle,
  Trophy,
  AlertCircle,
  Bot,
  Mic,
  Search,
  ChevronLeft,
  Construction,
  Eye,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface PharmacyCategory {
  id: string;
  name: string;
  name_en: string;
  description: string;
  icon: string;
  sort_order: number;
}

interface QuickAction {
  id: string;
  title: string;
  subtitle: string;
  icon: any;
  color: string;
  bgColor: string;
  route: string;
}

export default function PharmaciesTabScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [categories, setCategories] = useState<PharmacyCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [loyaltyPoints, setLoyaltyPoints] = useState(0);
  const [medicineCabinetCount, setMedicineCabinetCount] = useState(0);
  const [showDevelopmentModal, setShowDevelopmentModal] = useState(false);

  useEffect(() => {
    checkFirstVisit();
    loadData();
  }, []);

  async function checkFirstVisit() {
    try {
      const hasVisited = await AsyncStorage.getItem('pharmacy_visited');
      if (!hasVisited) {
        setShowDevelopmentModal(true);
      }
    } catch (error) {
      console.error('Error checking first visit:', error);
    }
  }

  async function handleContinue() {
    try {
      await AsyncStorage.setItem('pharmacy_visited', 'true');
      setShowDevelopmentModal(false);
    } catch (error) {
      console.error('Error saving visit:', error);
    }
  }

  async function loadData() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const [categoriesRes, pointsRes, cabinetRes] = await Promise.all([
        supabase
          .from('pharmacy_categories')
          .select('*')
          .eq('is_active', true)
          .order('sort_order', { ascending: true }),
        supabase.from('loyalty_points').select('points').eq('user_id', user.id).maybeSingle(),
        supabase.from('medicine_cabinet').select('id', { count: 'exact' }).eq('user_id', user.id),
      ]);

      if (categoriesRes.data) setCategories(categoriesRes.data);
      if (pointsRes.data) setLoyaltyPoints(pointsRes.data.points);
      if (cabinetRes.count) setMedicineCabinetCount(cabinetRes.count);
    } catch (error: any) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }

  const quickActions: QuickAction[] = [
    {
      id: 'scan-prescription',
      title: t('pharmacy.scanPrescription'),
      subtitle: t('pharmacy.prescription.title'),
      icon: Camera,
      color: '#0ea5e9',
      bgColor: '#e0f2fe',
      route: '/pharmacy/scan-prescription',
    },
    {
      id: 'medicine-cabinet',
      title: t('pharmacy.myMedicineCabinet'),
      subtitle: `${medicineCabinetCount} ${language === 'ar' ? 'دواء' : 'medicines'}`,
      icon: Package,
      color: '#8b5cf6',
      bgColor: '#f3e8ff',
      route: '/pharmacy/medicine-cabinet',
    },
    {
      id: 'price-comparison',
      title: t('pharmacy.priceComparison'),
      subtitle: t('pharmacy.priceWatch.title'),
      icon: TrendingUp,
      color: '#10b981',
      bgColor: '#d1fae5',
      route: '/pharmacy/price-comparison',
    },
    {
      id: 'emergency-delivery',
      title: t('pharmacy.emergencyDelivery'),
      subtitle: t('pharmacy.emergencyDelivery.description'),
      icon: Zap,
      color: '#f59e0b',
      bgColor: '#fef3c7',
      route: '/pharmacy/emergency-delivery',
    },
    {
      id: 'pharmacist-consultation',
      title: t('pharmacy.consultPharmacist'),
      subtitle: t('pharmacy.consultation.title'),
      icon: MessageCircle,
      color: '#06b6d4',
      bgColor: '#cffafe',
      route: '/pharmacy/consultation',
    },
    {
      id: 'loyalty-points',
      title: t('pharmacy.loyaltyPoints'),
      subtitle: `${loyaltyPoints} ${language === 'ar' ? 'نقطة' : 'points'}`,
      icon: Trophy,
      color: '#f97316',
      bgColor: '#ffedd5',
      route: '/pharmacy/loyalty',
    },
    {
      id: 'barcode-scanner',
      title: t('pharmacy.scanBarcode'),
      subtitle: language === 'ar' ? 'مسح باركود الدواء' : 'Scan medicine barcode',
      icon: ScanBarcode,
      color: '#6366f1',
      bgColor: '#e0e7ff',
      route: '/pharmacy/barcode-scanner',
    },
    {
      id: 'interaction-checker',
      title: t('pharmacy.interactionChecker'),
      subtitle: t('pharmacy.interactions.title'),
      icon: AlertCircle,
      color: '#ef4444',
      bgColor: '#fee2e2',
      route: '/pharmacy/interactions',
    },
  ];

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>{t('common.loading')}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Modal
        visible={showDevelopmentModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowDevelopmentModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalIconContainer}>
              <Construction size={64} color="#f59e0b" strokeWidth={2} />
            </View>

            <Text style={styles.modalTitle}>
              {language === 'ar' ? 'قيد التجهيز' : 'Under Development'}
            </Text>

            <Text style={styles.modalDescription}>
              {language === 'ar'
                ? 'هذه الميزة قيد التطوير والتحسين. يمكنك تصفح النموذج الأولي والتعرف على الخدمات المتاحة.'
                : 'This feature is under development. You can browse the prototype and explore available services.'}
            </Text>

            <View style={styles.modalFeatures}>
              <View style={styles.featureItem}>
                <Eye size={20} color="#10b981" strokeWidth={2} />
                <Text style={styles.featureText}>
                  {language === 'ar' ? 'تصفح النموذج الأولي' : 'Browse prototype'}
                </Text>
              </View>
              <View style={styles.featureItem}>
                <Package size={20} color="#10b981" strokeWidth={2} />
                <Text style={styles.featureText}>
                  {language === 'ar' ? 'استكشف الخدمات' : 'Explore services'}
                </Text>
              </View>
            </View>

            <TouchableOpacity style={styles.continueButton} onPress={handleContinue}>
              <Text style={styles.continueButtonText}>
                {language === 'ar' ? 'متابعة للنموذج' : 'Continue to Prototype'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.title}>{t('pharmacy.title')}</Text>
            <Text style={styles.subtitle}>{t('pharmacy.subtitle')}</Text>
          </View>
          <View style={styles.pointsBadge}>
            <Trophy size={20} color="#f59e0b" strokeWidth={2.5} />
            <Text style={styles.pointsText}>{loyaltyPoints}</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#94a3b8" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder={t('pharmacy.search')}
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          <TouchableOpacity style={styles.voiceButton}>
            <Mic size={20} color="#0ea5e9" strokeWidth={2} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <TouchableOpacity
          style={styles.aiRecommendationCard}
          onPress={() => router.push('/pharmacy/search')}
        >
          <View style={styles.aiIconContainer}>
            <Bot size={28} color="#8b5cf6" strokeWidth={2.5} />
          </View>
          <View style={styles.aiTextContainer}>
            <Text style={styles.aiTitle}>{t('pharmacy.aiRecommendations')}</Text>
            <Text style={styles.aiSubtitle}>{t('pharmacy.aiCart.basedOn')}</Text>
          </View>
          <ChevronLeft size={24} color="#8b5cf6" strokeWidth={2} />
        </TouchableOpacity>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'الخدمات السريعة' : 'Quick Services'}
          </Text>
        </View>

        <View style={styles.quickActionsGrid}>
          {quickActions.map((action) => {
            const IconComponent = action.icon;
            return (
              <TouchableOpacity
                key={action.id}
                style={[styles.quickActionCard, { backgroundColor: action.bgColor }]}
                onPress={() => router.push(action.route as any)}>
                <View style={[styles.quickActionIcon, { backgroundColor: action.color }]}>
                  <IconComponent size={24} color="#ffffff" strokeWidth={2.5} />
                </View>
                <Text style={styles.quickActionTitle}>{action.title}</Text>
                <Text style={[styles.quickActionSubtitle, { color: action.color }]}>
                  {action.subtitle}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'الفئات' : 'Categories'}
          </Text>
        </View>

        {categories.map((category) => (
          <TouchableOpacity
            key={category.id}
            style={styles.categoryCard}
            onPress={() => router.push(`/pharmacies/category/${category.id}`)}>
            <View style={styles.categoryIcon}>
              <Pill size={28} color="#0ea5e9" strokeWidth={2} />
            </View>
            <View style={styles.categoryInfo}>
              <Text style={styles.categoryName}>
                {language === 'ar' ? category.name : category.name_en}
              </Text>
              <Text style={styles.categoryDescription}>{category.description}</Text>
            </View>
            <ChevronLeft size={24} color="#cbd5e1" strokeWidth={2} />
          </TouchableOpacity>
        ))}

        <TouchableOpacity
          style={styles.nearbyPharmaciesButton}
          onPress={() => router.push('/pharmacy')}>
          <View style={styles.nearbyContent}>
            <View style={styles.nearbyIcon}>
              <Pill size={24} color="#ffffff" strokeWidth={2.5} />
            </View>
            <View style={styles.nearbyInfo}>
              <Text style={styles.nearbyTitle}>
                {language === 'ar' ? 'الصيدليات القريبة' : 'Nearby Pharmacies'}
              </Text>
              <Text style={styles.nearbySubtitle}>
                {language === 'ar' ? 'عرض الصيدليات حسب الموقع' : 'View by location'}
              </Text>
            </View>
            <ChevronLeft size={24} color="#ffffff" strokeWidth={2} />
          </View>
        </TouchableOpacity>

        <View style={{ height: 32 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f9ff',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#64748b',
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#fef3c7',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  pointsText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#f59e0b',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#f8fafc',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: '#e0f2fe',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
  },
  voiceButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  aiRecommendationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#faf5ff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#e9d5ff',
  },
  aiIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#f3e8ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  aiTextContainer: {
    flex: 1,
  },
  aiTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#7c3aed',
    marginBottom: 4,
    textAlign: 'right',
  },
  aiSubtitle: {
    fontSize: 14,
    color: '#a78bfa',
    textAlign: 'right',
  },
  sectionHeader: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 32,
  },
  quickActionCard: {
    width: '48%',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  quickActionIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  quickActionTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 6,
  },
  quickActionSubtitle: {
    fontSize: 12,
    textAlign: 'center',
    fontWeight: '600',
  },
  categoryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e0f2fe',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  categoryIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryInfo: {
    flex: 1,
  },
  categoryName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  categoryDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  nearbyPharmaciesButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 20,
    padding: 20,
    marginTop: 12,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 8,
  },
  nearbyContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  nearbyIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  nearbyInfo: {
    flex: 1,
  },
  nearbyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 4,
    textAlign: 'right',
  },
  nearbySubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.95)',
    textAlign: 'right',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 24,
    padding: 32,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
  },
  modalIconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#fef3c7',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalDescription: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  modalFeatures: {
    width: '100%',
    gap: 12,
    marginBottom: 24,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#f0fdf4',
    padding: 16,
    borderRadius: 12,
  },
  featureText: {
    fontSize: 15,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'right',
    flex: 1,
  },
  continueButton: {
    backgroundColor: '#0ea5e9',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    width: '100%',
  },
  continueButtonText: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
  },
});
