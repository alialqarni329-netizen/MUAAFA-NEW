import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, RefreshControl, Modal } from 'react-native';
import { useState, useEffect } from 'react';
import { Video, MessageSquare, Clock, Plus, Calendar, CheckCircle, AlertCircle, XCircle, Construction, Eye } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface Appointment {
  id: string;
  doctor_id: string;
  appointment_type: 'video' | 'chat' | 'instant';
  status: 'scheduled' | 'waiting' | 'in_progress' | 'completed' | 'cancelled' | 'no_show' | 'pending';
  scheduled_date: string;
  scheduled_time: string;
  meeting_url: string;
  meeting_platform: string;
  reason_for_visit: string;
  medical_brief_sent: boolean;
  doctors: {
    full_name: string;
    specialty: string;
  };
}

type FilterType = 'all' | 'upcoming' | 'pending' | 'completed';

export default function SessionsScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [showDevelopmentModal, setShowDevelopmentModal] = useState(false);

  useEffect(() => {
    checkFirstVisit();
    loadAppointments();
    retryPendingAppointments();
  }, []);

  async function checkFirstVisit() {
    try {
      const hasVisited = await AsyncStorage.getItem('sessions_visited');
      if (!hasVisited) {
        setShowDevelopmentModal(true);
      }
    } catch (error) {
      console.error('Error checking first visit:', error);
    }
  }

  async function handleContinue() {
    try {
      await AsyncStorage.setItem('sessions_visited', 'true');
      setShowDevelopmentModal(false);
    } catch (error) {
      console.error('Error saving visit:', error);
    }
  }

  async function loadAppointments() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('appointments')
        .select(`
          *,
          doctors (
            full_name,
            specialty
          )
        `)
        .eq('user_id', user.id)
        .order('scheduled_date', { ascending: false })
        .order('scheduled_time', { ascending: false });

      if (data) {
        setAppointments(data as any);
      }
    } catch (error) {
      console.error('Error loading appointments:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  const onRefresh = async () => {
    setRefreshing(true);
    await retryPendingAppointments();
    await loadAppointments();
  };

  async function retryPendingAppointments() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data: pendingAppointments } = await supabase
        .from('appointments')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'pending')
        .is('meeting_url', null);

      if (!pendingAppointments || pendingAppointments.length === 0) return;

      for (const appointment of pendingAppointments) {
        try {
          const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/create-meeting`;
          const { data: { session } } = await supabase.auth.getSession();

          const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${session?.access_token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              appointmentId: appointment.id,
              platform: appointment.meeting_platform || 'zoom',
              scheduledDate: appointment.scheduled_date,
              scheduledTime: appointment.scheduled_time,
              duration: 30,
              topic: `${language === 'ar' ? 'استشارة طبية' : 'Medical Consultation'}`,
            }),
          });

          if (response.ok) {
            console.log(`Successfully created meeting link for appointment ${appointment.id}`);
          }
        } catch (error) {
          console.error(`Failed to retry appointment ${appointment.id}:`, error);
        }
      }
    } catch (error) {
      console.error('Error retrying pending appointments:', error);
    }
  }

  const getFilteredAppointments = () => {
    const now = new Date();

    switch (activeFilter) {
      case 'upcoming':
        return appointments.filter(apt => {
          const appointmentDate = new Date(`${apt.scheduled_date}T${apt.scheduled_time}`);
          return (apt.status === 'scheduled' || apt.status === 'waiting') && appointmentDate >= now;
        });
      case 'pending':
        return appointments.filter(apt => apt.status === 'pending');
      case 'completed':
        return appointments.filter(apt => apt.status === 'completed' || apt.status === 'cancelled' || apt.status === 'no_show');
      default:
        return appointments;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled':
      case 'waiting':
        return '#3b82f6';
      case 'pending':
        return '#f59e0b';
      case 'completed':
        return '#10b981';
      case 'in_progress':
        return '#8b5cf6';
      default:
        return '#64748b';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'scheduled':
      case 'waiting':
        return language === 'ar' ? 'قادمة' : 'Upcoming';
      case 'pending':
        return language === 'ar' ? 'قيد الانتظار' : 'Pending';
      case 'completed':
        return language === 'ar' ? 'مكتملة' : 'Completed';
      case 'in_progress':
        return language === 'ar' ? 'جارية' : 'In Progress';
      case 'cancelled':
        return language === 'ar' ? 'ملغية' : 'Cancelled';
      default:
        return status;
    }
  };

  const filteredAppointments = getFilteredAppointments();
  const upcomingCount = appointments.filter(apt => apt.status === 'scheduled' || apt.status === 'waiting').length;
  const pendingCount = appointments.filter(apt => apt.status === 'pending').length;
  const completedCount = appointments.filter(apt => apt.status === 'completed').length;

  const handleBookSession = () => {
    router.push('/telehealth/book-appointment');
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    };
    return date.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', options);
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#8b5cf6" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Modal
        visible={showDevelopmentModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowDevelopmentModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalIconContainer}>
              <Construction size={64} color="#8b5cf6" strokeWidth={2} />
            </View>

            <Text style={styles.modalTitle}>
              {language === 'ar' ? 'قيد التجهيز' : 'Under Development'}
            </Text>

            <Text style={styles.modalDescription}>
              {language === 'ar'
                ? 'الجلسات الطبية قيد التطوير والتحسين. يمكنك تصفح النموذج الأولي وحجز جلسات تجريبية.'
                : 'Medical sessions are under development. You can browse the prototype and book trial sessions.'}
            </Text>

            <View style={styles.modalFeatures}>
              <View style={styles.featureItem}>
                <Eye size={20} color="#8b5cf6" strokeWidth={2} />
                <Text style={styles.featureText}>
                  {language === 'ar' ? 'تصفح النموذج الأولي' : 'Browse prototype'}
                </Text>
              </View>
              <View style={styles.featureItem}>
                <Video size={20} color="#8b5cf6" strokeWidth={2} />
                <Text style={styles.featureText}>
                  {language === 'ar' ? 'حجز جلسات تجريبية' : 'Book trial sessions'}
                </Text>
              </View>
            </View>

            <TouchableOpacity style={styles.continueButton} onPress={handleContinue}>
              <Text style={styles.continueButtonText}>
                {language === 'ar' ? 'متابعة للنموذج' : 'Continue to Prototype'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <View style={styles.header}>
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'الجلسات المحجوزة والنشطة' : 'Booked & Active Sessions'}
        </Text>
        <Text style={styles.headerSubtitle}>
          {language === 'ar' ? 'إدارة جميع جلساتك الطبية' : 'Manage all your medical sessions'}
        </Text>
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#8b5cf6" />
        }
      >
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Calendar size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statNumber}>{upcomingCount}</Text>
            <Text style={styles.statLabel}>{language === 'ar' ? 'قادمة' : 'Upcoming'}</Text>
          </View>
          <View style={styles.statCard}>
            <AlertCircle size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statNumber}>{pendingCount}</Text>
            <Text style={styles.statLabel}>{language === 'ar' ? 'قيد الانتظار' : 'Pending'}</Text>
          </View>
          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statNumber}>{completedCount}</Text>
            <Text style={styles.statLabel}>{language === 'ar' ? 'مكتملة' : 'Completed'}</Text>
          </View>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filtersContainer}>
          <TouchableOpacity
            style={[styles.filterChip, activeFilter === 'all' && styles.filterChipActive]}
            onPress={() => setActiveFilter('all')}
          >
            <Text style={[styles.filterText, activeFilter === 'all' && styles.filterTextActive]}>
              {language === 'ar' ? 'الكل' : 'All'} ({appointments.length})
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.filterChip, activeFilter === 'upcoming' && styles.filterChipActive]}
            onPress={() => setActiveFilter('upcoming')}
          >
            <Text style={[styles.filterText, activeFilter === 'upcoming' && styles.filterTextActive]}>
              {language === 'ar' ? 'قادمة' : 'Upcoming'} ({upcomingCount})
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.filterChip, activeFilter === 'pending' && styles.filterChipActive]}
            onPress={() => setActiveFilter('pending')}
          >
            <Text style={[styles.filterText, activeFilter === 'pending' && styles.filterTextActive]}>
              {language === 'ar' ? 'قيد الانتظار' : 'Pending'} ({pendingCount})
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.filterChip, activeFilter === 'completed' && styles.filterChipActive]}
            onPress={() => setActiveFilter('completed')}
          >
            <Text style={[styles.filterText, activeFilter === 'completed' && styles.filterTextActive]}>
              {language === 'ar' ? 'مكتملة' : 'Completed'} ({completedCount})
            </Text>
          </TouchableOpacity>
        </ScrollView>

        <>
            <View style={styles.quickActionsRow}>
              <TouchableOpacity
                style={[styles.bookButton, styles.bookButtonInstant]}
                onPress={async () => {
                  try {
                    const { data: { user } } = await supabase.auth.getUser();
                    if (!user) return;

                    const { data: virtualDoctor } = await supabase
                      .from('doctors')
                      .select('id')
                      .eq('full_name', 'د. مساعد معافى الذكي')
                      .single();

                    if (!virtualDoctor) {
                      Alert.alert(
                        language === 'ar' ? 'خطأ' : 'Error',
                        language === 'ar' ? 'الطبيب الافتراضي غير متاح حالياً' : 'Virtual doctor not available'
                      );
                      return;
                    }

                    const now = new Date();
                    const { data: appointment, error } = await supabase
                      .from('appointments')
                      .insert({
                        user_id: user.id,
                        doctor_id: virtualDoctor.id,
                        appointment_type: 'instant',
                        scheduled_date: now.toISOString().split('T')[0],
                        scheduled_time: now.toTimeString().slice(0, 5),
                        status: 'waiting',
                        reason_for_visit: language === 'ar' ? 'جلسة فورية' : 'Instant session'
                      })
                      .select()
                      .single();

                    if (error) throw error;

                    Alert.alert(
                      language === 'ar' ? '✅ تم الحجز' : '✅ Booked',
                      language === 'ar' ? 'تم حجز جلسة فورية. يمكنك الانضمام الآن!' : 'Instant session booked. You can join now!',
                      [
                        { text: language === 'ar' ? 'انضم الآن' : 'Join Now', onPress: () => router.push(`/telehealth/waiting-room?appointmentId=${appointment.id}`) },
                        { text: language === 'ar' ? 'لاحقاً' : 'Later' }
                      ]
                    );

                    await loadAppointments();
                  } catch (error) {
                    console.error('Error booking instant session:', error);
                    Alert.alert(
                      language === 'ar' ? 'خطأ' : 'Error',
                      language === 'ar' ? 'حدث خطأ أثناء الحجز' : 'Error booking session'
                    );
                  }
                }}
              >
                <Video size={24} color="#ffffff" strokeWidth={2} />
                <Text style={styles.bookButtonText}>{language === 'ar' ? 'جلسة فورية' : 'Instant Session'}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.bookButton} onPress={handleBookSession}>
                <Plus size={24} color="#ffffff" strokeWidth={2} />
                <Text style={styles.bookButtonText}>{language === 'ar' ? 'حجز موعد جديد' : 'Book New Appointment'}</Text>
              </TouchableOpacity>
            </View>

            {filteredAppointments.length > 0 ? (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>
                  {activeFilter === 'all' && (language === 'ar' ? 'جميع الجلسات' : 'All Sessions')}
                  {activeFilter === 'upcoming' && (language === 'ar' ? 'الجلسات القادمة' : 'Upcoming Sessions')}
                  {activeFilter === 'pending' && (language === 'ar' ? 'الجلسات قيد الانتظار' : 'Pending Sessions')}
                  {activeFilter === 'completed' && (language === 'ar' ? 'الجلسات المكتملة' : 'Completed Sessions')}
                </Text>
                {filteredAppointments.map((appointment) => (
                  <View key={appointment.id} style={styles.sessionCard}>
                    <View style={styles.sessionHeader}>
                      <View style={styles.sessionInfo}>
                        <Text style={styles.doctorName}>{appointment.doctors.full_name}</Text>
                        <Text style={styles.specialty}>{appointment.doctors.specialty}</Text>
                      </View>
                      <View
                        style={[
                          styles.statusBadge,
                          { backgroundColor: getStatusColor(appointment.status) },
                        ]}>
                        <Text style={styles.statusText}>
                          {getStatusText(appointment.status)}
                        </Text>
                      </View>
                    </View>

                    <View style={styles.sessionDetails}>
                      <View style={styles.detailRow}>
                        <Text style={styles.detailText}>{formatDate(appointment.scheduled_date)}</Text>
                        <Clock size={16} color="#64748b" strokeWidth={2} />
                      </View>
                      <View style={styles.detailRow}>
                        <Text style={styles.detailText}>{appointment.scheduled_time}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Text style={styles.detailText}>
                          {appointment.appointment_type === 'video'
                            ? (language === 'ar' ? 'جلسة فيديو' : 'Video Session')
                            : appointment.appointment_type === 'chat'
                            ? (language === 'ar' ? 'محادثة نصية' : 'Text Chat')
                            : (language === 'ar' ? 'جلسة فورية' : 'Instant Session')}
                        </Text>
                        {appointment.appointment_type === 'video' ? (
                          <Video size={16} color="#64748b" strokeWidth={2} />
                        ) : (
                          <MessageSquare size={16} color="#64748b" strokeWidth={2} />
                        )}
                      </View>
                      {appointment.meeting_platform && (
                        <View style={styles.detailRow}>
                          <Text style={styles.detailText}>{appointment.meeting_platform}</Text>
                        </View>
                      )}
                      {appointment.status === 'pending' && !appointment.meeting_url && (
                        <View style={[styles.detailRow, styles.pendingNote]}>
                          <Text style={styles.pendingNoteText}>
                            {language === 'ar' ? 'جاري إعداد رابط الجلسة...' : 'Session link being prepared...'}
                          </Text>
                          <AlertCircle size={16} color="#f59e0b" strokeWidth={2} />
                        </View>
                      )}
                    </View>

                    {appointment.status === 'pending' && !appointment.meeting_url && (
                      <TouchableOpacity
                        style={styles.retryButton}
                        onPress={async () => {
                          try {
                            const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/create-meeting`;
                            const { data: { session } } = await supabase.auth.getSession();

                            Alert.alert(
                              language === 'ar' ? 'جاري إنشاء الرابط...' : 'Creating link...',
                              language === 'ar' ? 'الرجاء الانتظار' : 'Please wait'
                            );

                            const response = await fetch(apiUrl, {
                              method: 'POST',
                              headers: {
                                'Authorization': `Bearer ${session?.access_token}`,
                                'Content-Type': 'application/json',
                              },
                              body: JSON.stringify({
                                appointmentId: appointment.id,
                                platform: appointment.meeting_platform || 'zoom',
                                scheduledDate: appointment.scheduled_date,
                                scheduledTime: appointment.scheduled_time,
                                duration: 30,
                                topic: `${language === 'ar' ? 'استشارة طبية' : 'Medical Consultation'}`,
                              }),
                            });

                            if (response.ok) {
                              Alert.alert(
                                language === 'ar' ? 'نجح!' : 'Success!',
                                language === 'ar' ? 'تم إنشاء رابط الجلسة بنجاح' : 'Session link created successfully'
                              );
                              await loadAppointments();
                            } else {
                              Alert.alert(
                                language === 'ar' ? 'فشل' : 'Failed',
                                language === 'ar' ? 'لم نتمكن من إنشاء الرابط. تأكد من إعداد مفاتيح Zoom.' : 'Could not create link. Please ensure Zoom keys are configured.'
                              );
                            }
                          } catch (error) {
                            console.error('Error retrying:', error);
                            Alert.alert(
                              language === 'ar' ? 'خطأ' : 'Error',
                              language === 'ar' ? 'حدث خطأ أثناء المحاولة' : 'An error occurred'
                            );
                          }
                        }}
                      >
                        <Text style={styles.retryButtonText}>
                          {language === 'ar' ? '🔄 إعادة محاولة إنشاء الرابط' : '🔄 Retry Creating Link'}
                        </Text>
                      </TouchableOpacity>
                    )}
                    {(appointment.status === 'scheduled' || appointment.status === 'waiting' || (appointment.status === 'pending' && appointment.meeting_url)) && (
                      <TouchableOpacity
                        style={styles.joinButton}
                        onPress={() => router.push(`/telehealth/waiting-room?appointmentId=${appointment.id}`)}
                      >
                        <Text style={styles.joinButtonText}>
                          {appointment.status === 'pending'
                            ? (language === 'ar' ? 'عرض التفاصيل' : 'View Details')
                            : (language === 'ar' ? 'الدخول للجلسة' : 'Join Session')}
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                ))}
              </View>
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>{language === 'ar' ? 'لا توجد جلسات حالياً' : 'No sessions currently'}</Text>
                <Text style={styles.emptyStateSubtext}>
                  {language === 'ar' ? 'احجز جلستك الأولى مع طبيب متخصص' : 'Book your first session with a specialist'}
                </Text>
              </View>
            )}
          </>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#8b5cf6',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'right',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#ddd6fe',
    textAlign: 'right',
    marginBottom: 12,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  filtersContainer: {
    marginBottom: 20,
  },
  filterChip: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginRight: 8,
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  filterChipActive: {
    backgroundColor: '#8b5cf6',
    borderColor: '#8b5cf6',
  },
  filterText: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  filterTextActive: {
    color: '#ffffff',
  },
  subscriptionBadge: {
    alignSelf: 'flex-end',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  subscriptionText: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '600',
  },
  subscriptionTextInactive: {
    fontSize: 12,
    color: '#fecaca',
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 80,
  },
  lockedContainer: {
    alignItems: 'center',
    paddingVertical: 60,
    paddingHorizontal: 32,
  },
  lockedTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 24,
    marginBottom: 12,
  },
  lockedText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  subscribeButton: {
    backgroundColor: '#8b5cf6',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
  },
  subscribeButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  quickActionsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  bookButton: {
    flex: 1,
    backgroundColor: '#8b5cf6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  bookButtonInstant: {
    backgroundColor: '#10b981',
  },
  bookButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  sessionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  sessionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  sessionInfo: {
    flex: 1,
  },
  doctorName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  specialty: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
  sessionDetails: {
    gap: 8,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
  },
  detailText: {
    fontSize: 14,
    color: '#475569',
  },
  pendingNote: {
    backgroundColor: '#fffbeb',
    padding: 8,
    borderRadius: 8,
    marginTop: 8,
  },
  pendingNoteText: {
    fontSize: 13,
    color: '#f59e0b',
    fontWeight: '600',
  },
  joinButton: {
    backgroundColor: '#3b82f6',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  joinButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  retryButton: {
    backgroundColor: '#f59e0b',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  retryButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#64748b',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 24,
    padding: 32,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 12,
  },
  modalIconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#f3e8ff',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalDescription: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  modalFeatures: {
    width: '100%',
    gap: 12,
    marginBottom: 24,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#f5f3ff',
    padding: 16,
    borderRadius: 12,
  },
  featureText: {
    fontSize: 15,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'right',
    flex: 1,
  },
  continueButton: {
    backgroundColor: '#8b5cf6',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    width: '100%',
    shadowColor: '#8b5cf6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  continueButtonText: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
  },
});
