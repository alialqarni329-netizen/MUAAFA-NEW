import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, Platform, Modal, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { Building2, ChevronRight, Calendar } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import DateTimePicker from '@react-native-community/datetimepicker';
import { validateBusinessEmail, validateCommercialRegistration, validateBusinessName, parseSupabaseError } from '@/lib/validation-utils';

export default function BusinessRegisterScreen() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    businessName: '',
    businessType: '',
    commercialRegistration: '',
    registrationExpiry: '',
    ownerNationalId: '',
    phone: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [loading, setLoading] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());

  async function handleRegister() {
    if (!formData.businessName || !formData.businessType || !formData.commercialRegistration || !formData.phone || !formData.email || !formData.password) {
      Alert.alert('خطأ', 'يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    const nameValidation = validateBusinessName(formData.businessName);
    if (!nameValidation.isValid) {
      Alert.alert('خطأ في اسم المنشأة', nameValidation.errorMessage);
      return;
    }

    const emailValidation = validateBusinessEmail(formData.email);
    if (!emailValidation.isValid) {
      Alert.alert('خطأ في البريد الإلكتروني', emailValidation.errorMessage);
      return;
    }

    const crValidation = validateCommercialRegistration(formData.commercialRegistration);
    if (!crValidation.isValid) {
      Alert.alert('خطأ في السجل التجاري', crValidation.errorMessage);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      Alert.alert('خطأ', 'كلمة المرور وتأكيد كلمة المرور غير متطابقين');
      return;
    }

    if (formData.password.length < 8) {
      Alert.alert('خطأ', 'كلمة المرور يجب أن تكون 8 أحرف على الأقل');
      return;
    }

    setLoading(true);

    try {
      const { data: duplicateCheck, error: checkError } = await supabase
        .rpc('check_duplicate_business_data', {
          p_phone: formData.phone.trim(),
          p_email: formData.email.toLowerCase().trim(),
          p_commercial_registration: formData.commercialRegistration.trim(),
        });

      if (checkError) {
        setLoading(false);
        Alert.alert('خطأ', 'حدث خطأ أثناء التحقق من البيانات');
        return;
      }

      if (duplicateCheck && duplicateCheck.length > 0 && duplicateCheck[0].is_duplicate) {
        setLoading(false);
        const duplicate = duplicateCheck[0];
        let errorMessage = duplicate.error_message || 'البيانات مسجلة مسبقاً';

        if (duplicate.duplicate_field === 'phone') {
          errorMessage = 'رقم الهاتف ' + formData.phone + ' مسجل مسبقاً في النظام\n\nلا يمكن استخدام نفس الرقم لأكثر من منشأة';
        } else if (duplicate.duplicate_field === 'email') {
          errorMessage = 'البريد الإلكتروني ' + formData.email + ' مسجل مسبقاً\n\nلا يمكن استخدام نفس البريد لأكثر من منشأة';
        } else if (duplicate.duplicate_field === 'commercial_registration') {
          errorMessage = 'رقم السجل التجاري ' + formData.commercialRegistration + ' مسجل مسبقاً في النظام\n\nلا يمكن تسجيل نفس السجل التجاري مرتين';
        }

        Alert.alert('لا يمكن التسجيل', errorMessage);
        return;
      }

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email.toLowerCase().trim(),
        password: formData.password,
        options: {
          data: {
            phone: formData.phone.trim(),
            user_role: 'business_admin',
            full_name: formData.businessName.trim(),
          },
        },
      });

      if (authError) {
        setLoading(false);
        const errorMsg = parseSupabaseError(authError);
        Alert.alert('خطأ في التسجيل', errorMsg);
        return;
      }

      if (!authData.user) {
        setLoading(false);
        Alert.alert('خطأ', 'حدث خطأ أثناء إنشاء الحساب');
        return;
      }

      const userId = authData.user.id;

      await new Promise(resolve => setTimeout(resolve, 500));

      supabase.from('users').update({
        phone: formData.phone.trim(),
        updated_at: new Date().toISOString(),
      }).eq('id', userId).then();

      const { error: businessError } = await supabase.from('business_registrations').insert({
        user_id: userId,
        business_name: formData.businessName.trim(),
        commercial_registration: formData.commercialRegistration.trim(),
        registration_expiry: formData.registrationExpiry || null,
        owner_national_id: formData.ownerNationalId.trim() || null,
        phone: formData.phone.trim(),
        email: formData.email.toLowerCase().trim(),
        status: 'pending',
        phone_verified: false,
        email_verified: false,
      });

      if (businessError) {
        setLoading(false);
        const errorMsg = parseSupabaseError(businessError);
        Alert.alert('خطأ في تسجيل المنشأة', 'تم إنشاء حسابك لكن حدث خطأ في حفظ بيانات المنشأة:\n\n' + errorMsg + '\n\nيرجى المحاولة مرة أخرى أو التواصل مع الدعم الفني.');
        return;
      }

      supabase.from('business_verification').insert({
        user_id: userId,
        business_type: formData.businessType,
        business_name: formData.businessName.trim(),
        commercial_registration: formData.commercialRegistration.trim(),
        headquarters_location: 'الرياض',
        admin_contact_phone: formData.phone.trim(),
        admin_contact_email: formData.email.toLowerCase().trim(),
        verification_status: 'pending',
      }).then();

      setLoading(false);
      Alert.alert('تم التسجيل بنجاح', 'تم إرسال طلب تسجيل منشأتك بنجاح\n\nسيتم مراجعة طلبك خلال 24-48 ساعة\n\nستتلقى إشعار عند الموافقة على طلبك', [
        { text: 'حسناً', onPress: () => router.replace('/business/pending-approval') },
      ]);
    } catch (error: any) {
      setLoading(false);
      const errorMsg = parseSupabaseError(error);
      Alert.alert('خطأ', errorMsg);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>تسجيل منشأة جديدة</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>اسم المنشأة *</Text>
            <TextInput
              style={styles.input}
              placeholder="شركة الصحة المتقدمة"
              value={formData.businessName}
              onChangeText={(text) => setFormData({ ...formData, businessName: text })}
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>نوع المنشأة *</Text>
            <View style={styles.businessTypeContainer}>
              <TouchableOpacity
                style={[
                  styles.businessTypeButton,
                  formData.businessType === 'pharmacy' && styles.businessTypeButtonActive
                ]}
                onPress={() => setFormData({ ...formData, businessType: 'pharmacy' })}>
                <Text style={[
                  styles.businessTypeText,
                  formData.businessType === 'pharmacy' && styles.businessTypeTextActive
                ]}>
                  صيدلية
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.businessTypeButton,
                  formData.businessType === 'hospital' && styles.businessTypeButtonActive
                ]}
                onPress={() => setFormData({ ...formData, businessType: 'hospital' })}>
                <Text style={[
                  styles.businessTypeText,
                  formData.businessType === 'hospital' && styles.businessTypeTextActive
                ]}>
                  مستشفى / مجمع طبي
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.businessTypeButton,
                  formData.businessType === 'insurance' && styles.businessTypeButtonActive
                ]}
                onPress={() => setFormData({ ...formData, businessType: 'insurance' })}>
                <Text style={[
                  styles.businessTypeText,
                  formData.businessType === 'insurance' && styles.businessTypeTextActive
                ]}>
                  شركة تأمين
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>رقم السجل التجاري *</Text>
            <TextInput
              style={styles.input}
              placeholder="1234567890"
              value={formData.commercialRegistration}
              onChangeText={(text) => setFormData({ ...formData, commercialRegistration: text })}
              keyboardType="number-pad"
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>تاريخ انتهاء السجل (اختياري)</Text>
            <TouchableOpacity
              style={[styles.input, styles.dateInput]}
              onPress={() => setShowDatePicker(true)}>
              <Calendar size={20} color="#64748b" strokeWidth={2} />
              <Text style={[styles.dateText, !formData.registrationExpiry && styles.datePlaceholder]}>
                {formData.registrationExpiry || 'اختر التاريخ'}
              </Text>
            </TouchableOpacity>
          </View>

          <Modal
            visible={showDatePicker}
            transparent={true}
            animationType="slide"
            onRequestClose={() => setShowDatePicker(false)}>
            <View style={styles.dateModalOverlay}>
              <View style={styles.dateModalContent}>
                <View style={styles.dateModalHeader}>
                  <TouchableOpacity
                    style={styles.dateModalButton}
                    onPress={() => {
                      const formattedDate = selectedDate.toISOString().split('T')[0];
                      setFormData({ ...formData, registrationExpiry: formattedDate });
                      setShowDatePicker(false);
                    }}>
                    <Text style={styles.dateModalDone}>تم</Text>
                  </TouchableOpacity>
                  <Text style={styles.dateModalTitle}>اختر تاريخ الانتهاء</Text>
                  <TouchableOpacity
                    style={styles.dateModalButton}
                    onPress={() => setShowDatePicker(false)}>
                    <Text style={styles.dateModalCancel}>إلغاء</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.datePickerWrapper}>
                  <DateTimePicker
                    value={selectedDate}
                    mode="date"
                    display={Platform.OS === 'ios' ? 'inline' : 'calendar'}
                    themeVariant="light"
                    onChange={(event, date) => {
                      if (Platform.OS === 'android') {
                        setShowDatePicker(false);
                        if (date) {
                          setSelectedDate(date);
                          const formattedDate = date.toISOString().split('T')[0];
                          setFormData({ ...formData, registrationExpiry: formattedDate });
                        }
                      } else {
                        if (date) {
                          setSelectedDate(date);
                        }
                      }
                    }}
                    minimumDate={new Date()}
                    locale="ar"
                    textColor="#0f172a"
                  />
                </View>
              </View>
            </View>
          </Modal>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>رقم الهوية لصاحب المنشأة (اختياري)</Text>
            <TextInput
              style={styles.input}
              placeholder="1234567890"
              value={formData.ownerNationalId}
              onChangeText={(text) => setFormData({ ...formData, ownerNationalId: text })}
              keyboardType="number-pad"
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>رقم الجوال *</Text>
            <TextInput
              style={styles.input}
              placeholder="+966501234567"
              value={formData.phone}
              onChangeText={(text) => setFormData({ ...formData, phone: text })}
              keyboardType="phone-pad"
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>البريد الإلكتروني *</Text>
            <TextInput
              style={styles.input}
              placeholder="business@example.com"
              value={formData.email}
              onChangeText={(text) => setFormData({ ...formData, email: text })}
              keyboardType="email-address"
              autoCapitalize="none"
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>كلمة المرور *</Text>
            <TextInput
              style={styles.input}
              placeholder="••••••••"
              value={formData.password}
              onChangeText={(text) => setFormData({ ...formData, password: text })}
              secureTextEntry
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>تأكيد كلمة المرور *</Text>
            <TextInput
              style={styles.input}
              placeholder="••••••••"
              value={formData.confirmPassword}
              onChangeText={(text) => setFormData({ ...formData, confirmPassword: text })}
              secureTextEntry
              textAlign="right"
            />
          </View>
        </View>

        <TouchableOpacity
          style={[styles.registerButton, loading && styles.registerButtonDisabled]}
          onPress={handleRegister}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <>
              <Building2 size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.registerButtonText}>تسجيل المنشأة</Text>
            </>
          )}
        </TouchableOpacity>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>ملاحظات هامة:</Text>
          <Text style={styles.infoText}>• سيتم مراجعة الطلب خلال 24-48 ساعة</Text>
          <Text style={styles.infoText}>• يجب أن يكون السجل التجاري ساري المفعول</Text>
          <Text style={styles.infoText}>• سيتم التحقق من رقم الجوال والبريد الإلكتروني</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  form: {
    gap: 16,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    padding: 16,
    fontSize: 16,
    color: '#0f172a',
  },
  dateInput: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  dateText: {
    fontSize: 16,
    color: '#0f172a',
    flex: 1,
  },
  datePlaceholder: {
    color: '#94a3b8',
  },
  registerButton: {
    backgroundColor: '#6366f1',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 24,
  },
  registerButtonDisabled: {
    opacity: 0.6,
  },
  registerButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  infoCard: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
    gap: 8,
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1e40af',
    textAlign: 'right',
  },
  infoText: {
    fontSize: 13,
    color: '#1e40af',
    textAlign: 'right',
    lineHeight: 20,
  },
  dateModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  dateModalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 30,
    width: '100%',
    maxWidth: 500,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  dateModalHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#e2e8f0',
    backgroundColor: '#f8fafc',
  },
  dateModalButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    minWidth: 60,
  },
  dateModalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
  },
  dateModalCancel: {
    fontSize: 17,
    fontWeight: '600',
    color: '#64748b',
  },
  dateModalDone: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#6366f1',
  },
  datePickerWrapper: {
    backgroundColor: '#ffffff',
    paddingVertical: 16,
    paddingHorizontal: 8,
  },
  businessTypeContainer: {
    gap: 12,
  },
  businessTypeButton: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    padding: 16,
    alignItems: 'center',
  },
  businessTypeButtonActive: {
    backgroundColor: '#ede9fe',
    borderColor: '#6366f1',
  },
  businessTypeText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
  businessTypeTextActive: {
    color: '#6366f1',
  },
});
