import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Users, FileText, Calendar, DollarSign, BarChart3, Settings, ShoppingBag, CheckCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface DashboardItem {
  id: string;
  title: string;
  icon: any;
  color: string;
  route: string;
  businessTypes: string[];
}

export default function BusinessDashboardScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [businessType, setBusinessType] = useState<string>('');
  const [businessStatus, setBusinessStatus] = useState<string>('');
  const [businessName, setBusinessName] = useState<string>('');

  const allItems: DashboardItem[] = [
    { id: 'employees', title: 'إدارة الموظفين', icon: Users, color: '#0ea5e9', route: '/business/employees', businessTypes: ['all'] },
    { id: 'claims', title: 'المطالبات التأمينية', icon: FileText, color: '#10b981', route: '/business/claims', businessTypes: ['insurance'] },
    { id: 'sessions', title: 'الجلسات الصحية', icon: Calendar, color: '#f59e0b', route: '/business/sessions', businessTypes: ['hospital'] },
    { id: 'pharmacy', title: 'إدارة الصيدلية', icon: ShoppingBag, color: '#ec4899', route: '/pharmacy/index', businessTypes: ['pharmacy'] },
    { id: 'billing', title: 'الفواتير والدفع', icon: DollarSign, color: '#8b5cf6', route: '/business/billing', businessTypes: ['all'] },
    { id: 'analytics', title: 'الإحصائيات', icon: BarChart3, color: '#ec4899', route: '/business/analytics', businessTypes: ['all'] },
    { id: 'settings', title: 'الإعدادات', icon: Settings, color: '#64748b', route: '/business/settings', businessTypes: ['all'] },
  ];

  useEffect(() => {
    loadBusinessData();
  }, []);

  async function loadBusinessData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.replace('/business/login');
        return;
      }

      const { data: businessData, error } = await supabase
        .from('business_registrations')
        .select('business_type, business_status, business_name')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (!businessData) {
        Alert.alert('خطأ', 'لم يتم العثور على منشأة مسجلة', [
          { text: 'حسناً', onPress: () => router.replace('/business/register') }
        ]);
        return;
      }

      if (!businessData.business_type) {
        Alert.alert('خطأ', 'يرجى تحديث معلومات منشأتك وإضافة نوع المنشأة', [
          { text: 'تحديث', onPress: () => router.replace('/business/settings') }
        ]);
        return;
      }

      setBusinessType(businessData.business_type || '');
      setBusinessStatus(businessData.business_status || 'pending_review');
      setBusinessName(businessData.business_name || '');
      setLoading(false);
    } catch (error: any) {
      console.error('Error loading business data:', error);
      setLoading(false);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحميل بيانات المنشأة');
    }
  }

  function getBusinessTypeName(type: string): string {
    switch (type) {
      case 'insurance': return 'شركة تأمين';
      case 'hospital': return 'مستشفى / مجمع طبي';
      case 'pharmacy': return 'صيدلية';
      default: return 'منشأة';
    }
  }

  function getStatusBadgeColor(status: string): string {
    switch (status) {
      case 'active': return '#10b981';
      case 'pending_review': return '#f59e0b';
      case 'suspended': return '#ef4444';
      default: return '#64748b';
    }
  }

  function getStatusText(status: string): string {
    switch (status) {
      case 'active': return 'مفعلة';
      case 'pending_review': return 'قيد المراجعة';
      case 'suspended': return 'موقوفة';
      default: return status;
    }
  }

  const dashboardItems = allItems.filter(item =>
    item.businessTypes.includes('all') || item.businessTypes.includes(businessType)
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6366f1" />
        <Text style={styles.loadingText}>جارٍ التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>لوحة التحكم</Text>
        <Text style={styles.subtitle}>{businessName}</Text>
        <View style={styles.businessInfo}>
          <View style={[styles.statusBadge, { backgroundColor: `${getStatusBadgeColor(businessStatus)}15` }]}>
            <View style={[styles.statusDot, { backgroundColor: getStatusBadgeColor(businessStatus) }]} />
            <Text style={[styles.statusText, { color: getStatusBadgeColor(businessStatus) }]}>
              {getStatusText(businessStatus)}
            </Text>
          </View>
          <Text style={styles.businessType}>{getBusinessTypeName(businessType)}</Text>
        </View>
      </View>

      {businessStatus === 'pending_review' && (
        <View style={styles.warningBanner}>
          <Text style={styles.warningText}>
            ⚠️ منشأتك قيد المراجعة - سيتم تفعيل جميع الميزات بعد الموافقة
          </Text>
        </View>
      )}

      {businessStatus === 'active' && (
        <View style={styles.successBanner}>
          <CheckCircle size={20} color="#10b981" strokeWidth={2} />
          <Text style={styles.successText}>منشأتك مفعلة بالكامل</Text>
        </View>
      )}

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.grid}>
          {dashboardItems.map((item) => {
            const IconComponent = item.icon;
            return (
              <TouchableOpacity
                key={item.id}
                style={styles.card}
                onPress={() => router.push(item.route as any)}>
                <View style={[styles.iconContainer, { backgroundColor: `${item.color}15` }]}>
                  <IconComponent size={32} color={item.color} strokeWidth={2} />
                </View>
                <Text style={styles.cardTitle}>{item.title}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    gap: 12,
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#6366f1',
    marginBottom: 4,
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 18,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'right',
    marginBottom: 12,
  },
  businessInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    justifyContent: 'flex-end',
  },
  businessType: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '500',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
  },
  warningBanner: {
    backgroundColor: '#fef3c7',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#fbbf24',
  },
  warningText: {
    fontSize: 14,
    color: '#92400e',
    textAlign: 'right',
    lineHeight: 20,
  },
  successBanner: {
    backgroundColor: '#d1fae5',
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    justifyContent: 'flex-end',
    borderBottomWidth: 1,
    borderBottomColor: '#6ee7b7',
  },
  successText: {
    fontSize: 14,
    color: '#065f46',
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  card: {
    width: '47%',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'center',
  },
});
