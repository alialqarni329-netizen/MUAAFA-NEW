import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { DollarSign, ChevronLeft, CreditCard, TrendingUp, Receipt } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { PERMISSIONS } from '@/lib/rbac/permissions';

export default function BillingScreen() {
  return (
    <ProtectedRoute requiredPermission={PERMISSIONS.FINANCIAL.VIEW_INVOICES}>
      <BillingContent />
    </ProtectedRoute>
  );
}

function BillingContent() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, paid: 0, pending: 0, invoiceCount: 0 });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.replace('/business/login');
        return;
      }

      const { data: businessData } = await supabase
        .from('business_registrations')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (businessData) {
        const { data: payments } = await supabase
          .from('payments')
          .select('total_amount, payment_status')
          .eq('business_id', businessData.id);

        const paid = payments?.filter(p => p.payment_status === 'completed').reduce((sum, p) => sum + p.total_amount, 0) || 0;
        const pending = payments?.filter(p => p.payment_status === 'pending').reduce((sum, p) => sum + p.total_amount, 0) || 0;

        setStats({
          total: paid + pending,
          paid,
          pending,
          invoiceCount: payments?.length || 0,
        });
      }

      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#8b5cf6" />
        <Text style={styles.loadingText}>جارٍ التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.title}>الفواتير والدفع</Text>
          <Text style={styles.subtitle}>إدارة المدفوعات والفواتير</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>الرصيد الإجمالي</Text>
          <Text style={styles.balanceAmount}>{stats.total.toLocaleString('ar-SA')} ر.س</Text>
          <View style={styles.balanceDetails}>
            <View style={styles.balanceItem}>
              <TrendingUp size={16} color="#10b981" strokeWidth={2} />
              <Text style={styles.balanceItemText}>{stats.pending.toLocaleString('ar-SA')} ر.س مستحق</Text>
            </View>
            <View style={styles.balanceItem}>
              <Receipt size={16} color="#64748b" strokeWidth={2} />
              <Text style={styles.balanceItemText}>{stats.invoiceCount} فاتورة</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <CreditCard size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statNumber}>{stats.paid.toLocaleString('ar-SA')} ر.س</Text>
            <Text style={styles.statLabel}>تم الدفع</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <DollarSign size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statNumber}>{stats.pending.toLocaleString('ar-SA')} ر.س</Text>
            <Text style={styles.statLabel}>قيد الانتظار</Text>
          </View>
        </View>

        <View style={styles.emptyState}>
          <Receipt size={64} color="#cbd5e1" strokeWidth={2} />
          <Text style={styles.emptyTitle}>لا توجد فواتير</Text>
          <Text style={styles.emptyText}>
            ستظهر هنا جميع الفواتير{'\n'}والمدفوعات
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    gap: 12,
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  headerContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  balanceCard: {
    backgroundColor: '#8b5cf6',
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
    gap: 8,
  },
  balanceLabel: {
    fontSize: 14,
    color: '#e9d5ff',
    fontWeight: '600',
    textAlign: 'right',
  },
  balanceAmount: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'right',
  },
  balanceDetails: {
    flexDirection: 'row',
    gap: 24,
    marginTop: 8,
    justifyContent: 'flex-end',
  },
  balanceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  balanceItemText: {
    fontSize: 13,
    color: '#e9d5ff',
    fontWeight: '500',
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    gap: 8,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 13,
    color: '#64748b',
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    gap: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#94a3b8',
  },
  emptyText: {
    fontSize: 15,
    color: '#cbd5e1',
    textAlign: 'center',
    lineHeight: 22,
  },
});
