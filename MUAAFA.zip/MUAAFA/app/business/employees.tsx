import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, ActivityIndicator, Modal } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Users, Plus, Search, Mail, Phone, Shield, ChevronLeft, Trash2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { PERMISSIONS } from '@/lib/rbac/permissions';
import { logActivity } from '@/lib/rbac/usePermissions';

interface StaffMember {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  role_name: string;
  status: string;
  hired_at: string;
}

interface StaffRole {
  id: string;
  name: string;
  name_en: string;
  description: string;
}

export default function EmployeesScreen() {
  return (
    <ProtectedRoute requiredPermission={PERMISSIONS.GENERAL.MANAGE_STAFF}>
      <EmployeesContent />
    </ProtectedRoute>
  );
}

function EmployeesContent() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [roles, setRoles] = useState<StaffRole[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [businessType, setBusinessType] = useState<string>('');
  const [businessId, setBusinessId] = useState<string>('');

  const [newStaff, setNewStaff] = useState({
    full_name: '',
    email: '',
    phone: '',
    national_id: '',
    role_id: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.replace('/business/login');
        return;
      }

      const { data: businessData } = await supabase
        .from('business_registrations')
        .select('id, business_type')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!businessData) {
        Alert.alert('خطأ', 'لم يتم العثور على منشأة مسجلة');
        router.back();
        return;
      }

      setBusinessType(businessData.business_type);
      setBusinessId(businessData.id);

      const [staffResult, rolesResult] = await Promise.all([
        supabase
          .from('staff_members_with_roles')
          .select('*')
          .eq('business_id', businessData.id)
          .order('created_at', { ascending: false }),

        supabase
          .from('staff_roles')
          .select('*')
          .or(`business_type.eq.${businessData.business_type},business_type.eq.all`)
      ]);

      if (staffResult.data) setStaff(staffResult.data);
      if (rolesResult.data) setRoles(rolesResult.data);

      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setLoading(false);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحميل البيانات');
    }
  }

  async function handleAddStaff() {
    if (!newStaff.full_name.trim() || !newStaff.email.trim() || !newStaff.phone.trim() || !newStaff.role_id) {
      Alert.alert('خطأ', 'يرجى إكمال جميع الحقول المطلوبة');
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: businessData } = await supabase
        .from('business_registrations')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!businessData) return;

      const { error } = await supabase.from('staff_members').insert({
        business_id: businessData.id,
        full_name: newStaff.full_name.trim(),
        email: newStaff.email.trim().toLowerCase(),
        phone: newStaff.phone.trim(),
        national_id: newStaff.national_id.trim() || null,
        role_id: newStaff.role_id,
        created_by: user.id,
      });

      if (error) throw error;

      await logActivity(businessData.id, 'add_staff_member', 'staff_member', null, {
        staff_name: newStaff.full_name,
        staff_email: newStaff.email
      });

      Alert.alert('نجح', 'تمت إضافة الموظف بنجاح');
      setShowAddModal(false);
      setNewStaff({ full_name: '', email: '', phone: '', national_id: '', role_id: '' });
      loadData();
    } catch (error: any) {
      console.error('Error adding staff:', error);
      Alert.alert('خطأ', error.message || 'حدث خطأ أثناء إضافة الموظف');
    }
  }

  async function handleDeleteStaff(staffId: string, name: string) {
    Alert.alert(
      'تأكيد الحذف',
      `هل أنت متأكد من حذف ${name}؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('staff_members')
                .delete()
                .eq('id', staffId);

              if (error) throw error;

              Alert.alert('نجح', 'تم حذف الموظف');
              loadData();
            } catch (error: any) {
              console.error('Error deleting staff:', error);
              Alert.alert('خطأ', 'حدث خطأ أثناء حذف الموظف');
            }
          }
        }
      ]
    );
  }

  const filteredStaff = staff.filter(member =>
    member.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جارٍ التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.title}>إدارة الموظفين</Text>
          <Text style={styles.subtitle}>{staff.length} موظف</Text>
        </View>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#64748b" strokeWidth={2} />
        <TextInput
          style={styles.searchInput}
          placeholder="بحث عن موظف..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {filteredStaff.map((member) => (
          <View key={member.id} style={styles.staffCard}>
            <View style={styles.staffInfo}>
              <Text style={styles.staffName}>{member.full_name}</Text>
              <View style={styles.staffDetails}>
                <View style={styles.detailRow}>
                  <Mail size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>{member.email}</Text>
                </View>
                {member.phone && (
                  <View style={styles.detailRow}>
                    <Phone size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailText}>{member.phone}</Text>
                  </View>
                )}
                <View style={styles.detailRow}>
                  <Shield size={16} color="#10b981" strokeWidth={2} />
                  <Text style={styles.roleText}>{member.role_name}</Text>
                </View>
              </View>
              <View style={[styles.statusBadge, member.status === 'active' && styles.statusActive]}>
                <Text style={[styles.statusText, member.status === 'active' && styles.statusTextActive]}>
                  {member.status === 'active' ? 'نشط' : 'غير نشط'}
                </Text>
              </View>
            </View>
            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => handleDeleteStaff(member.id, member.full_name)}>
              <Trash2 size={20} color="#ef4444" strokeWidth={2} />
            </TouchableOpacity>
          </View>
        ))}

        {filteredStaff.length === 0 && (
          <View style={styles.emptyState}>
            <Users size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا يوجد موظفين</Text>
            <Text style={styles.emptySubtext}>ابدأ بإضافة موظف جديد</Text>
          </View>
        )}
      </ScrollView>

      <TouchableOpacity style={styles.addButton} onPress={() => setShowAddModal(true)}>
        <Plus size={24} color="#ffffff" strokeWidth={2} />
        <Text style={styles.addButtonText}>إضافة موظف</Text>
      </TouchableOpacity>

      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>إضافة موظف جديد</Text>

            <TextInput
              style={styles.input}
              placeholder="الاسم الكامل *"
              value={newStaff.full_name}
              onChangeText={(text) => setNewStaff({ ...newStaff, full_name: text })}
            />

            <TextInput
              style={styles.input}
              placeholder="البريد الإلكتروني *"
              value={newStaff.email}
              onChangeText={(text) => setNewStaff({ ...newStaff, email: text })}
              keyboardType="email-address"
              autoCapitalize="none"
            />

            <TextInput
              style={styles.input}
              placeholder="رقم الجوال *"
              value={newStaff.phone}
              onChangeText={(text) => setNewStaff({ ...newStaff, phone: text })}
              keyboardType="phone-pad"
            />

            <TextInput
              style={styles.input}
              placeholder="رقم الهوية (اختياري)"
              value={newStaff.national_id}
              onChangeText={(text) => setNewStaff({ ...newStaff, national_id: text })}
              keyboardType="number-pad"
            />

            <Text style={styles.label}>الدور الوظيفي *</Text>
            <View style={styles.rolesContainer}>
              {roles.map((role) => (
                <TouchableOpacity
                  key={role.id}
                  style={[
                    styles.roleOption,
                    newStaff.role_id === role.id && styles.roleOptionActive
                  ]}
                  onPress={() => setNewStaff({ ...newStaff, role_id: role.id })}>
                  <Text style={[
                    styles.roleOptionText,
                    newStaff.role_id === role.id && styles.roleOptionTextActive
                  ]}>
                    {role.name}
                  </Text>
                  <Text style={styles.roleDescription}>{role.description}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => {
                  setShowAddModal(false);
                  setNewStaff({ full_name: '', email: '', phone: '', national_id: '', role_id: '' });
                }}>
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={handleAddStaff}>
                <Text style={styles.saveButtonText}>إضافة</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    gap: 12,
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  headerContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    margin: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  staffCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    flexDirection: 'row',
    gap: 12,
  },
  staffInfo: {
    flex: 1,
    gap: 8,
  },
  staffName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  staffDetails: {
    gap: 6,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    justifyContent: 'flex-end',
  },
  detailText: {
    fontSize: 14,
    color: '#64748b',
  },
  roleText: {
    fontSize: 14,
    color: '#10b981',
    fontWeight: '600',
  },
  statusBadge: {
    alignSelf: 'flex-end',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: '#f1f5f9',
  },
  statusActive: {
    backgroundColor: '#d1fae5',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
  },
  statusTextActive: {
    color: '#059669',
  },
  deleteButton: {
    padding: 8,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    gap: 12,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#94a3b8',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#cbd5e1',
  },
  addButton: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    left: 24,
    backgroundColor: '#0ea5e9',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  addButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    maxHeight: '90%',
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 24,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 12,
    textAlign: 'right',
  },
  rolesContainer: {
    gap: 8,
    marginBottom: 24,
  },
  roleOption: {
    backgroundColor: '#f8fafc',
    borderWidth: 2,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 12,
  },
  roleOptionActive: {
    backgroundColor: '#dbeafe',
    borderColor: '#0ea5e9',
  },
  roleOptionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
    textAlign: 'right',
    marginBottom: 4,
  },
  roleOptionTextActive: {
    color: '#0369a1',
  },
  roleDescription: {
    fontSize: 13,
    color: '#94a3b8',
    textAlign: 'right',
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#f1f5f9',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#64748b',
    fontSize: 16,
    fontWeight: 'bold',
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#0ea5e9',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
