import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, Platform } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { Building2, FileText, Phone, MapPin, Upload, User, CreditCard } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import * as ImagePicker from 'expo-image-picker';
import {
  validateEmailForBusiness,
  validatePhone,
  validateCommercialRegistration,
  validateBusinessName,
  parseSupabaseError,
} from '@/lib/validation-utils';

export default function UnifiedBusinessRegistrationScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [selectedType, setSelectedType] = useState('');

  const [formData, setFormData] = useState({
    business_type: '',
    business_name: '',
    commercial_registration: '',
    tax_number: '',
    health_license: '',
    authorized_person_name: '',
    authorized_person_phone: '',
    admin_contact_phone: '',
    admin_contact_email: '',
    geographic_address: '',
    headquarters_location: '',
    headquarters_latitude: null as number | null,
    headquarters_longitude: null as number | null,
    commercial_registration_image: '',
  });

  const businessTypes = [
    {
      id: 'insurance',
      name: language === 'ar' ? 'شركة تأمين' : 'Insurance Company',
      icon: '🛡️',
      description: language === 'ar' ? 'تقديم التغطية التأمينية الصحية' : 'Providing health insurance coverage',
    },
    {
      id: 'hospital',
      name: language === 'ar' ? 'مستشفى / مجمع طبي' : 'Hospital / Medical Center',
      icon: '🏥',
      description: language === 'ar' ? 'تقديم الخدمات الطبية والاستشارات' : 'Providing medical services and consultations',
    },
    {
      id: 'pharmacy',
      name: language === 'ar' ? 'صيدلية' : 'Pharmacy',
      icon: '💊',
      description: language === 'ar' ? 'بيع الأدوية والمستلزمات الطبية' : 'Selling medicines and medical supplies',
    },
  ];

  async function pickImage() {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];

        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('User not authenticated');

        const fileExt = asset.uri.split('.').pop();
        const fileName = `${user.id}-${Date.now()}.${fileExt}`;
        const filePath = `business-registrations/${fileName}`;

        const response = await fetch(asset.uri);
        const blob = await response.blob();
        const arrayBuffer = await blob.arrayBuffer();

        const { error: uploadError } = await supabase.storage
          .from('public')
          .upload(filePath, arrayBuffer, {
            contentType: `image/${fileExt}`,
            upsert: false,
          });

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('public')
          .getPublicUrl(filePath);

        setFormData({ ...formData, commercial_registration_image: publicUrl });

        Alert.alert(
          language === 'ar' ? 'تم الرفع' : 'Uploaded',
          language === 'ar' ? 'تم رفع الصورة بنجاح' : 'Image uploaded successfully'
        );
      }
    } catch (error: any) {
      console.error('Error picking image:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'حدث خطأ في رفع الصورة' : 'Error uploading image')
      );
    }
  }

  async function handleSubmit() {
    if (!formData.business_type) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'يرجى اختيار نوع الجهة أولاً' : 'Please select business type first'
      );
      return;
    }

    const businessNameValidation = validateBusinessName(formData.business_name);
    if (!businessNameValidation.isValid) {
      Alert.alert(
        language === 'ar' ? 'خطأ في اسم المنشأة' : 'Business Name Error',
        businessNameValidation.errorMessage
      );
      return;
    }

    const crValidation = validateCommercialRegistration(formData.commercial_registration);
    if (!crValidation.isValid) {
      Alert.alert(
        language === 'ar' ? 'خطأ في رقم السجل التجاري' : 'Commercial Registration Error',
        crValidation.errorMessage
      );
      return;
    }

    if (!formData.tax_number.trim()) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'الرقم الضريبي مطلوب' : 'Tax number is required'
      );
      return;
    }

    if (!formData.health_license.trim()) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'رقم الترخيص الصحي مطلوب' : 'Health license number is required'
      );
      return;
    }

    if (!formData.authorized_person_name.trim() || formData.authorized_person_name.trim().length < 3) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'اسم الشخص المفوض مطلوب ويجب أن يكون 3 أحرف على الأقل' : 'Authorized person name is required and must be at least 3 characters'
      );
      return;
    }

    const authPhoneValidation = validatePhone(formData.authorized_person_phone);
    if (!authPhoneValidation.isValid) {
      Alert.alert(
        language === 'ar' ? 'خطأ في رقم جوال الشخص المفوض' : 'Authorized Person Phone Error',
        authPhoneValidation.errorMessage
      );
      return;
    }

    const adminPhoneValidation = validatePhone(formData.admin_contact_phone);
    if (!adminPhoneValidation.isValid) {
      Alert.alert(
        language === 'ar' ? 'خطأ في رقم جوال الإدارة' : 'Admin Contact Phone Error',
        adminPhoneValidation.errorMessage
      );
      return;
    }

    const trimmedEmail = formData.admin_contact_email.trim();
    const emailValidation = validateEmailForBusiness(trimmedEmail);
    if (!emailValidation.isValid) {
      Alert.alert(
        language === 'ar' ? 'خطأ في البريد الإلكتروني' : 'Email Error',
        emailValidation.errorMessage
      );
      return;
    }

    if (!formData.geographic_address.trim() || formData.geographic_address.trim().length < 10) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'العنوان الجغرافي مطلوب ويجب أن يكون تفصيلياً (10 أحرف على الأقل)' : 'Geographic address is required and must be detailed (at least 10 characters)'
      );
      return;
    }

    if (!formData.commercial_registration_image) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'يرجى رفع صورة السجل التجاري' : 'Please upload commercial registration image'
      );
      return;
    }

    try {
      setLoading(true);
      const { data: { user }, error: authError } = await supabase.auth.getUser();

      if (authError || !user) {
        setLoading(false);
        Alert.alert(
          language === 'ar' ? 'يجب إنشاء حساب أولاً' : 'Account Required',
          language === 'ar'
            ? 'لتسجيل منشأة، يجب عليك:\n\n1. إنشاء حساب شخصي أولاً\n2. تسجيل الدخول\n3. ثم العودة لتسجيل المنشأة\n\nانتقل إلى صفحة التسجيل؟'
            : 'To register a business, you must:\n\n1. Create a personal account first\n2. Sign in\n3. Then return to register your business\n\nGo to registration page?',
          [
            {
              text: language === 'ar' ? 'إلغاء' : 'Cancel',
              style: 'cancel'
            },
            {
              text: language === 'ar' ? 'تسجيل حساب' : 'Sign Up',
              onPress: () => router.push('/auth/register')
            }
          ]
        );
        return;
      }

      const normalizedAuthPhone = authPhoneValidation.normalizedValue || formData.authorized_person_phone;
      const normalizedAdminPhone = adminPhoneValidation.normalizedValue || formData.admin_contact_phone;

      const { error } = await supabase
        .from('business_verification')
        .insert({
          user_id: user.id,
          business_type: formData.business_type,
          business_name: formData.business_name.trim(),
          commercial_registration: formData.commercial_registration.trim(),
          tax_number: formData.tax_number.trim(),
          health_license: formData.health_license.trim() || null,
          authorized_person_name: formData.authorized_person_name.trim(),
          authorized_person_phone: normalizedAuthPhone,
          admin_contact_phone: normalizedAdminPhone,
          admin_contact_email: trimmedEmail.toLowerCase(),
          geographic_address: formData.geographic_address.trim(),
          headquarters_location: formData.headquarters_location.trim() || formData.geographic_address.trim(),
          headquarters_latitude: formData.headquarters_latitude,
          headquarters_longitude: formData.headquarters_longitude,
          commercial_registration_image: formData.commercial_registration_image,
          verification_status: 'pending',
        });

      if (error) {
        setLoading(false);
        const errorMsg = parseSupabaseError(error);
        Alert.alert(
          language === 'ar' ? 'خطأ في التسجيل' : 'Registration Error',
          errorMsg
        );
        return;
      }

      setLoading(false);
      Alert.alert(
        language === 'ar' ? 'تم التسجيل بنجاح' : 'Registration Complete!',
        language === 'ar'
          ? `تم تسجيل منشأة "${formData.business_name.trim()}" بنجاح\n\nستتلقى إشعاراً عند الموافقة على حسابك من الإدارة.\n\nيمكنك متابعة حالة طلبك من صفحة الانتظار.`
          : `Business "${formData.business_name.trim()}" has been registered successfully\n\nYou will receive a notification when your account is approved by administration.\n\nYou can track your application status from the pending page.`,
        [
          {
            text: 'OK',
            onPress: () => router.replace('/business/pending-approval'),
          },
        ]
      );
    } catch (error: any) {
      setLoading(false);
      console.error('Error submitting registration:', error);
      const errorMsg = parseSupabaseError(error);
      Alert.alert(
        language === 'ar' ? 'خطأ غير متوقع' : 'Unexpected Error',
        errorMsg
      );
    }
  }

  if (!selectedType) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>
            {language === 'ar' ? 'تسجيل حساب أعمال' : 'Business Registration'}
          </Text>
          <Text style={styles.headerSubtitle}>
            {language === 'ar' ? 'اختر نوع نشاطك التجاري' : 'Choose your business type'}
          </Text>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {businessTypes.map((type) => (
            <TouchableOpacity
              key={type.id}
              style={styles.typeCard}
              onPress={() => {
                setSelectedType(type.id);
                setFormData({ ...formData, business_type: type.id });
              }}
            >
              <Text style={styles.typeIcon}>{type.icon}</Text>
              <View style={styles.typeInfo}>
                <Text style={styles.typeName}>{type.name}</Text>
                <Text style={styles.typeDescription}>{type.description}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => setSelectedType('')}
        >
          <Text style={styles.backButtonText}>
            {language === 'ar' ? '← رجوع' : '← Back'}
          </Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'بيانات التسجيل' : 'Registration Details'}
        </Text>
        <Text style={styles.headerSubtitle}>
          {businessTypes.find(t => t.id === selectedType)?.name}
        </Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'معلومات الكيان' : 'Entity Information'}
          </Text>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'اسم الكيان *' : 'Entity Name *'}
            </Text>
            <View style={styles.inputWithIcon}>
              <Building2 size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputField}
                value={formData.business_name}
                onChangeText={(text) => setFormData({ ...formData, business_name: text })}
                placeholder={language === 'ar' ? 'مثال: صيدلية النهدي' : 'Example: Al Nahdi Pharmacy'}
                placeholderTextColor="#94a3b8"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'رقم السجل التجاري *' : 'Commercial Registration Number *'}
            </Text>
            <View style={styles.inputWithIcon}>
              <FileText size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputField}
                value={formData.commercial_registration}
                onChangeText={(text) => setFormData({ ...formData, commercial_registration: text })}
                placeholder="1234567890"
                placeholderTextColor="#94a3b8"
                keyboardType="numeric"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'الرقم الضريبي *' : 'Tax Number *'}
            </Text>
            <View style={styles.inputWithIcon}>
              <CreditCard size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputField}
                value={formData.tax_number}
                onChangeText={(text) => setFormData({ ...formData, tax_number: text })}
                placeholder="300000000000003"
                placeholderTextColor="#94a3b8"
                keyboardType="numeric"
              />
            </View>
          </View>

          {selectedType !== 'delivery' && (
            <View style={styles.inputGroup}>
              <Text style={styles.label}>
                {language === 'ar' ? 'رقم الترخيص الصحي *' : 'Health License Number *'}
              </Text>
              <View style={styles.inputWithIcon}>
                <FileText size={20} color="#64748b" strokeWidth={2} />
                <TextInput
                  style={styles.inputField}
                  value={formData.health_license}
                  onChangeText={(text) => setFormData({ ...formData, health_license: text })}
                  placeholder="HL-123456"
                  placeholderTextColor="#94a3b8"
                />
              </View>
            </View>
          )}

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'صورة السجل التجاري *' : 'Commercial Registration Image *'}
            </Text>
            <TouchableOpacity style={styles.uploadButton} onPress={pickImage}>
              <Upload size={20} color="#0ea5e9" strokeWidth={2} />
              <Text style={styles.uploadButtonText}>
                {formData.commercial_registration_image
                  ? (language === 'ar' ? 'تم الرفع ✓' : 'Uploaded ✓')
                  : (language === 'ar' ? 'رفع الصورة' : 'Upload Image')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'بيانات المفوض' : 'Authorized Person'}
          </Text>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'اسم المفوض *' : 'Authorized Person Name *'}
            </Text>
            <View style={styles.inputWithIcon}>
              <User size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputField}
                value={formData.authorized_person_name}
                onChangeText={(text) => setFormData({ ...formData, authorized_person_name: text })}
                placeholder={language === 'ar' ? 'أحمد محمد' : 'Ahmed Mohammed'}
                placeholderTextColor="#94a3b8"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'رقم جوال المفوض *' : 'Authorized Person Phone *'}
            </Text>
            <View style={styles.inputWithIcon}>
              <Phone size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputField}
                value={formData.authorized_person_phone}
                onChangeText={(text) => setFormData({ ...formData, authorized_person_phone: text })}
                placeholder="05xxxxxxxx"
                placeholderTextColor="#94a3b8"
                keyboardType="phone-pad"
              />
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'معلومات التواصل' : 'Contact Information'}
          </Text>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'رقم التواصل الإداري *' : 'Admin Contact Phone *'}
            </Text>
            <View style={styles.inputWithIcon}>
              <Phone size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputField}
                value={formData.admin_contact_phone}
                onChangeText={(text) => setFormData({ ...formData, admin_contact_phone: text })}
                placeholder="05xxxxxxxx"
                placeholderTextColor="#94a3b8"
                keyboardType="phone-pad"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'البريد الإلكتروني *' : 'Email *'}
            </Text>
            <TextInput
              style={styles.input}
              value={formData.admin_contact_email}
              onChangeText={(text) => setFormData({ ...formData, admin_contact_email: text })}
              placeholder="info@company.com"
              placeholderTextColor="#94a3b8"
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'العنوان' : 'Address'}
          </Text>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              {language === 'ar' ? 'العنوان الجغرافي *' : 'Geographic Address *'}
            </Text>
            <View style={styles.inputWithIcon}>
              <MapPin size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputField}
                value={formData.geographic_address}
                onChangeText={(text) => setFormData({ ...formData, geographic_address: text })}
                placeholder={language === 'ar' ? 'الرياض، حي النخيل، شارع الملك فهد' : 'Riyadh, Al Nakheel, King Fahd Street'}
                placeholderTextColor="#94a3b8"
                multiline
              />
            </View>
          </View>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>
            {language === 'ar' ? '📌 ملاحظة هامة' : '📌 Important Note'}
          </Text>
          <Text style={styles.infoText}>
            {language === 'ar'
              ? 'سيتم مراجعة طلبك من قبل الإدارة خلال 24-48 ساعة. ستتلقى إشعاراً عند الموافقة على حسابك.'
              : 'Your application will be reviewed by administration within 24-48 hours. You will receive a notification when your account is approved.'}
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.submitButton, loading && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={loading}
        >
          <Text style={styles.submitButtonText}>
            {loading
              ? (language === 'ar' ? 'جاري التسجيل...' : 'Registering...')
              : (language === 'ar' ? 'تسجيل الحساب' : 'Register Account')}
          </Text>
        </TouchableOpacity>

        <View style={styles.spacer} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    marginBottom: 12,
  },
  backButtonText: {
    fontSize: 14,
    color: '#0ea5e9',
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
  },
  content: {
    flex: 1,
    padding: 24,
  },
  typeCard: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 16,
  },
  typeIcon: {
    fontSize: 48,
  },
  typeInfo: {
    flex: 1,
  },
  typeName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  typeDescription: {
    fontSize: 14,
    color: '#64748b',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
  },
  inputWithIcon: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  inputField: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  uploadButton: {
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#0ea5e9',
    borderStyle: 'dashed',
    borderRadius: 12,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  uploadButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  infoBox: {
    backgroundColor: '#eff6ff',
    borderLeftWidth: 4,
    borderLeftColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#64748b',
    lineHeight: 20,
  },
  submitButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  submitButtonDisabled: {
    opacity: 0.5,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  spacer: {
    height: 40,
  },
});
