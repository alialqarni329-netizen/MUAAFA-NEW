import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Building2, MapPin, Users } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { parseSupabaseError } from '@/lib/validation-utils';

export default function CompleteBusinessProfile() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [businessData, setBusinessData] = useState({
    description: '',
    address: '',
    city: '',
    employees_count: '',
    service_areas: '',
  });

  useEffect(() => {
    checkProfileStatus();
  }, []);

  async function checkProfileStatus() {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً');
        router.replace('/business/login');
        return;
      }

      const { data: business } = await supabase
        .from('business_registrations')
        .select('status, profile_completed')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!business) {
        Alert.alert('خطأ', 'لم يتم العثور على بيانات المنشأة');
        router.replace('/business/login');
        return;
      }

      if (business.status !== 'approved') {
        Alert.alert('تنبيه', 'حسابك لم يتم الموافقة عليه بعد');
        router.replace('/business/pending-approval');
        return;
      }

      if (business.profile_completed) {
        router.replace('/business/dashboard');
        return;
      }
    } catch (error) {
      console.error('Error checking profile status:', error);
    }
  }

  async function handleSubmit() {
    if (!businessData.description.trim()) {
      Alert.alert('خطأ', 'وصف المنشأة مطلوب');
      return;
    }

    if (!businessData.address.trim()) {
      Alert.alert('خطأ', 'عنوان المنشأة مطلوب');
      return;
    }

    if (!businessData.city.trim()) {
      Alert.alert('خطأ', 'المدينة مطلوبة');
      return;
    }

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        setLoading(false);
        Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً');
        router.replace('/business/login');
        return;
      }

      const { error: updateError } = await supabase
        .from('business_registrations')
        .update({
          description: businessData.description.trim(),
          address: businessData.address.trim(),
          city: businessData.city.trim(),
          employees_count: parseInt(businessData.employees_count) || null,
          service_areas: businessData.service_areas.trim() || null,
          profile_completed: true,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user.id);

      if (updateError) {
        setLoading(false);
        const errorMsg = parseSupabaseError(updateError);
        Alert.alert('خطأ في حفظ البيانات', errorMsg);
        return;
      }

      setLoading(false);
      Alert.alert(
        'تم بنجاح',
        'تم حفظ معلومات المنشأة بنجاح\n\nيمكنك الآن الوصول إلى لوحة التحكم',
        [
          {
            text: 'متابعة',
            onPress: () => router.replace('/business/dashboard')
          }
        ]
      );
    } catch (error: any) {
      setLoading(false);
      const errorMsg = parseSupabaseError(error);
      Alert.alert('خطأ غير متوقع', errorMsg);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Building2 size={48} color="#6366f1" strokeWidth={2} />
        <Text style={styles.title}>إكمال معلومات المنشأة</Text>
        <Text style={styles.subtitle}>يرجى إكمال المعلومات التالية للمتابعة</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>وصف المنشأة *</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="اكتب وصف مختصر عن المنشأة وخدماتها"
              value={businessData.description}
              onChangeText={(text) => setBusinessData({ ...businessData, description: text })}
              multiline
              numberOfLines={4}
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>عنوان المنشأة *</Text>
            <TextInput
              style={styles.input}
              placeholder="الشارع، الحي"
              value={businessData.address}
              onChangeText={(text) => setBusinessData({ ...businessData, address: text })}
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>المدينة *</Text>
            <TextInput
              style={styles.input}
              placeholder="الرياض، جدة، ..."
              value={businessData.city}
              onChangeText={(text) => setBusinessData({ ...businessData, city: text })}
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>عدد الموظفين (اختياري)</Text>
            <TextInput
              style={styles.input}
              placeholder="50"
              value={businessData.employees_count}
              onChangeText={(text) => setBusinessData({ ...businessData, employees_count: text })}
              keyboardType="number-pad"
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>مناطق الخدمة (اختياري)</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="الرياض، الشرقية، مكة المكرمة"
              value={businessData.service_areas}
              onChangeText={(text) => setBusinessData({ ...businessData, service_areas: text })}
              multiline
              numberOfLines={3}
              textAlign="right"
            />
          </View>
        </View>

        <TouchableOpacity
          style={[styles.submitButton, loading && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <>
              <Building2 size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.submitButtonText}>حفظ والمتابعة</Text>
            </>
          )}
        </TouchableOpacity>

        <View style={styles.infoBox}>
          <Text style={styles.infoText}>
            ملاحظة: يمكنك تحديث هذه المعلومات لاحقاً من الإعدادات
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#ffffff',
    padding: 32,
    paddingTop: 60,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 8,
    textAlign: 'center',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 24,
  },
  form: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    gap: 20,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    padding: 16,
    fontSize: 16,
    color: '#0f172a',
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: '#6366f1',
    borderRadius: 12,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 24,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  infoBox: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  },
  infoText: {
    fontSize: 13,
    color: '#1e40af',
    textAlign: 'center',
    lineHeight: 20,
  },
});
