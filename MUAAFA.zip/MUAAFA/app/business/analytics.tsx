import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { BarChart3, ChevronLeft, TrendingUp, Users, DollarSign, Activity } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { PERMISSIONS } from '@/lib/rbac/permissions';

export default function AnalyticsScreen() {
  return (
    <ProtectedRoute requiredPermission={PERMISSIONS.GENERAL.VIEW_STATISTICS}>
      <AnalyticsContent />
    </ProtectedRoute>
  );
}

function AnalyticsContent() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [businessType, setBusinessType] = useState<string>('');
  const [stats, setStats] = useState({
    customers: 0,
    growth: 0,
    revenue: 0,
    dailyActivity: 0,
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.replace('/business/login');
        return;
      }

      const { data: businessData } = await supabase
        .from('business_registrations')
        .select('id, business_type')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!businessData) {
        setLoading(false);
        return;
      }

      setBusinessType(businessData.business_type);

      const today = new Date().toISOString().split('T')[0];
      const lastMonth = new Date();
      lastMonth.setMonth(lastMonth.getMonth() - 1);

      const [paymentsResult, todayPaymentsResult] = await Promise.all([
        supabase
          .from('payments')
          .select('total_amount, created_at')
          .eq('business_id', businessData.id)
          .eq('payment_status', 'completed'),

        supabase
          .from('payments')
          .select('*', { count: 'exact', head: true })
          .eq('business_id', businessData.id)
          .gte('created_at', `${today}T00:00:00`)
      ]);

      const payments = paymentsResult.data || [];
      const totalRevenue = payments.reduce((sum, p) => sum + (p.total_amount || 0), 0);

      const recentPayments = payments.filter(p => new Date(p.created_at) >= lastMonth);
      const oldPayments = payments.filter(p => new Date(p.created_at) < lastMonth);

      const recentRevenue = recentPayments.reduce((sum, p) => sum + (p.total_amount || 0), 0);
      const oldRevenue = oldPayments.reduce((sum, p) => sum + (p.total_amount || 0), 0);

      const growthRate = oldRevenue > 0 ? ((recentRevenue - oldRevenue) / oldRevenue) * 100 : 0;

      setStats({
        customers: payments.length,
        growth: Math.round(growthRate),
        revenue: totalRevenue,
        dailyActivity: todayPaymentsResult.count || 0,
      });

      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#ec4899" />
        <Text style={styles.loadingText}>جارٍ التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.title}>الإحصائيات</Text>
          <Text style={styles.subtitle}>تحليلات الأداء والبيانات</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Users size={32} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statNumber}>{stats.customers}</Text>
            <Text style={styles.statLabel}>
              {businessType === 'insurance' ? 'مطالبات' : businessType === 'hospital' ? 'مرضى' : 'عملاء'}
            </Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <TrendingUp size={32} color="#10b981" strokeWidth={2} />
            <Text style={styles.statNumber}>{stats.growth}%</Text>
            <Text style={styles.statLabel}>النمو</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <DollarSign size={32} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statNumber}>{stats.revenue.toLocaleString('ar-SA')} ر.س</Text>
            <Text style={styles.statLabel}>الإيرادات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#e0e7ff' }]}>
            <Activity size={32} color="#6366f1" strokeWidth={2} />
            <Text style={styles.statNumber}>{stats.dailyActivity}</Text>
            <Text style={styles.statLabel}>النشاط اليومي</Text>
          </View>
        </View>

        <View style={styles.chartPlaceholder}>
          <BarChart3 size={48} color="#cbd5e1" strokeWidth={2} />
          <Text style={styles.chartText}>الرسوم البيانية قريباً</Text>
        </View>

        <View style={styles.emptyState}>
          <BarChart3 size={64} color="#cbd5e1" strokeWidth={2} />
          <Text style={styles.emptyTitle}>لا توجد بيانات كافية</Text>
          <Text style={styles.emptyText}>
            ستظهر الإحصائيات والتحليلات{'\n'}عند توفر البيانات
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    gap: 12,
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  headerContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    width: '47%',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    gap: 12,
  },
  statNumber: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 13,
    color: '#64748b',
    fontWeight: '600',
  },
  chartPlaceholder: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 48,
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    borderStyle: 'dashed',
  },
  chartText: {
    fontSize: 16,
    color: '#94a3b8',
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
    gap: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#94a3b8',
  },
  emptyText: {
    fontSize: 15,
    color: '#cbd5e1',
    textAlign: 'center',
    lineHeight: 22,
  },
});
