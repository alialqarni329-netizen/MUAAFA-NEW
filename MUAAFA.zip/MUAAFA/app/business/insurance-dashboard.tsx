import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, Alert, TextInput, Modal } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Shield, Clock, CheckCircle2, XCircle, AlertCircle, FileText, DollarSign, User } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface InsuranceApproval {
  id: string;
  order_id: string;
  user_id: string;
  provider_id: string;
  request_type: string;
  total_amount: number;
  coverage_percentage: number;
  status: string;
  diagnosis_description: string;
  treatment_plan: string;
  created_at: string;
  provider: {
    business_name: string;
    business_type: string;
  };
  user_profile: {
    full_name: string;
  };
}

export default function InsuranceDashboardScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [approvals, setApprovals] = useState<InsuranceApproval[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedApproval, setSelectedApproval] = useState<InsuranceApproval | null>(null);
  const [showDecisionModal, setShowDecisionModal] = useState(false);
  const [decision, setDecision] = useState<'approve' | 'reject' | 'more_info' | null>(null);
  const [coveragePercentage, setCoveragePercentage] = useState('80');
  const [rejectionReason, setRejectionReason] = useState('');
  const [additionalInfoRequest, setAdditionalInfoRequest] = useState('');

  useEffect(() => {
    loadApprovals();

    const subscription = supabase
      .channel('insurance_approvals_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'insurance_approvals',
      }, () => {
        loadApprovals();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  async function loadApprovals() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: businessData } = await supabase
        .from('business_verification')
        .select('id')
        .eq('user_id', user.id)
        .eq('business_type', 'insurance')
        .eq('verification_status', 'active')
        .maybeSingle();

      if (!businessData) {
        Alert.alert(
          language === 'ar' ? 'غير مصرح' : 'Unauthorized',
          language === 'ar' ? 'حسابك غير مفعل' : 'Your account is not activated'
        );
        return;
      }

      const { data, error } = await supabase
        .from('insurance_approvals')
        .select(`
          *,
          provider:provider_id(business_name, business_type),
          user_profile:user_id(full_name)
        `)
        .eq('insurance_company_id', businessData.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setApprovals(data || []);
    } catch (error) {
      console.error('Error loading approvals:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleDecision() {
    if (!selectedApproval || !decision) return;

    if (decision === 'approve' && !coveragePercentage) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'يرجى تحديد نسبة التغطية' : 'Please specify coverage percentage'
      );
      return;
    }

    if (decision === 'reject' && !rejectionReason) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'يرجى إدخال سبب الرفض' : 'Please enter rejection reason'
      );
      return;
    }

    if (decision === 'more_info' && !additionalInfoRequest) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'يرجى تحديد المعلومات المطلوبة' : 'Please specify required information'
      );
      return;
    }

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const updateData: any = {
        status: decision === 'approve' ? 'approved' : decision === 'reject' ? 'rejected' : 'more_info_needed',
        reviewed_at: new Date().toISOString(),
        approved_by: user.id,
      };

      if (decision === 'approve') {
        const coverage = parseFloat(coveragePercentage) / 100;
        const coveredAmount = selectedApproval.total_amount * coverage;
        const patientAmount = selectedApproval.total_amount - coveredAmount;

        updateData.coverage_percentage = parseFloat(coveragePercentage);
        updateData.covered_amount = coveredAmount;
        updateData.patient_amount = patientAmount;
        updateData.approved_at = new Date().toISOString();
        updateData.expires_at = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
      } else if (decision === 'reject') {
        updateData.rejection_reason = rejectionReason;
      } else if (decision === 'more_info') {
        updateData.additional_info_request = additionalInfoRequest;
      }

      const { error } = await supabase
        .from('insurance_approvals')
        .update(updateData)
        .eq('id', selectedApproval.id);

      if (error) throw error;

      Alert.alert(
        language === 'ar' ? 'تم بنجاح' : 'Success',
        language === 'ar' ? 'تم تحديث حالة الطلب' : 'Request status updated'
      );

      setShowDecisionModal(false);
      setSelectedApproval(null);
      setDecision(null);
      setCoveragePercentage('80');
      setRejectionReason('');
      setAdditionalInfoRequest('');
      loadApprovals();
    } catch (error: any) {
      console.error('Error updating approval:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'حدث خطأ' : 'An error occurred')
      );
    } finally {
      setLoading(false);
    }
  }

  function renderApprovalCard(approval: InsuranceApproval) {
    const statusConfig = {
      pending: {
        color: '#f59e0b',
        icon: Clock,
        text: language === 'ar' ? 'قيد المراجعة' : 'Pending',
      },
      approved: {
        color: '#10b981',
        icon: CheckCircle2,
        text: language === 'ar' ? 'موافق' : 'Approved',
      },
      rejected: {
        color: '#ef4444',
        icon: XCircle,
        text: language === 'ar' ? 'مرفوض' : 'Rejected',
      },
      more_info_needed: {
        color: '#0ea5e9',
        icon: AlertCircle,
        text: language === 'ar' ? 'معلومات إضافية' : 'More Info',
      },
    };

    const config = statusConfig[approval.status as keyof typeof statusConfig];
    const StatusIcon = config.icon;

    return (
      <TouchableOpacity
        key={approval.id}
        style={styles.approvalCard}
        onPress={() => {
          setSelectedApproval(approval);
          setShowDecisionModal(true);
        }}
        disabled={approval.status !== 'pending'}
      >
        <View style={styles.approvalHeader}>
          <View style={[styles.statusBadge, { backgroundColor: config.color + '20' }]}>
            <StatusIcon size={16} color={config.color} strokeWidth={2} />
            <Text style={[styles.statusText, { color: config.color }]}>
              {config.text}
            </Text>
          </View>
          <Text style={styles.approvalDate}>
            {new Date(approval.created_at).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
          </Text>
        </View>

        <View style={styles.approvalInfo}>
          <View style={styles.infoRow}>
            <User size={16} color="#64748b" strokeWidth={2} />
            <Text style={styles.infoLabel}>
              {language === 'ar' ? 'المريض:' : 'Patient:'}
            </Text>
            <Text style={styles.infoValue}>
              {approval.user_profile?.full_name || language === 'ar' ? 'غير متوفر' : 'N/A'}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Shield size={16} color="#64748b" strokeWidth={2} />
            <Text style={styles.infoLabel}>
              {language === 'ar' ? 'المقدم:' : 'Provider:'}
            </Text>
            <Text style={styles.infoValue}>
              {approval.provider?.business_name || language === 'ar' ? 'غير متوفر' : 'N/A'}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <FileText size={16} color="#64748b" strokeWidth={2} />
            <Text style={styles.infoLabel}>
              {language === 'ar' ? 'النوع:' : 'Type:'}
            </Text>
            <Text style={styles.infoValue}>
              {approval.request_type === 'medication' ? (language === 'ar' ? 'دواء' : 'Medication') :
               approval.request_type === 'procedure' ? (language === 'ar' ? 'إجراء' : 'Procedure') :
               approval.request_type === 'consultation' ? (language === 'ar' ? 'استشارة' : 'Consultation') :
               (language === 'ar' ? 'تنويم' : 'Hospitalization')}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <DollarSign size={16} color="#64748b" strokeWidth={2} />
            <Text style={styles.infoLabel}>
              {language === 'ar' ? 'المبلغ:' : 'Amount:'}
            </Text>
            <Text style={styles.amountValue}>
              {approval.total_amount.toLocaleString()} {language === 'ar' ? 'ريال' : 'SAR'}
            </Text>
          </View>
        </View>

        {approval.diagnosis_description && (
          <View style={styles.diagnosisBox}>
            <Text style={styles.diagnosisLabel}>
              {language === 'ar' ? 'التشخيص:' : 'Diagnosis:'}
            </Text>
            <Text style={styles.diagnosisText}>
              {approval.diagnosis_description}
            </Text>
          </View>
        )}

        {approval.status === 'pending' && (
          <View style={styles.actionHint}>
            <Text style={styles.actionHintText}>
              {language === 'ar' ? 'اضغط لاتخاذ قرار' : 'Tap to make decision'}
            </Text>
          </View>
        )}
      </TouchableOpacity>
    );
  }

  const pendingCount = approvals.filter(a => a.status === 'pending').length;
  const approvedCount = approvals.filter(a => a.status === 'approved').length;
  const rejectedCount = approvals.filter(a => a.status === 'rejected').length;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Shield size={32} color="#0ea5e9" strokeWidth={2} />
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'لوحة التأمين' : 'Insurance Portal'}
        </Text>
        <Text style={styles.headerSubtitle}>
          {language === 'ar' ? 'إدارة طلبات الموافقة المسبقة' : 'Manage Pre-Authorization Requests'}
        </Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
          <Text style={styles.statNumber}>{pendingCount}</Text>
          <Text style={styles.statLabel}>
            {language === 'ar' ? 'قيد المراجعة' : 'Pending'}
          </Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
          <Text style={styles.statNumber}>{approvedCount}</Text>
          <Text style={styles.statLabel}>
            {language === 'ar' ? 'موافق عليها' : 'Approved'}
          </Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
          <Text style={styles.statNumber}>{rejectedCount}</Text>
          <Text style={styles.statLabel}>
            {language === 'ar' ? 'مرفوضة' : 'Rejected'}
          </Text>
        </View>
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadApprovals(); }} />
        }
      >
        {approvals.length === 0 ? (
          <View style={styles.emptyState}>
            <Shield size={64} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyStateText}>
              {language === 'ar' ? 'لا توجد طلبات موافقة' : 'No approval requests'}
            </Text>
          </View>
        ) : (
          approvals.map(renderApprovalCard)
        )}
      </ScrollView>

      <Modal
        visible={showDecisionModal}
        animationType="slide"
        onRequestClose={() => setShowDecisionModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>
              {language === 'ar' ? 'اتخاذ قرار' : 'Make Decision'}
            </Text>
            <TouchableOpacity onPress={() => setShowDecisionModal(false)}>
              <Text style={styles.modalClose}>✕</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            {selectedApproval && (
              <>
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>
                    {language === 'ar' ? 'تفاصيل الطلب' : 'Request Details'}
                  </Text>
                  <Text style={styles.modalText}>
                    {language === 'ar' ? 'المبلغ:' : 'Amount:'} {selectedApproval.total_amount} {language === 'ar' ? 'ريال' : 'SAR'}
                  </Text>
                  <Text style={styles.modalText}>
                    {language === 'ar' ? 'التشخيص:' : 'Diagnosis:'} {selectedApproval.diagnosis_description}
                  </Text>
                </View>

                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>
                    {language === 'ar' ? 'القرار' : 'Decision'}
                  </Text>

                  <TouchableOpacity
                    style={[styles.decisionButton, decision === 'approve' && styles.decisionButtonActive, { borderColor: '#10b981' }]}
                    onPress={() => setDecision('approve')}
                  >
                    <CheckCircle2 size={24} color={decision === 'approve' ? '#ffffff' : '#10b981'} strokeWidth={2} />
                    <Text style={[styles.decisionButtonText, decision === 'approve' && styles.decisionButtonTextActive]}>
                      {language === 'ar' ? 'موافقة' : 'Approve'}
                    </Text>
                  </TouchableOpacity>

                  {decision === 'approve' && (
                    <View style={styles.coverageInput}>
                      <Text style={styles.inputLabel}>
                        {language === 'ar' ? 'نسبة التغطية %' : 'Coverage Percentage %'}
                      </Text>
                      <TextInput
                        style={styles.input}
                        value={coveragePercentage}
                        onChangeText={setCoveragePercentage}
                        keyboardType="numeric"
                        placeholder="80"
                      />
                    </View>
                  )}

                  <TouchableOpacity
                    style={[styles.decisionButton, decision === 'reject' && styles.decisionButtonActive, { borderColor: '#ef4444' }]}
                    onPress={() => setDecision('reject')}
                  >
                    <XCircle size={24} color={decision === 'reject' ? '#ffffff' : '#ef4444'} strokeWidth={2} />
                    <Text style={[styles.decisionButtonText, decision === 'reject' && styles.decisionButtonTextActive]}>
                      {language === 'ar' ? 'رفض' : 'Reject'}
                    </Text>
                  </TouchableOpacity>

                  {decision === 'reject' && (
                    <View style={styles.reasonInput}>
                      <Text style={styles.inputLabel}>
                        {language === 'ar' ? 'سبب الرفض' : 'Rejection Reason'}
                      </Text>
                      <TextInput
                        style={[styles.input, styles.textArea]}
                        value={rejectionReason}
                        onChangeText={setRejectionReason}
                        placeholder={language === 'ar' ? 'أدخل السبب...' : 'Enter reason...'}
                        multiline
                        numberOfLines={4}
                      />
                    </View>
                  )}

                  <TouchableOpacity
                    style={[styles.decisionButton, decision === 'more_info' && styles.decisionButtonActive, { borderColor: '#0ea5e9' }]}
                    onPress={() => setDecision('more_info')}
                  >
                    <AlertCircle size={24} color={decision === 'more_info' ? '#ffffff' : '#0ea5e9'} strokeWidth={2} />
                    <Text style={[styles.decisionButtonText, decision === 'more_info' && styles.decisionButtonTextActive]}>
                      {language === 'ar' ? 'طلب معلومات إضافية' : 'Request More Info'}
                    </Text>
                  </TouchableOpacity>

                  {decision === 'more_info' && (
                    <View style={styles.reasonInput}>
                      <Text style={styles.inputLabel}>
                        {language === 'ar' ? 'المعلومات المطلوبة' : 'Required Information'}
                      </Text>
                      <TextInput
                        style={[styles.input, styles.textArea]}
                        value={additionalInfoRequest}
                        onChangeText={setAdditionalInfoRequest}
                        placeholder={language === 'ar' ? 'حدد المعلومات المطلوبة...' : 'Specify required info...'}
                        multiline
                        numberOfLines={4}
                      />
                    </View>
                  )}
                </View>
              </>
            )}
          </ScrollView>

          <View style={styles.modalFooter}>
            <TouchableOpacity
              style={[styles.submitButton, !decision && styles.submitButtonDisabled]}
              onPress={handleDecision}
              disabled={!decision || loading}
            >
              <Text style={styles.submitButtonText}>
                {loading ? (language === 'ar' ? 'جاري الحفظ...' : 'Saving...') : (language === 'ar' ? 'تأكيد' : 'Confirm')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 12,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
  },
  statsContainer: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  approvalCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  approvalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  approvalDate: {
    fontSize: 12,
    color: '#94a3b8',
  },
  approvalInfo: {
    gap: 8,
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  infoValue: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '500',
  },
  amountValue: {
    fontSize: 16,
    color: '#0f172a',
    fontWeight: 'bold',
  },
  diagnosisBox: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
  },
  diagnosisLabel: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 4,
  },
  diagnosisText: {
    fontSize: 14,
    color: '#0f172a',
  },
  actionHint: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    alignItems: 'center',
  },
  actionHintText: {
    fontSize: 12,
    color: '#0ea5e9',
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    padding: 48,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
    paddingTop: 60,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  modalClose: {
    fontSize: 24,
    color: '#64748b',
  },
  modalContent: {
    flex: 1,
    padding: 24,
  },
  modalSection: {
    marginBottom: 24,
  },
  modalSectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
  },
  modalText: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 8,
  },
  decisionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    marginBottom: 12,
  },
  decisionButtonActive: {
    backgroundColor: '#10b981',
    borderColor: '#10b981',
  },
  decisionButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  decisionButtonTextActive: {
    color: '#ffffff',
  },
  coverageInput: {
    marginBottom: 16,
  },
  reasonInput: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  modalFooter: {
    padding: 24,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  submitButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  submitButtonDisabled: {
    opacity: 0.5,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
