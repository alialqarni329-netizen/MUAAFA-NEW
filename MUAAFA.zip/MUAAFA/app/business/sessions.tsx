import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Calendar, ChevronLeft, Video, MapPin, Clock } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { PERMISSIONS } from '@/lib/rbac/permissions';

export default function SessionsScreen() {
  return (
    <ProtectedRoute requiredPermission={PERMISSIONS.MEDICAL.MANAGE_SESSIONS}>
      <SessionsContent />
    </ProtectedRoute>
  );
}

function SessionsContent() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAccess();
  }, []);

  async function checkAccess() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.replace('/business/login');
        return;
      }

      const { data: businessData } = await supabase
        .from('business_registrations')
        .select('business_type')
        .eq('user_id', user.id)
        .maybeSingle();

      if (businessData?.business_type !== 'hospital') {
        router.back();
        return;
      }

      setLoading(false);
    } catch (error) {
      console.error('Error checking access:', error);
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#f59e0b" />
        <Text style={styles.loadingText}>جارٍ التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.title}>الجلسات الصحية</Text>
          <Text style={styles.subtitle}>إدارة المواعيد والجلسات</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Video size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statNumber}>0</Text>
            <Text style={styles.statLabel}>جلسات افتراضية</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <MapPin size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statNumber}>0</Text>
            <Text style={styles.statLabel}>جلسات حضورية</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Clock size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statNumber}>0</Text>
            <Text style={styles.statLabel}>قيد الانتظار</Text>
          </View>
        </View>

        <View style={styles.emptyState}>
          <Calendar size={64} color="#cbd5e1" strokeWidth={2} />
          <Text style={styles.emptyTitle}>لا توجد جلسات</Text>
          <Text style={styles.emptyText}>
            ستظهر هنا جميع المواعيد والجلسات{'\n'}المحجوزة من المرضى
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    gap: 12,
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  headerContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    width: '47%',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    gap: 8,
  },
  statNumber: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 13,
    color: '#64748b',
    fontWeight: '600',
    textAlign: 'center',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    gap: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#94a3b8',
  },
  emptyText: {
    fontSize: 15,
    color: '#cbd5e1',
    textAlign: 'center',
    lineHeight: 22,
  },
});
