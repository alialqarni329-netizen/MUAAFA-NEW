import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Settings as SettingsIcon, ChevronLeft, Building2, Bell, Lock, Mail, MapPin, Phone } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { PERMISSIONS } from '@/lib/rbac/permissions';

interface BusinessInfo {
  business_name: string;
  business_type: string;
  business_status: string;
  admin_contact_email: string;
  admin_contact_phone: string;
  geographic_address: string;
}

export default function SettingsScreen() {
  return (
    <ProtectedRoute requiredPermission={PERMISSIONS.GENERAL.MANAGE_SETTINGS}>
      <SettingsContent />
    </ProtectedRoute>
  );
}

function SettingsContent() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo | null>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.replace('/business/login');
        return;
      }

      const { data: businessData } = await supabase
        .from('business_registrations')
        .select('business_name, business_type, business_status, admin_contact_email, admin_contact_phone, geographic_address')
        .eq('user_id', user.id)
        .maybeSingle();

      if (businessData) {
        setBusinessInfo(businessData);
      }

      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setLoading(false);
    }
  }

  function getBusinessTypeName(type: string): string {
    switch (type) {
      case 'insurance': return 'شركة تأمين';
      case 'hospital': return 'مستشفى / مجمع طبي';
      case 'pharmacy': return 'صيدلية';
      default: return type;
    }
  }

  function getStatusName(status: string): string {
    switch (status) {
      case 'active': return 'مفعلة';
      case 'pending_review': return 'قيد المراجعة';
      case 'suspended': return 'موقوفة';
      case 'rejected': return 'مرفوضة';
      default: return status;
    }
  }

  function getStatusColor(status: string): string {
    switch (status) {
      case 'active': return '#10b981';
      case 'pending_review': return '#f59e0b';
      case 'suspended': return '#ef4444';
      case 'rejected': return '#dc2626';
      default: return '#64748b';
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#64748b" />
        <Text style={styles.loadingText}>جارٍ التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.title}>الإعدادات</Text>
          <Text style={styles.subtitle}>إدارة بيانات المنشأة</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {businessInfo && (
          <>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>معلومات المنشأة</Text>

              <View style={styles.infoCard}>
                <View style={styles.infoRow}>
                  <Building2 size={20} color="#64748b" strokeWidth={2} />
                  <View style={styles.infoContent}>
                    <Text style={styles.infoLabel}>اسم المنشأة</Text>
                    <Text style={styles.infoValue}>{businessInfo.business_name}</Text>
                  </View>
                </View>

                <View style={styles.infoRow}>
                  <Building2 size={20} color="#64748b" strokeWidth={2} />
                  <View style={styles.infoContent}>
                    <Text style={styles.infoLabel}>نوع الجهة</Text>
                    <Text style={styles.infoValue}>{getBusinessTypeName(businessInfo.business_type)}</Text>
                  </View>
                </View>

                <View style={styles.infoRow}>
                  <View style={[styles.statusDot, { backgroundColor: getStatusColor(businessInfo.business_status) }]} />
                  <View style={styles.infoContent}>
                    <Text style={styles.infoLabel}>حالة المنشأة</Text>
                    <Text style={[styles.infoValue, { color: getStatusColor(businessInfo.business_status) }]}>
                      {getStatusName(businessInfo.business_status)}
                    </Text>
                  </View>
                </View>
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>معلومات الاتصال</Text>

              <View style={styles.infoCard}>
                <View style={styles.infoRow}>
                  <Mail size={20} color="#64748b" strokeWidth={2} />
                  <View style={styles.infoContent}>
                    <Text style={styles.infoLabel}>البريد الإلكتروني</Text>
                    <Text style={styles.infoValue}>{businessInfo.admin_contact_email}</Text>
                  </View>
                </View>

                <View style={styles.infoRow}>
                  <Phone size={20} color="#64748b" strokeWidth={2} />
                  <View style={styles.infoContent}>
                    <Text style={styles.infoLabel}>رقم الجوال</Text>
                    <Text style={styles.infoValue}>{businessInfo.admin_contact_phone}</Text>
                  </View>
                </View>

                <View style={styles.infoRow}>
                  <MapPin size={20} color="#64748b" strokeWidth={2} />
                  <View style={styles.infoContent}>
                    <Text style={styles.infoLabel}>العنوان</Text>
                    <Text style={styles.infoValue}>{businessInfo.geographic_address}</Text>
                  </View>
                </View>
              </View>
            </View>
          </>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الإشعارات</Text>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Bell size={24} color="#64748b" strokeWidth={2} />
                <View>
                  <Text style={styles.settingTitle}>تفعيل الإشعارات</Text>
                  <Text style={styles.settingDescription}>استقبال التنبيهات والإشعارات</Text>
                </View>
              </View>
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: '#cbd5e1', true: '#86efac' }}
                thumbColor={notificationsEnabled ? '#10b981' : '#f1f5f9'}
              />
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الأمان</Text>

          <TouchableOpacity style={styles.actionCard} onPress={() => Alert.alert('قريباً', 'هذه الميزة قيد التطوير')}>
            <Lock size={24} color="#6366f1" strokeWidth={2} />
            <View style={styles.actionContent}>
              <Text style={styles.actionTitle}>تغيير كلمة المرور</Text>
              <Text style={styles.actionDescription}>تحديث كلمة مرور الحساب</Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    gap: 12,
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  headerContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  infoCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    gap: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  infoContent: {
    flex: 1,
    gap: 4,
    alignItems: 'flex-end',
  },
  infoLabel: {
    fontSize: 13,
    color: '#94a3b8',
    fontWeight: '500',
  },
  infoValue: {
    fontSize: 16,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'right',
  },
  statusDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    marginTop: 2,
  },
  settingCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  settingDescription: {
    fontSize: 13,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  actionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  actionContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  actionDescription: {
    fontSize: 13,
    color: '#64748b',
    marginTop: 2,
  },
});
