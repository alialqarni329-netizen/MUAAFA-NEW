import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, Image, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { Briefcase, Building2 } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '@/lib/supabase';
import { validateEmail, parseSupabaseError } from '@/lib/validation-utils';
import { AuthStorage } from '@/lib/auth-storage';

export default function BusinessLoginScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleLogin() {
    const trimmedEmail = email.trim();
    const emailValidation = validateEmail(trimmedEmail);
    if (!emailValidation.isValid) {
      Alert.alert('خطأ في البريد الإلكتروني', emailValidation.errorMessage);
      return;
    }

    if (!password) {
      Alert.alert('خطأ', 'كلمة المرور مطلوبة، يرجى إدخالها');
      return;
    }

    if (password.length < 6) {
      Alert.alert('خطأ', 'كلمة المرور قصيرة جداً');
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: trimmedEmail.toLowerCase(),
        password,
      });

      if (error) {
        setLoading(false);
        const errorMsg = parseSupabaseError(error);
        Alert.alert('فشل تسجيل الدخول', `حدث خطأ أثناء محاولة تسجيل الدخول:\n\n${errorMsg}\n\nيرجى التحقق من البريد الإلكتروني وكلمة المرور والمحاولة مرة أخرى`);
        return;
      }

      if (!data.user || !data.session) {
        setLoading(false);
        Alert.alert('خطأ في المصادقة', 'لم يتم إنشاء جلسة صالحة. يرجى المحاولة مرة أخرى');
        return;
      }

      const { data: businessData, error: businessError } = await supabase
        .from('business_registrations')
        .select('status, business_name, rejection_reason, profile_completed')
        .eq('user_id', data.user.id)
        .maybeSingle();

      if (businessError) {
        setLoading(false);
        const errorMsg = parseSupabaseError(businessError);
        Alert.alert('خطأ في جلب البيانات', `فشل التحقق من حالة المنشأة:\n\n${errorMsg}\n\nيرجى المحاولة مرة أخرى`);
        await supabase.auth.signOut();
        return;
      }

      if (!businessData) {
        setLoading(false);
        await supabase.auth.signOut();
        Alert.alert(
          'حساب غير مسجل',
          'لا يوجد حساب منشأة مرتبط بهذا البريد الإلكتروني\n\nيرجى التسجيل كمنشأة أولاً أو استخدام حساب فردي.'
        );
        return;
      }

      if (businessData.status === 'pending') {
        setLoading(false);
        Alert.alert(
          'قيد المراجعة',
          `حساب المنشأة "${businessData.business_name}" قيد المراجعة من الإدارة\n\nسيتم إخطارك عبر البريد الإلكتروني عند الموافقة على حسابك.\n\nيمكنك التواصل مع الدعم الفني للاستفسار عن حالة الطلب.`
        );
        await supabase.auth.signOut();
        return;
      }

      if (businessData.status === 'rejected') {
        setLoading(false);
        const rejectionMessage = businessData.rejection_reason
          ? `تم رفض طلب تسجيل المنشأة "${businessData.business_name}"\n\nسبب الرفض: ${businessData.rejection_reason}\n\nيرجى التواصل مع الدعم الفني للمزيد من التفاصيل أو لإعادة التقديم.`
          : `تم رفض طلب تسجيل المنشأة "${businessData.business_name}"\n\nيرجى التواصل مع الدعم الفني للمزيد من التفاصيل.`;

        Alert.alert('طلب مرفوض', rejectionMessage);
        await supabase.auth.signOut();
        return;
      }

      try {
        await AuthStorage.saveAuthToken(data.session.access_token);
        await AuthStorage.saveUserRole('business_admin');
        await AuthStorage.saveUserData({
          id: data.user.id,
          email: data.user.email,
          business_name: businessData.business_name,
          role: 'business_admin'
        });
      } catch (storageError) {
        console.error('Token storage error:', storageError);
        setLoading(false);
        Alert.alert('خطأ في حفظ البيانات', 'فشل حفظ بيانات الجلسة. يرجى المحاولة مرة أخرى');
        return;
      }

      setLoading(false);

      if (!businessData.profile_completed) {
        Alert.alert(
          'إكمال معلومات المنشأة',
          'تم الموافقة على حسابك! يرجى إكمال معلومات المنشأة للمتابعة',
          [
            {
              text: 'إكمال الآن',
              onPress: () => router.replace('/business/complete-profile')
            }
          ]
        );
      } else {
        router.replace('/business/dashboard');
      }
    } catch (error: any) {
      setLoading(false);
      console.error('Login error:', error);
      const errorMsg = parseSupabaseError(error);
      Alert.alert('خطأ غير متوقع', `حدث خطأ غير متوقع:\n\n${errorMsg}\n\nيرجى المحاولة مرة أخرى. إذا استمرت المشكلة، يرجى التواصل مع الدعم الفني`);
      await AuthStorage.clearAuth();
    }
  }

  return (
    <LinearGradient
      colors={['#ffffff', '#faf5ff', '#f3e8ff']}
      style={styles.gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Image
            source={require('@/assets/images/icon.png')}
            style={styles.logo}
            resizeMode="contain"
          />
          <Text style={styles.subtitle}>رحلتك الصحية تبدأ من هنا</Text>
        </View>

      <View style={styles.form}>
        <Text style={styles.formTitle}>تسجيل الدخول</Text>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>البريد الإلكتروني</Text>
          <TextInput
            style={styles.input}
            placeholder="business@example.com"
            value={email}
            onChangeText={(text) => setEmail(text.trim())}
            keyboardType="email-address"
            autoCapitalize="none"
            textAlign="right"
          />
          <Text style={styles.helpText}>البريد الإلكتروني المسجل للمنشأة</Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>كلمة المرور</Text>
          <TextInput
            style={styles.input}
            placeholder="••••••••"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            textAlign="right"
          />
          <Text style={styles.helpText}>كلمة المرور التي تم إنشاؤها عند التسجيل</Text>
        </View>

        <TouchableOpacity
          style={[styles.loginButton, loading && styles.loginButtonDisabled]}
          onPress={handleLogin}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.loginButtonText}>تسجيل الدخول</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.registerButton}
          onPress={() => router.push('/business/register')}>
          <Building2 size={20} color="#6366f1" strokeWidth={2} />
          <Text style={styles.registerButtonText}>تسجيل منشأة جديدة</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={styles.backLink}
        onPress={() => router.back()}>
        <Text style={styles.backLinkText}>← العودة لتسجيل الدخول العادي</Text>
      </TouchableOpacity>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  content: {
    padding: 24,
    paddingTop: 80,
  },
  header: {
    alignItems: 'center',
    marginBottom: 60,
    paddingTop: 20,
  },
  logo: {
    width: 240,
    height: 240,
    marginBottom: 32,
  },
  title: {
    fontSize: 48,
    fontWeight: '700',
    color: '#0f172a',
    marginBottom: 4,
    letterSpacing: 1,
  },
  titleEn: {
    fontSize: 32,
    fontWeight: '300',
    color: '#6366f1',
    marginBottom: 16,
    letterSpacing: 4,
  },
  subtitle: {
    fontSize: 22,
    fontWeight: '500',
    color: '#6366f1',
    letterSpacing: 0.8,
    marginTop: 16,
  },
  form: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 24,
    padding: 32,
    shadowColor: '#6366f1',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 24,
    elevation: 4,
  },
  formTitle: {
    fontSize: 28,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 32,
    textAlign: 'right',
    letterSpacing: 0.5,
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    fontSize: 15,
    fontWeight: '500',
    color: '#64748b',
    marginBottom: 12,
    textAlign: 'right',
    letterSpacing: 0.3,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 16,
    padding: 18,
    fontSize: 16,
    color: '#0f172a',
    fontWeight: '400',
  },
  helpText: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
    marginTop: 6,
    lineHeight: 18,
    fontWeight: '400',
  },
  loginButton: {
    backgroundColor: '#6366f1',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 20,
    shadowColor: '#6366f1',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  loginButtonDisabled: {
    opacity: 0.6,
  },
  loginButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  registerButton: {
    backgroundColor: 'rgba(238, 242, 255, 0.8)',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: '#c7d2fe',
  },
  registerButtonText: {
    color: '#6366f1',
    fontSize: 17,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  backLink: {
    marginTop: 24,
    alignItems: 'center',
  },
  backLinkText: {
    fontSize: 14,
    color: '#64748b',
  },
});
