import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, Alert, Modal, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Truck, Package, MapPin, CheckCircle2, Phone, Camera } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import * as ImagePicker from 'expo-image-picker';

interface DeliveryOrder {
  id: string;
  order_number: string;
  user_id: string;
  delivery_address: string;
  delivery_latitude: number;
  delivery_longitude: number;
  total_amount: number;
  status: string;
  pharmacy: {
    business_name: string;
    headquarters_location: string;
  };
  user_profile: {
    full_name: string;
    phone: string;
  };
  delivery_assignment?: {
    id: string;
    driver_name: string;
    status: string;
  };
}

export default function DeliveryDashboardScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [orders, setOrders] = useState<DeliveryOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<DeliveryOrder | null>(null);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showProofModal, setShowProofModal] = useState(false);
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [vehicleType, setVehicleType] = useState('');
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [proofImage, setProofImage] = useState('');

  useEffect(() => {
    loadOrders();

    const subscription = supabase
      .channel('delivery_orders_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'orders',
      }, () => {
        loadOrders();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  async function loadOrders() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: businessData } = await supabase
        .from('business_verification')
        .select('id')
        .eq('user_id', user.id)
        .eq('business_type', 'delivery')
        .eq('verification_status', 'active')
        .maybeSingle();

      if (!businessData) {
        Alert.alert(
          language === 'ar' ? 'غير مصرح' : 'Unauthorized',
          language === 'ar' ? 'حسابك غير مفعل' : 'Your account is not activated'
        );
        return;
      }

      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          pharmacy:pharmacy_id(business_name, headquarters_location),
          user_profile:user_id(full_name, phone),
          delivery_assignment:delivery_assignments(id, driver_name, status)
        `)
        .in('status', ['ready', 'picked_up', 'in_transit'])
        .eq('payment_status', 'paid')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setOrders(data || []);
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function assignDriver() {
    if (!selectedOrder || !driverName || !driverPhone || !vehicleType || !vehiclePlate) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'يرجى ملء جميع الحقول' : 'Please fill all fields'
      );
      return;
    }

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: businessData } = await supabase
        .from('business_verification')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!businessData) return;

      const { error } = await supabase
        .from('delivery_assignments')
        .insert({
          order_id: selectedOrder.id,
          delivery_company_id: businessData.id,
          driver_user_id: user.id,
          driver_name: driverName,
          driver_phone: driverPhone,
          vehicle_type: vehicleType,
          vehicle_plate: vehiclePlate,
          status: 'assigned',
        });

      if (error) throw error;

      await supabase
        .from('orders')
        .update({ status: 'picked_up' })
        .eq('id', selectedOrder.id);

      Alert.alert(
        language === 'ar' ? 'تم بنجاح' : 'Success',
        language === 'ar' ? 'تم تعيين السائق' : 'Driver assigned'
      );

      setShowAssignModal(false);
      setSelectedOrder(null);
      setDriverName('');
      setDriverPhone('');
      setVehicleType('');
      setVehiclePlate('');
      loadOrders();
    } catch (error: any) {
      console.error('Error assigning driver:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'حدث خطأ' : 'An error occurred')
      );
    } finally {
      setLoading(false);
    }
  }

  async function pickProofImage() {
    try {
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];

        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('User not authenticated');

        const fileExt = asset.uri.split('.').pop();
        const fileName = `${user.id}-${Date.now()}.${fileExt}`;
        const filePath = `delivery-proof/${fileName}`;

        const response = await fetch(asset.uri);
        const blob = await response.blob();
        const arrayBuffer = await blob.arrayBuffer();

        const { error: uploadError } = await supabase.storage
          .from('public')
          .upload(filePath, arrayBuffer, {
            contentType: `image/${fileExt}`,
            upsert: false,
          });

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('public')
          .getPublicUrl(filePath);

        setProofImage(publicUrl);

        Alert.alert(
          language === 'ar' ? 'تم الرفع' : 'Uploaded',
          language === 'ar' ? 'تم رفع الصورة بنجاح' : 'Image uploaded successfully'
        );
      }
    } catch (error: any) {
      console.error('Error picking image:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'حدث خطأ في رفع الصورة' : 'Error uploading image')
      );
    }
  }

  async function submitDeliveryProof() {
    if (!selectedOrder || (!proofImage && !verificationCode)) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'يرجى رفع صورة أو إدخال كود التحقق' : 'Please upload image or enter verification code'
      );
      return;
    }

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const assignment = selectedOrder.delivery_assignment;
      if (!assignment) return;

      const { error: proofError } = await supabase
        .from('delivery_proof')
        .insert({
          delivery_assignment_id: assignment.id,
          order_id: selectedOrder.id,
          proof_type: proofImage ? 'photo' : 'code',
          proof_image: proofImage || null,
          verification_code: verificationCode || null,
          verified_by: user.id,
        });

      if (proofError) throw proofError;

      await supabase
        .from('delivery_assignments')
        .update({
          status: 'delivered',
          delivered_at: new Date().toISOString(),
        })
        .eq('id', assignment.id);

      await supabase
        .from('orders')
        .update({ status: 'delivered' })
        .eq('id', selectedOrder.id);

      Alert.alert(
        language === 'ar' ? 'تم بنجاح' : 'Success',
        language === 'ar' ? 'تم تأكيد التسليم' : 'Delivery confirmed'
      );

      setShowProofModal(false);
      setSelectedOrder(null);
      setProofImage('');
      setVerificationCode('');
      loadOrders();
    } catch (error: any) {
      console.error('Error submitting proof:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'حدث خطأ' : 'An error occurred')
      );
    } finally {
      setLoading(false);
    }
  }

  function renderOrderCard(order: DeliveryOrder) {
    return (
      <View key={order.id} style={styles.orderCard}>
        <View style={styles.orderHeader}>
          <View style={styles.orderNumber}>
            <Package size={16} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.orderNumberText}>
              #{order.order_number}
            </Text>
          </View>
          <View style={[
            styles.statusBadge,
            order.status === 'ready' && { backgroundColor: '#fef3c7' },
            order.status === 'picked_up' && { backgroundColor: '#dbeafe' },
            order.status === 'in_transit' && { backgroundColor: '#e0e7ff' },
          ]}>
            <Text style={styles.statusText}>
              {order.status === 'ready' ? (language === 'ar' ? 'جاهز للاستلام' : 'Ready') :
               order.status === 'picked_up' ? (language === 'ar' ? 'تم الاستلام' : 'Picked Up') :
               (language === 'ar' ? 'في الطريق' : 'In Transit')}
            </Text>
          </View>
        </View>

        <View style={styles.orderInfo}>
          <View style={styles.locationRow}>
            <MapPin size={16} color="#64748b" strokeWidth={2} />
            <View style={styles.locationInfo}>
              <Text style={styles.locationLabel}>
                {language === 'ar' ? 'من:' : 'From:'}
              </Text>
              <Text style={styles.locationText}>
                {order.pharmacy?.business_name}
              </Text>
            </View>
          </View>

          <View style={styles.locationRow}>
            <MapPin size={16} color="#10b981" strokeWidth={2} />
            <View style={styles.locationInfo}>
              <Text style={styles.locationLabel}>
                {language === 'ar' ? 'إلى:' : 'To:'}
              </Text>
              <Text style={styles.locationText}>
                {order.user_profile?.full_name}
              </Text>
              <Text style={styles.locationSubtext}>
                {order.delivery_address}
              </Text>
            </View>
          </View>

          <View style={styles.customerRow}>
            <Phone size={16} color="#64748b" strokeWidth={2} />
            <Text style={styles.customerPhone}>
              {order.user_profile?.phone}
            </Text>
          </View>
        </View>

        <View style={styles.orderActions}>
          {!order.delivery_assignment && (
            <TouchableOpacity
              style={styles.assignButton}
              onPress={() => {
                setSelectedOrder(order);
                setShowAssignModal(true);
              }}
            >
              <Truck size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.assignButtonText}>
                {language === 'ar' ? 'تعيين سائق' : 'Assign Driver'}
              </Text>
            </TouchableOpacity>
          )}

          {order.delivery_assignment && order.delivery_assignment.status !== 'delivered' && (
            <TouchableOpacity
              style={styles.completeButton}
              onPress={() => {
                setSelectedOrder(order);
                setShowProofModal(true);
              }}
            >
              <CheckCircle2 size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.completeButtonText}>
                {language === 'ar' ? 'تأكيد التسليم' : 'Confirm Delivery'}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  }

  const readyCount = orders.filter(o => o.status === 'ready').length;
  const inTransitCount = orders.filter(o => o.status === 'in_transit' || o.status === 'picked_up').length;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Truck size={32} color="#0ea5e9" strokeWidth={2} />
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'لوحة التوصيل' : 'Delivery Portal'}
        </Text>
        <Text style={styles.headerSubtitle}>
          {language === 'ar' ? 'سوق الطلبات الجاهزة' : 'Ready Orders Marketplace'}
        </Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
          <Text style={styles.statNumber}>{readyCount}</Text>
          <Text style={styles.statLabel}>
            {language === 'ar' ? 'جاهز للاستلام' : 'Ready'}
          </Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
          <Text style={styles.statNumber}>{inTransitCount}</Text>
          <Text style={styles.statLabel}>
            {language === 'ar' ? 'قيد التوصيل' : 'In Transit'}
          </Text>
        </View>
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadOrders(); }} />
        }
      >
        {orders.length === 0 ? (
          <View style={styles.emptyState}>
            <Package size={64} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyStateText}>
              {language === 'ar' ? 'لا توجد طلبات متاحة' : 'No orders available'}
            </Text>
          </View>
        ) : (
          orders.map(renderOrderCard)
        )}
      </ScrollView>

      <Modal
        visible={showAssignModal}
        animationType="slide"
        onRequestClose={() => setShowAssignModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>
              {language === 'ar' ? 'تعيين سائق' : 'Assign Driver'}
            </Text>
            <TouchableOpacity onPress={() => setShowAssignModal(false)}>
              <Text style={styles.modalClose}>✕</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                {language === 'ar' ? 'اسم السائق *' : 'Driver Name *'}
              </Text>
              <TextInput
                style={styles.input}
                value={driverName}
                onChangeText={setDriverName}
                placeholder={language === 'ar' ? 'أحمد محمد' : 'Ahmed Mohammed'}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                {language === 'ar' ? 'رقم جوال السائق *' : 'Driver Phone *'}
              </Text>
              <TextInput
                style={styles.input}
                value={driverPhone}
                onChangeText={setDriverPhone}
                placeholder="05xxxxxxxx"
                keyboardType="phone-pad"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                {language === 'ar' ? 'نوع المركبة *' : 'Vehicle Type *'}
              </Text>
              <TextInput
                style={styles.input}
                value={vehicleType}
                onChangeText={setVehicleType}
                placeholder={language === 'ar' ? 'دراجة نارية' : 'Motorcycle'}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                {language === 'ar' ? 'رقم اللوحة *' : 'Plate Number *'}
              </Text>
              <TextInput
                style={styles.input}
                value={vehiclePlate}
                onChangeText={setVehiclePlate}
                placeholder="ABC 1234"
              />
            </View>
          </ScrollView>

          <View style={styles.modalFooter}>
            <TouchableOpacity
              style={styles.submitButton}
              onPress={assignDriver}
              disabled={loading}
            >
              <Text style={styles.submitButtonText}>
                {loading ? (language === 'ar' ? 'جاري التعيين...' : 'Assigning...') : (language === 'ar' ? 'تعيين' : 'Assign')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showProofModal}
        animationType="slide"
        onRequestClose={() => setShowProofModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>
              {language === 'ar' ? 'إثبات التسليم' : 'Delivery Proof'}
            </Text>
            <TouchableOpacity onPress={() => setShowProofModal(false)}>
              <Text style={styles.modalClose}>✕</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            <TouchableOpacity style={styles.cameraButton} onPress={pickProofImage}>
              <Camera size={24} color="#0ea5e9" strokeWidth={2} />
              <Text style={styles.cameraButtonText}>
                {proofImage
                  ? (language === 'ar' ? 'تم التصوير ✓' : 'Photo Taken ✓')
                  : (language === 'ar' ? 'تصوير الشحنة' : 'Take Photo')}
              </Text>
            </TouchableOpacity>

            <View style={styles.divider}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>
                {language === 'ar' ? 'أو' : 'OR'}
              </Text>
              <View style={styles.dividerLine} />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                {language === 'ar' ? 'كود الاستلام' : 'Verification Code'}
              </Text>
              <TextInput
                style={styles.input}
                value={verificationCode}
                onChangeText={setVerificationCode}
                placeholder="1234"
                keyboardType="numeric"
              />
            </View>
          </ScrollView>

          <View style={styles.modalFooter}>
            <TouchableOpacity
              style={styles.submitButton}
              onPress={submitDeliveryProof}
              disabled={loading}
            >
              <Text style={styles.submitButtonText}>
                {loading ? (language === 'ar' ? 'جاري التأكيد...' : 'Confirming...') : (language === 'ar' ? 'تأكيد التسليم' : 'Confirm Delivery')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 12,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
  },
  statsContainer: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  orderCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  orderNumber: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  orderNumberText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#0f172a',
  },
  orderInfo: {
    gap: 12,
    marginBottom: 16,
  },
  locationRow: {
    flexDirection: 'row',
    gap: 12,
  },
  locationInfo: {
    flex: 1,
  },
  locationLabel: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 2,
  },
  locationText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
  },
  locationSubtext: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
  },
  customerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  customerPhone: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '500',
  },
  orderActions: {
    gap: 8,
  },
  assignButton: {
    backgroundColor: '#0ea5e9',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 12,
  },
  assignButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  completeButton: {
    backgroundColor: '#10b981',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 12,
  },
  completeButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  emptyState: {
    alignItems: 'center',
    padding: 48,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
    paddingTop: 60,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  modalClose: {
    fontSize: 24,
    color: '#64748b',
  },
  modalContent: {
    flex: 1,
    padding: 24,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
  },
  modalFooter: {
    padding: 24,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  submitButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  cameraButton: {
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#0ea5e9',
    borderStyle: 'dashed',
    borderRadius: 12,
    padding: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  cameraButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
    gap: 12,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#e2e8f0',
  },
  dividerText: {
    fontSize: 14,
    color: '#94a3b8',
  },
});
