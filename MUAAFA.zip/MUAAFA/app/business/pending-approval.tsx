import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useEffect, useState } from 'react';
import { useRouter } from 'expo-router';
import { Clock, CheckCircle2, XCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function PendingApprovalScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [status, setStatus] = useState<'pending' | 'active' | 'rejected'>('pending');
  const [loading, setLoading] = useState(true);
  const [rejectionReason, setRejectionReason] = useState('');

  useEffect(() => {
    checkVerificationStatus();
    const subscription = supabase
      .channel('business_registrations_changes')
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'business_registrations',
      }, (payload: any) => {
        if (payload.new.status === 'approved') {
          setStatus('active');
          setTimeout(() => {
            router.replace('/business/dashboard');
          }, 2000);
        } else if (payload.new.status === 'rejected') {
          setStatus('rejected');
          setRejectionReason(payload.new.rejection_reason || '');
        }
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  async function checkVerificationStatus() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('business_registrations')
        .select('status, rejection_reason')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        if (data.status === 'approved') {
          setStatus('active');
          setTimeout(() => {
            router.replace('/business/dashboard');
          }, 1000);
        } else if (data.status === 'rejected') {
          setStatus('rejected');
          setRejectionReason(data.rejection_reason || '');
        } else {
          setStatus('pending');
        }
      }
    } catch (error) {
      console.error('Error checking status:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0ea5e9" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {status === 'pending' && (
          <>
            <Clock size={64} color="#f59e0b" strokeWidth={1.5} />
            <Text style={styles.title}>
              {language === 'ar' ? 'قيد المراجعة' : 'Under Review'}
            </Text>
            <Text style={styles.description}>
              {language === 'ar'
                ? 'تم استلام طلبك بنجاح. سيتم مراجعته من قبل الإدارة خلال 24-48 ساعة.'
                : 'Your application has been received. It will be reviewed by administration within 24-48 hours.'}
            </Text>
            <View style={styles.pulseContainer}>
              <View style={styles.pulse} />
            </View>
          </>
        )}

        {status === 'active' && (
          <>
            <CheckCircle2 size={64} color="#10b981" strokeWidth={1.5} />
            <Text style={styles.title}>
              {language === 'ar' ? 'تمت الموافقة!' : 'Approved!'}
            </Text>
            <Text style={styles.description}>
              {language === 'ar'
                ? 'تمت الموافقة على حسابك. جاري التوجيه للوحة التحكم...'
                : 'Your account has been approved. Redirecting to dashboard...'}
            </Text>
          </>
        )}

        {status === 'rejected' && (
          <>
            <XCircle size={64} color="#ef4444" strokeWidth={1.5} />
            <Text style={styles.title}>
              {language === 'ar' ? 'تم الرفض' : 'Rejected'}
            </Text>
            <Text style={styles.description}>
              {language === 'ar'
                ? 'عذراً، لم تتم الموافقة على طلبك.'
                : 'Sorry, your application was not approved.'}
            </Text>
            {rejectionReason && (
              <View style={styles.reasonBox}>
                <Text style={styles.reasonTitle}>
                  {language === 'ar' ? 'سبب الرفض:' : 'Rejection Reason:'}
                </Text>
                <Text style={styles.reasonText}>{rejectionReason}</Text>
              </View>
            )}
            <Text style={[styles.description, { marginTop: 16 }]}>
              {language === 'ar'
                ? 'يرجى التواصل مع الدعم للمزيد من المعلومات أو تقديم طلب جديد.'
                : 'Please contact support for more information or submit a new application.'}
            </Text>
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
    padding: 32,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 24,
    marginBottom: 12,
  },
  description: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
  },
  pulseContainer: {
    marginTop: 32,
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulse: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#f59e0b',
  },
  reasonBox: {
    backgroundColor: '#fee2e2',
    padding: 16,
    borderRadius: 12,
    marginTop: 16,
    width: '100%',
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  reasonTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#991b1b',
    marginBottom: 8,
    textAlign: 'right',
  },
  reasonText: {
    fontSize: 14,
    color: '#7f1d1d',
    lineHeight: 20,
    textAlign: 'right',
  },
});
