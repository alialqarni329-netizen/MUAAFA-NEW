import { ScrollView, View, Text, StyleSheet, TouchableOpacity, Image, ActivityIndicator, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { ArrowRight, Trash2, Plus, Minus, ShoppingBag } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface CartItem {
  id: string;
  medication_id: string;
  pharmacy_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  insurance_coverage_amount: number;
  patient_amount: number;
  medication: {
    name: string;
    description: string;
    image_url: string;
  };
  pharmacy: {
    business_name: string;
  };
}

export default function PharmacyCart() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [updating, setUpdating] = useState<string | null>(null);

  useEffect(() => {
    loadCart();
  }, []);

  async function loadCart() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('pharmacy_cart')
        .select(`
          *,
          medication:medications(name, description, image_url),
          pharmacy:business_registrations(business_name)
        `)
        .eq('user_id', user.id);

      if (error) throw error;
      setCartItems(data || []);
    } catch (error) {
      console.error('Error loading cart:', error);
    } finally {
      setLoading(false);
    }
  }

  async function updateQuantity(itemId: string, newQuantity: number) {
    if (newQuantity < 1) return;

    setUpdating(itemId);
    try {
      const item = cartItems.find(i => i.id === itemId);
      if (!item) return;

      const newTotalPrice = item.unit_price * newQuantity;
      const newPatientAmount = newTotalPrice - item.insurance_coverage_amount;

      const { error } = await supabase
        .from('pharmacy_cart')
        .update({
          quantity: newQuantity,
          total_price: newTotalPrice,
          patient_amount: newPatientAmount,
        })
        .eq('id', itemId);

      if (error) throw error;
      await loadCart();
    } catch (error) {
      console.error('Error updating quantity:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحديث الكمية');
    } finally {
      setUpdating(null);
    }
  }

  async function removeItem(itemId: string) {
    Alert.alert(
      'حذف من السلة',
      'هل أنت متأكد من حذف هذا المنتج؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('pharmacy_cart')
                .delete()
                .eq('id', itemId);

              if (error) throw error;
              await loadCart();
            } catch (error) {
              console.error('Error removing item:', error);
              Alert.alert('خطأ', 'حدث خطأ أثناء حذف المنتج');
            }
          },
        },
      ]
    );
  }

  function calculateTotals() {
    const subtotal = cartItems.reduce((sum, item) => sum + item.total_price, 0);
    const insurance = cartItems.reduce((sum, item) => sum + item.insurance_coverage_amount, 0);
    const total = cartItems.reduce((sum, item) => sum + item.patient_amount, 0);

    return { subtotal, insurance, total };
  }

  async function goToCheckout() {
    if (cartItems.length === 0) {
      Alert.alert('السلة فارغة', 'يرجى إضافة منتجات للمتابعة');
      return;
    }

    Alert.alert(
      'إتمام الطلب',
      `المبلغ المستحق: ${total.toFixed(2)} ر.س\n\nستتم إحالتك لبوابة الدفع`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'متابعة للدفع',
          onPress: () => router.push('/pharmacy-checkout'),
        },
      ]
    );
  }

  const { subtotal, insurance, total } = calculateTotals();

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>سلة الأدوية</Text>
      </View>

      {cartItems.length === 0 ? (
        <View style={styles.emptyState}>
          <ShoppingBag size={64} color="#cbd5e1" strokeWidth={1.5} />
          <Text style={styles.emptyTitle}>السلة فارغة</Text>
          <Text style={styles.emptyText}>لم تضف أي أدوية بعد</Text>
          <TouchableOpacity
            style={styles.shopButton}
            onPress={() => router.push('/pharmacies')}
          >
            <Text style={styles.shopButtonText}>تصفح الصيدليات</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            {cartItems.map((item) => (
              <View key={item.id} style={styles.cartItem}>
                {item.medication.image_url && (
                  <Image
                    source={{ uri: item.medication.image_url }}
                    style={styles.itemImage}
                  />
                )}

                <View style={styles.itemDetails}>
                  <Text style={styles.itemName}>{item.medication.name}</Text>
                  <Text style={styles.pharmacyName}>{item.pharmacy.business_name}</Text>

                  <View style={styles.priceRow}>
                    <Text style={styles.price}>{item.unit_price} ر.س</Text>
                    {item.insurance_coverage_amount > 0 && (
                      <View style={styles.insuranceBadge}>
                        <Text style={styles.insuranceText}>
                          تغطية: {item.insurance_coverage_amount} ر.س
                        </Text>
                      </View>
                    )}
                  </View>

                  <View style={styles.itemActions}>
                    <View style={styles.quantityControl}>
                      <TouchableOpacity
                        style={styles.quantityButton}
                        onPress={() => updateQuantity(item.id, item.quantity - 1)}
                        disabled={updating === item.id || item.quantity === 1}
                      >
                        <Minus size={16} color="#64748b" strokeWidth={2} />
                      </TouchableOpacity>

                      <Text style={styles.quantity}>{item.quantity}</Text>

                      <TouchableOpacity
                        style={styles.quantityButton}
                        onPress={() => updateQuantity(item.id, item.quantity + 1)}
                        disabled={updating === item.id}
                      >
                        <Plus size={16} color="#64748b" strokeWidth={2} />
                      </TouchableOpacity>
                    </View>

                    <TouchableOpacity
                      style={styles.removeButton}
                      onPress={() => removeItem(item.id)}
                    >
                      <Trash2 size={18} color="#ef4444" strokeWidth={2} />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}
          </ScrollView>

          <View style={styles.summary}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>المجموع الفرعي</Text>
              <Text style={styles.summaryValue}>{subtotal.toFixed(2)} ر.س</Text>
            </View>

            {insurance > 0 && (
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>تغطية التأمين</Text>
                <Text style={[styles.summaryValue, styles.insuranceValue]}>
                  - {insurance.toFixed(2)} ر.س
                </Text>
              </View>
            )}

            <View style={styles.divider} />

            <View style={styles.summaryRow}>
              <Text style={styles.totalLabel}>المبلغ المستحق</Text>
              <Text style={styles.totalValue}>{total.toFixed(2)} ر.س</Text>
            </View>

            <TouchableOpacity style={styles.checkoutButton} onPress={goToCheckout}>
              <Text style={styles.checkoutButtonText}>متابعة الدفع</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    gap: 12,
  },
  backButton: {
    padding: 8,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  itemImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
  },
  itemDetails: {
    flex: 1,
    marginRight: 12,
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  pharmacyName: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 8,
    textAlign: 'right',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
    marginBottom: 8,
  },
  price: {
    fontSize: 14,
    fontWeight: '600',
    color: '#3b82f6',
  },
  insuranceBadge: {
    backgroundColor: '#dbeafe',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  insuranceText: {
    fontSize: 10,
    color: '#1e40af',
  },
  itemActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#f1f5f9',
    borderRadius: 8,
    padding: 4,
  },
  quantityButton: {
    width: 28,
    height: 28,
    borderRadius: 6,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantity: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    minWidth: 20,
    textAlign: 'center',
  },
  removeButton: {
    padding: 8,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
  },
  emptyText: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 8,
    marginBottom: 24,
  },
  shopButton: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  shopButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  summary: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
  },
  insuranceValue: {
    color: '#10b981',
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 12,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  totalValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#3b82f6',
  },
  checkoutButton: {
    backgroundColor: '#3b82f6',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 16,
  },
  checkoutButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
