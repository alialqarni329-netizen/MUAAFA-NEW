import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { TrendingUp, MapPin, Check, Search, ArrowRight } from 'lucide-react-native';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function PriceComparisonScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');

  const priceData = [
    {
      pharmacy: 'صيدلية النهدي',
      price: 25.5,
      distance: 1.2,
      available: true,
      chain: 'النهدي',
    },
    {
      pharmacy: 'صيدلية الدواء',
      price: 22.0,
      distance: 2.5,
      available: true,
      chain: 'الدواء',
    },
    {
      pharmacy: 'صيدلية رعاية',
      price: 28.0,
      distance: 0.8,
      available: true,
      chain: 'رعاية',
    },
    {
      pharmacy: 'صيدلية المتحدة',
      price: 24.0,
      distance: 3.1,
      available: false,
      chain: 'المتحدة',
    },
  ];

  const sortedByPrice = [...priceData].sort((a, b) => a.price - b.price);
  const cheapest = sortedByPrice[0];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerTextContainer}>
          <Text style={styles.title}>{t('pharmacy.priceComparison')}</Text>
          <Text style={styles.subtitle}>{t('pharmacy.priceWatch.title')}</Text>
        </View>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#94a3b8" strokeWidth={2} />
        <TextInput
          style={styles.searchInput}
          placeholder={t('pharmacy.search')}
          placeholderTextColor="#94a3b8"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.infoCard}>
          <TrendingUp size={24} color="#10b981" strokeWidth={2} />
          <View style={styles.infoTextContainer}>
            <Text style={styles.infoTitle}>
              {language === 'ar' ? 'وفّر حتى 20% على أدويتك' : 'Save up to 20% on medicines'}
            </Text>
            <Text style={styles.infoDescription}>
              {language === 'ar'
                ? 'نقارن الأسعار من أكثر من 500 صيدلية'
                : 'We compare prices from 500+ pharmacies'}
            </Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'مقارنة الأسعار - باراسيتامول 500 مجم' : 'Price Comparison - Paracetamol 500mg'}
          </Text>
        </View>

        {sortedByPrice.map((pharmacy, index) => (
          <View
            key={index}
            style={[
              styles.pharmacyCard,
              pharmacy.pharmacy === cheapest.pharmacy && styles.cheapestCard,
            ]}>
            {pharmacy.pharmacy === cheapest.pharmacy && (
              <View style={styles.cheapestBadge}>
                <Check size={14} color="#10b981" strokeWidth={2.5} />
                <Text style={styles.cheapestText}>{t('pharmacy.priceWatch.cheapest')}</Text>
              </View>
            )}

            <View style={styles.pharmacyHeader}>
              <View style={styles.pharmacyInfo}>
                <Text style={styles.pharmacyName}>{pharmacy.pharmacy}</Text>
                <View style={styles.locationContainer}>
                  <MapPin size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.distanceText}>
                    {pharmacy.distance} {t('pharmacy.priceWatch.km')}
                  </Text>
                </View>
              </View>
              <View style={styles.priceContainer}>
                <Text style={styles.price}>{pharmacy.price} {t('pharmacy.priceWatch.sar')}</Text>
                {pharmacy.pharmacy === cheapest.pharmacy && (
                  <Text style={styles.savingText}>
                    {t('pharmacy.priceWatch.save')} {(sortedByPrice[1].price - pharmacy.price).toFixed(2)} {t('pharmacy.priceWatch.sar')}
                  </Text>
                )}
              </View>
            </View>

            <View style={styles.pharmacyFooter}>
              <View
                style={[
                  styles.availabilityBadge,
                  { backgroundColor: pharmacy.available ? '#d1fae5' : '#fee2e2' },
                ]}>
                <Text
                  style={[
                    styles.availabilityText,
                    { color: pharmacy.available ? '#10b981' : '#ef4444' },
                  ]}>
                  {pharmacy.available
                    ? t('pharmacy.priceWatch.available')
                    : t('pharmacy.priceWatch.notAvailable')}
                </Text>
              </View>
              <TouchableOpacity style={styles.viewMapButton}>
                <MapPin size={16} color="#0ea5e9" strokeWidth={2} />
                <Text style={styles.viewMapText}>{t('pharmacy.priceWatch.viewOnMap')}</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f9ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextContainer: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#ffffff',
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: '#e0f2fe',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#d1fae5',
    borderRadius: 16,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#86efac',
  },
  infoTextContainer: {
    flex: 1,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#065f46',
    marginBottom: 4,
    textAlign: 'right',
  },
  infoDescription: {
    fontSize: 14,
    color: '#047857',
    textAlign: 'right',
  },
  sectionHeader: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  pharmacyCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e0f2fe',
  },
  cheapestCard: {
    borderWidth: 2,
    borderColor: '#10b981',
    backgroundColor: '#f0fdf4',
  },
  cheapestBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-end',
    backgroundColor: '#d1fae5',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 12,
  },
  cheapestText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#10b981',
  },
  pharmacyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  pharmacyInfo: {
    flex: 1,
  },
  pharmacyName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 6,
    textAlign: 'right',
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    justifyContent: 'flex-end',
  },
  distanceText: {
    fontSize: 14,
    color: '#64748b',
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  price: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0ea5e9',
    marginBottom: 4,
  },
  savingText: {
    fontSize: 12,
    color: '#10b981',
    fontWeight: '600',
  },
  pharmacyFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  availabilityBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  availabilityText: {
    fontSize: 12,
    fontWeight: '600',
  },
  viewMapButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  viewMapText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0ea5e9',
  },
});
