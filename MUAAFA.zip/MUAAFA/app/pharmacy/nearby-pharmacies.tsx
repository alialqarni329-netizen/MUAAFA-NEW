import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Linking,
  Platform,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import {
  ChevronRight,
  MapPin,
  Phone,
  Clock,
  Navigation,
  Star,
  CheckCircle,
} from 'lucide-react-native';
import * as Location from 'expo-location';

interface Pharmacy {
  id: string;
  name: string;
  address: string;
  phone: string;
  rating: number;
  distance: number;
  isOpen: boolean;
  openingHours: string;
  latitude: number;
  longitude: number;
  has24Hours: boolean;
}

export default function NearbyPharmaciesScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [locationGranted, setLocationGranted] = useState(false);
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [userLocation, setUserLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);

  useEffect(() => {
    checkLocationPermission();
  }, []);

  async function checkLocationPermission() {
    try {
      const { status } = await Location.getForegroundPermissionsAsync();
      if (status === 'granted') {
        setLocationGranted(true);
        await getUserLocation();
      }
    } catch (error) {
      console.error('Error checking location permission:', error);
    }
  }

  async function requestLocationPermission() {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();

      if (status === 'granted') {
        setLocationGranted(true);
        await getUserLocation();
        Alert.alert('تم', 'تم منح إذن الوصول للموقع بنجاح');
      } else {
        Alert.alert(
          'تنبيه',
          'يرجى تفعيل خدمة الموقع من إعدادات الجهاز لاستخدام هذه الميزة',
          [
            { text: 'إلغاء', style: 'cancel' },
            {
              text: 'فتح الإعدادات',
              onPress: () => {
                if (Platform.OS === 'ios') {
                  Linking.openURL('app-settings:');
                } else {
                  Linking.openSettings();
                }
              },
            },
          ]
        );
      }
    } catch (error) {
      console.error('Error requesting location permission:', error);
      Alert.alert('خطأ', 'فشل طلب إذن الموقع');
    }
  }

  async function getUserLocation() {
    setLoading(true);
    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      setUserLocation({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });

      await loadNearbyPharmacies(
        location.coords.latitude,
        location.coords.longitude
      );
    } catch (error) {
      console.error('Error getting user location:', error);
      Alert.alert('خطأ', 'فشل الحصول على موقعك الحالي');
    } finally {
      setLoading(false);
    }
  }

  async function loadNearbyPharmacies(latitude: number, longitude: number) {
    const mockPharmacies: Pharmacy[] = [
      {
        id: '1',
        name: 'صيدلية النهدي',
        address: 'طريق الملك فهد، الرياض',
        phone: '+966112345678',
        rating: 4.5,
        distance: 0.8,
        isOpen: true,
        openingHours: '8 ص - 12 م',
        latitude: latitude + 0.01,
        longitude: longitude + 0.01,
        has24Hours: true,
      },
      {
        id: '2',
        name: 'صيدلية الدواء',
        address: 'شارع العليا، الرياض',
        phone: '+966112345679',
        rating: 4.3,
        distance: 1.2,
        isOpen: true,
        openingHours: '9 ص - 11 م',
        latitude: latitude + 0.02,
        longitude: longitude - 0.01,
        has24Hours: false,
      },
      {
        id: '3',
        name: 'صيدلية رعاية',
        address: 'حي الملقا، الرياض',
        phone: '+966112345680',
        rating: 4.7,
        distance: 1.5,
        isOpen: true,
        openingHours: '24 ساعة',
        latitude: latitude - 0.01,
        longitude: longitude + 0.02,
        has24Hours: true,
      },
      {
        id: '4',
        name: 'صيدلية الحكمة',
        address: 'شارع التحلية، الرياض',
        phone: '+966112345681',
        rating: 4.2,
        distance: 2.3,
        isOpen: false,
        openingHours: '9 ص - 9 م',
        latitude: latitude + 0.03,
        longitude: longitude - 0.02,
        has24Hours: false,
      },
    ];

    setPharmacies(mockPharmacies);
  }

  function handleCall(phone: string) {
    Linking.openURL(`tel:${phone}`);
  }

  function handleNavigate(latitude: number, longitude: number) {
    const url = Platform.select({
      ios: `maps:0,0?q=${latitude},${longitude}`,
      android: `geo:0,0?q=${latitude},${longitude}`,
      default: `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`,
    });

    if (url) {
      Linking.openURL(url);
    }
  }

  if (!locationGranted) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>الصيدليات القريبة</Text>
          <View style={styles.backButton} />
        </View>

        <View style={styles.permissionContainer}>
          <View style={styles.permissionIconContainer}>
            <MapPin size={80} color="#0ea5e9" strokeWidth={1.5} />
          </View>
          <Text style={styles.permissionTitle}>السماح بالوصول للموقع</Text>
          <Text style={styles.permissionText}>
            للعثور على الصيدليات القريبة منك، نحتاج إلى إذن الوصول لموقعك الجغرافي
          </Text>

          <TouchableOpacity
            style={styles.permissionButton}
            onPress={requestLocationPermission}>
            <Text style={styles.permissionButtonText}>منح الإذن</Text>
          </TouchableOpacity>

          <View style={styles.privacyNote}>
            <Text style={styles.privacyNoteText}>
              🔒 موقعك آمن ولن نشاركه مع أي طرف ثالث
            </Text>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>الصيدليات القريبة</Text>
        <TouchableOpacity
          onPress={getUserLocation}
          style={styles.refreshButton}
          disabled={loading}>
          <Navigation size={20} color="#0ea5e9" strokeWidth={2} />
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#0ea5e9" />
          <Text style={styles.loadingText}>جاري البحث عن الصيدليات القريبة...</Text>
        </View>
      ) : (
        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {userLocation && (
            <View style={styles.locationBanner}>
              <MapPin size={20} color="#10b981" strokeWidth={2} />
              <Text style={styles.locationBannerText}>
                تم تحديد موقعك بنجاح • {pharmacies.length} صيدلية قريبة
              </Text>
            </View>
          )}

          {pharmacies.length === 0 ? (
            <View style={styles.emptyState}>
              <MapPin size={64} color="#cbd5e1" strokeWidth={1.5} />
              <Text style={styles.emptyStateTitle}>لا توجد صيدليات قريبة</Text>
              <Text style={styles.emptyStateText}>
                جرب البحث في منطقة أخرى
              </Text>
            </View>
          ) : (
            <View style={styles.pharmaciesList}>
              {pharmacies.map((pharmacy) => (
                <View key={pharmacy.id} style={styles.pharmacyCard}>
                  <View style={styles.pharmacyHeader}>
                    <View style={styles.pharmacyInfo}>
                      <Text style={styles.pharmacyName}>{pharmacy.name}</Text>
                      <View style={styles.pharmacyMeta}>
                        <View style={styles.ratingContainer}>
                          <Star size={14} color="#f59e0b" fill="#f59e0b" strokeWidth={2} />
                          <Text style={styles.ratingText}>{pharmacy.rating}</Text>
                        </View>
                        <Text style={styles.distanceText}>
                          • {pharmacy.distance} كم
                        </Text>
                      </View>
                    </View>
                    {pharmacy.has24Hours && (
                      <View style={styles.badge24}>
                        <Text style={styles.badge24Text}>24 ساعة</Text>
                      </View>
                    )}
                  </View>

                  <View style={styles.pharmacyDetails}>
                    <View style={styles.detailRow}>
                      <MapPin size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailText}>{pharmacy.address}</Text>
                    </View>

                    <View style={styles.detailRow}>
                      <Clock size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailText}>
                        {pharmacy.openingHours}
                      </Text>
                      {pharmacy.isOpen && (
                        <View style={styles.openBadge}>
                          <Text style={styles.openBadgeText}>مفتوح الآن</Text>
                        </View>
                      )}
                    </View>

                    <View style={styles.detailRow}>
                      <Phone size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailText}>{pharmacy.phone}</Text>
                    </View>
                  </View>

                  <View style={styles.pharmacyActions}>
                    <TouchableOpacity
                      style={styles.callButton}
                      onPress={() => handleCall(pharmacy.phone)}>
                      <Phone size={18} color="#10b981" strokeWidth={2} />
                      <Text style={styles.callButtonText}>اتصال</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={styles.navigateButton}
                      onPress={() =>
                        handleNavigate(pharmacy.latitude, pharmacy.longitude)
                      }>
                      <Navigation size={18} color="#ffffff" strokeWidth={2} />
                      <Text style={styles.navigateButtonText}>اتجاهات</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  refreshButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  permissionContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  permissionIconContainer: {
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  permissionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'center',
  },
  permissionText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  permissionButton: {
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  permissionButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  privacyNote: {
    backgroundColor: '#dcfce7',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
  },
  privacyNoteText: {
    fontSize: 14,
    color: '#15803d',
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
    marginTop: 16,
    textAlign: 'center',
  },
  content: {
    flex: 1,
  },
  locationBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#dcfce7',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  locationBannerText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#15803d',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 40,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
  },
  pharmaciesList: {
    padding: 20,
  },
  pharmacyCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  pharmacyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  pharmacyInfo: {
    flex: 1,
  },
  pharmacyName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  pharmacyMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#f59e0b',
  },
  distanceText: {
    fontSize: 14,
    color: '#64748b',
  },
  badge24: {
    backgroundColor: '#dbeafe',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  badge24Text: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  pharmacyDetails: {
    gap: 12,
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  detailText: {
    flex: 1,
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  openBadge: {
    backgroundColor: '#dcfce7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  openBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#10b981',
  },
  pharmacyActions: {
    flexDirection: 'row',
    gap: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  callButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#dcfce7',
    paddingVertical: 12,
    borderRadius: 8,
  },
  callButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#10b981',
  },
  navigateButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#0ea5e9',
    paddingVertical: 12,
    borderRadius: 8,
  },
  navigateButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
