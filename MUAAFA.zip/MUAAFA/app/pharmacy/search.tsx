import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Search, ShoppingCart, Plus, Pill } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { addToCart as addToCartUtil } from '@/lib/cart-utils';

interface Medication {
  id: string;
  name: string;
  name_en: string;
  category: string;
  description: string;
  requires_prescription: boolean;
  price?: number;
  stock_quantity?: number;
  is_available?: boolean;
}

export default function PharmacySearchScreen() {
  const router = useRouter();
  const { pharmacy_id } = useLocalSearchParams();
  const [searchQuery, setSearchQuery] = useState('');
  const [medications, setMedications] = useState<Medication[]>([]);
  const [loading, setLoading] = useState(true);
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    loadMedications();
    loadCartCount();
  }, [pharmacy_id]);

  async function loadCartCount() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from('cart_items')
      .select('quantity')
      .eq('user_id', user.id);

    const count = data?.reduce((sum, item) => sum + item.quantity, 0) || 0;
    setCartCount(count);
  }

  async function loadMedications() {
    try {
      if (pharmacy_id) {
        const { data, error } = await supabase
          .from('pharmacy_inventory')
          .select(`
            medication_id,
            price,
            stock_quantity,
            is_available,
            medications (*)
          `)
          .eq('pharmacy_id', pharmacy_id)
          .eq('is_available', true)
          .gt('stock_quantity', 0);

        if (error) throw error;

        const formattedMedications = (data || []).map((item: any) => ({
          ...item.medications,
          price: item.price,
          stock_quantity: item.stock_quantity,
          is_available: item.is_available,
        })) as Medication[];

        setMedications(formattedMedications);
      } else {
        const { data, error } = await supabase
          .from('medications')
          .select('*')
          .order('name', { ascending: true });

        if (error) throw error;
        setMedications(data || []);
      }
    } catch (error: any) {
      console.error('Error loading medications:', error);
      Alert.alert('خطأ', 'تعذر جلب الأدوية');
    } finally {
      setLoading(false);
    }
  }

  function filterMedications() {
    if (!searchQuery) return medications;

    return medications.filter(med =>
      med.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (med.name_en && med.name_en.toLowerCase().includes(searchQuery.toLowerCase())) ||
      med.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }

  async function addToCart(medication: Medication) {
    if (medication.requires_prescription) {
      Alert.alert(
        'يتطلب وصفة طبية',
        'هذا الدواء يتطلب وصفة طبية. يرجى رفع وصفتك أولاً.',
        [
          { text: 'إلغاء', style: 'cancel' },
          { text: 'رفع وصفة', onPress: () => router.push('/pharmacy/upload-prescription') },
        ]
      );
      return;
    }

    try {
      const success = await addToCartUtil({
        id: medication.id,
        name: medication.name,
        price: medication.price || 0,
        type: 'product',
        metadata: {
          name_en: medication.name_en,
          category: medication.category,
          description: medication.description,
        },
      }, 1);

      if (success) {
        Alert.alert('تم الإضافة', `تم إضافة ${medication.name} للسلة`);
        await loadCartCount();
      } else {
        Alert.alert('خطأ', 'تعذر إضافة المنتج للسلة');
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء إضافة المنتج');
    }
  }


  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري تحميل الأدوية...</Text>
      </View>
    );
  }

  const filteredMedications = filterMedications();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>البحث عن الأدوية</Text>
        {cartCount > 0 && (
          <TouchableOpacity
            style={styles.cartButton}
            onPress={() => router.push('/cart')}>
            <ShoppingCart size={24} color="#ffffff" />
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText}>{cartCount}</Text>
            </View>
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#64748b" />
        <TextInput
          style={styles.searchInput}
          placeholder="ابحث عن دواء..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          textAlign="right"
        />
      </View>

      <ScrollView style={styles.content}>
        {filteredMedications.map((medication) => (
          <View key={medication.id} style={styles.medicationCard}>
            <View style={styles.medicationInfo}>
              <View style={styles.medicationHeader}>
                <View style={styles.medicationIcon}>
                  <Pill size={24} color="#0ea5e9" />
                </View>
                <View style={styles.medicationDetails}>
                  <Text style={styles.medicationName}>{medication.name}</Text>
                  {medication.name_en && (
                    <Text style={styles.medicationNameEn}>{medication.name_en}</Text>
                  )}
                  <Text style={styles.medicationCategory}>{medication.category}</Text>
                </View>
              </View>

              {medication.description && (
                <Text style={styles.medicationDescription} numberOfLines={2}>
                  {medication.description}
                </Text>
              )}

              {medication.requires_prescription && (
                <View style={styles.prescriptionBadge}>
                  <Text style={styles.prescriptionBadgeText}>يتطلب وصفة طبية</Text>
                </View>
              )}

              <View style={styles.medicationFooter}>
                {medication.price !== undefined && (
                  <View style={styles.priceContainer}>
                    <Text style={styles.price}>{medication.price.toFixed(2)}</Text>
                    <Text style={styles.currency}>ريال</Text>
                  </View>
                )}

                {medication.stock_quantity !== undefined && (
                  <Text style={styles.stock}>
                    المخزون: {medication.stock_quantity}
                  </Text>
                )}

                <TouchableOpacity
                  style={styles.addButton}
                  onPress={() => addToCart(medication)}>
                  <Plus size={20} color="#ffffff" />
                  <Text style={styles.addButtonText}>إضافة</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}

        {filteredMedications.length === 0 && (
          <View style={styles.emptyState}>
            <Pill size={48} color="#cbd5e1" />
            <Text style={styles.emptyStateText}>
              {searchQuery ? 'لا توجد نتائج' : 'لا توجد أدوية متاحة'}
            </Text>
          </View>
        )}
      </ScrollView>

      {cartCount > 0 && (
        <View style={styles.cartFooter}>
          <TouchableOpacity
            style={styles.checkoutButton}
            onPress={() => router.push('/cart')}>
            <ShoppingCart size={20} color="#ffffff" />
            <Text style={styles.checkoutButtonText}>عرض السلة ({cartCount})</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  cartButton: {
    position: 'relative',
    backgroundColor: '#0ea5e9',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#ef4444',
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartBadgeText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    margin: 16,
    padding: 12,
    borderRadius: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
  },
  medicationCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  medicationInfo: {
    gap: 12,
  },
  medicationHeader: {
    flexDirection: 'row',
    gap: 12,
  },
  medicationIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#eff6ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  medicationDetails: {
    flex: 1,
  },
  medicationName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  medicationNameEn: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  medicationCategory: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
  },
  medicationDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  prescriptionBadge: {
    backgroundColor: '#fef3c7',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    alignSelf: 'flex-end',
  },
  prescriptionBadgeText: {
    fontSize: 12,
    color: '#92400e',
    fontWeight: '600',
  },
  medicationFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
  },
  price: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  currency: {
    fontSize: 14,
    color: '#64748b',
  },
  stock: {
    fontSize: 12,
    color: '#64748b',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#10b981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 48,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
  cartFooter: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  checkoutButton: {
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  checkoutButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
