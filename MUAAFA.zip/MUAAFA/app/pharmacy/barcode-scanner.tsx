import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { ScanBarcode, Package, Calendar, AlertCircle, ShoppingCart, ArrowRight } from 'lucide-react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function BarcodeScannerScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanning, setScanning] = useState(false);
  const [medicineData, setMedicineData] = useState<any>(null);

  if (!permission) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
          </TouchableOpacity>
          <View style={styles.headerTextContainer}>
            <Text style={styles.title}>{t('pharmacy.scanBarcode')}</Text>
          </View>
        </View>
        <View style={styles.permissionContainer}>
          <ScanBarcode size={64} color="#cbd5e1" strokeWidth={2} />
          <Text style={styles.permissionTitle}>
            {language === 'ar' ? 'إذن الكاميرا مطلوب' : 'Camera Permission Required'}
          </Text>
          <Text style={styles.permissionText}>
            {language === 'ar'
              ? 'نحتاج إلى إذن الكاميرا لمسح الباركود'
              : 'We need camera permission to scan barcodes'}
          </Text>
          <TouchableOpacity style={styles.permissionButton} onPress={requestPermission}>
            <Text style={styles.permissionButtonText}>
              {language === 'ar' ? 'منح الإذن' : 'Grant Permission'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  function handleBarCodeScanned({ data }: any) {
    if (scanning) return;
    setScanning(true);

    const mockData = {
      name: 'باراسيتامول 500 مجم',
      barcode: data,
      expiryDate: '2025-12-31',
      manufacturer: 'الشركة العربية',
      price: 25.0,
      usage: 'مسكن للآلام وخافض للحرارة',
    };

    setMedicineData(mockData);
    setScanning(false);
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerTextContainer}>
          <Text style={styles.title}>{t('pharmacy.scanBarcode')}</Text>
          <Text style={styles.subtitle}>
            {language === 'ar' ? 'امسح الباركود للحصول على معلومات الدواء' : 'Scan to get medicine info'}
          </Text>
        </View>
      </View>

      {!medicineData ? (
        <View style={styles.cameraContainer}>
          <CameraView
            style={styles.camera}
            onBarcodeScanned={handleBarCodeScanned}
            barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8'] }}
          />
          <View style={styles.scanOverlay}>
            <View style={styles.scanBox} />
            <Text style={styles.scanText}>
              {language === 'ar' ? 'وجّه الكاميرا على الباركود' : 'Point camera at barcode'}
            </Text>
          </View>
        </View>
      ) : (
        <View style={styles.resultContainer}>
          <View style={styles.resultCard}>
            <View style={styles.resultIcon}>
              <Package size={40} color="#0ea5e9" strokeWidth={2} />
            </View>
            <Text style={styles.medicineName}>{medicineData.name}</Text>
            <Text style={styles.barcode}>{medicineData.barcode}</Text>

            <View style={styles.infoGrid}>
              <View style={styles.infoItem}>
                <Calendar size={20} color="#64748b" strokeWidth={2} />
                <Text style={styles.infoLabel}>
                  {language === 'ar' ? 'تاريخ الانتهاء' : 'Expiry Date'}
                </Text>
                <Text style={styles.infoValue}>{medicineData.expiryDate}</Text>
              </View>

              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>
                  {language === 'ar' ? 'الشركة المصنعة' : 'Manufacturer'}
                </Text>
                <Text style={styles.infoValue}>{medicineData.manufacturer}</Text>
              </View>

              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>{language === 'ar' ? 'الاستخدام' : 'Usage'}</Text>
                <Text style={styles.infoValue}>{medicineData.usage}</Text>
              </View>
            </View>

            <View style={styles.priceContainer}>
              <Text style={styles.priceLabel}>{language === 'ar' ? 'السعر' : 'Price'}</Text>
              <Text style={styles.price}>{medicineData.price} {t('pharmacy.priceWatch.sar')}</Text>
            </View>

            <TouchableOpacity style={styles.addToCartButton}>
              <ShoppingCart size={20} color="#ffffff" strokeWidth={2.5} />
              <Text style={styles.addToCartText}>
                {language === 'ar' ? 'إضافة للسلة' : 'Add to Cart'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.scanAgainButton}
              onPress={() => setMedicineData(null)}>
              <ScanBarcode size={20} color="#0ea5e9" strokeWidth={2} />
              <Text style={styles.scanAgainText}>
                {language === 'ar' ? 'مسح باركود آخر' : 'Scan Another'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f9ff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f9ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextContainer: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  permissionContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  permissionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 24,
    marginBottom: 8,
  },
  permissionText: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 24,
  },
  permissionButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 32,
  },
  permissionButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  cameraContainer: {
    flex: 1,
  },
  camera: {
    flex: 1,
  },
  scanOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanBox: {
    width: 250,
    height: 250,
    borderWidth: 3,
    borderColor: '#0ea5e9',
    borderRadius: 20,
    backgroundColor: 'transparent',
  },
  scanText: {
    marginTop: 32,
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  resultContainer: {
    flex: 1,
    padding: 20,
  },
  resultCard: {
    backgroundColor: '#ffffff',
    borderRadius: 24,
    padding: 24,
    alignItems: 'center',
  },
  resultIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  medicineName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'center',
  },
  barcode: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 24,
  },
  infoGrid: {
    width: '100%',
    gap: 12,
    marginBottom: 20,
  },
  infoItem: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 16,
  },
  infoLabel: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  priceContainer: {
    width: '100%',
    backgroundColor: '#f0f9ff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#bae6fd',
  },
  priceLabel: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  price: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0ea5e9',
    textAlign: 'right',
  },
  addToCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    width: '100%',
    backgroundColor: '#0ea5e9',
    borderRadius: 16,
    paddingVertical: 16,
    marginBottom: 12,
  },
  addToCartText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  scanAgainButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    width: '100%',
    backgroundColor: '#e0f2fe',
    borderRadius: 16,
    paddingVertical: 14,
  },
  scanAgainText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0ea5e9',
  },
});
