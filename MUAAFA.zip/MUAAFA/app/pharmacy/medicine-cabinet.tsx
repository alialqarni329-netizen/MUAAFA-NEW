import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import {
  Package,
  Plus,
  Calendar,
  Bell,
  AlertCircle,
  ShoppingCart,
  ArrowRight,
  X,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface Medicine {
  id: string;
  medicine_name: string;
  quantity: number;
  expiry_date: string | null;
  daily_dosage: string | null;
  reminder_enabled: boolean;
  notes: string | null;
}

export default function MedicineCabinetScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMedicine, setNewMedicine] = useState({
    name: '',
    quantity: '',
    expiryDate: '',
    dosage: '',
  });

  useEffect(() => {
    loadMedicines();
  }, []);

  async function loadMedicines() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('medicine_cabinet')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMedicines(data || []);
    } catch (error: any) {
      console.error('Error loading medicines:', error);
    } finally {
      setLoading(false);
    }
  }

  async function addMedicine() {
    if (!newMedicine.name.trim()) {
      alert(language === 'ar' ? 'الرجاء إدخال اسم الدواء' : 'Please enter medicine name');
      return;
    }

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase.from('medicine_cabinet').insert({
        user_id: user.id,
        medicine_name: newMedicine.name,
        quantity: parseInt(newMedicine.quantity) || 0,
        expiry_date: newMedicine.expiryDate || null,
        daily_dosage: newMedicine.dosage || null,
        reminder_enabled: true,
      });

      if (error) throw error;

      setShowAddModal(false);
      setNewMedicine({ name: '', quantity: '', expiryDate: '', dosage: '' });
      loadMedicines();
    } catch (error: any) {
      console.error('Error adding medicine:', error);
    }
  }

  async function reorderMedicine(medicineId: string) {
    alert(language === 'ar' ? 'تمت إضافة الدواء للسلة' : 'Medicine added to cart');
  }

  function getDaysUntilExpiry(expiryDate: string): number {
    const expiry = new Date(expiryDate);
    const today = new Date();
    const diffTime = expiry.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  function getMedicineStatus(medicine: Medicine): { text: string; color: string; bgColor: string } {
    if (!medicine.expiry_date) {
      return { text: '', color: '', bgColor: '' };
    }

    const daysLeft = getDaysUntilExpiry(medicine.expiry_date);

    if (daysLeft < 0) {
      return {
        text: t('pharmacy.medicineCabinet.expired'),
        color: '#ef4444',
        bgColor: '#fee2e2',
      };
    } else if (daysLeft <= 30) {
      return {
        text: `${t('pharmacy.medicineCabinet.expiresIn')} ${daysLeft} ${t('pharmacy.medicineCabinet.days')}`,
        color: '#f59e0b',
        bgColor: '#fef3c7',
      };
    }

    if (medicine.quantity < 5) {
      return {
        text: t('pharmacy.medicineCabinet.runningLow'),
        color: '#f59e0b',
        bgColor: '#fef3c7',
      };
    }

    return { text: '', color: '', bgColor: '' };
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>{t('common.loading')}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerTextContainer}>
          <Text style={styles.title}>{t('pharmacy.myMedicineCabinet')}</Text>
          <Text style={styles.subtitle}>
            {medicines.length} {language === 'ar' ? 'دواء' : 'medicines'}
          </Text>
        </View>
        <TouchableOpacity style={styles.addButton} onPress={() => setShowAddModal(true)}>
          <Plus size={24} color="#ffffff" strokeWidth={2.5} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {medicines.length === 0 ? (
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIcon}>
              <Package size={48} color="#cbd5e1" strokeWidth={2} />
            </View>
            <Text style={styles.emptyTitle}>
              {language === 'ar' ? 'خزانة الأدوية فارغة' : 'Medicine Cabinet is Empty'}
            </Text>
            <Text style={styles.emptyDescription}>
              {language === 'ar'
                ? 'ابدأ بإضافة أدويتك لتتبع الكميات وتواريخ الانتهاء'
                : 'Start adding your medicines to track quantities and expiry dates'}
            </Text>
            <TouchableOpacity style={styles.emptyButton} onPress={() => setShowAddModal(true)}>
              <Plus size={20} color="#ffffff" strokeWidth={2.5} />
              <Text style={styles.emptyButtonText}>{t('pharmacy.medicineCabinet.addMedicine')}</Text>
            </TouchableOpacity>
          </View>
        ) : (
          medicines.map((medicine) => {
            const status = getMedicineStatus(medicine);
            return (
              <View key={medicine.id} style={styles.medicineCard}>
                <View style={styles.medicineHeader}>
                  <View style={styles.medicineInfo}>
                    <Text style={styles.medicineName}>{medicine.medicine_name}</Text>
                    {status.text && (
                      <View style={[styles.statusBadge, { backgroundColor: status.bgColor }]}>
                        <AlertCircle size={14} color={status.color} strokeWidth={2} />
                        <Text style={[styles.statusText, { color: status.color }]}>
                          {status.text}
                        </Text>
                      </View>
                    )}
                  </View>
                </View>

                <View style={styles.medicineDetails}>
                  <View style={styles.detailRow}>
                    <View style={styles.detailItem}>
                      <Package size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailLabel}>{t('pharmacy.medicineCabinet.quantity')}</Text>
                      <Text style={styles.detailValue}>
                        {medicine.quantity} {t('pharmacy.medicineCabinet.pills')}
                      </Text>
                    </View>
                    {medicine.expiry_date && (
                      <View style={styles.detailItem}>
                        <Calendar size={16} color="#64748b" strokeWidth={2} />
                        <Text style={styles.detailLabel}>
                          {t('pharmacy.medicineCabinet.expiryDate')}
                        </Text>
                        <Text style={styles.detailValue}>
                          {new Date(medicine.expiry_date).toLocaleDateString('ar-SA')}
                        </Text>
                      </View>
                    )}
                  </View>

                  {medicine.daily_dosage && (
                    <View style={styles.dosageContainer}>
                      <Text style={styles.dosageLabel}>{t('pharmacy.medicineCabinet.dosage')}</Text>
                      <Text style={styles.dosageValue}>{medicine.daily_dosage}</Text>
                    </View>
                  )}

                  {medicine.reminder_enabled && (
                    <View style={styles.reminderBadge}>
                      <Bell size={14} color="#8b5cf6" strokeWidth={2} />
                      <Text style={styles.reminderText}>{t('pharmacy.medicineCabinet.reminder')}</Text>
                    </View>
                  )}
                </View>

                <TouchableOpacity
                  style={styles.reorderButton}
                  onPress={() => reorderMedicine(medicine.id)}>
                  <ShoppingCart size={18} color="#0ea5e9" strokeWidth={2} />
                  <Text style={styles.reorderButtonText}>
                    {t('pharmacy.medicineCabinet.reorder')}
                  </Text>
                </TouchableOpacity>
              </View>
            );
          })
        )}
      </ScrollView>

      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{t('pharmacy.medicineCabinet.addMedicine')}</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <X size={24} color="#64748b" strokeWidth={2} />
              </TouchableOpacity>
            </View>

            <View style={styles.form}>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>
                  {language === 'ar' ? 'اسم الدواء *' : 'Medicine Name *'}
                </Text>
                <TextInput
                  style={styles.input}
                  value={newMedicine.name}
                  onChangeText={(text) => setNewMedicine({ ...newMedicine, name: text })}
                  placeholder={language === 'ar' ? 'مثال: باراسيتامول' : 'e.g., Paracetamol'}
                  placeholderTextColor="#94a3b8"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>{t('pharmacy.medicineCabinet.quantity')}</Text>
                <TextInput
                  style={styles.input}
                  value={newMedicine.quantity}
                  onChangeText={(text) => setNewMedicine({ ...newMedicine, quantity: text })}
                  keyboardType="numeric"
                  placeholder="30"
                  placeholderTextColor="#94a3b8"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>{t('pharmacy.medicineCabinet.expiryDate')}</Text>
                <TextInput
                  style={styles.input}
                  value={newMedicine.expiryDate}
                  onChangeText={(text) => setNewMedicine({ ...newMedicine, expiryDate: text })}
                  placeholder="2025-12-31"
                  placeholderTextColor="#94a3b8"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>{t('pharmacy.medicineCabinet.dosage')}</Text>
                <TextInput
                  style={styles.input}
                  value={newMedicine.dosage}
                  onChangeText={(text) => setNewMedicine({ ...newMedicine, dosage: text })}
                  placeholder={language === 'ar' ? '3 مرات يومياً' : '3 times daily'}
                  placeholderTextColor="#94a3b8"
                />
              </View>

              <TouchableOpacity style={styles.submitButton} onPress={addMedicine}>
                <Text style={styles.submitButtonText}>{t('common.save')}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f9ff',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f9ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextContainer: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#8b5cf6',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 24,
    paddingHorizontal: 32,
    lineHeight: 20,
  },
  emptyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#8b5cf6',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  emptyButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  medicineCard: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e0f2fe',
  },
  medicineHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  medicineInfo: {
    flex: 1,
  },
  medicineName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-end',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  medicineDetails: {
    gap: 12,
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    gap: 12,
  },
  detailItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 12,
  },
  detailLabel: {
    fontSize: 12,
    color: '#64748b',
    flex: 1,
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
  },
  dosageContainer: {
    backgroundColor: '#f0f9ff',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#bae6fd',
  },
  dosageLabel: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  dosageValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0ea5e9',
    textAlign: 'right',
  },
  reminderBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-end',
  },
  reminderText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#8b5cf6',
  },
  reorderButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#e0f2fe',
    borderRadius: 12,
    paddingVertical: 12,
  },
  reorderButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  form: {
    gap: 16,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  submitButton: {
    backgroundColor: '#8b5cf6',
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
