import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Modal, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { AlertCircle, Plus, X, Shield, ArrowRight } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface Interaction {
  medicine_pair: string;
  severity: string;
  description: string;
  recommendation: string;
}

export default function InteractionsScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [medicines, setMedicines] = useState<string[]>([]);
  const [interactions, setInteractions] = useState<Interaction[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMedicine, setNewMedicine] = useState('');

  async function checkInteractions() {
    if (medicines.length < 2) return;

    try {
      const { data, error } = await supabase.rpc('check_drug_interactions', {
        medicines,
      });

      if (error) throw error;
      setInteractions(data || []);
    } catch (error) {
      console.error('Error checking interactions:', error);
    }
  }

  function addMedicine() {
    if (newMedicine.trim()) {
      setMedicines([...medicines, newMedicine.trim()]);
      setNewMedicine('');
      setShowAddModal(false);
    }
  }

  function removeMedicine(index: number) {
    const updated = medicines.filter((_, i) => i !== index);
    setMedicines(updated);
  }

  function getSeverityColor(severity: string) {
    switch (severity) {
      case 'low':
        return { bg: '#d1fae5', text: '#065f46', border: '#86efac' };
      case 'medium':
        return { bg: '#fef3c7', text: '#92400e', border: '#fde68a' };
      case 'high':
        return { bg: '#fed7aa', text: '#9a3412', border: '#fdba74' };
      case 'severe':
        return { bg: '#fee2e2', text: '#991b1b', border: '#fca5a5' };
      default:
        return { bg: '#f1f5f9', text: '#475569', border: '#cbd5e1' };
    }
  }

  useEffect(() => {
    checkInteractions();
  }, [medicines]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerTextContainer}>
          <Text style={styles.title}>{t('pharmacy.interactionChecker')}</Text>
          <Text style={styles.subtitle}>{t('pharmacy.interactions.title')}</Text>
        </View>
        <TouchableOpacity style={styles.addButton} onPress={() => setShowAddModal(true)}>
          <Plus size={24} color="#ffffff" strokeWidth={2.5} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {medicines.length === 0 ? (
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIcon}>
              <Shield size={48} color="#cbd5e1" strokeWidth={2} />
            </View>
            <Text style={styles.emptyTitle}>
              {language === 'ar' ? 'لم تضف أدوية بعد' : 'No medicines added yet'}
            </Text>
            <Text style={styles.emptyDescription}>
              {language === 'ar'
                ? 'أضف على الأقل دواءين للتحقق من التفاعلات بينهما'
                : 'Add at least two medicines to check interactions'}
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.medicinesSection}>
              <Text style={styles.sectionTitle}>
                {language === 'ar' ? 'أدويتك الحالية' : 'Your Current Medicines'}
              </Text>
              <View style={styles.medicinesList}>
                {medicines.map((medicine, index) => (
                  <View key={index} style={styles.medicineChip}>
                    <Text style={styles.medicineChipText}>{medicine}</Text>
                    <TouchableOpacity onPress={() => removeMedicine(index)}>
                      <X size={18} color="#64748b" strokeWidth={2} />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            </View>

            {interactions.length === 0 ? (
              <View style={styles.safeCard}>
                <Shield size={32} color="#10b981" strokeWidth={2} />
                <Text style={styles.safeTitle}>{t('pharmacy.interactions.noInteractions')}</Text>
                <Text style={styles.safeDescription}>
                  {language === 'ar'
                    ? 'لم نعثر على أي تفاعلات خطيرة بين الأدوية المدخلة'
                    : 'No dangerous interactions found between entered medicines'}
                </Text>
              </View>
            ) : (
              <>
                <View style={styles.warningCard}>
                  <AlertCircle size={24} color="#ef4444" strokeWidth={2} />
                  <Text style={styles.warningText}>{t('pharmacy.interactions.warningFound')}</Text>
                  <Text style={styles.warningCount}>
                    {interactions.length} {language === 'ar' ? 'تفاعل' : 'interaction(s)'}
                  </Text>
                </View>

                {interactions.map((interaction, index) => {
                  const colors = getSeverityColor(interaction.severity);
                  return (
                    <View
                      key={index}
                      style={[
                        styles.interactionCard,
                        { backgroundColor: colors.bg, borderColor: colors.border },
                      ]}>
                      <View style={styles.interactionHeader}>
                        <Text style={[styles.medicinePair, { color: colors.text }]}>
                          {interaction.medicine_pair}
                        </Text>
                        <View style={[styles.severityBadge, { backgroundColor: colors.text }]}>
                          <Text style={styles.severityText}>
                            {t(`pharmacy.interactions.severity.${interaction.severity}`)}
                          </Text>
                        </View>
                      </View>

                      <View style={styles.interactionDetails}>
                        <Text style={styles.detailLabel}>{t('pharmacy.interactions.description')}</Text>
                        <Text style={[styles.detailText, { color: colors.text }]}>
                          {interaction.description}
                        </Text>
                      </View>

                      {interaction.recommendation && (
                        <View style={styles.recommendationBox}>
                          <Text style={styles.recommendationLabel}>
                            {t('pharmacy.interactions.recommendation')}
                          </Text>
                          <Text style={[styles.recommendationText, { color: colors.text }]}>
                            {interaction.recommendation}
                          </Text>
                        </View>
                      )}
                    </View>
                  );
                })}
              </>
            )}
          </>
        )}
      </ScrollView>

      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {language === 'ar' ? 'إضافة دواء' : 'Add Medicine'}
              </Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <X size={24} color="#64748b" strokeWidth={2} />
              </TouchableOpacity>
            </View>
            <TextInput
              style={styles.input}
              value={newMedicine}
              onChangeText={setNewMedicine}
              placeholder={language === 'ar' ? 'اسم الدواء' : 'Medicine name'}
              placeholderTextColor="#94a3b8"
              autoFocus
            />
            <TouchableOpacity style={styles.submitButton} onPress={addMedicine}>
              <Text style={styles.submitButtonText}>{t('common.save')}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f9ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextContainer: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#ef4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    paddingHorizontal: 32,
  },
  medicinesSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  medicinesList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    justifyContent: 'flex-end',
  },
  medicineChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#e0f2fe',
  },
  medicineChipText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
  },
  safeCard: {
    backgroundColor: '#d1fae5',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#86efac',
  },
  safeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#065f46',
    marginTop: 16,
    marginBottom: 8,
  },
  safeDescription: {
    fontSize: 14,
    color: '#047857',
    textAlign: 'center',
  },
  warningCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#fee2e2',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#fca5a5',
  },
  warningText: {
    flex: 1,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#991b1b',
    textAlign: 'right',
  },
  warningCount: {
    fontSize: 14,
    fontWeight: '600',
    color: '#991b1b',
  },
  interactionCard: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
  },
  interactionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  medicinePair: {
    flex: 1,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  severityBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  severityText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  interactionDetails: {
    marginBottom: 12,
  },
  detailLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  detailText: {
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'right',
  },
  recommendationBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    borderRadius: 12,
    padding: 12,
  },
  recommendationLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  recommendationText: {
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
    textAlign: 'right',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  submitButton: {
    backgroundColor: '#ef4444',
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
