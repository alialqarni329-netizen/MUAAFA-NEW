import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { MapPin, Search, Clock, Star, Truck } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface Pharmacy {
  id: string;
  name: string;
  phone: string;
  address: string;
  city: string;
  latitude: number;
  longitude: number;
  rating: number;
  is_24_hours: boolean;
  has_instant_delivery: boolean;
  delivery_time_minutes: number;
}

export default function PharmacyListScreen() {
  const router = useRouter();
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCity, setFilterCity] = useState('');

  useEffect(() => {
    loadPharmacies();
  }, []);

  async function loadPharmacies() {
    try {
      let query = supabase
        .from('pharmacies')
        .select('*')
        .eq('is_active', true)
        .order('rating', { ascending: false });

      if (filterCity) {
        query = query.eq('city', filterCity);
      }

      const { data, error } = await query;

      if (error) throw error;
      setPharmacies(data || []);
    } catch (error: any) {
      console.error('Error loading pharmacies:', error);
      Alert.alert('خطأ', 'تعذر جلب الصيدليات');
    } finally {
      setLoading(false);
    }
  }

  function filterPharmacies() {
    return pharmacies.filter(pharmacy => {
      const matchesSearch = pharmacy.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           pharmacy.address.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCity = !filterCity || pharmacy.city === filterCity;
      return matchesSearch && matchesCity;
    });
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري تحميل الصيدليات...</Text>
      </View>
    );
  }

  const filteredPharmacies = filterPharmacies();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>الصيدليات القريبة</Text>
        <Text style={styles.subtitle}>اختر صيدلية للطلب</Text>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#64748b" />
        <TextInput
          style={styles.searchInput}
          placeholder="ابحث عن صيدلية..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          textAlign="right"
        />
      </View>

      <View style={styles.filterContainer}>
        <TouchableOpacity
          style={[styles.filterButton, !filterCity && styles.filterButtonActive]}
          onPress={() => setFilterCity('')}>
          <Text style={[styles.filterButtonText, !filterCity && styles.filterButtonTextActive]}>
            الكل
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterButton, filterCity === 'الرياض' && styles.filterButtonActive]}
          onPress={() => setFilterCity('الرياض')}>
          <Text style={[styles.filterButtonText, filterCity === 'الرياض' && styles.filterButtonTextActive]}>
            الرياض
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterButton, filterCity === 'جدة' && styles.filterButtonActive]}
          onPress={() => setFilterCity('جدة')}>
          <Text style={[styles.filterButtonText, filterCity === 'جدة' && styles.filterButtonTextActive]}>
            جدة
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        {filteredPharmacies.map((pharmacy) => (
          <TouchableOpacity
            key={pharmacy.id}
            style={styles.pharmacyCard}
            onPress={() => router.push(`/pharmacy/search?pharmacy_id=${pharmacy.id}`)}>
            <View style={styles.pharmacyHeader}>
              <View style={styles.pharmacyInfo}>
                <Text style={styles.pharmacyName}>{pharmacy.name}</Text>
                <View style={styles.ratingContainer}>
                  <Star size={16} color="#f59e0b" fill="#f59e0b" />
                  <Text style={styles.rating}>{pharmacy.rating.toFixed(1)}</Text>
                </View>
              </View>

              {pharmacy.is_24_hours && (
                <View style={styles.badge24}>
                  <Clock size={14} color="#10b981" />
                  <Text style={styles.badge24Text}>24 ساعة</Text>
                </View>
              )}
            </View>

            <View style={styles.pharmacyDetails}>
              <View style={styles.detailRow}>
                <MapPin size={16} color="#64748b" />
                <Text style={styles.detailText}>{pharmacy.address}</Text>
              </View>

              {pharmacy.has_instant_delivery && (
                <View style={styles.detailRow}>
                  <Truck size={16} color="#10b981" />
                  <Text style={styles.deliveryText}>
                    توصيل فوري ({pharmacy.delivery_time_minutes} دقيقة)
                  </Text>
                </View>
              )}
            </View>

            <TouchableOpacity
              style={styles.orderButton}
              onPress={() => router.push(`/pharmacy/search?pharmacy_id=${pharmacy.id}`)}>
              <Text style={styles.orderButtonText}>تصفح الأدوية</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}

        {filteredPharmacies.length === 0 && (
          <View style={styles.emptyState}>
            <MapPin size={48} color="#cbd5e1" />
            <Text style={styles.emptyStateText}>لا توجد صيدليات متاحة</Text>
          </View>
        )}
      </ScrollView>

      <TouchableOpacity
        style={styles.fabButton}
        onPress={() => router.push('/pharmacy/upload-prescription')}>
        <Text style={styles.fabButtonText}>رفع وصفة طبية</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#64748b',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    margin: 16,
    padding: 12,
    borderRadius: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  filterContainer: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  filterButtonActive: {
    backgroundColor: '#0ea5e9',
    borderColor: '#0ea5e9',
  },
  filterButtonText: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  filterButtonTextActive: {
    color: '#ffffff',
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
  },
  pharmacyCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  pharmacyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  pharmacyInfo: {
    flex: 1,
  },
  pharmacyName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  badge24: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#d1fae5',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  badge24Text: {
    fontSize: 12,
    color: '#10b981',
    fontWeight: '600',
  },
  pharmacyDetails: {
    gap: 8,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  detailText: {
    flex: 1,
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  deliveryText: {
    flex: 1,
    fontSize: 14,
    color: '#10b981',
    fontWeight: '600',
    textAlign: 'right',
  },
  orderButton: {
    backgroundColor: '#0ea5e9',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  orderButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 48,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
  fabButton: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    left: 24,
    backgroundColor: '#10b981',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  fabButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
