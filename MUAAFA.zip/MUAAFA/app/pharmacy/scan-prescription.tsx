import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  ScrollView,
  Image,
  Platform,
} from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { ChevronRight, Camera, Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { supabase } from '@/lib/supabase';

interface PrescriptionAnalysis {
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
  }>;
  doctor_name?: string;
  clinic_name?: string;
  date?: string;
  notes?: string;
  demo_mode?: boolean;
}

export default function ScanPrescriptionScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<PrescriptionAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleTakePhoto() {
    try {
      setError(null);
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('تنبيه', 'يرجى السماح بالوصول إلى الكاميرا');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 0.8,
        base64: false,
      });

      if (!result.canceled && result.assets[0]) {
        setImageUri(result.assets[0].uri);
        await analyzePrescription(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      setError('فشل التقاط الصورة. تأكد من منح الأذونات اللازمة.');
      Alert.alert('خطأ', 'فشل التقاط الصورة. يرجى المحاولة مرة أخرى.');
    }
  }

  async function handlePickImage() {
    try {
      setError(null);
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('تنبيه', 'يرجى السماح بالوصول إلى المعرض');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 0.8,
        base64: false,
      });

      if (!result.canceled && result.assets[0]) {
        setImageUri(result.assets[0].uri);
        await analyzePrescription(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error picking image:', error);
      setError('فشل اختيار الصورة. تأكد من منح الأذونات اللازمة.');
      Alert.alert('خطأ', 'فشل اختيار الصورة. يرجى المحاولة مرة أخرى.');
    }
  }

  async function analyzePrescription(uri: string) {
    setAnalyzing(true);
    setError(null);

    try {
      // Step 1: Verify environment variables
      const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
      const openaiKey = process.env.EXPO_PUBLIC_OPENAI_API_KEY;

      if (!supabaseUrl) {
        throw new Error('MISSING_SUPABASE_URL: متغير EXPO_PUBLIC_SUPABASE_URL غير موجود');
      }

      if (!openaiKey) {
        throw new Error('MISSING_OPENAI_KEY: متغير EXPO_PUBLIC_OPENAI_API_KEY غير موجود في .env');
      }

      // Step 2: Convert image to base64
      let base64Image: string;

      if (Platform.OS === 'web') {
        // Web platform
        const response = await fetch(uri);
        const blob = await response.blob();
        base64Image = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });
      } else {
        // Native platforms (iOS/Android)
        try {
          const base64 = await FileSystem.readAsStringAsync(uri, {
            encoding: FileSystem.EncodingType.Base64,
          });
          base64Image = `data:image/jpeg;base64,${base64}`;
        } catch (fsError) {
          console.error('FileSystem error:', fsError);
          throw new Error('FILE_READ_ERROR: فشل قراءة الصورة من الجهاز');
        }
      }

      // Step 3: Get authentication session (optional)
      const { data: { session } } = await supabase.auth.getSession();

      // Step 4: Call Edge Function
      const apiUrl = `${supabaseUrl}/functions/v1/analyze-prescription`;
      const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

      if (!anonKey) {
        throw new Error('MISSING_ANON_KEY: مفتاح Supabase غير موجود');
      }

      console.log('Calling API:', apiUrl);

      const analysisResponse = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session?.access_token || anonKey}`,
          'Content-Type': 'application/json',
          'apikey': anonKey,
        },
        body: JSON.stringify({
          image: base64Image,
        }),
      });

      console.log('API Response status:', analysisResponse.status);

      // Step 5: Handle response
      if (!analysisResponse.ok) {
        const errorText = await analysisResponse.text();
        console.error('API Error:', errorText);

        if (analysisResponse.status === 404) {
          throw new Error('API_NOT_FOUND: Edge Function غير موجودة أو غير منشورة');
        } else if (analysisResponse.status === 401) {
          throw new Error('UNAUTHORIZED: خطأ في المصادقة');
        } else if (analysisResponse.status === 500) {
          throw new Error('SERVER_ERROR: خطأ في السيرفر - ' + errorText);
        } else {
          throw new Error(`HTTP_ERROR_${analysisResponse.status}: ${errorText}`);
        }
      }

      const analysisData = await analysisResponse.json();

      if (!analysisData || !analysisData.analysis) {
        throw new Error('INVALID_RESPONSE: استجابة غير صحيحة من السيرفر');
      }

      setAnalysis(analysisData.analysis);
      setError(null);

      if (analysisData.mode === 'demo') {
        Alert.alert(
          'النظام التجريبي 🎯',
          'تم استخدام بيانات تجريبية لعرض كيفية عمل الميزة.\n\nللحصول على تحليل حقيقي للوصفة، يرجى إضافة OpenAI API Key في إعدادات المشروع.',
          [{ text: 'حسناً', style: 'default' }]
        );
      }

    } catch (error: any) {
      console.error('Error analyzing prescription:', error);

      let userMessage = 'فشل تحليل الوصفة الطبية. يرجى المحاولة مرة أخرى.';

      if (error.message?.includes('MISSING_OPENAI_KEY')) {
        userMessage = 'تم استخدام النظام التجريبي. للحصول على تحليل حقيقي، أضف OpenAI API Key';
      } else if (error.message?.includes('MISSING_SUPABASE_URL')) {
        userMessage = 'خطأ في الإعدادات. رابط Supabase غير موجود';
      } else if (error.message?.includes('MISSING_ANON_KEY')) {
        userMessage = 'خطأ في الإعدادات. مفتاح Supabase غير موجود';
      } else if (error.message?.includes('API_NOT_FOUND')) {
        userMessage = 'الخدمة غير متوفرة حالياً. جاري العمل على حل المشكلة';
      } else if (error.message?.includes('FILE_READ_ERROR')) {
        userMessage = 'فشل قراءة الصورة. جرب صورة أخرى بجودة أفضل';
      } else if (error.message?.includes('UNAUTHORIZED')) {
        userMessage = 'مشكلة في الاتصال بالخادم. حاول مرة أخرى';
      } else if (error.message?.includes('SERVER_ERROR')) {
        userMessage = 'خطأ في الخادم. حاول مرة أخرى بعد قليل';
      } else if (error.message) {
        userMessage = 'حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى';
      }

      setError(userMessage);

      Alert.alert(
        'خطأ في التحليل',
        userMessage + '\n\nالتفاصيل التقنية:\n' + (error.message || 'Unknown error'),
        [
          { text: 'حسناً', style: 'cancel' },
          {
            text: 'المحاولة مرة أخرى',
            onPress: () => {
              setImageUri(null);
              setAnalysis(null);
              setError(null);
            },
          },
        ]
      );
    } finally {
      setAnalyzing(false);
    }
  }

  async function handleSavePrescription() {
    if (!analysis) return;

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('يجب تسجيل الدخول أولاً');
      }

      const { error } = await supabase.from('prescriptions').insert({
        user_id: user.id,
        doctor_name: analysis.doctor_name || 'غير محدد',
        clinic_name: analysis.clinic_name || 'غير محدد',
        prescription_date: analysis.date || new Date().toISOString().split('T')[0],
        medications: analysis.medications,
        notes: analysis.notes || '',
        image_url: imageUri,
      });

      if (error) throw error;

      Alert.alert(
        'تم الحفظ ✅',
        'تم حفظ الوصفة الطبية في سجلاتك الصحية بنجاح',
        [
          {
            text: 'عرض السجلات',
            onPress: () => router.push('/reports/history'),
          },
          {
            text: 'إضافة تنبيهات',
            onPress: () => router.push('/pharmacy/medication-reminders'),
          },
          {
            text: 'حسناً',
            style: 'cancel',
          },
        ]
      );
    } catch (error: any) {
      console.error('Error saving prescription:', error);
      Alert.alert('خطأ', error.message || 'فشل حفظ الوصفة الطبية');
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>مسح الوصفة الطبية</Text>
        <View style={styles.backButton} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {!imageUri ? (
          <View style={styles.emptyState}>
            <View style={styles.iconContainer}>
              <FileText size={80} color="#0ea5e9" strokeWidth={1.5} />
            </View>
            <Text style={styles.emptyStateTitle}>مسح وصفة طبية</Text>
            <Text style={styles.emptyStateText}>
              التقط صورة للوصفة الطبية أو اختر صورة من المعرض لتحليلها تلقائياً
            </Text>

            <View style={styles.buttonContainer}>
              <TouchableOpacity style={styles.primaryButton} onPress={handleTakePhoto}>
                <Camera size={24} color="#ffffff" strokeWidth={2} />
                <Text style={styles.primaryButtonText}>التقاط صورة</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.secondaryButton} onPress={handlePickImage}>
                <Upload size={24} color="#0ea5e9" strokeWidth={2} />
                <Text style={styles.secondaryButtonText}>اختيار من المعرض</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>نصائح للحصول على أفضل نتيجة:</Text>
              <Text style={styles.infoText}>• تأكد من وضوح الصورة</Text>
              <Text style={styles.infoText}>• تجنب الظلال والانعكاسات</Text>
              <Text style={styles.infoText}>• التقط الصورة في إضاءة جيدة</Text>
              <Text style={styles.infoText}>• احرص على ظهور الوصفة كاملة</Text>
            </View>
          </View>
        ) : (
          <View style={styles.resultContainer}>
            <View style={styles.imagePreview}>
              <Image source={{ uri: imageUri }} style={styles.image} />
            </View>

            {analyzing ? (
              <View style={styles.analyzingContainer}>
                <ActivityIndicator size="large" color="#0ea5e9" />
                <Text style={styles.analyzingText}>جاري تحليل الوصفة...</Text>
                <Text style={styles.analyzingSubtext}>قد تستغرق العملية بضع ثوانٍ</Text>
              </View>
            ) : error ? (
              <View style={styles.errorContainer}>
                <View style={styles.errorIcon}>
                  <AlertCircle size={48} color="#ef4444" strokeWidth={2} />
                </View>
                <Text style={styles.errorTitle}>فشل التحليل</Text>
                <Text style={styles.errorMessage}>{error}</Text>
                <TouchableOpacity
                  style={styles.retryButton}
                  onPress={() => {
                    setImageUri(null);
                    setAnalysis(null);
                    setError(null);
                  }}>
                  <Text style={styles.retryButtonText}>المحاولة مرة أخرى</Text>
                </TouchableOpacity>
              </View>
            ) : analysis ? (
              <View style={styles.analysisContainer}>
                {analysis.demo_mode && (
                  <View style={styles.demoBadge}>
                    <Text style={styles.demoText}>وضع تجريبي - بيانات للعرض فقط</Text>
                  </View>
                )}
                <View style={styles.successBadge}>
                  <CheckCircle size={24} color="#10b981" strokeWidth={2} />
                  <Text style={styles.successText}>تم التحليل بنجاح</Text>
                </View>

                {analysis.doctor_name && (
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>اسم الطبيب:</Text>
                    <Text style={styles.infoValue}>{analysis.doctor_name}</Text>
                  </View>
                )}

                {analysis.clinic_name && (
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>العيادة:</Text>
                    <Text style={styles.infoValue}>{analysis.clinic_name}</Text>
                  </View>
                )}

                {analysis.date && (
                  <View style={styles.infoRow}>
                    <Text style={styles.infoLabel}>التاريخ:</Text>
                    <Text style={styles.infoValue}>{analysis.date}</Text>
                  </View>
                )}

                <Text style={styles.sectionTitle}>الأدوية المكتوبة:</Text>
                {analysis.medications.map((med, index) => (
                  <View key={index} style={styles.medicationCard}>
                    <Text style={styles.medicationName}>{med.name}</Text>
                    <View style={styles.medicationDetails}>
                      <Text style={styles.medicationDetail}>الجرعة: {med.dosage}</Text>
                      <Text style={styles.medicationDetail}>التكرار: {med.frequency}</Text>
                      {med.duration && (
                        <Text style={styles.medicationDetail}>المدة: {med.duration}</Text>
                      )}
                    </View>
                  </View>
                ))}

                {analysis.notes && (
                  <View style={styles.notesContainer}>
                    <Text style={styles.notesTitle}>ملاحظات إضافية:</Text>
                    <Text style={styles.notesText}>{analysis.notes}</Text>
                  </View>
                )}

                <TouchableOpacity
                  style={styles.saveButton}
                  onPress={handleSavePrescription}
                  disabled={loading}>
                  {loading ? (
                    <ActivityIndicator color="#ffffff" />
                  ) : (
                    <Text style={styles.saveButtonText}>حفظ في السجلات</Text>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.retryButton}
                  onPress={() => {
                    setImageUri(null);
                    setAnalysis(null);
                    setError(null);
                  }}>
                  <Text style={styles.retryButtonText}>مسح وصفة أخرى</Text>
                </TouchableOpacity>
              </View>
            ) : null}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  content: {
    flex: 1,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  iconContainer: {
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyStateTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  buttonContainer: {
    width: '100%',
    gap: 12,
    marginBottom: 32,
  },
  primaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    backgroundColor: '#0ea5e9',
    paddingVertical: 16,
    borderRadius: 12,
  },
  primaryButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  secondaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    backgroundColor: '#ffffff',
    paddingVertical: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#0ea5e9',
  },
  secondaryButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  infoCard: {
    backgroundColor: '#eff6ff',
    padding: 20,
    borderRadius: 12,
    width: '100%',
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  infoText: {
    fontSize: 14,
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  resultContainer: {
    padding: 20,
  },
  imagePreview: {
    width: '100%',
    height: 300,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 20,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  analyzingContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  analyzingText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
  },
  analyzingSubtext: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 8,
  },
  errorContainer: {
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  errorIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#fee2e2',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#dc2626',
    marginBottom: 12,
    textAlign: 'center',
  },
  errorMessage: {
    fontSize: 15,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
    paddingHorizontal: 20,
  },
  analysisContainer: {
    gap: 16,
  },
  demoBadge: {
    backgroundColor: '#fef3c7',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#f59e0b',
    marginBottom: 12,
  },
  demoText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#92400e',
    textAlign: 'center',
  },
  successBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#dcfce7',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    marginBottom: 8,
  },
  successText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#10b981',
  },
  infoRow: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  infoLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  infoValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
    marginBottom: 8,
    textAlign: 'right',
  },
  medicationCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#0ea5e9',
  },
  medicationName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  medicationDetails: {
    gap: 4,
  },
  medicationDetail: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  notesContainer: {
    backgroundColor: '#fef3c7',
    padding: 16,
    borderRadius: 12,
  },
  notesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  notesText: {
    fontSize: 14,
    color: '#475569',
    textAlign: 'right',
    lineHeight: 20,
  },
  saveButton: {
    backgroundColor: '#0ea5e9',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  retryButton: {
    backgroundColor: '#ffffff',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  retryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
});
