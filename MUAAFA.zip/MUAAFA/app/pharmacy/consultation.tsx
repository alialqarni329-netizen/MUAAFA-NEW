import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { MessageCircle, Send, User, CheckCircle, Clock, ArrowRight, X } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface Consultation {
  id: string;
  medicine_name: string | null;
  question: string;
  answer: string | null;
  status: string;
  created_at: string;
  answered_at: string | null;
}

export default function ConsultationScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [showNewModal, setShowNewModal] = useState(false);
  const [newQuestion, setNewQuestion] = useState({ medicine: '', question: '' });

  useEffect(() => {
    loadConsultations();
  }, []);

  async function loadConsultations() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('pharmacist_consultations')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setConsultations(data || []);
    } catch (error) {
      console.error('Error loading consultations:', error);
    }
  }

  async function submitQuestion() {
    if (!newQuestion.question.trim()) {
      alert(language === 'ar' ? 'الرجاء كتابة سؤالك' : 'Please enter your question');
      return;
    }

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase.from('pharmacist_consultations').insert({
        user_id: user.id,
        medicine_name: newQuestion.medicine || null,
        question: newQuestion.question,
        status: 'pending',
      });

      if (error) throw error;

      setShowNewModal(false);
      setNewQuestion({ medicine: '', question: '' });
      loadConsultations();
    } catch (error) {
      console.error('Error submitting question:', error);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerTextContainer}>
          <Text style={styles.title}>{t('pharmacy.consultPharmacist')}</Text>
          <Text style={styles.subtitle}>{t('pharmacy.consultation.title')}</Text>
        </View>
        <TouchableOpacity style={styles.addButton} onPress={() => setShowNewModal(true)}>
          <MessageCircle size={24} color="#ffffff" strokeWidth={2.5} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {consultations.length === 0 ? (
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIcon}>
              <MessageCircle size={48} color="#cbd5e1" strokeWidth={2} />
            </View>
            <Text style={styles.emptyTitle}>
              {language === 'ar' ? 'لا توجد استشارات بعد' : 'No consultations yet'}
            </Text>
            <Text style={styles.emptyDescription}>
              {language === 'ar'
                ? 'اسأل الصيدلي عن أي دواء أو استفسار طبي'
                : 'Ask pharmacist about any medicine or medical inquiry'}
            </Text>
            <TouchableOpacity style={styles.emptyButton} onPress={() => setShowNewModal(true)}>
              <Send size={20} color="#ffffff" strokeWidth={2.5} />
              <Text style={styles.emptyButtonText}>{t('pharmacy.consultation.askQuestion')}</Text>
            </TouchableOpacity>
          </View>
        ) : (
          consultations.map((consultation) => (
            <View key={consultation.id} style={styles.consultationCard}>
              <View style={styles.statusBadge}>
                {consultation.status === 'answered' ? (
                  <>
                    <CheckCircle size={14} color="#10b981" strokeWidth={2} />
                    <Text style={styles.statusAnswered}>{t('pharmacy.consultation.answered')}</Text>
                  </>
                ) : (
                  <>
                    <Clock size={14} color="#f59e0b" strokeWidth={2} />
                    <Text style={styles.statusPending}>{t('pharmacy.consultation.pending')}</Text>
                  </>
                )}
              </View>

              {consultation.medicine_name && (
                <View style={styles.medicineTag}>
                  <Text style={styles.medicineTagText}>{consultation.medicine_name}</Text>
                </View>
              )}

              <View style={styles.questionSection}>
                <View style={styles.userAvatar}>
                  <User size={16} color="#0ea5e9" strokeWidth={2} />
                </View>
                <View style={styles.messageContent}>
                  <Text style={styles.messageLabel}>
                    {language === 'ar' ? 'سؤالك' : 'Your Question'}
                  </Text>
                  <Text style={styles.questionText}>{consultation.question}</Text>
                  <Text style={styles.dateText}>
                    {new Date(consultation.created_at).toLocaleDateString('ar-SA')}
                  </Text>
                </View>
              </View>

              {consultation.answer && (
                <View style={styles.answerSection}>
                  <View style={styles.pharmacistAvatar}>
                    <MessageCircle size={16} color="#ffffff" strokeWidth={2} />
                  </View>
                  <View style={styles.messageContent}>
                    <Text style={styles.messageLabel}>{t('pharmacy.consultation.pharmacist')}</Text>
                    <Text style={styles.answerText}>{consultation.answer}</Text>
                    {consultation.answered_at && (
                      <Text style={styles.dateText}>
                        {new Date(consultation.answered_at).toLocaleDateString('ar-SA')}
                      </Text>
                    )}
                  </View>
                </View>
              )}
            </View>
          ))
        )}
      </ScrollView>

      <Modal visible={showNewModal} animationType="slide" transparent>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{t('pharmacy.consultation.askQuestion')}</Text>
              <TouchableOpacity onPress={() => setShowNewModal(false)}>
                <X size={24} color="#64748b" strokeWidth={2} />
              </TouchableOpacity>
            </View>

            <View style={styles.form}>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>{t('pharmacy.consultation.medicine')}</Text>
                <TextInput
                  style={styles.input}
                  value={newQuestion.medicine}
                  onChangeText={(text) => setNewQuestion({ ...newQuestion, medicine: text })}
                  placeholder={language === 'ar' ? 'اختياري' : 'Optional'}
                  placeholderTextColor="#94a3b8"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>{t('pharmacy.consultation.question')} *</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={newQuestion.question}
                  onChangeText={(text) => setNewQuestion({ ...newQuestion, question: text })}
                  placeholder={
                    language === 'ar'
                      ? 'ما هي الأعراض الجانبية؟ كيف أستخدم الدواء؟'
                      : 'What are side effects? How to use?'
                  }
                  placeholderTextColor="#94a3b8"
                  multiline
                  numberOfLines={4}
                />
              </View>

              <TouchableOpacity style={styles.submitButton} onPress={submitQuestion}>
                <Send size={20} color="#ffffff" strokeWidth={2.5} />
                <Text style={styles.submitButtonText}>{t('pharmacy.consultation.send')}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f9ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextContainer: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#06b6d4',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 24,
    paddingHorizontal: 32,
  },
  emptyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#06b6d4',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  emptyButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  consultationCard: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e0f2fe',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-end',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    marginBottom: 12,
  },
  statusAnswered: {
    fontSize: 12,
    fontWeight: '600',
    color: '#10b981',
  },
  statusPending: {
    fontSize: 12,
    fontWeight: '600',
    color: '#f59e0b',
  },
  medicineTag: {
    alignSelf: 'flex-end',
    backgroundColor: '#f0f9ff',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#bae6fd',
  },
  medicineTagText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  questionSection: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  userAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
  },
  messageContent: {
    flex: 1,
  },
  messageLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
    marginBottom: 6,
    textAlign: 'right',
  },
  questionText: {
    fontSize: 14,
    color: '#0f172a',
    lineHeight: 20,
    textAlign: 'right',
    marginBottom: 6,
  },
  dateText: {
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'right',
  },
  answerSection: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: '#f0f9ff',
    borderRadius: 16,
    padding: 12,
    borderWidth: 1,
    borderColor: '#bae6fd',
  },
  pharmacistAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#06b6d4',
    justifyContent: 'center',
    alignItems: 'center',
  },
  answerText: {
    fontSize: 14,
    color: '#0f172a',
    lineHeight: 20,
    textAlign: 'right',
    marginBottom: 6,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  form: {
    gap: 16,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#06b6d4',
    borderRadius: 16,
    paddingVertical: 16,
    marginTop: 8,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
