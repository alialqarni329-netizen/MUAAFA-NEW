import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Modal,
  TextInput,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import {
  ChevronRight,
  Plus,
  Bell,
  Clock,
  Pill,
  Trash2,
  Edit,
  X,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import DateTimePicker from '@react-native-community/datetimepicker';
import {
  requestNotificationPermissions,
  scheduleMedicationReminder,
  cancelNotification,
} from '@/lib/notifications';

interface MedicationReminder {
  id: string;
  medication_name: string;
  dosage: string;
  frequency: string;
  time_slots: string[];
  start_date: string;
  end_date: string;
  notes: string;
  is_active: boolean;
}

export default function MedicationRemindersScreen() {
  const router = useRouter();
  const [reminders, setReminders] = useState<MedicationReminder[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);

  const [formData, setFormData] = useState({
    medication_name: '',
    dosage: '',
    frequency: 'daily',
    time_slots: ['09:00'],
    start_date: new Date().toISOString().split('T')[0],
    end_date: '',
    notes: '',
  });

  useEffect(() => {
    loadReminders();
    checkPermissions();
  }, []);

  async function checkPermissions() {
    const permissions = await requestNotificationPermissions();
    if (!permissions.granted) {
      Alert.alert(
        'تنبيه',
        'يرجى السماح بالإشعارات من إعدادات الجهاز لاستخدام تنبيهات الدواء',
        [{ text: 'حسناً' }]
      );
    }
  }

  async function loadReminders() {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('medication_reminders')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setReminders(data || []);
    } catch (error) {
      console.error('Error loading reminders:', error);
      Alert.alert('خطأ', 'فشل تحميل التنبيهات');
    } finally {
      setLoading(false);
    }
  }

  async function handleAddReminder() {
    if (!formData.medication_name) {
      Alert.alert('خطأ', 'يرجى إدخال اسم الدواء');
      return;
    }

    if (!formData.dosage) {
      Alert.alert('خطأ', 'يرجى إدخال الجرعة');
      return;
    }

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not found');

      const { data: newReminder, error } = await supabase
        .from('medication_reminders')
        .insert({
          user_id: user.id,
          medication_name: formData.medication_name,
          dosage: formData.dosage,
          frequency: formData.frequency,
          time_slots: formData.time_slots,
          start_date: formData.start_date,
          end_date: formData.end_date || null,
          notes: formData.notes || null,
          is_active: true,
        })
        .select()
        .single();

      if (error) throw error;

      for (const timeSlot of formData.time_slots) {
        const [hours, minutes] = timeSlot.split(':').map(Number);
        const time = new Date();
        time.setHours(hours, minutes, 0, 0);

        await scheduleMedicationReminder(
          formData.medication_name,
          time,
          newReminder.id
        );
      }

      Alert.alert('نجح', 'تم إضافة التنبيه بنجاح');
      setShowAddModal(false);
      setFormData({
        medication_name: '',
        dosage: '',
        frequency: 'daily',
        time_slots: ['09:00'],
        start_date: new Date().toISOString().split('T')[0],
        end_date: '',
        notes: '',
      });
      loadReminders();
    } catch (error) {
      console.error('Error adding reminder:', error);
      Alert.alert('خطأ', 'فشل إضافة التنبيه');
    } finally {
      setSaving(false);
    }
  }

  async function handleDeleteReminder(id: string) {
    Alert.alert('حذف التنبيه', 'هل أنت متأكد من حذف هذا التنبيه؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'حذف',
        style: 'destructive',
        onPress: async () => {
          try {
            const { error } = await supabase
              .from('medication_reminders')
              .delete()
              .eq('id', id);

            if (error) throw error;

            Alert.alert('تم', 'تم حذف التنبيه بنجاح');
            loadReminders();
          } catch (error) {
            console.error('Error deleting reminder:', error);
            Alert.alert('خطأ', 'فشل حذف التنبيه');
          }
        },
      },
    ]);
  }

  async function toggleReminderStatus(id: string, currentStatus: boolean) {
    try {
      const { error } = await supabase
        .from('medication_reminders')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;
      loadReminders();
    } catch (error) {
      console.error('Error toggling reminder status:', error);
      Alert.alert('خطأ', 'فشل تحديث حالة التنبيه');
    }
  }

  const frequencyOptions = [
    { value: 'daily', label: 'يومياً' },
    { value: 'twice_daily', label: 'مرتين يومياً' },
    { value: 'three_times_daily', label: 'ثلاث مرات يومياً' },
    { value: 'weekly', label: 'أسبوعياً' },
  ];

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>تنبيهات الدواء</Text>
        <TouchableOpacity
          onPress={() => setShowAddModal(true)}
          style={styles.addButton}>
          <Plus size={24} color="#ffffff" strokeWidth={2} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {reminders.length === 0 ? (
          <View style={styles.emptyState}>
            <Bell size={64} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyStateTitle}>لا توجد تنبيهات</Text>
            <Text style={styles.emptyStateText}>
              أضف تنبيهاً لتذكيرك بمواعيد الأدوية
            </Text>
            <TouchableOpacity
              style={styles.addFirstButton}
              onPress={() => setShowAddModal(true)}>
              <Plus size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.addFirstButtonText}>إضافة تنبيه</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.remindersList}>
            {reminders.map((reminder) => (
              <View
                key={reminder.id}
                style={[
                  styles.reminderCard,
                  !reminder.is_active && styles.reminderCardInactive,
                ]}>
                <View style={styles.reminderHeader}>
                  <View style={styles.reminderIconContainer}>
                    <Pill size={24} color="#0ea5e9" strokeWidth={2} />
                  </View>
                  <View style={styles.reminderInfo}>
                    <Text style={styles.reminderName}>
                      {reminder.medication_name}
                    </Text>
                    <Text style={styles.reminderDosage}>{reminder.dosage}</Text>
                  </View>
                  <TouchableOpacity
                    onPress={() =>
                      toggleReminderStatus(reminder.id, reminder.is_active)
                    }
                    style={[
                      styles.statusBadge,
                      reminder.is_active
                        ? styles.statusBadgeActive
                        : styles.statusBadgeInactive,
                    ]}>
                    <Text
                      style={[
                        styles.statusBadgeText,
                        reminder.is_active
                          ? styles.statusBadgeTextActive
                          : styles.statusBadgeTextInactive,
                      ]}>
                      {reminder.is_active ? 'نشط' : 'متوقف'}
                    </Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.reminderDetails}>
                  <View style={styles.reminderDetailRow}>
                    <Clock size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.reminderDetailText}>
                      {reminder.time_slots.join(' - ')}
                    </Text>
                  </View>
                  <View style={styles.reminderDetailRow}>
                    <Bell size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.reminderDetailText}>
                      {
                        frequencyOptions.find(
                          (opt) => opt.value === reminder.frequency
                        )?.label
                      }
                    </Text>
                  </View>
                </View>

                {reminder.notes && (
                  <Text style={styles.reminderNotes}>{reminder.notes}</Text>
                )}

                <View style={styles.reminderActions}>
                  <TouchableOpacity
                    onPress={() => handleDeleteReminder(reminder.id)}
                    style={styles.deleteButton}>
                    <Trash2 size={18} color="#ef4444" strokeWidth={2} />
                    <Text style={styles.deleteButtonText}>حذف</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      <Modal
        visible={showAddModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowAddModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <X size={24} color="#64748b" strokeWidth={2} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>إضافة تنبيه دواء</Text>
              <View style={{ width: 24 }} />
            </View>

            <ScrollView style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>اسم الدواء *</Text>
                <TextInput
                  style={styles.input}
                  value={formData.medication_name}
                  onChangeText={(text) =>
                    setFormData({ ...formData, medication_name: text })
                  }
                  placeholder="مثال: باراسيتامول"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>الجرعة *</Text>
                <TextInput
                  style={styles.input}
                  value={formData.dosage}
                  onChangeText={(text) =>
                    setFormData({ ...formData, dosage: text })
                  }
                  placeholder="مثال: 500 ملغ"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>التكرار</Text>
                <View style={styles.frequencyButtons}>
                  {frequencyOptions.map((option) => (
                    <TouchableOpacity
                      key={option.value}
                      onPress={() =>
                        setFormData({ ...formData, frequency: option.value })
                      }
                      style={[
                        styles.frequencyButton,
                        formData.frequency === option.value &&
                          styles.frequencyButtonActive,
                      ]}>
                      <Text
                        style={[
                          styles.frequencyButtonText,
                          formData.frequency === option.value &&
                            styles.frequencyButtonTextActive,
                        ]}>
                        {option.label}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>الوقت</Text>
                <TextInput
                  style={styles.input}
                  value={formData.time_slots[0]}
                  onChangeText={(text) =>
                    setFormData({ ...formData, time_slots: [text] })
                  }
                  placeholder="09:00"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>ملاحظات</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={formData.notes}
                  onChangeText={(text) =>
                    setFormData({ ...formData, notes: text })
                  }
                  placeholder="ملاحظات إضافية..."
                  multiline
                  numberOfLines={3}
                  textAlign="right"
                />
              </View>

              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleAddReminder}
                disabled={saving}>
                {saving ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.saveButtonText}>إضافة التنبيه</Text>
                )}
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#0ea5e9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 40,
  },
  emptyStateTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 24,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  addFirstButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
  },
  addFirstButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  remindersList: {
    padding: 20,
  },
  reminderCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  reminderCardInactive: {
    opacity: 0.6,
  },
  reminderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  reminderIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  reminderInfo: {
    flex: 1,
  },
  reminderName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  reminderDosage: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  statusBadgeActive: {
    backgroundColor: '#dcfce7',
  },
  statusBadgeInactive: {
    backgroundColor: '#fee2e2',
  },
  statusBadgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  statusBadgeTextActive: {
    color: '#16a34a',
  },
  statusBadgeTextInactive: {
    color: '#dc2626',
  },
  reminderDetails: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 12,
  },
  reminderDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  reminderDetailText: {
    fontSize: 14,
    color: '#64748b',
  },
  reminderNotes: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
    lineHeight: 20,
    marginBottom: 12,
  },
  reminderActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#fef2f2',
  },
  deleteButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ef4444',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  modalBody: {
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  frequencyButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  frequencyButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    backgroundColor: '#ffffff',
  },
  frequencyButtonActive: {
    borderColor: '#0ea5e9',
    backgroundColor: '#e0f2fe',
  },
  frequencyButtonText: {
    fontSize: 14,
    color: '#64748b',
  },
  frequencyButtonTextActive: {
    color: '#0ea5e9',
    fontWeight: '600',
  },
  saveButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
