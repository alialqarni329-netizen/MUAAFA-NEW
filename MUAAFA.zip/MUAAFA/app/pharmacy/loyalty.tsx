import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Trophy, Star, Gift, TrendingUp, ArrowRight } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function LoyaltyPointsScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [points, setPoints] = useState(0);
  const [totalEarned, setTotalEarned] = useState(0);
  const [transactions, setTransactions] = useState<any[]>([]);

  useEffect(() => {
    loadPoints();
  }, []);

  async function loadPoints() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('loyalty_points')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (data) {
        setPoints(data.points);
        setTotalEarned(data.total_earned);
        setTransactions(data.transactions || []);
      }
    } catch (error) {
      console.error('Error loading points:', error);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerTextContainer}>
          <Text style={styles.title}>{t('pharmacy.loyaltyPoints')}</Text>
          <Text style={styles.subtitle}>{t('pharmacy.loyalty.title')}</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.pointsCard}>
          <View style={styles.pointsIconContainer}>
            <Trophy size={40} color="#f59e0b" strokeWidth={2.5} />
          </View>
          <Text style={styles.pointsLabel}>{t('pharmacy.loyalty.currentPoints')}</Text>
          <Text style={styles.pointsValue}>{points}</Text>
          <View style={styles.totalEarnedContainer}>
            <Star size={16} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.totalEarnedText}>
              {t('pharmacy.loyalty.totalEarned')}: {totalEarned}
            </Text>
          </View>
        </View>

        <View style={styles.benefitsCard}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'كيف تكسب النقاط؟' : 'How to Earn Points?'}
          </Text>

          <View style={styles.benefitItem}>
            <View style={styles.benefitIcon}>
              <Gift size={20} color="#8b5cf6" strokeWidth={2} />
            </View>
            <Text style={styles.benefitText}>{t('pharmacy.loyalty.benefits.purchase')}</Text>
          </View>

          <View style={styles.benefitItem}>
            <View style={styles.benefitIcon}>
              <TrendingUp size={20} color="#10b981" strokeWidth={2} />
            </View>
            <Text style={styles.benefitText}>{t('pharmacy.loyalty.benefits.onTime')}</Text>
          </View>

          <View style={styles.benefitItem}>
            <View style={styles.benefitIcon}>
              <Star size={20} color="#f59e0b" strokeWidth={2} />
            </View>
            <Text style={styles.benefitText}>{t('pharmacy.loyalty.benefits.discount')}</Text>
          </View>
        </View>

        {transactions.length > 0 && (
          <View style={styles.historySection}>
            <Text style={styles.sectionTitle}>{t('pharmacy.loyalty.history')}</Text>
            {transactions.slice(0, 5).map((transaction: any, index: number) => (
              <View key={index} style={styles.transactionItem}>
                <View style={styles.transactionInfo}>
                  <Text style={styles.transactionReason}>{transaction.reason}</Text>
                  <Text style={styles.transactionDate}>
                    {new Date(transaction.date).toLocaleDateString('ar-SA')}
                  </Text>
                </View>
                <Text style={styles.transactionPoints}>+{transaction.points}</Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f9ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextContainer: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  pointsCard: {
    backgroundColor: '#ffffff',
    borderRadius: 24,
    padding: 32,
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#fde68a',
    shadowColor: '#f59e0b',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  pointsIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#fef3c7',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  pointsLabel: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 8,
  },
  pointsValue: {
    fontSize: 56,
    fontWeight: 'bold',
    color: '#f59e0b',
  },
  totalEarnedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 12,
  },
  totalEarnedText: {
    fontSize: 14,
    color: '#64748b',
  },
  benefitsCard: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#e0f2fe',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  benefitIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f9ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  benefitText: {
    flex: 1,
    fontSize: 14,
    color: '#0f172a',
    textAlign: 'right',
  },
  historySection: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: '#e0f2fe',
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  transactionInfo: {
    flex: 1,
  },
  transactionReason: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  transactionDate: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  transactionPoints: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#10b981',
  },
});
