import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Zap, MapPin, Clock, Phone, Package, ArrowRight, X } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface EmergencyDelivery {
  id: string;
  pharmacy_name: string;
  status: string;
  delivery_address: string;
  estimated_time: number;
  driver_name: string | null;
  driver_phone: string | null;
  created_at: string;
}

export default function EmergencyDeliveryScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [deliveries, setDeliveries] = useState<EmergencyDelivery[]>([]);
  const [showNewModal, setShowNewModal] = useState(false);
  const [address, setAddress] = useState('');

  useEffect(() => {
    loadDeliveries();
  }, []);

  async function loadDeliveries() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('emergency_deliveries')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDeliveries(data || []);
    } catch (error) {
      console.error('Error loading deliveries:', error);
    }
  }

  async function requestDelivery() {
    if (!address.trim()) {
      alert(language === 'ar' ? 'الرجاء إدخال العنوان' : 'Please enter address');
      return;
    }

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase.from('emergency_deliveries').insert({
        user_id: user.id,
        pharmacy_name: 'صيدلية النهدي',
        delivery_address: address,
        status: 'pending',
        estimated_time: 30,
      });

      if (error) throw error;

      setShowNewModal(false);
      setAddress('');
      loadDeliveries();
    } catch (error) {
      console.error('Error requesting delivery:', error);
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'pending':
        return { bg: '#fef3c7', text: '#92400e', icon: '#f59e0b' };
      case 'assigned':
        return { bg: '#dbeafe', text: '#1e3a8a', icon: '#3b82f6' };
      case 'in_transit':
        return { bg: '#d1fae5', text: '#065f46', icon: '#10b981' };
      case 'delivered':
        return { bg: '#f3e8ff', text: '#581c87', icon: '#a855f7' };
      default:
        return { bg: '#f1f5f9', text: '#475569', icon: '#64748b' };
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerTextContainer}>
          <Text style={styles.title}>{t('pharmacy.emergencyDelivery')}</Text>
          <Text style={styles.subtitle}>{t('pharmacy.emergencyDelivery.description')}</Text>
        </View>
        <TouchableOpacity style={styles.addButton} onPress={() => setShowNewModal(true)}>
          <Zap size={24} color="#ffffff" strokeWidth={2.5} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.infoCard}>
          <Zap size={32} color="#f59e0b" strokeWidth={2} />
          <View style={styles.infoTextContainer}>
            <Text style={styles.infoTitle}>
              {language === 'ar' ? 'توصيل فائق السرعة' : 'Ultra Fast Delivery'}
            </Text>
            <Text style={styles.infoDescription}>
              {language === 'ar'
                ? 'نوصل أدويتك في 30 دقيقة أو أقل'
                : 'We deliver your medicines in 30 minutes or less'}
            </Text>
          </View>
        </View>

        {deliveries.length === 0 ? (
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIcon}>
              <Package size={48} color="#cbd5e1" strokeWidth={2} />
            </View>
            <Text style={styles.emptyTitle}>
              {language === 'ar' ? 'لا توجد طلبات توصيل' : 'No delivery orders'}
            </Text>
            <Text style={styles.emptyDescription}>
              {language === 'ar'
                ? 'اطلب توصيل عاجل لأدويتك الآن'
                : 'Request emergency delivery now'}
            </Text>
          </View>
        ) : (
          deliveries.map((delivery) => {
            const colors = getStatusColor(delivery.status);
            return (
              <View key={delivery.id} style={styles.deliveryCard}>
                <View style={styles.cardHeader}>
                  <Text style={styles.pharmacyName}>{delivery.pharmacy_name}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
                    <Text style={[styles.statusText, { color: colors.text }]}>
                      {t(`pharmacy.emergencyDelivery.status.${delivery.status}`)}
                    </Text>
                  </View>
                </View>

                <View style={styles.detailsContainer}>
                  <View style={styles.detailRow}>
                    <MapPin size={18} color={colors.icon} strokeWidth={2} />
                    <Text style={styles.detailText}>{delivery.delivery_address}</Text>
                  </View>

                  <View style={styles.detailRow}>
                    <Clock size={18} color={colors.icon} strokeWidth={2} />
                    <Text style={styles.detailText}>
                      {delivery.estimated_time} {t('pharmacy.emergencyDelivery.minutes')}
                    </Text>
                  </View>

                  {delivery.driver_name && (
                    <>
                      <View style={styles.detailRow}>
                        <Package size={18} color={colors.icon} strokeWidth={2} />
                        <Text style={styles.detailText}>{delivery.driver_name}</Text>
                      </View>

                      {delivery.driver_phone && (
                        <TouchableOpacity style={styles.callButton}>
                          <Phone size={18} color="#0ea5e9" strokeWidth={2} />
                          <Text style={styles.callButtonText}>{delivery.driver_phone}</Text>
                        </TouchableOpacity>
                      )}
                    </>
                  )}
                </View>

                {delivery.status === 'in_transit' && (
                  <TouchableOpacity style={styles.trackButton}>
                    <MapPin size={18} color="#ffffff" strokeWidth={2} />
                    <Text style={styles.trackButtonText}>
                      {t('pharmacy.emergencyDelivery.track')}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            );
          })
        )}
      </ScrollView>

      <Modal visible={showNewModal} animationType="slide" transparent>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {language === 'ar' ? 'طلب توصيل عاجل' : 'Request Emergency Delivery'}
              </Text>
              <TouchableOpacity onPress={() => setShowNewModal(false)}>
                <X size={24} color="#64748b" strokeWidth={2} />
              </TouchableOpacity>
            </View>

            <View style={styles.form}>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>{t('pharmacy.emergencyDelivery.address')} *</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={address}
                  onChangeText={setAddress}
                  placeholder={
                    language === 'ar'
                      ? 'أدخل عنوانك بالتفصيل'
                      : 'Enter your detailed address'
                  }
                  placeholderTextColor="#94a3b8"
                  multiline
                  numberOfLines={3}
                />
              </View>

              <View style={styles.estimateBox}>
                <Clock size={24} color="#f59e0b" strokeWidth={2} />
                <View>
                  <Text style={styles.estimateLabel}>
                    {t('pharmacy.emergencyDelivery.estimatedTime')}
                  </Text>
                  <Text style={styles.estimateValue}>
                    30 {t('pharmacy.emergencyDelivery.minutes')}
                  </Text>
                </View>
              </View>

              <TouchableOpacity style={styles.submitButton} onPress={requestDelivery}>
                <Zap size={20} color="#ffffff" strokeWidth={2.5} />
                <Text style={styles.submitButtonText}>
                  {language === 'ar' ? 'تأكيد الطلب' : 'Confirm Order'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f9ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextContainer: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f59e0b',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#fef3c7',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#fde68a',
  },
  infoTextContainer: {
    flex: 1,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#92400e',
    marginBottom: 4,
    textAlign: 'right',
  },
  infoDescription: {
    fontSize: 14,
    color: '#b45309',
    textAlign: 'right',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  deliveryCard: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e0f2fe',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  pharmacyName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  detailsContainer: {
    gap: 12,
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  detailText: {
    flex: 1,
    fontSize: 14,
    color: '#0f172a',
    textAlign: 'right',
  },
  callButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#e0f2fe',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  callButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  trackButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#10b981',
    borderRadius: 12,
    paddingVertical: 14,
  },
  trackButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    maxHeight: '70%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  form: {
    gap: 16,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  estimateBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#fef3c7',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#fde68a',
  },
  estimateLabel: {
    fontSize: 12,
    color: '#92400e',
    marginBottom: 4,
    textAlign: 'right',
  },
  estimateValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#f59e0b',
    textAlign: 'right',
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#f59e0b',
    borderRadius: 16,
    paddingVertical: 16,
    marginTop: 8,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
