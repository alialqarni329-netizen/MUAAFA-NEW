import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'expo-router';
import { Bot, Send, TriangleAlert as AlertTriangle, ShoppingCart, ArrowRight, Stethoscope, Pill, FileText, Activity } from 'lucide-react-native';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { useChat } from '@/lib/ChatContext';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  status?: 'sending' | 'sent' | 'failed';
  analysis?: {
    severity_level: string;
    suggested_action?: string;
    critical_warning?: string;
    medications_mentioned?: Array<{
      name: string;
      medication_id?: string;
      add_to_cart: boolean;
    }>;
    drug_interactions?: Array<{
      medicines: string[];
      severity: string;
      description: string;
    }>;
    app_features_mentioned?: string[];
  };
}

export default function SmartDoctorScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const { messages, loading, isSending, initializeChat, sendMessage: chatSendMessage } = useChat();
  const [inputText, setInputText] = useState('');
  const scrollViewRef = useRef<ScrollView>(null);

  useEffect(() => {
    console.log('[SMART_DOCTOR] MOUNT');
    return () => console.log('[SMART_DOCTOR] UNMOUNT');
  }, []);

  useEffect(() => {
    initializeChat(language);
  }, []);

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages]);

  async function handleSendMessage() {
    const text = inputText.trim();
    if (!text || isSending) return;

    setInputText('');
    await chatSendMessage(text, language);
  }

  function addMedicationToCart(medicationId: string, medicationName: string) {
    router.push('/pharmacy');
  }

  function navigateToFeature(feature: string) {
    const routes: Record<string, string> = {
      pharmacy: '/pharmacy',
      prescription_scanner: '/pharmacy/scan-prescription',
      drug_interactions: '/pharmacy/interactions',
      virtual_sessions: '/telehealth/book-appointment',
      fitness: '/fitness',
    };

    const route = routes[feature];
    if (route) {
      router.push(route as any);
    }
  }

  function getSeverityColor(severity: string) {
    switch (severity) {
      case 'emergency':
        return '#dc2626';
      case 'severe':
        return '#ea580c';
      case 'moderate':
        return '#f59e0b';
      case 'mild':
        return '#10b981';
      default:
        return '#64748b';
    }
  }

  function getMessageStatusIcon(status?: string) {
    if (status === 'sending') {
      return <ActivityIndicator size="small" color="#0ea5e9" />;
    }
    if (status === 'failed') {
      return <AlertTriangle size={16} color="#ef4444" strokeWidth={2} />;
    }
    return null;
  }

  if (loading && messages.length === 0) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>
          {language === 'ar' ? 'جاري تحميل الطبيب الذكي...' : 'Loading Smart Doctor...'}
        </Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#ffffff" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <View style={styles.headerIcon}>
            <Bot size={28} color="#ffffff" strokeWidth={2} />
          </View>
          <View style={styles.headerText}>
            <Text style={styles.headerTitle}>
              {language === 'ar' ? 'الطبيب الذكي' : 'Smart Doctor'}
            </Text>
            <Text style={styles.headerSubtitle}>
              {language === 'ar' ? 'مساعدك الطبي الذكي' : 'Your AI Medical Assistant'}
            </Text>
          </View>
        </View>
        <View style={styles.statusIndicator}>
          <View style={styles.statusDot} />
          <Text style={styles.statusText}>{language === 'ar' ? 'متصل' : 'Online'}</Text>
        </View>
      </View>

      <ScrollView
        ref={scrollViewRef}
        style={styles.messagesContainer}
        contentContainerStyle={styles.messagesContent}
        onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })}>
        {messages.map((message) => (
          <View key={message.id}>
            <View
              style={[
                styles.messageBubble,
                message.role === 'user' ? styles.userBubble : styles.assistantBubble,
              ]}>
              {message.role === 'assistant' && (
                <View style={styles.botAvatar}>
                  <Stethoscope size={16} color="#ffffff" strokeWidth={2} />
                </View>
              )}
              <View
                style={[
                  styles.messageContent,
                  message.role === 'user' ? styles.userContent : styles.assistantContent,
                  message.status === 'failed' && styles.failedMessage,
                ]}>
                <Text
                  style={[
                    styles.messageText,
                    message.role === 'user' ? styles.userText : styles.assistantText,
                  ]}>
                  {message.content}
                </Text>
                {message.role === 'user' && message.status && (
                  <View style={styles.statusIcon}>
                    {getMessageStatusIcon(message.status)}
                  </View>
                )}
              </View>
            </View>

            {message.analysis?.critical_warning && (
              <View style={styles.criticalWarning}>
                <AlertTriangle size={24} color="#dc2626" strokeWidth={2.5} />
                <Text style={styles.criticalWarningText}>{message.analysis.critical_warning}</Text>
              </View>
            )}

            {message.analysis?.drug_interactions &&
              message.analysis.drug_interactions.length > 0 && (
                <View style={styles.interactionsCard}>
                  <View style={styles.interactionsHeader}>
                    <AlertTriangle size={20} color="#dc2626" strokeWidth={2} />
                    <Text style={styles.interactionsTitle}>
                      {language === 'ar' ? 'تفاعلات دوائية خطيرة!' : 'Dangerous Drug Interactions!'}
                    </Text>
                  </View>
                  {message.analysis.drug_interactions.map((interaction, idx) => (
                    <View key={idx} style={styles.interactionItem}>
                      <Text style={styles.interactionMeds}>{interaction.medicines.join(' + ')}</Text>
                      <Text style={styles.interactionDesc}>{interaction.description}</Text>
                    </View>
                  ))}
                  <TouchableOpacity
                    style={styles.interactionButton}
                    onPress={() => navigateToFeature('drug_interactions')}>
                    <Text style={styles.interactionButtonText}>
                      {language === 'ar' ? 'فحص كامل للتفاعلات' : 'Full Interaction Check'}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}

            {message.analysis?.medications_mentioned &&
              message.analysis.medications_mentioned.length > 0 && (
                <View style={styles.medicationsCard}>
                  <Text style={styles.medicationsTitle}>
                    {language === 'ar' ? '💊 أدوية مذكورة' : '💊 Mentioned Medications'}
                  </Text>
                  {message.analysis.medications_mentioned.map((med, idx) => (
                    <TouchableOpacity
                      key={idx}
                      style={styles.medicationItem}
                      onPress={() =>
                        med.medication_id && addMedicationToCart(med.medication_id, med.name)
                      }>
                      <View style={styles.medicationInfo}>
                        <Pill size={20} color="#0ea5e9" strokeWidth={2} />
                        <Text style={styles.medicationName}>{med.name}</Text>
                      </View>
                      <View style={styles.addToCartButton}>
                        <ShoppingCart size={16} color="#ffffff" strokeWidth={2} />
                        <Text style={styles.addToCartText}>
                          {language === 'ar' ? 'إضافة' : 'Add'}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  ))}
                </View>
              )}

            {message.analysis?.suggested_action && (
              <View
                style={[
                  styles.actionCard,
                  {
                    borderLeftColor: getSeverityColor(
                      message.analysis.severity_level || 'none'
                    ),
                  },
                ]}>
                <Text style={styles.actionLabel}>
                  {language === 'ar' ? '📋 الإجراء الموصى به:' : '📋 Recommended Action:'}
                </Text>
                <Text style={styles.actionText}>{message.analysis.suggested_action}</Text>

                {(message.analysis.severity_level === 'severe' || message.analysis.severity_level === 'emergency') && (
                  <TouchableOpacity
                    style={styles.urgentButton}
                    onPress={() => navigateToFeature('virtual_sessions')}>
                    <Activity size={18} color="#ffffff" strokeWidth={2} />
                    <Text style={styles.urgentButtonText}>
                      {language === 'ar' ? 'احجز جلسة فوراً' : 'Book Session Now'}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            )}

            {message.analysis?.app_features_mentioned &&
              message.analysis.app_features_mentioned.length > 0 && (
                <View style={styles.featuresCard}>
                  {message.analysis.app_features_mentioned.map((feature, idx) => {
                    const featureNames: Record<string, { ar: string; en: string }> = {
                      pharmacy: { ar: '🏪 الصيدلية', en: '🏪 Pharmacy' },
                      prescription_scanner: {
                        ar: '📷 مسح الوصفة',
                        en: '📷 Scan Prescription',
                      },
                      drug_interactions: {
                        ar: '⚠️ فحص التفاعلات',
                        en: '⚠️ Check Interactions',
                      },
                      virtual_sessions: {
                        ar: '👨‍⚕️ جلسة طبية',
                        en: '👨‍⚕️ Virtual Session',
                      },
                      fitness: { ar: '🏃 اللياقة', en: '🏃 Fitness' },
                    };

                    const featureName = featureNames[feature];
                    if (!featureName) return null;

                    return (
                      <TouchableOpacity
                        key={idx}
                        style={styles.featureChip}
                        onPress={() => navigateToFeature(feature)}>
                        <Text style={styles.featureChipText}>
                          {language === 'ar' ? featureName.ar : featureName.en}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}
          </View>
        ))}

        {isSending && (
          <View style={styles.loadingBubble}>
            <View style={styles.botAvatar}>
              <Stethoscope size={16} color="#ffffff" strokeWidth={2} />
            </View>
            <View style={styles.typingIndicator}>
              <View style={styles.typingDot} />
              <View style={styles.typingDot} />
              <View style={styles.typingDot} />
            </View>
          </View>
        )}
      </ScrollView>

      <View style={styles.inputContainer}>
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={styles.quickActionChip}
            onPress={() => setInputText(language === 'ar' ? 'أعاني من صداع' : 'I have a headache')}>
            <Text style={styles.quickActionText}>
              {language === 'ar' ? 'صداع' : 'Headache'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.quickActionChip}
            onPress={() =>
              setInputText(
                language === 'ar'
                  ? 'فحص التفاعلات: أسبرين ووارفارين'
                  : 'Check interaction: Aspirin and Warfarin'
              )
            }>
            <Text style={styles.quickActionText}>
              {language === 'ar' ? 'فحص تفاعلات' : 'Check Interactions'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.quickActionChip}
            onPress={() => navigateToFeature('prescription_scanner')}>
            <FileText size={14} color="#64748b" strokeWidth={2} />
            <Text style={styles.quickActionText}>
              {language === 'ar' ? 'رفع وصفة' : 'Upload Rx'}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.inputRow}>
          <TextInput
            style={styles.input}
            value={inputText}
            onChangeText={setInputText}
            placeholder={
              language === 'ar' ? 'اسأل الطبيب الذكي...' : 'Ask the Smart Doctor...'
            }
            placeholderTextColor="#94a3b8"
            multiline
            maxLength={500}
            textAlign={language === 'ar' ? 'right' : 'left'}
            editable={!isSending}
          />
          <TouchableOpacity
            style={[styles.sendButton, (!inputText.trim() || isSending) && styles.sendButtonDisabled]}
            onPress={handleSendMessage}
            disabled={!inputText.trim() || isSending}>
            {isSending ? (
              <ActivityIndicator size="small" color="#ffffff" />
            ) : (
              <Send size={20} color="#ffffff" strokeWidth={2} />
            )}
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
    fontWeight: '500',
  },
  header: {
    backgroundColor: '#0ea5e9',
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'right',
  },
  headerSubtitle: {
    fontSize: 13,
    color: 'rgba(255, 255, 255, 0.9)',
    textAlign: 'right',
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10b981',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
    gap: 16,
  },
  messageBubble: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 8,
  },
  userBubble: {
    justifyContent: 'flex-end',
  },
  assistantBubble: {
    justifyContent: 'flex-start',
  },
  botAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#0ea5e9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  messageContent: {
    maxWidth: '75%',
    borderRadius: 20,
    padding: 14,
  },
  userContent: {
    backgroundColor: '#0ea5e9',
    borderBottomRightRadius: 4,
  },
  assistantContent: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderBottomLeftRadius: 4,
  },
  failedMessage: {
    backgroundColor: '#fee2e2',
    borderColor: '#fca5a5',
  },
  messageText: {
    fontSize: 15,
    lineHeight: 22,
  },
  userText: {
    color: '#ffffff',
    textAlign: 'right',
  },
  assistantText: {
    color: '#0f172a',
    textAlign: 'right',
  },
  statusIcon: {
    position: 'absolute',
    bottom: 4,
    left: 4,
  },
  retryButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ef4444',
  },
  criticalWarning: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#fee2e2',
    borderLeftWidth: 4,
    borderLeftColor: '#dc2626',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  criticalWarningText: {
    flex: 1,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#991b1b',
    lineHeight: 22,
    textAlign: 'right',
  },
  interactionsCard: {
    backgroundColor: '#fef2f2',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#fca5a5',
    padding: 16,
    marginBottom: 12,
  },
  interactionsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  interactionsTitle: {
    flex: 1,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#dc2626',
    textAlign: 'right',
  },
  interactionItem: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  interactionMeds: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#991b1b',
    marginBottom: 6,
    textAlign: 'right',
  },
  interactionDesc: {
    fontSize: 14,
    color: '#7f1d1d',
    lineHeight: 20,
    textAlign: 'right',
  },
  interactionButton: {
    backgroundColor: '#dc2626',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  interactionButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  medicationsCard: {
    backgroundColor: '#f0f9ff',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#bae6fd',
    padding: 16,
    marginBottom: 12,
  },
  medicationsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0c4a6e',
    marginBottom: 12,
    textAlign: 'right',
  },
  medicationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  medicationInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  medicationName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0f172a',
  },
  addToCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 10,
  },
  addToCartText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  actionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    borderLeftWidth: 4,
    padding: 16,
    marginBottom: 12,
  },
  actionLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#64748b',
    marginBottom: 8,
    textAlign: 'right',
  },
  actionText: {
    fontSize: 15,
    color: '#0f172a',
    lineHeight: 22,
    marginBottom: 12,
    textAlign: 'right',
  },
  urgentButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#ea580c',
    borderRadius: 12,
    paddingVertical: 12,
  },
  urgentButtonText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  featuresCard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
    justifyContent: 'flex-end',
  },
  featureChip: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  featureChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  loadingBubble: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  typingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#ffffff',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    paddingHorizontal: 18,
    paddingVertical: 14,
  },
  typingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#cbd5e1',
  },
  inputContainer: {
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: Platform.OS === 'ios' ? 34 : 16,
  },
  quickActions: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
    justifyContent: 'flex-end',
  },
  quickActionChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#f1f5f9',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  quickActionText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 12,
  },
  input: {
    flex: 1,
    backgroundColor: '#f8fafc',
    borderRadius: 24,
    paddingHorizontal: 18,
    paddingVertical: 12,
    fontSize: 15,
    color: '#0f172a',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    maxHeight: 100,
  },
  sendButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#0ea5e9',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  sendButtonDisabled: {
    backgroundColor: '#cbd5e1',
    shadowOpacity: 0,
    elevation: 0,
  },
});
