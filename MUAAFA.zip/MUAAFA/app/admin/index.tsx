import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import {
  Users,
  Calendar,
  TrendingUp,
  Settings,
  Shield,
  Video,
  ArrowRight,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { checkIsAdmin, getUsersStats, getRecentActivity, AdminUser } from '@/lib/admin';

interface Stats {
  totalUsers: number;
  activeSubscriptions: number;
  completedSessions: number;
  totalRecordings: number;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    activeSubscriptions: 0,
    completedSessions: 0,
    totalRecordings: 0,
  });
  const [recentActivity, setRecentActivity] = useState<any>({
    recentUsers: [],
    recentSessions: [],
  });

  useEffect(() => {
    checkAdminAccess();
  }, []);

  async function checkAdminAccess() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.replace('/auth/login');
      return;
    }

    const admin = await checkIsAdmin(user.id);

    if (!admin) {
      router.replace('/');
      return;
    }

    setAdminUser(admin);
    await loadData();
  }

  async function loadData() {
    setLoading(true);
    const statsData = await getUsersStats();
    const activityData = await getRecentActivity(5);

    setStats(statsData);
    setRecentActivity(activityData);
    setLoading(false);
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>لوحة التحكم</Text>
          <Text style={styles.subtitle}>مرحباً بك في لوحة الإدارة</Text>
        </View>
        <View style={styles.badge}>
          <Shield size={16} color="#ffffff" strokeWidth={2} />
          <Text style={styles.badgeText}>{adminUser?.role || 'Admin'}</Text>
        </View>
      </View>

      <View style={styles.statsGrid}>
        <View style={[styles.statCard, { backgroundColor: '#eff6ff' }]}>
          <View style={[styles.statIcon, { backgroundColor: '#3b82f6' }]}>
            <Users size={24} color="#ffffff" strokeWidth={2} />
          </View>
          <Text style={styles.statValue}>{stats.totalUsers}</Text>
          <Text style={styles.statLabel}>إجمالي المستخدمين</Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#f0fdf4' }]}>
          <View style={[styles.statIcon, { backgroundColor: '#22c55e' }]}>
            <TrendingUp size={24} color="#ffffff" strokeWidth={2} />
          </View>
          <Text style={styles.statValue}>{stats.activeSubscriptions}</Text>
          <Text style={styles.statLabel}>الاشتراكات النشطة</Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
          <View style={[styles.statIcon, { backgroundColor: '#f59e0b' }]}>
            <Calendar size={24} color="#ffffff" strokeWidth={2} />
          </View>
          <Text style={styles.statValue}>{stats.completedSessions}</Text>
          <Text style={styles.statLabel}>الجلسات المكتملة</Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#fce7f3' }]}>
          <View style={[styles.statIcon, { backgroundColor: '#ec4899' }]}>
            <Video size={24} color="#ffffff" strokeWidth={2} />
          </View>
          <Text style={styles.statValue}>{stats.totalRecordings}</Text>
          <Text style={styles.statLabel}>التسجيلات</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الإدارة السريعة</Text>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/admin/users')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#dbeafe' }]}>
              <Users size={20} color="#3b82f6" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>إدارة المستخدمين</Text>
              <Text style={styles.menuItemSubtitle}>
                عرض وإدارة جميع المستخدمين
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/admin/sessions')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#fef3c7' }]}>
              <Calendar size={20} color="#f59e0b" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>إدارة الجلسات</Text>
              <Text style={styles.menuItemSubtitle}>
                عرض وإدارة جميع الجلسات
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/admin/settings')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#f3e8ff' }]}>
              <Settings size={20} color="#a855f7" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>الإعدادات</Text>
              <Text style={styles.menuItemSubtitle}>
                إعدادات النظام والتطبيق
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>
      </View>

      {recentActivity.recentUsers.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>المستخدمين الجدد</Text>
          <View style={styles.activityList}>
            {recentActivity.recentUsers.slice(0, 5).map((user: any, index: number) => (
              <View key={index} style={styles.activityItem}>
                <View style={styles.activityIcon}>
                  <Users size={16} color="#64748b" strokeWidth={2} />
                </View>
                <View style={styles.activityContent}>
                  <Text style={styles.activityText}>{user.full_name}</Text>
                  <Text style={styles.activityTime}>
                    {new Date(user.created_at).toLocaleDateString('ar')}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        </View>
      )}

      <TouchableOpacity
        style={styles.backButton}
        onPress={() => router.back()}
      >
        <Text style={styles.backButtonText}>العودة للتطبيق</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
    paddingTop: 60,
    paddingBottom: 40,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'right',
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  badgeText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'capitalize',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    padding: 16,
    borderRadius: 16,
    alignItems: 'center',
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'center',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  menuItem: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuItemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  menuItemSubtitle: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  activityList: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 12,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  activityIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activityContent: {
    flex: 1,
  },
  activityText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#0f172a',
    textAlign: 'right',
  },
  activityTime: {
    fontSize: 12,
    color: '#94a3b8',
    marginTop: 2,
    textAlign: 'right',
  },
  backButton: {
    backgroundColor: '#e2e8f0',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#475569',
  },
});
