import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { ArrowLeft, Calendar, Clock, User, Video } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { checkIsAdmin, getAllSessions } from '@/lib/admin';

interface SessionData {
  id: string;
  user_id: string;
  scheduled_date: string;
  scheduled_time: string;
  status: string;
  notes?: string;
  created_at: string;
  users?: {
    full_name: string;
  };
}

export default function SessionsManagement() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [sessions, setSessions] = useState<SessionData[]>([]);
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    checkAccess();
  }, []);

  async function checkAccess() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.replace('/auth/login');
      return;
    }

    const admin = await checkIsAdmin(user.id);

    if (!admin) {
      router.replace('/');
      return;
    }

    await loadSessions();
  }

  async function loadSessions() {
    setLoading(true);
    const { sessions: sessionsData, total: totalCount } = await getAllSessions(page);
    setSessions(sessionsData as SessionData[]);
    setTotal(totalCount);
    setLoading(false);
  }

  async function onRefresh() {
    setRefreshing(true);
    setPage(0);
    await loadSessions();
    setRefreshing(false);
  }

  function getStatusInfo(status: string) {
    switch (status) {
      case 'scheduled':
        return { text: 'مجدولة', color: '#3b82f6', bgColor: '#dbeafe' };
      case 'completed':
        return { text: 'مكتملة', color: '#22c55e', bgColor: '#dcfce7' };
      case 'cancelled':
        return { text: 'ملغاة', color: '#ef4444', bgColor: '#fee2e2' };
      case 'in_progress':
        return { text: 'جارية', color: '#f59e0b', bgColor: '#fef3c7' };
      default:
        return { text: status, color: '#64748b', bgColor: '#f1f5f9' };
    }
  }

  function renderSessionItem({ item }: { item: SessionData }) {
    const statusInfo = getStatusInfo(item.status);

    return (
      <View style={styles.sessionCard}>
        <View style={styles.sessionHeader}>
          <View style={[styles.statusBadge, { backgroundColor: statusInfo.bgColor }]}>
            <Text style={[styles.statusText, { color: statusInfo.color }]}>
              {statusInfo.text}
            </Text>
          </View>
          <Text style={styles.sessionId}>#{item.id.slice(0, 8)}</Text>
        </View>

        <View style={styles.sessionContent}>
          <View style={styles.infoRow}>
            <User size={16} color="#64748b" strokeWidth={2} />
            <Text style={styles.infoText}>
              {item.users?.full_name || 'مستخدم غير معروف'}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Calendar size={16} color="#64748b" strokeWidth={2} />
            <Text style={styles.infoText}>
              {new Date(item.scheduled_date).toLocaleDateString('ar')}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Clock size={16} color="#64748b" strokeWidth={2} />
            <Text style={styles.infoText}>{item.scheduled_time}</Text>
          </View>

          {item.notes && (
            <View style={styles.notesContainer}>
              <Text style={styles.notesLabel}>ملاحظات:</Text>
              <Text style={styles.notesText}>{item.notes}</Text>
            </View>
          )}

          <View style={styles.sessionFooter}>
            <Text style={styles.createdText}>
              تم الإنشاء: {new Date(item.created_at).toLocaleDateString('ar')}
            </Text>
          </View>
        </View>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ArrowLeft size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.title}>إدارة الجلسات</Text>
          <Text style={styles.subtitle}>{total} جلسة</Text>
        </View>
      </View>

      <FlatList
        data={sessions}
        renderItem={renderSessionItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Calendar size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا توجد جلسات</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 50,
    paddingBottom: 16,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
    gap: 12,
  },
  backButton: {
    padding: 8,
  },
  headerContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 2,
  },
  listContent: {
    padding: 16,
  },
  sessionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
    overflow: 'hidden',
  },
  sessionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f8fafc',
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  sessionId: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
    fontFamily: 'monospace',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  sessionContent: {
    padding: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#0f172a',
  },
  notesContainer: {
    marginTop: 12,
    padding: 12,
    backgroundColor: '#f8fafc',
    borderRadius: 8,
  },
  notesLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  notesText: {
    fontSize: 14,
    color: '#0f172a',
    textAlign: 'right',
    lineHeight: 20,
  },
  sessionFooter: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  createdText: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 12,
  },
});
