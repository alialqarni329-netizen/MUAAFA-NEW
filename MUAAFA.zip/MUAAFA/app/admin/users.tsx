import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  TextInput,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Search, ArrowLeft, User, Mail, Phone, MapPin } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { checkIsAdmin, getAllUsers } from '@/lib/admin';

interface UserData {
  id: string;
  full_name: string;
  phone: string;
  email?: string;
  location: string;
  gender: string;
  created_at: string;
  subscriptions: any[];
}

export default function UsersManagement() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [users, setUsers] = useState<UserData[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<UserData[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    checkAccess();
  }, []);

  useEffect(() => {
    if (searchQuery) {
      const filtered = users.filter(
        (user) =>
          user.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.phone.includes(searchQuery) ||
          user.location.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchQuery, users]);

  async function checkAccess() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.replace('/auth/login');
      return;
    }

    const admin = await checkIsAdmin(user.id);

    if (!admin) {
      router.replace('/');
      return;
    }

    await loadUsers();
  }

  async function loadUsers() {
    setLoading(true);
    const { users: userData, total: totalCount } = await getAllUsers(page);
    setUsers(userData as UserData[]);
    setFilteredUsers(userData as UserData[]);
    setTotal(totalCount);
    setLoading(false);
  }

  async function onRefresh() {
    setRefreshing(true);
    setPage(0);
    await loadUsers();
    setRefreshing(false);
  }

  function getSubscriptionStatus(user: UserData) {
    if (!user.subscriptions || user.subscriptions.length === 0) {
      return { text: 'بدون اشتراك', color: '#ef4444' };
    }

    const activeSub = user.subscriptions.find((sub) => sub.status === 'active');

    if (activeSub) {
      if (activeSub.plan_type === 'trial') {
        return { text: 'تجريبي', color: '#f59e0b' };
      }
      return { text: 'نشط', color: '#22c55e' };
    }

    return { text: 'منتهي', color: '#94a3b8' };
  }

  function renderUserItem({ item }: { item: UserData }) {
    const subStatus = getSubscriptionStatus(item);

    return (
      <View style={styles.userCard}>
        <View style={styles.userHeader}>
          <View style={styles.userAvatar}>
            <User size={24} color="#64748b" strokeWidth={2} />
          </View>
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{item.full_name}</Text>
            <View style={[styles.statusBadge, { backgroundColor: `${subStatus.color}20` }]}>
              <Text style={[styles.statusText, { color: subStatus.color }]}>
                {subStatus.text}
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.userDetails}>
          <View style={styles.detailRow}>
            <Phone size={14} color="#64748b" strokeWidth={2} />
            <Text style={styles.detailText}>{item.phone}</Text>
          </View>

          <View style={styles.detailRow}>
            <MapPin size={14} color="#64748b" strokeWidth={2} />
            <Text style={styles.detailText}>{item.location}</Text>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>الجنس:</Text>
            <Text style={styles.detailText}>
              {item.gender === 'male' ? 'ذكر' : 'أنثى'}
            </Text>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>تاريخ التسجيل:</Text>
            <Text style={styles.detailText}>
              {new Date(item.created_at).toLocaleDateString('ar')}
            </Text>
          </View>
        </View>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.title}>إدارة المستخدمين</Text>
          <Text style={styles.subtitle}>{total} مستخدم</Text>
        </View>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#64748b" strokeWidth={2} />
        <TextInput
          style={styles.searchInput}
          placeholder="البحث بالاسم، الجوال، أو المدينة..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          textAlign="right"
        />
      </View>

      <FlatList
        data={filteredUsers}
        renderItem={renderUserItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <User size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا يوجد مستخدمين</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 50,
    paddingBottom: 16,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
    gap: 12,
  },
  backButton: {
    padding: 8,
  },
  headerContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 2,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    margin: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  userCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  userAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  userInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  userDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
  },
  detailLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  detailText: {
    fontSize: 14,
    color: '#0f172a',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 12,
  },
});
