import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator, Linking } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Calendar, Clock, DollarSign, Shield, CreditCard } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { getUserActiveInsurance, createMedicalSession, formatCurrency, calculatePayment, generatePaymentUrl } from '@/lib/payment-utils';

export default function BookMedicalSessionScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [checkingInsurance, setCheckingInsurance] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    doctorName: '',
    specialty: '',
    sessionDate: '',
    notes: '',
  });

  const [price] = useState(200);
  const [insurance, setInsurance] = useState<any>(null);
  const [paymentDetails, setPaymentDetails] = useState({
    insuranceCovered: 0,
    userPayable: 200,
  });

  useEffect(() => {
    loadUserAndInsurance();
  }, []);

  useEffect(() => {
    if (insurance) {
      const calculation = calculatePayment(price, insurance.coverage_percentage);
      setPaymentDetails(calculation);
    } else {
      setPaymentDetails({ insuranceCovered: 0, userPayable: price });
    }
  }, [insurance, price]);

  async function loadUserAndInsurance() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً');
        router.back();
        return;
      }

      setUserId(user.id);
      const insurancePolicy = await getUserActiveInsurance(user.id);
      setInsurance(insurancePolicy);
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setCheckingInsurance(false);
    }
  }

  async function handleBookSession() {
    if (!formData.doctorName || !formData.specialty || !formData.sessionDate) {
      Alert.alert('خطأ', 'يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    if (!userId) {
      Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً');
      return;
    }

    setLoading(true);

    try {
      const sessionDate = new Date(formData.sessionDate);

      const session = await createMedicalSession(
        userId,
        formData.doctorName,
        formData.specialty,
        sessionDate,
        price,
        insurance?.id
      );

      Alert.alert(
        'تم إنشاء الحجز',
        `المبلغ المطلوب: ${formatCurrency(paymentDetails.userPayable)}\n\nسيتم تحويلك لبوابة الدفع`,
        [
          {
            text: 'إلغاء',
            style: 'cancel',
            onPress: () => setLoading(false),
          },
          {
            text: 'الدفع الآن',
            onPress: () => proceedToPayment(session.id),
          },
        ]
      );
    } catch (error: any) {
      setLoading(false);
      console.error('Error creating session:', error);
      Alert.alert('خطأ', error.message || 'حدث خطأ أثناء إنشاء الحجز');
    }
  }

  function proceedToPayment(sessionId: string) {
    const paymentUrl = generatePaymentUrl(sessionId, paymentDetails.userPayable, 'medical_session');

    Linking.openURL(paymentUrl).catch((err) => {
      console.error('Error opening payment URL:', err);
      Alert.alert('خطأ', 'لا يمكن فتح بوابة الدفع');
      setLoading(false);
    });
  }

  if (checkingInsurance) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6366f1" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>حجز جلسة طبية</Text>
        <Text style={styles.subtitle}>احجز موعدك مع الطبيب</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {insurance && (
          <View style={styles.insuranceCard}>
            <View style={styles.insuranceHeader}>
              <Shield size={24} color="#10b981" strokeWidth={2} />
              <Text style={styles.insuranceTitle}>لديك تأمين فعّال</Text>
            </View>
            <View style={styles.insuranceDetails}>
              <View style={styles.insuranceRow}>
                <Text style={styles.insuranceLabel}>شركة التأمين:</Text>
                <Text style={styles.insuranceValue}>{insurance.provider_name}</Text>
              </View>
              <View style={styles.insuranceRow}>
                <Text style={styles.insuranceLabel}>نسبة التغطية:</Text>
                <Text style={styles.insuranceValue}>{insurance.coverage_percentage}%</Text>
              </View>
              <View style={styles.insuranceRow}>
                <Text style={styles.insuranceLabel}>ساري حتى:</Text>
                <Text style={styles.insuranceValue}>{new Date(insurance.end_date).toLocaleDateString('ar-SA')}</Text>
              </View>
            </View>
          </View>
        )}

        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>اسم الطبيب *</Text>
            <TextInput
              style={styles.input}
              placeholder="د. محمد أحمد"
              value={formData.doctorName}
              onChangeText={(text) => setFormData({ ...formData, doctorName: text })}
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>التخصص *</Text>
            <TextInput
              style={styles.input}
              placeholder="طب عام، قلب، عظام، ..."
              value={formData.specialty}
              onChangeText={(text) => setFormData({ ...formData, specialty: text })}
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>تاريخ الجلسة *</Text>
            <View style={styles.inputWithIcon}>
              <Calendar size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={[styles.input, styles.inputWithIconText]}
                placeholder="YYYY-MM-DD HH:MM"
                value={formData.sessionDate}
                onChangeText={(text) => setFormData({ ...formData, sessionDate: text })}
                textAlign="right"
              />
            </View>
            <Text style={styles.helpText}>مثال: 2025-01-15 10:00</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>ملاحظات (اختياري)</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="أي ملاحظات إضافية..."
              value={formData.notes}
              onChangeText={(text) => setFormData({ ...formData, notes: text })}
              textAlign="right"
              multiline
              numberOfLines={4}
            />
          </View>
        </View>

        <View style={styles.priceCard}>
          <View style={styles.priceHeader}>
            <DollarSign size={24} color="#6366f1" strokeWidth={2} />
            <Text style={styles.priceTitle}>تفاصيل الدفع</Text>
          </View>

          <View style={styles.priceDetails}>
            <View style={styles.priceRow}>
              <Text style={styles.priceValue}>{formatCurrency(price)}</Text>
              <Text style={styles.priceLabel}>سعر الجلسة:</Text>
            </View>

            {insurance && paymentDetails.insuranceCovered > 0 && (
              <>
                <View style={[styles.priceRow, styles.discountRow]}>
                  <Text style={styles.discountValue}>- {formatCurrency(paymentDetails.insuranceCovered)}</Text>
                  <Text style={styles.priceLabel}>التغطية التأمينية:</Text>
                </View>
                <View style={styles.divider} />
              </>
            )}

            <View style={[styles.priceRow, styles.totalRow]}>
              <Text style={styles.totalValue}>{formatCurrency(paymentDetails.userPayable)}</Text>
              <Text style={styles.totalLabel}>المبلغ المطلوب:</Text>
            </View>
          </View>

          <View style={styles.warningBox}>
            <Text style={styles.warningText}>
              ⚠️ يجب إتمام الدفع لتأكيد الحجز
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={[styles.bookButton, loading && styles.bookButtonDisabled]}
          onPress={handleBookSession}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <>
              <CreditCard size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.bookButtonText}>متابعة للدفع</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  insuranceCard: {
    backgroundColor: '#ecfdf5',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#10b981',
  },
  insuranceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  insuranceTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#065f46',
  },
  insuranceDetails: {
    gap: 8,
  },
  insuranceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  insuranceLabel: {
    fontSize: 14,
    color: '#047857',
  },
  insuranceValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#065f46',
  },
  form: {
    gap: 16,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    padding: 16,
    fontSize: 16,
    color: '#0f172a',
  },
  inputWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    paddingHorizontal: 16,
  },
  inputWithIconText: {
    flex: 1,
    borderWidth: 0,
    padding: 16,
    paddingRight: 0,
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  helpText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  priceCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  priceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  priceTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  priceDetails: {
    gap: 12,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  priceValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  discountRow: {
    paddingVertical: 4,
  },
  discountValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10b981',
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 8,
  },
  totalRow: {
    paddingTop: 8,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  totalValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#6366f1',
  },
  warningBox: {
    backgroundColor: '#fef3c7',
    borderRadius: 8,
    padding: 12,
    marginTop: 16,
  },
  warningText: {
    fontSize: 13,
    color: '#92400e',
    textAlign: 'center',
    fontWeight: '600',
  },
  bookButton: {
    backgroundColor: '#6366f1',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 8,
  },
  bookButtonDisabled: {
    opacity: 0.6,
  },
  bookButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
