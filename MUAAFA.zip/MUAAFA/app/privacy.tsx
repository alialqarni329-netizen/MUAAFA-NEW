import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Stack } from 'expo-router';
import { Shield } from 'lucide-react-native';

export default function PrivacyScreen() {
  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'سياسة الخصوصية',
          headerStyle: {
            backgroundColor: '#0ea5e9',
          },
          headerTintColor: '#ffffff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      />
      <View style={styles.container}>
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <Shield size={48} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.headerTitle}>سياسة الخصوصية</Text>
            <Text style={styles.headerDate}>آخر تحديث: نوفمبر 2025</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>1. جمع المعلومات</Text>
            <Text style={styles.sectionText}>
              نقوم بجمع المعلومات التي تقدمها لنا عند التسجيل واستخدام التطبيق، بما في ذلك:
            </Text>
            <View style={styles.list}>
              <Text style={styles.listItem}>• الاسم الكامل وتاريخ الميلاد</Text>
              <Text style={styles.listItem}>• البريد الإلكتروني ورقم الجوال</Text>
              <Text style={styles.listItem}>• الموقع الجغرافي والجنس</Text>
              <Text style={styles.listItem}>• المعلومات الصحية والاستشارات</Text>
              <Text style={styles.listItem}>• الصور الطبية المرفوعة للتحليل</Text>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>2. استخدام المعلومات</Text>
            <Text style={styles.sectionText}>نستخدم معلوماتك للأغراض التالية:</Text>
            <View style={styles.list}>
              <Text style={styles.listItem}>• تقديم الخدمات الصحية والاستشارات</Text>
              <Text style={styles.listItem}>• تحليل الصور بالذكاء الاصطناعي</Text>
              <Text style={styles.listItem}>• تنسيق الجلسات مع الأطباء المتخصصين</Text>
              <Text style={styles.listItem}>• تحسين جودة خدماتنا</Text>
              <Text style={styles.listItem}>• إرسال الإشعارات والتحديثات المهمة</Text>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>3. حماية البيانات</Text>
            <Text style={styles.sectionText}>
              نلتزم بحماية معلوماتك الشخصية والصحية من خلال:
            </Text>
            <View style={styles.list}>
              <Text style={styles.listItem}>• تشفير جميع البيانات المرسلة والمخزنة</Text>
              <Text style={styles.listItem}>• استخدام خوادم آمنة ومحمية</Text>
              <Text style={styles.listItem}>• عدم مشاركة معلوماتك مع أطراف ثالثة</Text>
              <Text style={styles.listItem}>• الوصول المحدود للمعلومات الطبية</Text>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>4. حقوقك</Text>
            <Text style={styles.sectionText}>لديك الحق في:</Text>
            <View style={styles.list}>
              <Text style={styles.listItem}>• الوصول إلى بياناتك الشخصية</Text>
              <Text style={styles.listItem}>• تعديل أو تحديث معلوماتك</Text>
              <Text style={styles.listItem}>• حذف حسابك وجميع بياناتك</Text>
              <Text style={styles.listItem}>• سحب الموافقة على معالجة بياناتك</Text>
              <Text style={styles.listItem}>• تقديم شكوى حول كيفية التعامل مع بياناتك</Text>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>5. الكوكيز والتتبع</Text>
            <Text style={styles.sectionText}>
              نستخدم تقنيات التتبع لتحسين تجربة المستخدم وتحليل استخدام التطبيق. يمكنك
              التحكم في إعدادات الكوكيز من خلال إعدادات التطبيق.
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>6. التغييرات على السياسة</Text>
            <Text style={styles.sectionText}>
              قد نقوم بتحديث سياسة الخصوصية من وقت لآخر. سيتم إشعارك بأي تغييرات جوهرية عبر
              البريد الإلكتروني أو من خلال إشعار في التطبيق.
            </Text>
          </View>

          <View style={styles.importantCard}>
            <Text style={styles.importantTitle}>تنويه قانوني مهم</Text>
            <Text style={styles.importantText}>
              معلوماتك الصحية محمية بموجب قوانين الخصوصية الطبية. لن نقوم بمشاركة أي معلومات
              صحية مع أي طرف ثالث دون موافقتك الصريحة، باستثناء ما يتطلبه القانون أو في حالات
              الطوارئ الطبية.
            </Text>
          </View>

          <View style={styles.contactCard}>
            <Text style={styles.contactTitle}>للاستفسارات حول الخصوصية</Text>
            <Text style={styles.contactText}>support@muaafa.com</Text>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
    marginBottom: 8,
  },
  headerDate: {
    fontSize: 14,
    color: '#64748b',
  },
  section: {
    marginBottom: 28,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  sectionText: {
    fontSize: 16,
    color: '#475569',
    lineHeight: 26,
    textAlign: 'right',
    marginBottom: 12,
  },
  list: {
    gap: 8,
  },
  listItem: {
    fontSize: 15,
    color: '#64748b',
    lineHeight: 24,
    textAlign: 'right',
  },
  importantCard: {
    backgroundColor: '#fee2e2',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#fca5a5',
  },
  importantTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#991b1b',
    marginBottom: 12,
    textAlign: 'right',
  },
  importantText: {
    fontSize: 14,
    color: '#991b1b',
    textAlign: 'right',
    lineHeight: 22,
  },
  contactCard: {
    backgroundColor: '#e0f2fe',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
  },
  contactTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#075985',
    marginBottom: 8,
  },
  contactText: {
    fontSize: 15,
    color: '#0c4a6e',
    fontWeight: '600',
  },
});
