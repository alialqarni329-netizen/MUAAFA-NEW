import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, ScrollView, Alert } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { CheckCircle, XCircle, AlertCircle, ChevronRight, RefreshCw } from 'lucide-react-native';

interface TestResult {
  keysConfigured: boolean;
  keysValid: boolean;
  connectionSuccess: boolean;
  errors: string[];
  details: {
    accountId?: string;
    clientId?: string;
    clientSecret?: string;
    accessToken?: string;
    userEmail?: string;
    accountType?: number;
    oauthError?: string;
  };
}

export default function TestZoomScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<TestResult | null>(null);

  async function testZoomConnection() {
    setTesting(true);
    setResult(null);

    try {
      const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/test-zoom-connection`;
      const { data: { session } } = await supabase.auth.getSession();

      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();
      setResult(data);
    } catch (error: any) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'فشل الاختبار' : 'Test failed')
      );
    } finally {
      setTesting(false);
    }
  }

  const getStatusIcon = (status: boolean) => {
    if (status) {
      return <CheckCircle size={24} color="#10b981" strokeWidth={2} />;
    }
    return <XCircle size={24} color="#ef4444" strokeWidth={2} />;
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronRight size={24} color="#ffffff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'اختبار اتصال Zoom' : 'Test Zoom Connection'}
        </Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.infoCard}>
          <AlertCircle size={32} color="#3b82f6" strokeWidth={2} />
          <Text style={styles.infoTitle}>
            {language === 'ar' ? 'اختبار تكامل Zoom' : 'Zoom Integration Test'}
          </Text>
          <Text style={styles.infoText}>
            {language === 'ar'
              ? 'استخدم هذه الأداة للتحقق من أن مفاتيح Zoom مضبوطة بشكل صحيح ويمكن الاتصال بـ Zoom API.'
              : 'Use this tool to verify that your Zoom keys are properly configured and can connect to the Zoom API.'}
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.testButton, testing && styles.testButtonDisabled]}
          onPress={testZoomConnection}
          disabled={testing}
        >
          {testing ? (
            <ActivityIndicator color="#ffffff" />
          ) : (
            <>
              <RefreshCw size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.testButtonText}>
                {language === 'ar' ? 'تشغيل الاختبار' : 'Run Test'}
              </Text>
            </>
          )}
        </TouchableOpacity>

        {result && (
          <View style={styles.resultsContainer}>
            <Text style={styles.resultsTitle}>
              {language === 'ar' ? 'نتائج الاختبار:' : 'Test Results:'}
            </Text>

            <View style={styles.resultCard}>
              <View style={styles.resultRow}>
                {getStatusIcon(result.keysConfigured)}
                <Text style={styles.resultLabel}>
                  {language === 'ar' ? 'المفاتيح مضبوطة' : 'Keys Configured'}
                </Text>
              </View>
              {result.details.accountId && (
                <Text style={styles.resultDetail}>
                  Account ID: {result.details.accountId}
                </Text>
              )}
              {result.details.clientId && (
                <Text style={styles.resultDetail}>
                  Client ID: {result.details.clientId}
                </Text>
              )}
            </View>

            <View style={styles.resultCard}>
              <View style={styles.resultRow}>
                {getStatusIcon(result.keysValid)}
                <Text style={styles.resultLabel}>
                  {language === 'ar' ? 'المفاتيح صالحة' : 'Keys Valid'}
                </Text>
              </View>
              {result.details.accessToken && (
                <Text style={styles.resultDetail}>
                  {language === 'ar' ? 'تم الحصول على رمز الوصول بنجاح' : 'Access token obtained successfully'}
                </Text>
              )}
            </View>

            <View style={styles.resultCard}>
              <View style={styles.resultRow}>
                {getStatusIcon(result.connectionSuccess)}
                <Text style={styles.resultLabel}>
                  {language === 'ar' ? 'اتصال ناجح' : 'Connection Success'}
                </Text>
              </View>
              {result.details.userEmail && (
                <>
                  <Text style={styles.resultDetail}>
                    Email: {result.details.userEmail}
                  </Text>
                  <Text style={styles.resultDetail}>
                    Account Type: {result.details.accountType === 1 ? 'Basic' : result.details.accountType === 2 ? 'Pro' : 'Unknown'}
                  </Text>
                </>
              )}
            </View>

            {result.errors.length > 0 && (
              <View style={styles.errorsCard}>
                <Text style={styles.errorsTitle}>
                  {language === 'ar' ? 'الأخطاء:' : 'Errors:'}
                </Text>
                {result.errors.map((error, index) => (
                  <Text key={index} style={styles.errorText}>
                    • {error}
                  </Text>
                ))}
              </View>
            )}

            {result.connectionSuccess ? (
              <View style={styles.successCard}>
                <CheckCircle size={48} color="#10b981" strokeWidth={2} />
                <Text style={styles.successTitle}>
                  {language === 'ar' ? 'ممتاز!' : 'Excellent!'}
                </Text>
                <Text style={styles.successText}>
                  {language === 'ar'
                    ? 'مفاتيح Zoom تعمل بشكل صحيح. يمكنك الآن إنشاء جلسات فيديو حقيقية!'
                    : 'Your Zoom keys are working correctly. You can now create real video sessions!'}
                </Text>
              </View>
            ) : (
              <View style={styles.failCard}>
                <XCircle size={48} color="#ef4444" strokeWidth={2} />
                <Text style={styles.failTitle}>
                  {language === 'ar' ? 'تحتاج إلى ضبط المفاتيح' : 'Keys Need Configuration'}
                </Text>
                <Text style={styles.failText}>
                  {language === 'ar'
                    ? 'راجع دليل ZOOM_SETUP_GUIDE.md للحصول على تعليمات مفصلة حول كيفية الحصول على مفاتيح Zoom وضبطها.'
                    : 'Check the ZOOM_SETUP_GUIDE.md for detailed instructions on how to obtain and configure your Zoom keys.'}
                </Text>
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#8b5cf6',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    marginLeft: 8,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    flex: 1,
    textAlign: 'right',
    marginRight: 8,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  infoCard: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#bfdbfe',
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e40af',
    marginTop: 12,
    marginBottom: 8,
    textAlign: 'center',
  },
  infoText: {
    fontSize: 14,
    color: '#3b82f6',
    textAlign: 'center',
    lineHeight: 20,
  },
  testButton: {
    backgroundColor: '#8b5cf6',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 24,
  },
  testButtonDisabled: {
    opacity: 0.6,
  },
  testButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultsContainer: {
    gap: 12,
  },
  resultsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  resultCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  resultLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  resultDetail: {
    fontSize: 13,
    color: '#64748b',
    marginLeft: 36,
    marginTop: 4,
  },
  errorsCard: {
    backgroundColor: '#fef2f2',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  errorsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#dc2626',
    marginBottom: 8,
  },
  errorText: {
    fontSize: 13,
    color: '#ef4444',
    marginTop: 4,
    lineHeight: 20,
  },
  successCard: {
    backgroundColor: '#f0fdf4',
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#bbf7d0',
  },
  successTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#15803d',
    marginTop: 12,
    marginBottom: 8,
  },
  successText: {
    fontSize: 14,
    color: '#16a34a',
    textAlign: 'center',
    lineHeight: 20,
  },
  failCard: {
    backgroundColor: '#fef2f2',
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  failTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#dc2626',
    marginTop: 12,
    marginBottom: 8,
  },
  failText: {
    fontSize: 14,
    color: '#ef4444',
    textAlign: 'center',
    lineHeight: 20,
  },
});
