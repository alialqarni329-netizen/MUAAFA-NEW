import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator, Linking } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { MapPin, CreditCard, FileText, ShoppingBag } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { getUserActiveInsurance, createPharmacyOrder, formatCurrency, generatePaymentUrl } from '@/lib/payment-utils';

interface CartItem {
  id: string;
  medication_id: string;
  pharmacy_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  insurance_coverage_amount: number;
  patient_amount: number;
  medication: {
    name: string;
  };
  pharmacy: {
    business_name: string;
  };
}

export default function PharmacyCheckoutScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [insurance, setInsurance] = useState<any>(null);

  const [formData, setFormData] = useState({
    deliveryAddress: '',
    deliveryNotes: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً');
        router.back();
        return;
      }

      setUserId(user.id);

      const { data: cartData, error: cartError } = await supabase
        .from('pharmacy_cart')
        .select(`
          *,
          medication:medications(name),
          pharmacy:business_registrations(business_name)
        `)
        .eq('user_id', user.id);

      if (cartError) throw cartError;

      if (!cartData || cartData.length === 0) {
        Alert.alert('السلة فارغة', 'يرجى إضافة منتجات أولاً', [
          { text: 'حسناً', onPress: () => router.back() },
        ]);
        return;
      }

      setCartItems(cartData);
      const insurancePolicy = await getUserActiveInsurance(user.id);
      setInsurance(insurancePolicy);
    } catch (error) {
      console.error('Error loading data:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحميل البيانات');
    } finally {
      setLoading(false);
    }
  }

  function calculateTotals() {
    const subtotal = cartItems.reduce((sum, item) => sum + item.total_price, 0);
    const insuranceCovered = cartItems.reduce((sum, item) => sum + item.insurance_coverage_amount, 0);
    const total = cartItems.reduce((sum, item) => sum + item.patient_amount, 0);

    return { subtotal, insuranceCovered, total };
  }

  async function handleSubmitOrder() {
    if (!formData.deliveryAddress) {
      Alert.alert('خطأ', 'يرجى إدخال عنوان التوصيل');
      return;
    }

    if (!userId || cartItems.length === 0) {
      Alert.alert('خطأ', 'لا يمكن إتمام الطلب');
      return;
    }

    setSubmitting(true);

    try {
      const { subtotal, insuranceCovered, total } = calculateTotals();
      const pharmacyId = cartItems[0].pharmacy_id;
      const pharmacyName = cartItems[0].pharmacy.business_name;

      const orderItems = cartItems.map(item => ({
        medication_id: item.medication_id,
        medication_name: item.medication.name,
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price,
      }));

      const order = await createPharmacyOrder(
        userId,
        pharmacyId,
        pharmacyName,
        orderItems,
        subtotal,
        insurance?.id,
        formData.deliveryAddress,
        formData.deliveryNotes
      );

      await supabase
        .from('pharmacy_cart')
        .delete()
        .eq('user_id', userId);

      Alert.alert(
        'تم إنشاء الطلب',
        `المبلغ المطلوب: ${formatCurrency(order.user_payable)}\n\nسيتم تحويلك لبوابة الدفع`,
        [
          {
            text: 'الدفع الآن',
            onPress: () => proceedToPayment(order.id, order.user_payable),
          },
        ]
      );
    } catch (error: any) {
      setSubmitting(false);
      console.error('Error creating order:', error);
      Alert.alert('خطأ', error.message || 'حدث خطأ أثناء إنشاء الطلب');
    }
  }

  function proceedToPayment(orderId: string, amount: number) {
    const paymentUrl = generatePaymentUrl(orderId, amount, 'pharmacy_order');

    Linking.openURL(paymentUrl).catch((err) => {
      console.error('Error opening payment URL:', err);
      Alert.alert('خطأ', 'لا يمكن فتح بوابة الدفع');
      setSubmitting(false);
    });
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6366f1" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  const { subtotal, insuranceCovered, total } = calculateTotals();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>إتمام طلب الصيدلية</Text>
        <Text style={styles.subtitle}>أدخل بيانات التوصيل</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <ShoppingBag size={20} color="#6366f1" strokeWidth={2} />
            <Text style={styles.sectionTitle}>ملخص الطلب</Text>
          </View>

          {cartItems.map((item, index) => (
            <View key={item.id} style={styles.orderItem}>
              <Text style={styles.orderItemName}>
                {item.quantity}× {item.medication.name}
              </Text>
              <Text style={styles.orderItemPrice}>
                {formatCurrency(item.total_price)}
              </Text>
            </View>
          ))}

          <View style={styles.divider} />

          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>المجموع:</Text>
            <Text style={styles.totalValue}>{formatCurrency(subtotal)}</Text>
          </View>

          {insuranceCovered > 0 && (
            <View style={styles.totalRow}>
              <Text style={styles.discountLabel}>التغطية التأمينية:</Text>
              <Text style={styles.discountValue}>- {formatCurrency(insuranceCovered)}</Text>
            </View>
          )}

          <View style={styles.finalTotalRow}>
            <Text style={styles.finalTotalLabel}>المبلغ المستحق:</Text>
            <Text style={styles.finalTotalValue}>{formatCurrency(total)}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <MapPin size={20} color="#6366f1" strokeWidth={2} />
            <Text style={styles.sectionTitle}>عنوان التوصيل</Text>
          </View>

          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="أدخل عنوان التوصيل الكامل"
            value={formData.deliveryAddress}
            onChangeText={(text) => setFormData({ ...formData, deliveryAddress: text })}
            textAlign="right"
            multiline
            numberOfLines={3}
          />
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <FileText size={20} color="#6366f1" strokeWidth={2} />
            <Text style={styles.sectionTitle}>ملاحظات إضافية (اختياري)</Text>
          </View>

          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="أي ملاحظات للصيدلية..."
            value={formData.deliveryNotes}
            onChangeText={(text) => setFormData({ ...formData, deliveryNotes: text })}
            textAlign="right"
            multiline
            numberOfLines={3}
          />
        </View>

        <View style={styles.warningBox}>
          <Text style={styles.warningText}>
            ⚠️ يجب إتمام الدفع لتأكيد الطلب
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.submitButton, submitting && styles.submitButtonDisabled]}
          onPress={handleSubmitOrder}
          disabled={submitting}>
          {submitting ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <>
              <CreditCard size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.submitButtonText}>متابعة للدفع</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  orderItemName: {
    fontSize: 14,
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  orderItemPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 12,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
  },
  totalLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  totalValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  discountLabel: {
    fontSize: 14,
    color: '#10b981',
  },
  discountValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10b981',
  },
  finalTotalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    marginTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  finalTotalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  finalTotalValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#6366f1',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    padding: 16,
    fontSize: 16,
    color: '#0f172a',
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  warningBox: {
    backgroundColor: '#fef3c7',
    borderRadius: 8,
    padding: 12,
    marginTop: 8,
  },
  warningText: {
    fontSize: 13,
    color: '#92400e',
    textAlign: 'center',
    fontWeight: '600',
  },
  submitButton: {
    backgroundColor: '#6366f1',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 8,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
