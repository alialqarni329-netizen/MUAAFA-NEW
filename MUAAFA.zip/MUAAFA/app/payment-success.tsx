import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useEffect, useState } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { CheckCircle, XCircle, FileText } from 'lucide-react-native';
import { updatePaymentStatus } from '@/lib/payment-utils';
import { supabase } from '@/lib/supabase';

export default function PaymentSuccessScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const [loading, setLoading] = useState(true);
  const [success, setSuccess] = useState(false);
  const [message, setMessage] = useState('جاري معالجة الدفع...');

  useEffect(() => {
    processPayment();
  }, []);

  async function processPayment() {
    try {
      const type = params.type as 'medical_session' | 'pharmacy_order';
      const id = params.id as string;
      const status = params.status as string;
      const transactionId = params.transaction_id as string;

      if (!type || !id) {
        throw new Error('معلومات الدفع غير مكتملة');
      }

      if (status === 'success' || status === 'paid') {
        await updatePaymentStatus(type, id, 'paid', 'zedpay', transactionId);

        const tableName = type === 'medical_session' ? 'medical_sessions' : 'pharmacy_orders';
        const { data } = await supabase
          .from(tableName)
          .select('*')
          .eq('id', id)
          .single();

        setSuccess(true);
        setMessage('تم الدفع بنجاح!');
      } else {
        await updatePaymentStatus(type, id, 'failed', 'zedpay', transactionId);
        setSuccess(false);
        setMessage('فشل الدفع. يرجى المحاولة مرة أخرى.');
      }
    } catch (error: any) {
      console.error('Payment processing error:', error);
      setSuccess(false);
      setMessage(error.message || 'حدث خطأ أثناء معالجة الدفع');
    } finally {
      setLoading(false);
    }
  }

  function handleGoHome() {
    router.replace('/(tabs)');
  }

  function handleViewHistory() {
    router.replace('/(tabs)/history');
  }

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#6366f1" />
        <Text style={styles.loadingText}>{message}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {success ? (
          <>
            <View style={styles.iconContainer}>
              <CheckCircle size={80} color="#10b981" strokeWidth={2} />
            </View>
            <Text style={styles.successTitle}>تم الدفع بنجاح!</Text>
            <Text style={styles.successMessage}>
              تم تأكيد حجزك/طلبك بنجاح.{'\n'}
              ستتلقى فاتورة إلكترونية قريباً.
            </Text>

            <View style={styles.buttonGroup}>
              <TouchableOpacity style={styles.primaryButton} onPress={handleViewHistory}>
                <FileText size={20} color="#ffffff" strokeWidth={2} />
                <Text style={styles.primaryButtonText}>عرض السجل</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.secondaryButton} onPress={handleGoHome}>
                <Text style={styles.secondaryButtonText}>العودة للرئيسية</Text>
              </TouchableOpacity>
            </View>
          </>
        ) : (
          <>
            <View style={styles.iconContainer}>
              <XCircle size={80} color="#ef4444" strokeWidth={2} />
            </View>
            <Text style={styles.errorTitle}>فشل الدفع</Text>
            <Text style={styles.errorMessage}>{message}</Text>

            <View style={styles.buttonGroup}>
              <TouchableOpacity style={styles.retryButton} onPress={() => router.back()}>
                <Text style={styles.retryButtonText}>المحاولة مرة أخرى</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.secondaryButton} onPress={handleGoHome}>
                <Text style={styles.secondaryButtonText}>العودة للرئيسية</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  content: {
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
  },
  iconContainer: {
    marginBottom: 24,
  },
  successTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#10b981',
    marginBottom: 12,
    textAlign: 'center',
  },
  successMessage: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  errorTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ef4444',
    marginBottom: 12,
    textAlign: 'center',
  },
  errorMessage: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  buttonGroup: {
    width: '100%',
    gap: 12,
  },
  primaryButton: {
    backgroundColor: '#6366f1',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  primaryButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  secondaryButton: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  secondaryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#ef4444',
    borderRadius: 12,
    padding: 16,
  },
  retryButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
  },
});
