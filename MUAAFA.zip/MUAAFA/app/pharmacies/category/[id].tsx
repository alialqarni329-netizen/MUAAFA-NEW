import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface TreatmentCategory {
  id: string;
  name: string;
  name_en: string;
  description: string;
  icon: string;
  product_count: number;
}

export default function PharmacyCategoryScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [categoryName, setCategoryName] = useState('');
  const [treatments, setTreatments] = useState<TreatmentCategory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadCategoryDetails();
    }
  }, [id]);

  async function loadCategoryDetails() {
    try {
      const { data: category, error: catError } = await supabase
        .from('pharmacy_categories')
        .select('name')
        .eq('id', id)
        .single();

      if (catError) throw catError;
      setCategoryName(category?.name || '');

      const { data: treatmentData, error: treatError } = await supabase
        .from('treatment_categories')
        .select('*, products(count)')
        .eq('pharmacy_category_id', id)
        .eq('is_active', true)
        .order('sort_order', { ascending: true });

      if (treatError) throw treatError;

      const formattedTreatments = (treatmentData || []).map((item: any) => ({
        id: item.id,
        name: item.name,
        name_en: item.name_en,
        description: item.description,
        icon: item.icon,
        product_count: item.products?.[0]?.count || 0,
      }));

      setTreatments(formattedTreatments);
    } catch (error: any) {
      console.error('Error loading category:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerText}>
          <Text style={styles.title}>{categoryName}</Text>
          <Text style={styles.subtitle}>اختر قسم العلاج</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {treatments.map((treatment) => (
          <TouchableOpacity
            key={treatment.id}
            style={styles.treatmentCard}
            onPress={() => router.push(`/pharmacies/treatment/${treatment.id}`)}>
            <View style={styles.treatmentInfo}>
              <Text style={styles.treatmentName}>{treatment.name}</Text>
              {treatment.description && (
                <Text style={styles.treatmentDescription}>{treatment.description}</Text>
              )}
              <Text style={styles.productCount}>
                {treatment.product_count} منتج
              </Text>
            </View>
            <ChevronLeft size={24} color="#94a3b8" strokeWidth={2} />
          </TouchableOpacity>
        ))}

        {treatments.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>لا توجد أقسام متاحة حالياً</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 12,
  },
  treatmentCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  treatmentInfo: {
    flex: 1,
  },
  treatmentName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  treatmentDescription: {
    fontSize: 13,
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  productCount: {
    fontSize: 12,
    color: '#0ea5e9',
    fontWeight: '600',
    textAlign: 'right',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyStateText: {
    fontSize: 16,
    color: '#94a3b8',
  },
});
