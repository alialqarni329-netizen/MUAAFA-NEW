import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ChevronRight, ShoppingCart, Plus, Package } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { addToCart as addToCartUtil } from '@/lib/cart-utils';

interface Product {
  id: string;
  name: string;
  name_en: string;
  description: string;
  price: number;
  stock_quantity: number;
  is_available: boolean;
  requires_prescription: boolean;
  delivery_options: any;
}

export default function TreatmentProductsScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [treatmentName, setTreatmentName] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    if (id) {
      loadProducts();
      loadCartCount();
    }
  }, [id]);

  async function loadCartCount() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from('cart_items')
      .select('quantity')
      .eq('user_id', user.id);

    const count = data?.reduce((sum, item) => sum + item.quantity, 0) || 0;
    setCartCount(count);
  }

  async function loadProducts() {
    try {
      const { data: treatment, error: treatError } = await supabase
        .from('treatment_categories')
        .select('name')
        .eq('id', id)
        .single();

      if (treatError) throw treatError;
      setTreatmentName(treatment?.name || '');

      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('treatment_category_id', id)
        .eq('is_available', true)
        .order('name', { ascending: true });

      if (error) throw error;
      setProducts(data || []);
    } catch (error: any) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  }

  async function addToCart(product: Product) {
    if (product.requires_prescription) {
      Alert.alert(
        'يتطلب وصفة طبية',
        'هذا المنتج يتطلب وصفة طبية. يرجى رفع وصفتك أولاً.',
        [
          { text: 'إلغاء', style: 'cancel' },
          { text: 'رفع وصفة', onPress: () => router.push('/pharmacy/upload-prescription') },
        ]
      );
      return;
    }

    try {
      const success = await addToCartUtil({
        id: product.id,
        name: product.name,
        price: product.price,
        type: 'product',
        metadata: {
          name_en: product.name_en,
          description: product.description,
          delivery_options: product.delivery_options,
        },
      }, 1);

      if (success) {
        Alert.alert('تم الإضافة', `تم إضافة ${product.name} للسلة`);
        await loadCartCount();
      } else {
        Alert.alert('خطأ', 'تعذر إضافة المنتج');
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء إضانة المنتج');
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerText}>
          <Text style={styles.title}>{treatmentName}</Text>
          <Text style={styles.subtitle}>{products.length} منتج</Text>
        </View>
        {cartCount > 0 && (
          <TouchableOpacity
            style={styles.cartButton}
            onPress={() => router.push('/cart')}>
            <ShoppingCart size={20} color="#ffffff" strokeWidth={2} />
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText}>{cartCount}</Text>
            </View>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {products.map((product) => (
          <View key={product.id} style={styles.productCard}>
            <View style={styles.productHeader}>
              <View style={styles.productIcon}>
                <Package size={24} color="#0ea5e9" strokeWidth={2} />
              </View>
              <View style={styles.productInfo}>
                <Text style={styles.productName}>{product.name}</Text>
                {product.name_en && (
                  <Text style={styles.productNameEn}>{product.name_en}</Text>
                )}
              </View>
            </View>

            {product.description && (
              <Text style={styles.productDescription} numberOfLines={2}>
                {product.description}
              </Text>
            )}

            <View style={styles.productDetails}>
              <View style={styles.priceContainer}>
                <Text style={styles.price}>{product.price.toFixed(2)}</Text>
                <Text style={styles.currency}>ريال</Text>
              </View>

              <View style={styles.stockContainer}>
                <Text style={styles.stockLabel}>
                  المخزون: {product.stock_quantity}
                </Text>
              </View>
            </View>

            {product.requires_prescription && (
              <View style={styles.prescriptionBadge}>
                <Text style={styles.prescriptionText}>يتطلب وصفة طبية</Text>
              </View>
            )}

            <View style={styles.deliveryInfo}>
              {product.delivery_options?.standard && (
                <Text style={styles.deliveryText}>✓ توصيل عادي</Text>
              )}
              {product.delivery_options?.express && (
                <Text style={styles.deliveryText}>✓ توصيل سريع</Text>
              )}
            </View>

            <TouchableOpacity
              style={styles.addButton}
              onPress={() => addToCart(product)}>
              <Plus size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.addButtonText}>إضافة للسلة</Text>
            </TouchableOpacity>
          </View>
        ))}

        {products.length === 0 && (
          <View style={styles.emptyState}>
            <Package size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyStateText}>لا توجد منتجات متاحة حالياً</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  cartButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#0ea5e9',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  cartBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#ef4444',
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartBadgeText: {
    color: '#ffffff',
    fontSize: 11,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  productCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  productHeader: {
    flexDirection: 'row',
    gap: 12,
  },
  productIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#eff6ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  productNameEn: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  productDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
    lineHeight: 20,
  },
  productDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
  },
  price: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  currency: {
    fontSize: 14,
    color: '#64748b',
  },
  stockContainer: {
    backgroundColor: '#f1f5f9',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  stockLabel: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
  },
  prescriptionBadge: {
    backgroundColor: '#fef3c7',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  prescriptionText: {
    fontSize: 13,
    color: '#92400e',
    fontWeight: '600',
    textAlign: 'right',
  },
  deliveryInfo: {
    flexDirection: 'row',
    gap: 12,
    flexWrap: 'wrap',
  },
  deliveryText: {
    fontSize: 12,
    color: '#10b981',
    fontWeight: '600',
  },
  addButton: {
    backgroundColor: '#10b981',
    borderRadius: 10,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  addButtonText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
    gap: 16,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#94a3b8',
  },
});
