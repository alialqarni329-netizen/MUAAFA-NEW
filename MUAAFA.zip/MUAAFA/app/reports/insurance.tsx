import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { ChevronRight, FileText, Clock, CheckCircle, XCircle, AlertCircle, Download } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface Report {
  id: string;
  title: string;
  status: string;
  submitted_at: string;
  reviewed_at: string | null;
}

export default function InsuranceReportsScreen() {
  const router = useRouter();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReports();
  }, []);

  async function loadReports() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('medical_reports')
        .select('*')
        .eq('user_id', user.id)
        .eq('report_type', 'insurance')
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      setReports(data || []);
    } catch (error: any) {
      console.error('Error loading reports:', error);
    } finally {
      setLoading(false);
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'completed':
        return <CheckCircle size={20} color="#10b981" strokeWidth={2} />;
      case 'rejected':
        return <XCircle size={20} color="#ef4444" strokeWidth={2} />;
      case 'in_review':
        return <Clock size={20} color="#f59e0b" strokeWidth={2} />;
      case 'awaiting_info':
        return <AlertCircle size={20} color="#f59e0b" strokeWidth={2} />;
      default:
        return <Clock size={20} color="#94a3b8" strokeWidth={2} />;
    }
  }

  function getStatusText(status: string) {
    const statusMap: Record<string, string> = {
      pending: 'قيد الانتظار',
      in_review: 'قيد المراجعة',
      completed: 'مكتمل',
      rejected: 'مرفوض',
      awaiting_info: 'بانتظار معلومات',
    };
    return statusMap[status] || status;
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'completed':
        return '#d1fae5';
      case 'rejected':
        return '#fee2e2';
      case 'in_review':
        return '#fef3c7';
      case 'awaiting_info':
        return '#fed7aa';
      default:
        return '#f1f5f9';
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerText}>
          <Text style={styles.title}>طلبات التأمين الطبي</Text>
          <Text style={styles.subtitle}>{reports.length} طلب</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <TouchableOpacity
          style={styles.newReportButton}
          onPress={() => router.push('/reports/submit?type=insurance')}>
          <FileText size={24} color="#ffffff" strokeWidth={2} />
          <Text style={styles.newReportButtonText}>تقديم طلب جديد</Text>
        </TouchableOpacity>

        {reports.map((report) => (
          <TouchableOpacity
            key={report.id}
            style={styles.reportCard}
            onPress={() => router.push(`/reports/details/${report.id}`)}>
            <View style={[styles.statusBadge, { backgroundColor: getStatusColor(report.status) }]}>
              {getStatusIcon(report.status)}
              <Text style={styles.statusText}>{getStatusText(report.status)}</Text>
            </View>

            <Text style={styles.reportTitle}>{report.title}</Text>

            <View style={styles.reportMeta}>
              <Text style={styles.reportDate}>
                {new Date(report.submitted_at).toLocaleDateString('ar-SA')}
              </Text>
              {report.status === 'completed' && (
                <TouchableOpacity style={styles.downloadButton}>
                  <Download size={16} color="#0ea5e9" strokeWidth={2} />
                  <Text style={styles.downloadText}>تحميل PDF</Text>
                </TouchableOpacity>
              )}
            </View>
          </TouchableOpacity>
        ))}

        {reports.length === 0 && (
          <View style={styles.emptyState}>
            <FileText size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyStateText}>لا توجد طلبات حالياً</Text>
            <Text style={styles.emptyStateSubtext}>
              ابدأ بتقديم طلب تأمين جديد
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  newReportButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  newReportButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  reportCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    alignSelf: 'flex-end',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
  },
  reportTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  reportMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  reportDate: {
    fontSize: 13,
    color: '#64748b',
  },
  downloadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  downloadText: {
    fontSize: 13,
    color: '#0ea5e9',
    fontWeight: '600',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
    gap: 12,
  },
  emptyStateText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#94a3b8',
  },
});
