import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ChevronRight, FileText, Clock, CheckCircle, XCircle, AlertCircle, Download } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface ReportDetails {
  id: string;
  title: string;
  description: string;
  report_type: string;
  status: string;
  submitted_at: string;
  reviewed_at: string | null;
  rejection_reason: string | null;
  documents: string[];
  pdf_url: string | null;
}

export default function ReportDetailsScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [report, setReport] = useState<ReportDetails | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadReportDetails();
    }
  }, [id]);

  async function loadReportDetails() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('medical_reports')
        .select('*')
        .eq('id', id)
        .eq('user_id', user.id)
        .single();

      if (error) throw error;
      setReport(data);
    } catch (error: any) {
      console.error('Error loading report:', error);
      Alert.alert('خطأ', 'تعذر تحميل تفاصيل التقرير');
    } finally {
      setLoading(false);
    }
  }

  function getStatusIcon() {
    if (!report) return null;

    switch (report.status) {
      case 'completed':
        return <CheckCircle size={32} color="#10b981" strokeWidth={2} />;
      case 'rejected':
        return <XCircle size={32} color="#ef4444" strokeWidth={2} />;
      case 'in_review':
        return <Clock size={32} color="#f59e0b" strokeWidth={2} />;
      case 'awaiting_info':
        return <AlertCircle size={32} color="#f59e0b" strokeWidth={2} />;
      default:
        return <Clock size={32} color="#94a3b8" strokeWidth={2} />;
    }
  }

  function getStatusText() {
    if (!report) return '';

    const statusMap: Record<string, string> = {
      pending: 'قيد الانتظار',
      in_review: 'قيد المراجعة',
      completed: 'مكتمل',
      rejected: 'مرفوض',
      awaiting_info: 'بانتظار معلومات إضافية',
    };
    return statusMap[report.status] || report.status;
  }

  function getReportTypeText() {
    if (!report) return '';
    return report.report_type === 'insurance' ? 'تأمين طبي' : 'موافقة صحية';
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  if (!report) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>لم يتم العثور على التقرير</Text>
        <TouchableOpacity
          style={styles.backButtonError}
          onPress={() => router.back()}>
          <Text style={styles.backButtonText}>العودة</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>تفاصيل التقرير</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.statusCard}>
          <View style={styles.statusIcon}>
            {getStatusIcon()}
          </View>
          <Text style={styles.statusTitle}>{getStatusText()}</Text>
          <Text style={styles.statusSubtitle}>الحالة الحالية للتقرير</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>معلومات التقرير</Text>
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Text style={styles.infoValue}>{report.title}</Text>
              <Text style={styles.infoLabel}>العنوان:</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoValue}>{getReportTypeText()}</Text>
              <Text style={styles.infoLabel}>النوع:</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoValue}>
                {new Date(report.submitted_at).toLocaleDateString('ar-SA')}
              </Text>
              <Text style={styles.infoLabel}>تاريخ التقديم:</Text>
            </View>
            {report.reviewed_at && (
              <View style={styles.infoRow}>
                <Text style={styles.infoValue}>
                  {new Date(report.reviewed_at).toLocaleDateString('ar-SA')}
                </Text>
                <Text style={styles.infoLabel}>تاريخ المراجعة:</Text>
              </View>
            )}
          </View>
        </View>

        {report.description && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>التفاصيل</Text>
            <View style={styles.descriptionCard}>
              <Text style={styles.descriptionText}>{report.description}</Text>
            </View>
          </View>
        )}

        {report.rejection_reason && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>سبب الرفض</Text>
            <View style={styles.rejectionCard}>
              <Text style={styles.rejectionText}>{report.rejection_reason}</Text>
            </View>
          </View>
        )}

        {report.documents && report.documents.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>المستندات</Text>
            {report.documents.map((doc, index) => (
              <View key={index} style={styles.documentCard}>
                <FileText size={20} color="#64748b" strokeWidth={2} />
                <Text style={styles.documentName}>مستند {index + 1}</Text>
              </View>
            ))}
          </View>
        )}

        {report.status === 'completed' && report.pdf_url && (
          <TouchableOpacity style={styles.downloadButton}>
            <Download size={20} color="#ffffff" strokeWidth={2} />
            <Text style={styles.downloadButtonText}>تحميل التقرير PDF</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 16,
  },
  backButtonError: {
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 20,
  },
  statusCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statusIcon: {
    marginBottom: 8,
  },
  statusTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statusSubtitle: {
    fontSize: 14,
    color: '#64748b',
  },
  section: {
    gap: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  infoCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  infoLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  infoValue: {
    fontSize: 14,
    color: '#0f172a',
  },
  descriptionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  descriptionText: {
    fontSize: 14,
    color: '#0f172a',
    lineHeight: 22,
    textAlign: 'right',
  },
  rejectionCard: {
    backgroundColor: '#fef2f2',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  rejectionText: {
    fontSize: 14,
    color: '#991b1b',
    lineHeight: 22,
    textAlign: 'right',
  },
  documentCard: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  documentName: {
    fontSize: 14,
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  downloadButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  downloadButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
