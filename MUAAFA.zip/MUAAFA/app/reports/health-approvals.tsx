import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { ChevronRight, Shield, Clock, CheckCircle, XCircle, AlertCircle, Download } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface Approval {
  id: string;
  title: string;
  status: string;
  submitted_at: string;
}

export default function HealthApprovalsScreen() {
  const router = useRouter();
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadApprovals();
  }, []);

  async function loadApprovals() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('medical_reports')
        .select('*')
        .eq('user_id', user.id)
        .eq('report_type', 'health_approval')
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      setApprovals(data || []);
    } catch (error: any) {
      console.error('Error loading approvals:', error);
    } finally {
      setLoading(false);
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'completed':
        return <CheckCircle size={20} color="#10b981" strokeWidth={2} />;
      case 'rejected':
        return <XCircle size={20} color="#ef4444" strokeWidth={2} />;
      case 'in_review':
        return <Clock size={20} color="#f59e0b" strokeWidth={2} />;
      case 'awaiting_info':
        return <AlertCircle size={20} color="#f59e0b" strokeWidth={2} />;
      default:
        return <Clock size={20} color="#94a3b8" strokeWidth={2} />;
    }
  }

  function getStatusText(status: string) {
    const statusMap: Record<string, string> = {
      pending: 'قيد الانتظار',
      in_review: 'قيد المراجعة',
      completed: 'مكتمل',
      rejected: 'مرفوض',
      awaiting_info: 'بانتظار معلومات',
    };
    return statusMap[status] || status;
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#10b981" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerText}>
          <Text style={styles.title}>الموافقات الصحية</Text>
          <Text style={styles.subtitle}>{approvals.length} طلب</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <TouchableOpacity
          style={styles.newApprovalButton}
          onPress={() => router.push('/reports/submit?type=health_approval')}>
          <Shield size={24} color="#ffffff" strokeWidth={2} />
          <Text style={styles.newApprovalButtonText}>تقديم طلب جديد</Text>
        </TouchableOpacity>

        {approvals.map((approval) => (
          <TouchableOpacity
            key={approval.id}
            style={styles.approvalCard}
            onPress={() => router.push(`/reports/details/${approval.id}`)}>
            <View style={styles.cardHeader}>
              <View style={styles.iconContainer}>
                <Shield size={24} color="#10b981" strokeWidth={2} />
              </View>
              <View style={styles.cardInfo}>
                <Text style={styles.approvalTitle}>{approval.title}</Text>
                <Text style={styles.approvalDate}>
                  {new Date(approval.submitted_at).toLocaleDateString('ar-SA')}
                </Text>
              </View>
            </View>

            <View style={styles.statusContainer}>
              {getStatusIcon(approval.status)}
              <Text style={styles.statusLabel}>{getStatusText(approval.status)}</Text>
            </View>
          </TouchableOpacity>
        ))}

        {approvals.length === 0 && (
          <View style={styles.emptyState}>
            <Shield size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyStateText}>لا توجد طلبات حالياً</Text>
            <Text style={styles.emptyStateSubtext}>
              ابدأ بتقديم طلب موافقة صحية جديد
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  newApprovalButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  newApprovalButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  approvalCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderLeftWidth: 4,
    borderLeftColor: '#10b981',
    gap: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    gap: 12,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#d1fae5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardInfo: {
    flex: 1,
  },
  approvalTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  approvalDate: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#f8fafc',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    alignSelf: 'flex-end',
  },
  statusLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
    gap: 12,
  },
  emptyStateText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#94a3b8',
  },
});
