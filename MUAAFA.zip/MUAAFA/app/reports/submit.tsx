import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { useState } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ChevronRight, FileText, Upload, X } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import * as ImagePicker from 'expo-image-picker';

export default function SubmitReportScreen() {
  const router = useRouter();
  const { type } = useLocalSearchParams();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [documents, setDocuments] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const reportType = type === 'insurance' ? 'insurance' : 'health_approval';
  const reportTitle = type === 'insurance' ? 'طلب تأمين طبي' : 'طلب موافقة صحية';

  async function pickDocument() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 0.8,
    });

    if (!result.canceled) {
      const uris = result.assets.map(asset => asset.uri);
      setDocuments([...documents, ...uris]);
    }
  }

  function removeDocument(index: number) {
    setDocuments(documents.filter((_, i) => i !== index));
  }

  async function handleSubmit() {
    if (!title) {
      Alert.alert('خطأ', 'يرجى إدخال عنوان التقرير');
      return;
    }

    setSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not found');

      const { error } = await supabase.from('medical_reports').insert({
        user_id: user.id,
        report_type: reportType,
        title,
        description: description || null,
        documents,
        status: 'pending',
      });

      if (error) throw error;

      Alert.alert('تم الإرسال', 'تم تقديم التقرير بنجاح', [
        { text: 'حسناً', onPress: () => router.back() },
      ]);
    } catch (error: any) {
      console.error('Error submitting report:', error);
      Alert.alert('خطأ', 'تعذر إرسال التقرير');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>{reportTitle}</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>عنوان التقرير *</Text>
            <TextInput
              style={styles.input}
              placeholder="مثال: طلب موافقة للعملية الجراحية"
              value={title}
              onChangeText={setTitle}
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>التفاصيل</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="أضف تفاصيل إضافية..."
              value={description}
              onChangeText={setDescription}
              multiline
              numberOfLines={5}
              textAlign="right"
              textAlignVertical="top"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>المستندات</Text>
            <TouchableOpacity style={styles.uploadButton} onPress={pickDocument}>
              <Upload size={20} color="#0ea5e9" strokeWidth={2} />
              <Text style={styles.uploadButtonText}>رفع مستندات</Text>
            </TouchableOpacity>

            {documents.length > 0 && (
              <View style={styles.documentsList}>
                {documents.map((doc, index) => (
                  <View key={index} style={styles.documentItem}>
                    <FileText size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.documentName} numberOfLines={1}>
                      مستند {index + 1}
                    </Text>
                    <TouchableOpacity onPress={() => removeDocument(index)}>
                      <X size={18} color="#ef4444" strokeWidth={2} />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>

        <TouchableOpacity
          style={[styles.submitButton, submitting && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={submitting}>
          <Text style={styles.submitButtonText}>
            {submitting ? 'جاري الإرسال...' : 'إرسال التقرير'}
          </Text>
        </TouchableOpacity>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>ملاحظات هامة:</Text>
          <Text style={styles.infoText}>• سيتم مراجعة التقرير خلال 24-48 ساعة</Text>
          <Text style={styles.infoText}>• يمكنك متابعة حالة التقرير من الصفحة الرئيسية</Text>
          <Text style={styles.infoText}>• سيتم إرسال إشعار عند تحديث الحالة</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  form: {
    gap: 20,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    padding: 16,
    fontSize: 16,
    color: '#0f172a',
  },
  textArea: {
    minHeight: 120,
  },
  uploadButton: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: '#bfdbfe',
  },
  uploadButtonText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  documentsList: {
    gap: 8,
    marginTop: 8,
  },
  documentItem: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  documentName: {
    flex: 1,
    fontSize: 14,
    color: '#0f172a',
    textAlign: 'right',
  },
  submitButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 24,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  infoCard: {
    backgroundColor: '#fffbeb',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
    gap: 8,
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#92400e',
    textAlign: 'right',
  },
  infoText: {
    fontSize: 13,
    color: '#78350f',
    textAlign: 'right',
    lineHeight: 20,
  },
});
