import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ChevronRight, FileText, Calendar, AlertCircle, CheckCircle, Clock } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface Report {
  id: string;
  report_type: string;
  status: string;
  created_at: string;
  updated_at: string;
  diagnosis?: string;
  notes?: string;
}

const reportTypeNames: Record<string, string> = {
  xray: 'أشعة',
  lab_test: 'تحليل',
  medical_report: 'تقرير طبي',
  insurance: 'موافقة تأمينية',
};

const statusNames: Record<string, { label: string; color: string; icon: any }> = {
  pending: { label: 'قيد المراجعة', color: '#f59e0b', icon: Clock },
  approved: { label: 'تمت الموافقة', color: '#10b981', icon: CheckCircle },
  rejected: { label: 'مرفوض', color: '#ef4444', icon: AlertCircle },
  completed: { label: 'مكتمل', color: '#0ea5e9', icon: CheckCircle },
};

export default function ReportsHistoryScreen() {
  const router = useRouter();
  const { type } = useLocalSearchParams();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReports();
  }, [type]);

  async function loadReports() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      let query = supabase
        .from('medical_reports')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (type && type !== 'all') {
        query = query.eq('report_type', type);
      }

      const { data, error } = await query;

      if (error) throw error;
      setReports(data || []);
    } catch (error: any) {
      console.error('Error loading reports:', error);
    } finally {
      setLoading(false);
    }
  }

  function formatDate(dateString: string) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري تحميل السجلات...</Text>
      </View>
    );
  }

  const pageTitle = type && type !== 'all'
    ? `${reportTypeNames[type as string] || 'التقارير'} السابقة`
    : 'جميع التقارير';

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerText}>
          <Text style={styles.title}>{pageTitle}</Text>
          <Text style={styles.subtitle}>{reports.length} سجل</Text>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        {reports.length === 0 ? (
          <View style={styles.emptyState}>
            <FileText size={64} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyTitle}>لا توجد سجلات</Text>
            <Text style={styles.emptyText}>
              لم تقم بتقديم أي تقارير من هذا النوع بعد
            </Text>
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => router.push('/reports/submit')}>
              <Text style={styles.addButtonText}>تقديم تقرير جديد</Text>
            </TouchableOpacity>
          </View>
        ) : (
          reports.map((report) => {
            const statusInfo = statusNames[report.status] || statusNames.pending;
            const StatusIcon = statusInfo.icon;

            return (
              <TouchableOpacity
                key={report.id}
                style={styles.reportCard}
                onPress={() => router.push(`/reports/details/${report.id}`)}>
                <View style={styles.reportHeader}>
                  <View style={styles.reportIcon}>
                    <FileText size={24} color="#0ea5e9" strokeWidth={2} />
                  </View>
                  <View style={styles.reportInfo}>
                    <Text style={styles.reportType}>
                      {reportTypeNames[report.report_type] || report.report_type}
                    </Text>
                    <View style={styles.dateRow}>
                      <Calendar size={14} color="#94a3b8" strokeWidth={2} />
                      <Text style={styles.reportDate}>
                        {formatDate(report.created_at)}
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: `${statusInfo.color}15` }]}>
                    <StatusIcon size={14} color={statusInfo.color} strokeWidth={2} />
                    <Text style={[styles.statusText, { color: statusInfo.color }]}>
                      {statusInfo.label}
                    </Text>
                  </View>
                </View>

                {report.diagnosis && (
                  <Text style={styles.reportDiagnosis} numberOfLines={2}>
                    {report.diagnosis}
                  </Text>
                )}

                {report.notes && (
                  <Text style={styles.reportNotes} numberOfLines={1}>
                    {report.notes}
                  </Text>
                )}

                <View style={styles.reportFooter}>
                  <Text style={styles.viewDetails}>عرض التفاصيل ←</Text>
                </View>
              </TouchableOpacity>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 12,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
    gap: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  emptyText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
  },
  addButton: {
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: 16,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  reportCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  reportHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  reportIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#eff6ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  reportInfo: {
    flex: 1,
  },
  reportType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    justifyContent: 'flex-end',
    marginTop: 4,
  },
  reportDate: {
    fontSize: 13,
    color: '#94a3b8',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  reportDiagnosis: {
    fontSize: 14,
    color: '#475569',
    textAlign: 'right',
    lineHeight: 20,
  },
  reportNotes: {
    fontSize: 13,
    color: '#94a3b8',
    textAlign: 'right',
  },
  reportFooter: {
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  viewDetails: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0ea5e9',
    textAlign: 'right',
  },
});
