import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Modal,
  TextInput,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  User,
  ChevronRight,
  Shield,
  Key,
  Eye,
  Bell,
  Globe,
  Moon,
  FileText,
  Info,
  LogOut,
  Trash2,
  Phone,
  Mail,
  Calendar,
  CheckCircle,
  Edit,
  X,
  MessageSquare,
} from 'lucide-react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { requestNotificationPermissions } from '@/lib/notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface UserProfile {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  date_of_birth: string;
  gender: string;
  location: string;
  avatar_url?: string;
}

interface UserPreferences {
  dark_mode: boolean;
  medication_notifications: boolean;
  appointment_notifications: boolean;
  language: string;
}

export default function SettingsScreen() {
  const router = useRouter();
  const { language, setLanguage } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [darkMode, setDarkMode] = useState(false);
  const [medicationNotifications, setMedicationNotifications] = useState(true);
  const [privacyLevel, setPrivacyLevel] = useState('doctor_only');
  const [showEditModal, setShowEditModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);

  const [editForm, setEditForm] = useState({
    full_name: '',
    email: '',
    date_of_birth: '',
  });

  const [passwordForm, setPasswordForm] = useState({
    current: '',
    new: '',
    confirm: '',
  });

  useEffect(() => {
    loadProfile();
    loadPreferences();
  }, []);

  async function loadProfile() {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.replace('/auth/login');
        return;
      }

      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setProfile(data);
        setEditForm({
          full_name: data.full_name || '',
          email: data.email || user.email || '',
          date_of_birth: data.date_of_birth || '',
        });
      }
    } catch (error) {
      console.error('Error loading profile:', error);
      Alert.alert('خطأ', 'فشل تحميل البيانات');
    } finally {
      setLoading(false);
    }
  }

  async function loadPreferences() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (data) {
        setDarkMode(data.dark_mode || false);
        setMedicationNotifications(data.medication_notifications !== false);

        await AsyncStorage.setItem('darkMode', data.dark_mode ? 'true' : 'false');
      } else {
        await supabase.from('user_preferences').insert({
          user_id: user.id,
          dark_mode: false,
          medication_notifications: true,
          appointment_notifications: true,
          language: language || 'ar',
        });
      }
    } catch (error) {
      console.error('Error loading preferences:', error);
    }
  }

  async function savePreferences(updates: Partial<UserPreferences>) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: user.id,
          ...updates,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'user_id' });

      if (error) throw error;

      if (updates.dark_mode !== undefined) {
        await AsyncStorage.setItem('darkMode', updates.dark_mode ? 'true' : 'false');
      }
    } catch (error) {
      console.error('Error saving preferences:', error);
      Alert.alert('خطأ', 'فشل حفظ الإعدادات');
    }
  }

  async function handleUpdateProfile() {
    try {
      if (!profile) return;

      setLoading(true);
      const { error } = await supabase
        .from('users')
        .update({
          full_name: editForm.full_name,
          date_of_birth: editForm.date_of_birth,
          updated_at: new Date().toISOString(),
        })
        .eq('id', profile.id);

      if (error) throw error;

      if (editForm.email !== profile.email) {
        const { error: emailError } = await supabase.auth.updateUser({
          email: editForm.email,
        });
        if (emailError) throw emailError;
      }

      Alert.alert('نجح', 'تم تحديث الملف الشخصي');
      setShowEditModal(false);
      loadProfile();
    } catch (error: any) {
      console.error('Error updating profile:', error);
      Alert.alert('خطأ', error.message || 'فشل تحديث الملف الشخصي');
    } finally {
      setLoading(false);
    }
  }

  async function handleChangePassword() {
    try {
      if (!passwordForm.new || passwordForm.new.length < 6) {
        Alert.alert('خطأ', 'كلمة المرور يجب أن تكون 6 أحرف على الأقل');
        return;
      }

      if (passwordForm.new !== passwordForm.confirm) {
        Alert.alert('خطأ', 'كلمة المرور وتأكيد كلمة المرور غير متطابقين');
        return;
      }

      setLoading(true);
      const { error } = await supabase.auth.updateUser({
        password: passwordForm.new,
      });

      if (error) throw error;

      Alert.alert('نجح', 'تم تغيير كلمة المرور');
      setShowPasswordModal(false);
      setPasswordForm({ current: '', new: '', confirm: '' });
    } catch (error: any) {
      console.error('Error changing password:', error);
      Alert.alert('خطأ', error.message || 'فشل تغيير كلمة المرور');
    } finally {
      setLoading(false);
    }
  }

  async function handleLogout() {
    Alert.alert(
      'تسجيل الخروج',
      'هل أنت متأكد من تسجيل الخروج؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'تسجيل الخروج',
          style: 'destructive',
          onPress: async () => {
            try {
              await supabase.auth.signOut();
              router.replace('/auth/login');
            } catch (error) {
              console.error('Error signing out:', error);
              Alert.alert('خطأ', 'فشل تسجيل الخروج');
            }
          },
        },
      ]
    );
  }

  async function handleDeleteAccount() {
    Alert.alert(
      'حذف الحساب',
      'تحذير: سيتم حذف جميع بياناتك الطبية بشكل نهائي. هذا الإجراء لا يمكن التراجع عنه.',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف نهائي',
          style: 'destructive',
          onPress: () => setShowDeleteModal(true),
        },
      ]
    );
  }

  async function confirmDeleteAccount() {
    try {
      if (!profile) return;

      setLoading(true);

      const { error: deleteError } = await supabase
        .from('users')
        .delete()
        .eq('id', profile.id);

      if (deleteError) throw deleteError;

      await supabase.auth.signOut();
      Alert.alert('تم الحذف', 'تم حذف حسابك بنجاح');
      router.replace('/auth/login');
    } catch (error: any) {
      console.error('Error deleting account:', error);
      Alert.alert('خطأ', error.message || 'فشل حذف الحساب');
    } finally {
      setLoading(false);
      setShowDeleteModal(false);
    }
  }

  function handlePrivacyChange(level: string) {
    setPrivacyLevel(level);
    setShowPrivacyModal(false);
    Alert.alert('تم', `تم تغيير إعدادات الخصوصية إلى: ${
      level === 'doctor_only' ? 'الطبيب فقط' :
      level === 'everyone' ? 'الكل' : 'لا أحد'
    }`);
  }

  function openSupportChat() {
    router.push('/help');
  }

  if (loading && !profile) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronRight size={24} color="#0f172a" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>الإعدادات</Text>
        <View style={styles.backButton} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.profileCard}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatar}>
              <User size={40} color="#ffffff" strokeWidth={2} />
            </View>
          </View>
          <Text style={styles.profileName}>{profile?.full_name || 'مستخدم'}</Text>
          <View style={styles.profileInfo}>
            <Phone size={14} color="#64748b" />
            <Text style={styles.profileInfoText}>{profile?.phone || 'غير متوفر'}</Text>
          </View>
          <View style={styles.profileInfo}>
            <Mail size={14} color="#64748b" />
            <Text style={styles.profileInfoText}>{profile?.email || 'غير متوفر'}</Text>
          </View>
          <TouchableOpacity
            style={styles.editProfileButton}
            onPress={() => setShowEditModal(true)}
          >
            <Edit size={18} color="#ffffff" />
            <Text style={styles.editProfileButtonText}>تعديل الملف</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>إدارة الحساب والأمان</Text>

          <TouchableOpacity style={styles.card}>
            <View style={styles.cardIcon}>
              <CheckCircle size={22} color="#10b981" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>توثيق الحساب</Text>
              <Text style={styles.cardSubtitle}>موثق برقم الجوال</Text>
            </View>
            <View style={styles.verifiedBadge}>
              <Text style={styles.verifiedBadgeText}>✓</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.card}
            onPress={() => setShowPasswordModal(true)}
          >
            <View style={styles.cardIcon}>
              <Key size={22} color="#0ea5e9" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>تغيير كلمة المرور</Text>
              <Text style={styles.cardSubtitle}>تحديث رمز الدخول</Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.card}
            onPress={() => setShowPrivacyModal(true)}
          >
            <View style={styles.cardIcon}>
              <Eye size={22} color="#8b5cf6" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>إعدادات الخصوصية</Text>
              <Text style={styles.cardSubtitle}>
                {privacyLevel === 'doctor_only' ? 'الطبيب فقط' :
                 privacyLevel === 'everyone' ? 'الكل' : 'لا أحد'}
              </Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>التفضيلات</Text>

          <TouchableOpacity
            style={styles.card}
            onPress={() => router.push('/pharmacy/medication-reminders')}>
            <View style={styles.cardIcon}>
              <Bell size={22} color="#f59e0b" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>تنبيهات الدواء</Text>
              <Text style={styles.cardSubtitle}>إدارة تنبيهات مواعيد الأدوية</Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.card}
            onPress={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
          >
            <View style={styles.cardIcon}>
              <Globe size={22} color="#06b6d4" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>اللغة</Text>
              <Text style={styles.cardSubtitle}>
                {language === 'ar' ? 'العربية' : 'English'}
              </Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>

          <View style={styles.card}>
            <View style={styles.cardIcon}>
              <Moon size={22} color="#64748b" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>الوضع الداكن</Text>
              <Text style={styles.cardSubtitle}>المظهر الليلي</Text>
            </View>
            <Switch
              value={darkMode}
              onValueChange={async (value) => {
                setDarkMode(value);
                await savePreferences({ dark_mode: value });
                Alert.alert(
                  'تم',
                  value
                    ? 'تم تفعيل الوضع الداكن. سيتم تطبيقه في التحديث القادم'
                    : 'تم إيقاف الوضع الداكن',
                  [{ text: 'حسناً' }]
                );
              }}
              trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
              thumbColor="#ffffff"
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الدعم والسياسات</Text>

          <TouchableOpacity style={styles.card} onPress={openSupportChat}>
            <View style={styles.cardIcon}>
              <MessageSquare size={22} color="#10b981" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>مركز المساعدة</Text>
              <Text style={styles.cardSubtitle}>الدردشة مع الدعم الفني</Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.card}
            onPress={() => router.push('/privacy')}
          >
            <View style={styles.cardIcon}>
              <Shield size={22} color="#0ea5e9" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>سياسة الخصوصية</Text>
              <Text style={styles.cardSubtitle}>تشفير البيانات الطبية</Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.card}
            onPress={() => router.push('/about')}
          >
            <View style={styles.cardIcon}>
              <Info size={22} color="#8b5cf6" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>عن مُعافى</Text>
              <Text style={styles.cardSubtitle}>الإصدار 1.0.0</Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>منطقة العمليات الحرجة</Text>

          <TouchableOpacity
            style={[styles.card, styles.dangerCard]}
            onPress={handleLogout}
          >
            <View style={[styles.cardIcon, styles.dangerIcon]}>
              <LogOut size={22} color="#ef4444" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={[styles.cardTitle, styles.dangerText]}>تسجيل الخروج</Text>
              <Text style={styles.cardSubtitle}>إنهاء الجلسة الحالية</Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.card, styles.dangerCard]}
            onPress={handleDeleteAccount}
          >
            <View style={[styles.cardIcon, styles.dangerIcon]}>
              <Trash2 size={22} color="#ef4444" strokeWidth={2} />
            </View>
            <View style={styles.cardContent}>
              <Text style={[styles.cardTitle, styles.dangerText]}>حذف الحساب</Text>
              <Text style={styles.cardSubtitle}>حذف جميع البيانات نهائياً</Text>
            </View>
            <ChevronRight size={20} color="#cbd5e1" />
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>مُعافى © 2024</Text>
          <Text style={styles.footerText}>جميع الحقوق محفوظة</Text>
        </View>
      </ScrollView>

      <Modal
        visible={showEditModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowEditModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setShowEditModal(false)}>
                <X size={24} color="#64748b" />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>تعديل الملف الشخصي</Text>
              <View style={{ width: 24 }} />
            </View>

            <ScrollView style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>الاسم الكامل</Text>
                <TextInput
                  style={styles.input}
                  value={editForm.full_name}
                  onChangeText={(text) => setEditForm({ ...editForm, full_name: text })}
                  placeholder="أدخل اسمك الكامل"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>البريد الإلكتروني</Text>
                <TextInput
                  style={styles.input}
                  value={editForm.email}
                  onChangeText={(text) => setEditForm({ ...editForm, email: text })}
                  placeholder="example@email.com"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>تاريخ الميلاد</Text>
                <TouchableOpacity
                  style={styles.dateButton}
                  onPress={() => setShowDatePicker(true)}
                >
                  <Calendar size={20} color="#8b5cf6" strokeWidth={2} />
                  <Text style={styles.dateButtonText}>
                    {editForm.date_of_birth
                      ? new Date(editForm.date_of_birth + 'T00:00:00').toLocaleDateString('ar-SA', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })
                      : 'اختر تاريخ الميلاد'}
                  </Text>
                </TouchableOpacity>
              </View>

              {showDatePicker && (
                <DateTimePicker
                  value={editForm.date_of_birth ? new Date(editForm.date_of_birth + 'T00:00:00') : new Date()}
                  mode="date"
                  display="default"
                  onChange={(event, date) => {
                    setShowDatePicker(Platform.OS === 'ios');
                    if (date) {
                      setEditForm({ ...editForm, date_of_birth: date.toISOString().split('T')[0] });
                    }
                  }}
                  maximumDate={new Date()}
                  minimumDate={new Date(1920, 0, 1)}
                />
              )}

              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleUpdateProfile}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.saveButtonText}>حفظ التغييرات</Text>
                )}
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showPasswordModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowPasswordModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setShowPasswordModal(false)}>
                <X size={24} color="#64748b" />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>تغيير كلمة المرور</Text>
              <View style={{ width: 24 }} />
            </View>

            <View style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>كلمة المرور الجديدة</Text>
                <TextInput
                  style={styles.input}
                  value={passwordForm.new}
                  onChangeText={(text) => setPasswordForm({ ...passwordForm, new: text })}
                  placeholder="أدخل كلمة المرور الجديدة"
                  secureTextEntry
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>تأكيد كلمة المرور</Text>
                <TextInput
                  style={styles.input}
                  value={passwordForm.confirm}
                  onChangeText={(text) => setPasswordForm({ ...passwordForm, confirm: text })}
                  placeholder="أعد إدخال كلمة المرور"
                  secureTextEntry
                  textAlign="right"
                />
              </View>

              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleChangePassword}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.saveButtonText}>تغيير كلمة المرور</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showPrivacyModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowPrivacyModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setShowPrivacyModal(false)}>
                <X size={24} color="#64748b" />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>إعدادات الخصوصية</Text>
              <View style={{ width: 24 }} />
            </View>

            <View style={styles.modalBody}>
              <Text style={styles.privacyDescription}>
                من يمكنه رؤية ملفك الطبي؟
              </Text>

              <TouchableOpacity
                style={[styles.privacyOption, privacyLevel === 'doctor_only' && styles.privacyOptionActive]}
                onPress={() => handlePrivacyChange('doctor_only')}
              >
                <View style={styles.privacyOptionContent}>
                  <Text style={styles.privacyOptionTitle}>الطبيب فقط</Text>
                  <Text style={styles.privacyOptionSubtitle}>الأطباء المسجلون فقط</Text>
                </View>
                {privacyLevel === 'doctor_only' && (
                  <CheckCircle size={24} color="#0ea5e9" />
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.privacyOption, privacyLevel === 'everyone' && styles.privacyOptionActive]}
                onPress={() => handlePrivacyChange('everyone')}
              >
                <View style={styles.privacyOptionContent}>
                  <Text style={styles.privacyOptionTitle}>الكل</Text>
                  <Text style={styles.privacyOptionSubtitle}>جميع المستخدمين</Text>
                </View>
                {privacyLevel === 'everyone' && (
                  <CheckCircle size={24} color="#0ea5e9" />
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.privacyOption, privacyLevel === 'none' && styles.privacyOptionActive]}
                onPress={() => handlePrivacyChange('none')}
              >
                <View style={styles.privacyOptionContent}>
                  <Text style={styles.privacyOptionTitle}>لا أحد</Text>
                  <Text style={styles.privacyOptionSubtitle}>خاص تماماً</Text>
                </View>
                {privacyLevel === 'none' && (
                  <CheckCircle size={24} color="#0ea5e9" />
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showDeleteModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowDeleteModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.deleteModalContent}>
            <View style={styles.deleteIcon}>
              <Trash2 size={40} color="#ef4444" strokeWidth={2} />
            </View>
            <Text style={styles.deleteModalTitle}>تأكيد الحذف</Text>
            <Text style={styles.deleteModalText}>
              هل أنت متأكد من حذف حسابك؟{'\n'}
              سيتم حذف جميع بياناتك الطبية بشكل نهائي ولا يمكن استعادتها.
            </Text>
            <View style={styles.deleteModalButtons}>
              <TouchableOpacity
                style={styles.deleteModalButtonCancel}
                onPress={() => setShowDeleteModal(false)}
              >
                <Text style={styles.deleteModalButtonCancelText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.deleteModalButtonConfirm}
                onPress={confirmDeleteAccount}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.deleteModalButtonConfirmText}>حذف نهائي</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  content: {
    flex: 1,
  },
  profileCard: {
    backgroundColor: '#ffffff',
    margin: 20,
    marginBottom: 12,
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  avatarContainer: {
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#0ea5e9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
  },
  profileInfoText: {
    fontSize: 14,
    color: '#64748b',
  },
  editProfileButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: 16,
  },
  editProfileButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
  },
  section: {
    marginBottom: 24,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  cardIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  cardContent: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 2,
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  verifiedBadge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#dcfce7',
    justifyContent: 'center',
    alignItems: 'center',
  },
  verifiedBadgeText: {
    fontSize: 16,
    color: '#10b981',
    fontWeight: 'bold',
  },
  dangerCard: {
    borderWidth: 1,
    borderColor: '#fee2e2',
  },
  dangerIcon: {
    backgroundColor: '#fef2f2',
  },
  dangerText: {
    color: '#ef4444',
  },
  footer: {
    paddingVertical: 32,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: '#94a3b8',
    textAlign: 'center',
    marginBottom: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  modalBody: {
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
  },
  dateButtonText: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
  },
  saveButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  privacyDescription: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'right',
    marginBottom: 16,
  },
  privacyOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  privacyOptionActive: {
    borderColor: '#0ea5e9',
    backgroundColor: '#f0f9ff',
  },
  privacyOptionContent: {
    flex: 1,
  },
  privacyOptionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 2,
  },
  privacyOptionSubtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  deleteModalContent: {
    backgroundColor: '#ffffff',
    margin: 20,
    padding: 24,
    borderRadius: 20,
    alignItems: 'center',
  },
  deleteIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#fef2f2',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  deleteModalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
  },
  deleteModalText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  deleteModalButtons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  deleteModalButtonCancel: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    alignItems: 'center',
  },
  deleteModalButtonCancelText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
  deleteModalButtonConfirm: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#ef4444',
    alignItems: 'center',
  },
  deleteModalButtonConfirmText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
