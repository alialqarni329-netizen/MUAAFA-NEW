import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  Modal,
  ActivityIndicator,
  Platform,
  Image,
} from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { Heart, MapPin, Calendar } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import DateTimePicker from '@react-native-community/datetimepicker';
import { supabase } from '@/lib/supabase';
import {
  validateEmail,
  validatePhone,
  validateNationalId,
  validatePassword,
  parseSupabaseError,
} from '@/lib/validation-utils';
import { AuthStorage } from '@/lib/auth-storage';

const SAUDI_CITIES = [
  'الرياض',
  'جدة',
  'مكة المكرمة',
  'المدينة المنورة',
  'الدمام',
  'الخبر',
  'الظهران',
  'الطائف',
  'تبوك',
  'بريدة',
  'خميس مشيط',
  'الهفوف',
  'المبرز',
  'حفر الباطن',
  'الجبيل',
  'حائل',
  'نجران',
  'ينبع',
  'أبها',
  'عرعر',
  'سكاكا',
  'جازان',
  'عنيزة',
  'القطيف',
  'الخرج',
  'الباحة',
  'الزلفي',
  'رأس تنورة',
  'الدوادمي',
  'صبيا',
  'القريات',
  'أخرى',
];

export default function RegisterScreen() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    nationalId: '',
    dateOfBirth: '',
    gender: 'male' as 'male' | 'female',
    location: '',
    password: '',
    confirmPassword: '',
  });
  const [loading, setLoading] = useState(false);
  const [showCityModal, setShowCityModal] = useState(false);
  const [showOtherCityInput, setShowOtherCityInput] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date(2000, 0, 1));
  const [showYearPicker, setShowYearPicker] = useState(false);

  const handleCitySelect = (city: string) => {
    if (city === 'أخرى') {
      setShowOtherCityInput(true);
      setShowCityModal(false);
      setFormData({ ...formData, location: '' });
    } else {
      setFormData({ ...formData, location: city });
      setShowCityModal(false);
      setShowOtherCityInput(false);
    }
  };

  async function handleRegister() {
    if (!formData.fullName.trim()) {
      Alert.alert('خطأ', 'الاسم الكامل مطلوب، يرجى إدخاله');
      return;
    }

    if (formData.fullName.trim().length < 3) {
      Alert.alert('خطأ في الاسم', 'الاسم يجب أن يكون 3 أحرف على الأقل');
      return;
    }

    const trimmedEmail = formData.email.trim();
    const emailValidation = validateEmail(trimmedEmail);
    if (!emailValidation.isValid) {
      Alert.alert('خطأ في البريد الإلكتروني', emailValidation.errorMessage);
      return;
    }

    const phoneValidation = validatePhone(formData.phone);
    if (!phoneValidation.isValid) {
      Alert.alert('خطأ في رقم الجوال', phoneValidation.errorMessage);
      return;
    }

    const idValidation = validateNationalId(formData.nationalId);
    if (!idValidation.isValid) {
      Alert.alert('خطأ في رقم الهوية', idValidation.errorMessage);
      return;
    }

    if (!formData.dateOfBirth) {
      Alert.alert('خطأ', 'تاريخ الميلاد مطلوب، يرجى اختياره من التقويم');
      return;
    }

    if (!formData.location.trim()) {
      Alert.alert('خطأ', 'المدينة مطلوبة، يرجى اختيار المدينة');
      return;
    }

    const passwordValidation = validatePassword(formData.password);
    if (!passwordValidation.isValid) {
      Alert.alert('خطأ في كلمة المرور', passwordValidation.errorMessage);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      Alert.alert('خطأ', 'كلمة المرور وتأكيد كلمة المرور غير متطابقين، يرجى التأكد من إدخال نفس كلمة المرور في كلا الحقلين');
      return;
    }

    setLoading(true);

    try {
      const normalizedPhone = phoneValidation.normalizedValue || formData.phone;

      const { data: duplicateCheck, error: checkError } = await supabase
        .rpc('check_duplicate_user_data', {
          p_phone: normalizedPhone,
          p_national_id: formData.nationalId.trim(),
          p_email: trimmedEmail.toLowerCase(),
        });

      if (checkError) {
        setLoading(false);
        console.error('Error checking duplicates:', checkError);
        Alert.alert('خطأ', 'حدث خطأ أثناء التحقق من البيانات');
        return;
      }

      if (duplicateCheck && duplicateCheck.length > 0 && duplicateCheck[0].is_duplicate) {
        setLoading(false);
        const duplicate = duplicateCheck[0];
        let errorMessage = duplicate.error_message || 'البيانات مسجلة مسبقاً';

        if (duplicate.duplicate_field === 'phone') {
          errorMessage = 'رقم الهاتف ' + normalizedPhone + ' مسجل مسبقاً في النظام\n\nإذا كان هذا الرقم لك، يمكنك تسجيل الدخول أو استعادة كلمة المرور';
        } else if (duplicate.duplicate_field === 'national_id') {
          errorMessage = 'رقم الهوية الوطنية مسجل مسبقاً في النظام\n\nلا يمكن استخدام نفس رقم الهوية لأكثر من حساب';
        } else if (duplicate.duplicate_field === 'email') {
          errorMessage = 'البريد الإلكتروني ' + trimmedEmail + ' مسجل مسبقاً\n\nإذا كان هذا البريد لك، يمكنك تسجيل الدخول أو استعادة كلمة المرور';
        }

        Alert.alert('لا يمكن التسجيل', errorMessage);
        return;
      }

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: trimmedEmail.toLowerCase(),
        password: formData.password,
        options: {
          data: {
            full_name: formData.fullName.trim(),
            phone: normalizedPhone,
            user_role: 'individual_user',
          }
        }
      });

      if (authError) {
        setLoading(false);
        const errorMsg = parseSupabaseError(authError);
        Alert.alert('فشل إنشاء الحساب', `حدث خطأ أثناء محاولة إنشاء الحساب:\n\n${errorMsg}\n\nيرجى التحقق من البيانات والمحاولة مرة أخرى`);
        return;
      }

      if (!authData.user || !authData.session) {
        setLoading(false);
        Alert.alert('خطأ في التسجيل', 'لم يتم إنشاء حساب صالح. يرجى المحاولة مرة أخرى');
        return;
      }

      try {
        await AuthStorage.saveAuthToken(authData.session.access_token);
      } catch (storageError) {
        console.error('Token storage error:', storageError);
        setLoading(false);
        Alert.alert('خطأ في حفظ البيانات', 'تم إنشاء الحساب لكن فشل حفظ بيانات الجلسة. يرجى تسجيل الدخول');
        router.replace('/auth/login');
        return;
      }

      const userId = authData.user.id;

      await new Promise(resolve => setTimeout(resolve, 500));

      const { error: userUpdateError } = await supabase.from('users').update({
        full_name: formData.fullName.trim(),
        phone: normalizedPhone,
        national_id: formData.nationalId.trim(),
        date_of_birth: formData.dateOfBirth,
        gender: formData.gender,
        location: formData.location.trim(),
        updated_at: new Date().toISOString(),
      }).eq('id', userId);

      if (userUpdateError) {
        console.error('User update error:', userUpdateError);
      }

      try {
        await AuthStorage.saveUserRole('individual_user');
        await AuthStorage.saveUserData({
          id: userId,
          email: authData.user.email,
          full_name: formData.fullName.trim(),
          role: 'individual_user'
        });
      } catch (storageError) {
        console.error('User data storage error:', storageError);
      }

      setLoading(false);

      Alert.alert(
        'تم إنشاء الحساب بنجاح',
        `مرحباً ${formData.fullName.trim()}!\n\nتم تفعيل حسابك في مُعافى بنجاح\n• تم تفعيل الباقة الأساسية المجانية\n• يرجى إكمال الاستبيان الطبي لتحسين خدماتنا`,
        [
          {
            text: 'ابدأ الاستبيان',
            onPress: () => router.replace('/questionnaire'),
          },
        ]
      );
    } catch (error: any) {
      setLoading(false);
      console.error('Registration error:', error);
      const errorMsg = parseSupabaseError(error);
      Alert.alert('خطأ غير متوقع', `حدث خطأ غير متوقع:\n\n${errorMsg}\n\nيرجى المحاولة مرة أخرى. إذا استمرت المشكلة، يرجى التواصل مع الدعم الفني`);
      await AuthStorage.clearAuth();
    }
  }


  return (
    <LinearGradient
      colors={['#ffffff', '#f0f9ff', '#e0f2fe']}
      style={styles.gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Image
            source={require('@/assets/images/icon.png')}
            style={styles.logo}
            resizeMode="contain"
          />
          <Text style={styles.subtitle}>رحلتك الصحية تبدأ من هنا</Text>
        </View>

      <View style={styles.form}>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            الاسم الكامل <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={styles.input}
            placeholder="أدخل اسمك الكامل"
            value={formData.fullName}
            onChangeText={(text) => setFormData({ ...formData, fullName: text })}
            textAlign="right"
          />
          <Text style={styles.helpText}>الاسم الكامل (3 أحرف على الأقل)</Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            البريد الإلكتروني <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={styles.input}
            placeholder="example@gmail.com"
            value={formData.email}
            onChangeText={(text) => setFormData({ ...formData, email: text.trim() })}
            keyboardType="email-address"
            autoCapitalize="none"
            textAlign="right"
          />
          <Text style={styles.helpText}>استخدم بريد حقيقي من نطاق معروف (gmail، outlook، hotmail)</Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            رقم الجوال <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={styles.input}
            placeholder="0501234567"
            value={formData.phone}
            onChangeText={(text) => setFormData({ ...formData, phone: text })}
            keyboardType="phone-pad"
            textAlign="right"
            maxLength={10}
          />
          <Text style={styles.helpText}>رقم سعودي يبدأ بـ 05 (9 أرقام)</Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            رقم الهوية <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={styles.input}
            placeholder="1234567890"
            value={formData.nationalId}
            onChangeText={(text) => setFormData({ ...formData, nationalId: text })}
            keyboardType="number-pad"
            textAlign="right"
            maxLength={10}
          />
          <Text style={styles.helpText}>10 أرقام، يبدأ بـ 1 (سعودي) أو 2 (مقيم)</Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            تاريخ الميلاد <Text style={styles.required}>*</Text>
          </Text>
          <TouchableOpacity
            style={styles.datePickerButton}
            onPress={() => setShowDatePicker(true)}>
            <Calendar size={20} color="#0ea5e9" strokeWidth={2} />
            <Text style={[styles.datePickerText, !formData.dateOfBirth && styles.datePickerPlaceholder]}>
              {formData.dateOfBirth
                ? new Date(formData.dateOfBirth + 'T00:00:00').toLocaleDateString('ar-SA', {
                    weekday: 'short',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })
                : 'اختر تاريخ الميلاد'}
            </Text>
          </TouchableOpacity>

          <Modal
            visible={showDatePicker}
            transparent={true}
            animationType="slide"
            onRequestClose={() => setShowDatePicker(false)}>
            <View style={styles.dateModalOverlay}>
              <View style={styles.dateModalContent}>
                <View style={styles.dateModalHeader}>
                  <TouchableOpacity
                    style={styles.dateModalButton}
                    onPress={() => {
                      const formattedDate = selectedDate.toISOString().split('T')[0];
                      setFormData({ ...formData, dateOfBirth: formattedDate });
                      setShowDatePicker(false);
                    }}>
                    <Text style={styles.dateModalDone}>تم</Text>
                  </TouchableOpacity>
                  <Text style={styles.dateModalTitle}>اختر تاريخ الميلاد</Text>
                  <TouchableOpacity
                    style={styles.dateModalButton}
                    onPress={() => setShowDatePicker(false)}>
                    <Text style={styles.dateModalCancel}>إلغاء</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.yearPickerContainer}>
                  <Text style={styles.yearPickerLabel}>السنة:</Text>
                  <TouchableOpacity
                    style={styles.yearPickerButton}
                    onPress={() => setShowYearPicker(!showYearPicker)}>
                    <Text style={styles.yearPickerText}>{selectedDate.getFullYear()}</Text>
                  </TouchableOpacity>
                </View>

                {showYearPicker && (
                  <ScrollView style={styles.yearList} contentContainerStyle={styles.yearListContent}>
                    {Array.from(
                      { length: new Date().getFullYear() - 1920 + 1 },
                      (_, i) => new Date().getFullYear() - i
                    ).map((year) => (
                      <TouchableOpacity
                        key={year}
                        style={[
                          styles.yearItem,
                          selectedDate.getFullYear() === year && styles.yearItemSelected,
                        ]}
                        onPress={() => {
                          const newDate = new Date(selectedDate);
                          newDate.setFullYear(year);
                          setSelectedDate(newDate);
                          setShowYearPicker(false);
                        }}>
                        <Text
                          style={[
                            styles.yearItemText,
                            selectedDate.getFullYear() === year && styles.yearItemTextSelected,
                          ]}>
                          {year}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                )}

                {!showYearPicker && (
                  <View style={styles.datePickerWrapper}>
                    <DateTimePicker
                      value={selectedDate}
                      mode="date"
                      display={Platform.OS === 'ios' ? 'inline' : 'calendar'}
                      themeVariant="light"
                      onChange={(event, date) => {
                        if (Platform.OS === 'android') {
                          setShowDatePicker(false);
                          if (date) {
                            setSelectedDate(date);
                            const formattedDate = date.toISOString().split('T')[0];
                            setFormData({ ...formData, dateOfBirth: formattedDate });
                          }
                        } else {
                          if (date) {
                            setSelectedDate(date);
                          }
                        }
                      }}
                      maximumDate={new Date()}
                      minimumDate={new Date(1920, 0, 1)}
                      locale="ar"
                      textColor="#0f172a"
                    />
                  </View>
                )}
              </View>
            </View>
          </Modal>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            الجنس <Text style={styles.required}>*</Text>
          </Text>
          <View style={styles.genderContainer}>
            <TouchableOpacity
              style={[
                styles.genderButton,
                formData.gender === 'female' && styles.genderButtonActive,
              ]}
              onPress={() => setFormData({ ...formData, gender: 'female' })}>
              <Text
                style={[
                  styles.genderButtonText,
                  formData.gender === 'female' && styles.genderButtonTextActive,
                ]}>
                أنثى
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.genderButton,
                formData.gender === 'male' && styles.genderButtonActive,
              ]}
              onPress={() => setFormData({ ...formData, gender: 'male' })}>
              <Text
                style={[
                  styles.genderButtonText,
                  formData.gender === 'male' && styles.genderButtonTextActive,
                ]}>
                ذكر
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            المدينة <Text style={styles.required}>*</Text>
          </Text>
          {!showOtherCityInput ? (
            <TouchableOpacity
              style={styles.datePickerButton}
              onPress={() => setShowCityModal(true)}>
              <MapPin size={20} color="#64748b" strokeWidth={2} />
              <Text style={styles.datePickerText}>
                {formData.location || 'اختر المدينة'}
              </Text>
            </TouchableOpacity>
          ) : (
            <TextInput
              style={styles.input}
              placeholder="اكتب اسم المدينة"
              value={formData.location}
              onChangeText={(text) => setFormData({ ...formData, location: text })}
              textAlign="right"
            />
          )}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            كلمة المرور <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={styles.input}
            placeholder="••••••••"
            value={formData.password}
            onChangeText={(text) => setFormData({ ...formData, password: text })}
            secureTextEntry
            textAlign="right"
          />
          <Text style={styles.helpText}>8 أحرف على الأقل، تحتوي على: حرف كبير، حرف صغير، ورقم</Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            تأكيد كلمة المرور <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={styles.input}
            placeholder="••••••••"
            value={formData.confirmPassword}
            onChangeText={(text) => setFormData({ ...formData, confirmPassword: text })}
            secureTextEntry
            textAlign="right"
          />
          <Text style={styles.helpText}>أعد إدخال نفس كلمة المرور</Text>
        </View>

        <TouchableOpacity
          style={[styles.registerButton, loading && styles.registerButtonDisabled]}
          onPress={handleRegister}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.registerButtonText}>إنشاء حساب</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.loginLink} onPress={() => router.back()}>
          <Text style={styles.loginLinkText}>لديك حساب؟ تسجيل الدخول</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          بإنشاء حساب، أنت توافق على شروط الخدمة وسياسة الخصوصية الخاصة بـ مُعافى
        </Text>
      </View>

      <Modal
        visible={showCityModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowCityModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>اختر المدينة</Text>
            <ScrollView style={styles.cityList}>
              {SAUDI_CITIES.map((city) => (
                <TouchableOpacity
                  key={city}
                  style={styles.cityItem}
                  onPress={() => handleCitySelect(city)}>
                  <Text style={styles.cityItemText}>{city}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity
              style={styles.modalCloseButton}
              onPress={() => setShowCityModal(false)}>
              <Text style={styles.modalCloseButtonText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  content: {
    padding: 24,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
    paddingTop: 20,
  },
  logo: {
    width: 200,
    height: 200,
    marginBottom: 24,
  },
  title: {
    fontSize: 42,
    fontWeight: '700',
    color: '#0f172a',
    marginBottom: 4,
    letterSpacing: 1,
  },
  titleEn: {
    fontSize: 28,
    fontWeight: '300',
    color: '#0ea5e9',
    marginBottom: 12,
    letterSpacing: 3,
  },
  subtitle: {
    fontSize: 22,
    fontWeight: '500',
    color: '#0ea5e9',
    letterSpacing: 0.8,
    marginTop: 16,
  },
  form: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 24,
    padding: 28,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 24,
    elevation: 4,
  },
  inputGroup: {
    marginBottom: 22,
  },
  label: {
    fontSize: 15,
    fontWeight: '500',
    color: '#64748b',
    marginBottom: 10,
    textAlign: 'right',
    letterSpacing: 0.3,
  },
  required: {
    color: '#ef4444',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 14,
    padding: 16,
    fontSize: 16,
    color: '#0f172a',
    fontWeight: '400',
  },
  helpText: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
    marginTop: 6,
    lineHeight: 18,
    fontWeight: '400',
  },
  genderContainer: {
    flexDirection: 'row',
    gap: 12,
    justifyContent: 'flex-end',
  },
  genderButton: {
    flex: 1,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
  },
  genderButtonActive: {
    backgroundColor: '#e0f2fe',
    borderColor: '#0ea5e9',
  },
  genderButtonText: {
    fontSize: 16,
    color: '#64748b',
    fontWeight: '600',
  },
  genderButtonTextActive: {
    color: '#0ea5e9',
  },
  registerButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginTop: 16,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  registerButtonDisabled: {
    opacity: 0.6,
  },
  registerButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 16,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#e2e8f0',
  },
  dividerText: {
    marginHorizontal: 12,
    fontSize: 14,
    color: '#64748b',
  },
  googleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 16,
    gap: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  googleButtonText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4285F4',
  },
  googleButtonLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  loginLink: {
    marginTop: 8,
    alignItems: 'center',
  },
  loginLinkText: {
    color: '#0ea5e9',
    fontSize: 14,
    fontWeight: '600',
  },
  footer: {
    marginTop: 24,
  },
  footerText: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'center',
    lineHeight: 18,
  },
  datePickerButton: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  datePickerText: {
    fontSize: 16,
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
    fontWeight: '500',
  },
  datePickerPlaceholder: {
    color: '#94a3b8',
    fontWeight: '400',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingTop: 20,
    maxHeight: '70%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 16,
    paddingHorizontal: 20,
  },
  cityList: {
    maxHeight: 400,
    paddingHorizontal: 20,
  },
  cityItem: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  cityItemText: {
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
  },
  modalCloseButton: {
    backgroundColor: '#ef4444',
    padding: 16,
    margin: 20,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalCloseButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  dateModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  dateModalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 30,
    width: '100%',
    maxWidth: 500,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  dateModalHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#e2e8f0',
    backgroundColor: '#f8fafc',
  },
  dateModalButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    minWidth: 60,
  },
  dateModalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
  },
  dateModalCancel: {
    fontSize: 17,
    fontWeight: '600',
    color: '#64748b',
  },
  dateModalDone: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  yearPickerContainer: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    backgroundColor: '#f8fafc',
    gap: 12,
  },
  yearPickerLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#475569',
  },
  yearPickerButton: {
    backgroundColor: '#0ea5e9',
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 12,
    minWidth: 100,
    alignItems: 'center',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  yearPickerText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  yearList: {
    maxHeight: 300,
    backgroundColor: '#ffffff',
  },
  yearListContent: {
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  yearItem: {
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginVertical: 4,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  yearItemSelected: {
    backgroundColor: '#e0f2fe',
    borderColor: '#0ea5e9',
    borderWidth: 2,
  },
  yearItemText: {
    fontSize: 16,
    color: '#475569',
    textAlign: 'center',
    fontWeight: '500',
  },
  yearItemTextSelected: {
    color: '#0ea5e9',
    fontWeight: 'bold',
    fontSize: 18,
  },
  datePickerWrapper: {
    backgroundColor: '#ffffff',
    paddingVertical: 16,
    paddingHorizontal: 8,
  },
});
