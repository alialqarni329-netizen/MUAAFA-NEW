import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, Modal, Platform } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { Check, X, Camera, MapPin, Bell, Image as ImageIcon, Shield, User, Calendar, Droplet, Scale, Ruler } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function IndividualOnboardingScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    full_name: '',
    phone: '',
    email: '',
    date_of_birth: new Date(2000, 0, 1),
    gender: '',
    height_cm: '',
    weight_kg: '',
    blood_type: '',
    chronic_diseases: [] as string[],
    drug_allergies: [] as string[],
    food_allergies: [] as string[],
    current_medications: [] as string[],
  });

  const [permissions, setPermissions] = useState({
    camera: false,
    location: false,
    notifications: false,
    photos: false,
  });

  const [showDatePicker, setShowDatePicker] = useState(false);

  const chronicDiseasesList = [
    language === 'ar' ? 'السكري' : 'Diabetes',
    language === 'ar' ? 'الضغط' : 'Hypertension',
    language === 'ar' ? 'الربو' : 'Asthma',
    language === 'ar' ? 'القلب' : 'Heart Disease',
    language === 'ar' ? 'الكلى' : 'Kidney Disease',
    language === 'ar' ? 'الكبد' : 'Liver Disease',
  ];

  const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  async function handleNext() {
    if (step === 1) {
      if (!formData.full_name || !formData.phone || !formData.email) {
        Alert.alert(
          language === 'ar' ? 'خطأ' : 'Error',
          language === 'ar' ? 'يرجى ملء جميع الحقول الإلزامية' : 'Please fill all required fields'
        );
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!formData.gender || !formData.blood_type) {
        Alert.alert(
          language === 'ar' ? 'خطأ' : 'Error',
          language === 'ar' ? 'يرجى ملء البيانات الإلزامية' : 'Please fill required fields'
        );
        return;
      }
      await completeOnboarding();
    }
  }

  async function completeOnboarding() {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      const { error: profileError } = await supabase
        .from('health_profiles')
        .upsert({
          user_id: user.id,
          full_name: formData.full_name,
          phone: formData.phone,
          date_of_birth: formData.date_of_birth.toISOString().split('T')[0],
          gender: formData.gender,
          height_cm: parseInt(formData.height_cm) || null,
          weight_kg: parseFloat(formData.weight_kg) || null,
          blood_type: formData.blood_type,
          chronic_diseases: formData.chronic_diseases,
          drug_allergies: formData.drug_allergies,
          food_allergies: formData.food_allergies,
          current_medications: formData.current_medications.map(med => ({ name: med, dosage: '' })),
          onboarding_completed: true,
          onboarding_completed_at: new Date().toISOString(),
        }, { onConflict: 'user_id' });

      if (profileError) throw profileError;

      const { error: permissionsError } = await supabase
        .from('user_permissions')
        .upsert({
          user_id: user.id,
          camera_permission: permissions.camera,
          location_permission: permissions.location,
          notifications_permission: permissions.notifications,
          photos_permission: permissions.photos,
          camera_granted_at: permissions.camera ? new Date().toISOString() : null,
          location_granted_at: permissions.location ? new Date().toISOString() : null,
          notifications_granted_at: permissions.notifications ? new Date().toISOString() : null,
          photos_granted_at: permissions.photos ? new Date().toISOString() : null,
        }, { onConflict: 'user_id' });

      if (permissionsError) throw permissionsError;

      Alert.alert(
        language === 'ar' ? 'تم بنجاح!' : 'Success!',
        language === 'ar' ? 'تم إكمال التسجيل بنجاح' : 'Registration completed successfully',
        [{ text: 'OK', onPress: () => router.replace('/(tabs)') }]
      );
    } catch (error: any) {
      console.error('Error completing onboarding:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'حدث خطأ' : 'An error occurred')
      );
    } finally {
      setLoading(false);
    }
  }

  function renderStep1() {
    return (
      <View style={styles.stepContainer}>
        <View style={styles.stepHeader}>
          <User size={32} color="#0ea5e9" strokeWidth={2} />
          <Text style={styles.stepTitle}>
            {language === 'ar' ? 'البيانات الأساسية' : 'Basic Information'}
          </Text>
          <Text style={styles.stepDescription}>
            {language === 'ar' ? 'نحتاج بعض المعلومات للبدء' : 'We need some information to get started'}
          </Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            {language === 'ar' ? 'الاسم الكامل *' : 'Full Name *'}
          </Text>
          <TextInput
            style={styles.input}
            value={formData.full_name}
            onChangeText={(text) => setFormData({ ...formData, full_name: text })}
            placeholder={language === 'ar' ? 'أدخل اسمك الكامل' : 'Enter your full name'}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            {language === 'ar' ? 'رقم الجوال *' : 'Phone Number *'}
          </Text>
          <TextInput
            style={styles.input}
            value={formData.phone}
            onChangeText={(text) => setFormData({ ...formData, phone: text })}
            placeholder={language === 'ar' ? '05xxxxxxxx' : '05xxxxxxxx'}
            placeholderTextColor="#94a3b8"
            keyboardType="phone-pad"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            {language === 'ar' ? 'البريد الإلكتروني *' : 'Email *'}
          </Text>
          <TextInput
            style={styles.input}
            value={formData.email}
            onChangeText={(text) => setFormData({ ...formData, email: text })}
            placeholder={language === 'ar' ? 'example@email.com' : 'example@email.com'}
            placeholderTextColor="#94a3b8"
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            {language === 'ar' ? 'تاريخ الميلاد *' : 'Date of Birth *'}
          </Text>
          <TouchableOpacity
            style={styles.dateButton}
            onPress={() => setShowDatePicker(true)}
          >
            <Calendar size={20} color="#64748b" strokeWidth={2} />
            <Text style={styles.dateButtonText}>
              {formData.date_of_birth.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
            </Text>
          </TouchableOpacity>

          {showDatePicker && (
            <DateTimePicker
              value={formData.date_of_birth}
              mode="date"
              display="default"
              onChange={(event, date) => {
                setShowDatePicker(Platform.OS === 'ios');
                if (date) {
                  setFormData({ ...formData, date_of_birth: date });
                }
              }}
              maximumDate={new Date()}
            />
          )}
        </View>
      </View>
    );
  }

  function renderStep3() {
    const permissionsList = [
      {
        key: 'camera' as const,
        icon: Camera,
        title: language === 'ar' ? 'الكاميرا' : 'Camera',
        description: language === 'ar'
          ? 'لمسح الوصفات الطبية والباركود'
          : 'To scan prescriptions and barcodes',
      },
      {
        key: 'location' as const,
        icon: MapPin,
        title: language === 'ar' ? 'الموقع' : 'Location',
        description: language === 'ar'
          ? 'للعثور على أقرب صيدلية أو مستشفى'
          : 'To find nearest pharmacy or hospital',
      },
      {
        key: 'notifications' as const,
        icon: Bell,
        title: language === 'ar' ? 'الإشعارات' : 'Notifications',
        description: language === 'ar'
          ? 'لتذكيرك بالأدوية والمواعيد'
          : 'To remind you of medications and appointments',
      },
      {
        key: 'photos' as const,
        icon: ImageIcon,
        title: language === 'ar' ? 'مكتبة الصور' : 'Photo Library',
        description: language === 'ar'
          ? 'لرفع التقارير الطبية والصور'
          : 'To upload medical reports and images',
      },
    ];

    return (
      <View style={styles.stepContainer}>
        <View style={styles.stepHeader}>
          <Shield size={32} color="#8b5cf6" strokeWidth={2} />
          <Text style={styles.stepTitle}>
            {language === 'ar' ? 'الأذونات' : 'Permissions'}
          </Text>
          <Text style={styles.stepDescription}>
            {language === 'ar'
              ? 'اختر الأذونات التي ترغب في منحها'
              : 'Choose permissions you want to grant'}
          </Text>
        </View>

        {permissionsList.map((perm) => {
          const Icon = perm.icon;
          const isGranted = permissions[perm.key];

          return (
            <TouchableOpacity
              key={perm.key}
              style={[styles.permissionCard, isGranted && styles.permissionCardActive]}
              onPress={() =>
                setPermissions({ ...permissions, [perm.key]: !isGranted })
              }
            >
              <View style={styles.permissionIcon}>
                <Icon size={24} color={isGranted ? '#10b981' : '#64748b'} strokeWidth={2} />
              </View>
              <View style={styles.permissionInfo}>
                <Text style={styles.permissionTitle}>{perm.title}</Text>
                <Text style={styles.permissionDescription}>{perm.description}</Text>
              </View>
              <View
                style={[
                  styles.permissionToggle,
                  isGranted && styles.permissionToggleActive,
                ]}
              >
                {isGranted && <Check size={16} color="#ffffff" strokeWidth={3} />}
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  }

  function renderStep4() {
    return (
      <ScrollView style={styles.stepScrollContainer}>
        <View style={styles.stepHeader}>
          <Droplet size={32} color="#ef4444" strokeWidth={2} />
          <Text style={styles.stepTitle}>
            {language === 'ar' ? 'الاستبيان الصحي' : 'Health Questionnaire'}
          </Text>
          <Text style={styles.stepDescription}>
            {language === 'ar'
              ? 'ساعدنا في فهم حالتك الصحية بشكل أفضل'
              : 'Help us understand your health condition better'}
          </Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            {language === 'ar' ? 'الجنس *' : 'Gender *'}
          </Text>
          <View style={styles.genderButtons}>
            <TouchableOpacity
              style={[
                styles.genderButton,
                formData.gender === 'male' && styles.genderButtonActive,
              ]}
              onPress={() => setFormData({ ...formData, gender: 'male' })}
            >
              <Text
                style={[
                  styles.genderButtonText,
                  formData.gender === 'male' && styles.genderButtonTextActive,
                ]}
              >
                {language === 'ar' ? 'ذكر' : 'Male'}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.genderButton,
                formData.gender === 'female' && styles.genderButtonActive,
              ]}
              onPress={() => setFormData({ ...formData, gender: 'female' })}
            >
              <Text
                style={[
                  styles.genderButtonText,
                  formData.gender === 'female' && styles.genderButtonTextActive,
                ]}
              >
                {language === 'ar' ? 'أنثى' : 'Female'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.row}>
          <View style={[styles.inputGroup, styles.halfWidth]}>
            <Text style={styles.label}>
              {language === 'ar' ? 'الطول (سم)' : 'Height (cm)'}
            </Text>
            <View style={styles.inputWithIcon}>
              <Ruler size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputWithIconField}
                value={formData.height_cm}
                onChangeText={(text) => setFormData({ ...formData, height_cm: text })}
                placeholder="170"
                placeholderTextColor="#94a3b8"
                keyboardType="numeric"
              />
            </View>
          </View>

          <View style={[styles.inputGroup, styles.halfWidth]}>
            <Text style={styles.label}>
              {language === 'ar' ? 'الوزن (كجم)' : 'Weight (kg)'}
            </Text>
            <View style={styles.inputWithIcon}>
              <Scale size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.inputWithIconField}
                value={formData.weight_kg}
                onChangeText={(text) => setFormData({ ...formData, weight_kg: text })}
                placeholder="70"
                placeholderTextColor="#94a3b8"
                keyboardType="numeric"
              />
            </View>
          </View>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            {language === 'ar' ? 'فصيلة الدم *' : 'Blood Type *'}
          </Text>
          <View style={styles.bloodTypeGrid}>
            {bloodTypes.map((type) => (
              <TouchableOpacity
                key={type}
                style={[
                  styles.bloodTypeButton,
                  formData.blood_type === type && styles.bloodTypeButtonActive,
                ]}
                onPress={() => setFormData({ ...formData, blood_type: type })}
              >
                <Text
                  style={[
                    styles.bloodTypeText,
                    formData.blood_type === type && styles.bloodTypeTextActive,
                  ]}
                >
                  {type}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>
            {language === 'ar' ? 'الأمراض المزمنة' : 'Chronic Diseases'}
          </Text>
          {chronicDiseasesList.map((disease) => (
            <TouchableOpacity
              key={disease}
              style={styles.checkboxRow}
              onPress={() => {
                const diseases = [...formData.chronic_diseases];
                const index = diseases.indexOf(disease);
                if (index > -1) {
                  diseases.splice(index, 1);
                } else {
                  diseases.push(disease);
                }
                setFormData({ ...formData, chronic_diseases: diseases });
              }}
            >
              <View
                style={[
                  styles.checkbox,
                  formData.chronic_diseases.includes(disease) && styles.checkboxActive,
                ]}
              >
                {formData.chronic_diseases.includes(disease) && (
                  <Check size={16} color="#ffffff" strokeWidth={3} />
                )}
              </View>
              <Text style={styles.checkboxLabel}>{disease}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.spacer} />
      </ScrollView>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.progressBar}>
          {[1, 2, 3, 4].map((s) => (
            <View
              key={s}
              style={[
                styles.progressStep,
                s <= step && styles.progressStepActive,
              ]}
            />
          ))}
        </View>
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'إنشاء حساب' : 'Create Account'}
        </Text>
        <Text style={styles.headerSubtitle}>
          {language === 'ar' ? `الخطوة ${step} من 2` : `Step ${step} of 2`}
        </Text>
      </View>

      {step === 1 && renderStep1()}
      {step === 2 && renderStep4()}

      <View style={styles.footer}>
        {step > 1 && (
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => setStep(step - 1)}
          >
            <Text style={styles.backButtonText}>
              {language === 'ar' ? 'السابق' : 'Back'}
            </Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={[styles.nextButton, step === 1 && styles.nextButtonFull]}
          onPress={handleNext}
          disabled={loading}
        >
          <Text style={styles.nextButtonText}>
            {loading
              ? (language === 'ar' ? 'جاري الحفظ...' : 'Saving...')
              : step === 4
              ? (language === 'ar' ? 'إنهاء' : 'Finish')
              : (language === 'ar' ? 'التالي' : 'Next')}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  progressBar: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  progressStep: {
    flex: 1,
    height: 4,
    backgroundColor: '#e2e8f0',
    borderRadius: 2,
  },
  progressStepActive: {
    backgroundColor: '#0ea5e9',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
  },
  stepContainer: {
    flex: 1,
    padding: 24,
  },
  stepScrollContainer: {
    flex: 1,
    padding: 24,
  },
  stepHeader: {
    alignItems: 'center',
    marginBottom: 32,
  },
  stepTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 12,
    marginBottom: 8,
  },
  stepDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
  },
  dateButton: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  dateButtonText: {
    fontSize: 16,
    color: '#0f172a',
  },
  termsCard: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  termsText: {
    flex: 1,
    fontSize: 14,
    color: '#0f172a',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
    paddingTop: 60,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  modalContent: {
    flex: 1,
    padding: 24,
  },
  termsContent: {
    fontSize: 14,
    lineHeight: 24,
    color: '#0f172a',
  },
  modalFooter: {
    padding: 24,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  acceptButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  acceptButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  permissionCard: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  permissionCardActive: {
    borderColor: '#10b981',
    backgroundColor: '#ecfdf5',
  },
  permissionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  permissionInfo: {
    flex: 1,
  },
  permissionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 4,
  },
  permissionDescription: {
    fontSize: 12,
    color: '#64748b',
  },
  permissionToggle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  permissionToggleActive: {
    backgroundColor: '#10b981',
    borderColor: '#10b981',
  },
  genderButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  genderButton: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
  },
  genderButtonActive: {
    backgroundColor: '#0ea5e9',
    borderColor: '#0ea5e9',
  },
  genderButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
  genderButtonTextActive: {
    color: '#ffffff',
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  halfWidth: {
    flex: 1,
  },
  inputWithIcon: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  inputWithIconField: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  bloodTypeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  bloodTypeButton: {
    width: '22%',
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  bloodTypeButtonActive: {
    backgroundColor: '#ef4444',
    borderColor: '#ef4444',
  },
  bloodTypeText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
  bloodTypeTextActive: {
    color: '#ffffff',
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 8,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxActive: {
    backgroundColor: '#10b981',
    borderColor: '#10b981',
  },
  checkboxLabel: {
    fontSize: 14,
    color: '#0f172a',
  },
  spacer: {
    height: 40,
  },
  footer: {
    flexDirection: 'row',
    padding: 24,
    gap: 12,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  backButton: {
    flex: 1,
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
  nextButton: {
    flex: 2,
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  nextButtonFull: {
    flex: 1,
  },
  nextButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
