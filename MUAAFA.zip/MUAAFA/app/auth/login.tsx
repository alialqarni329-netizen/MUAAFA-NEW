import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator, Image } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Heart, Briefcase, Check } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '@/lib/supabase';
import { validateEmail, parseSupabaseError } from '@/lib/validation-utils';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { syncCart } from '@/lib/cart-utils';
import BrandLogo from '@/components/BrandLogo';
import { AuthStorage } from '@/lib/auth-storage';

export default function LoginScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSavedCredentials();
  }, []);

  async function loadSavedCredentials() {
    try {
      const savedEmail = await AsyncStorage.getItem('savedEmail');
      const shouldRemember = await AsyncStorage.getItem('rememberMe');

      if (savedEmail && shouldRemember === 'true') {
        setEmail(savedEmail);
        setRememberMe(true);
      }
    } catch (error) {
      console.error('Error loading saved credentials:', error);
    }
  }

  async function handleLogin() {
    const trimmedEmail = email.trim();
    const emailValidation = validateEmail(trimmedEmail);
    if (!emailValidation.isValid) {
      Alert.alert('خطأ في البريد الإلكتروني', emailValidation.errorMessage);
      return;
    }

    if (!password) {
      Alert.alert('خطأ', 'كلمة المرور مطلوبة، يرجى إدخالها');
      return;
    }

    if (password.length < 6) {
      Alert.alert('خطأ', 'كلمة المرور قصيرة جداً، يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: trimmedEmail.toLowerCase(),
        password,
      });

      if (error) {
        setLoading(false);
        const errorMsg = parseSupabaseError(error);
        Alert.alert('فشل تسجيل الدخول', `حدث خطأ أثناء محاولة تسجيل الدخول:\n\n${errorMsg}\n\nيرجى التحقق من البريد الإلكتروني وكلمة المرور والمحاولة مرة أخرى`);
        return;
      }

      if (!data.user || !data.session) {
        setLoading(false);
        Alert.alert('خطأ في المصادقة', 'لم يتم إنشاء جلسة صالحة. يرجى المحاولة مرة أخرى');
        return;
      }

      try {
        await AuthStorage.saveAuthToken(data.session.access_token);
      } catch (storageError) {
        console.error('Token storage error:', storageError);
        setLoading(false);
        Alert.alert('خطأ في حفظ البيانات', 'فشل حفظ بيانات الجلسة. يرجى التحقق من المساحة المتاحة والمحاولة مرة أخرى');
        return;
      }

      if (rememberMe) {
        AsyncStorage.setItem('savedEmail', trimmedEmail.toLowerCase()).catch(e => console.log(e));
        AsyncStorage.setItem('rememberMe', 'true').catch(e => console.log(e));
      } else {
        AsyncStorage.removeItem('savedEmail').catch(e => console.log(e));
        AsyncStorage.setItem('rememberMe', 'false').catch(e => console.log(e));
      }

      const { data: userRoleData, error: roleError } = await supabase
        .from('users')
        .select('user_role, full_name')
        .eq('id', data.user.id)
        .maybeSingle();

      if (roleError) {
        console.error('Role fetch error:', roleError);
        setLoading(false);
        Alert.alert('خطأ في جلب البيانات', 'فشل التحقق من نوع المستخدم. يرجى المحاولة مرة أخرى');
        await AuthStorage.clearAuth();
        await supabase.auth.signOut();
        return;
      }

      const userRole = userRoleData?.user_role || 'individual_user';

      try {
        await AuthStorage.saveUserRole(userRole);
        await AuthStorage.saveUserData({
          id: data.user.id,
          email: data.user.email,
          full_name: userRoleData?.full_name,
          role: userRole
        });
      } catch (storageError) {
        console.error('User data storage error:', storageError);
      }

      syncCart().catch(err => console.log('Cart sync error:', err));

      setLoading(false);

      if (userRole === 'owner') {
        router.replace('/owner');
      } else if (userRole === 'business_admin') {
        router.replace('/business/dashboard');
      } else {
        router.replace('/(tabs)');
      }
    } catch (error: any) {
      setLoading(false);
      console.error('Login error:', error);
      const errorMsg = parseSupabaseError(error);
      Alert.alert('خطأ غير متوقع', `حدث خطأ غير متوقع:\n\n${errorMsg}\n\nيرجى المحاولة مرة أخرى. إذا استمرت المشكلة، يرجى التواصل مع الدعم الفني`);
      await AuthStorage.clearAuth();
    }
  }

  return (
    <LinearGradient
      colors={['#ffffff', '#f0f9ff', '#e0f2fe']}
      style={styles.gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Image
            source={require('@/assets/images/icon.png')}
            style={styles.logo}
            resizeMode="contain"
          />
          <Text style={styles.subtitle}>رحلتك الصحية تبدأ من هنا</Text>
        </View>

      <View style={styles.form}>
        <Text style={styles.formTitle}>تسجيل الدخول</Text>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>البريد الإلكتروني</Text>
          <TextInput
            style={styles.input}
            placeholder="example@gmail.com"
            value={email}
            onChangeText={(text) => setEmail(text.trim())}
            keyboardType="email-address"
            autoCapitalize="none"
            textAlign="right"
          />
          <Text style={styles.helpText}>البريد الإلكتروني المسجل في مُعافى</Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>كلمة المرور</Text>
          <TextInput
            style={styles.input}
            placeholder="••••••••"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            textAlign="right"
          />
          <Text style={styles.helpText}>كلمة المرور التي أنشأتها عند التسجيل</Text>
        </View>

        <View style={styles.rememberMeRow}>
          <TouchableOpacity
            style={styles.forgotPasswordButton}
            onPress={() => router.push('/auth/forgot-password')}>
            <Text style={styles.forgotPasswordText}>نسيت كلمة المرور؟</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.rememberMeContainer}
            onPress={() => setRememberMe(!rememberMe)}>
            <View style={[styles.checkbox, rememberMe && styles.checkboxChecked]}>
              {rememberMe && <Check size={16} color="#ffffff" strokeWidth={3} />}
            </View>
            <Text style={styles.rememberMeText}>تذكرني</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={[styles.loginButton, loading && styles.loginButtonDisabled]}
          onPress={handleLogin}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.loginButtonText}>تسجيل الدخول</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.registerButton}
          onPress={() => router.push('/auth/register')}>
          <Text style={styles.registerButtonText}>إنشاء حساب جديد</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.businessButton}
          onPress={() => router.push('/business/login')}>
          <Briefcase size={20} color="#6366f1" strokeWidth={2} />
          <Text style={styles.businessButtonText}>بوابة الأعمال</Text>
        </TouchableOpacity>
      </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            بالمتابعة، أنت توافق على شروط الخدمة وسياسة الخصوصية
          </Text>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  content: {
    padding: 24,
    paddingTop: 80,
  },
  header: {
    alignItems: 'center',
    marginBottom: 60,
    paddingTop: 20,
  },
  logo: {
    width: 240,
    height: 240,
    marginBottom: 32,
  },
  title: {
    fontSize: 48,
    fontWeight: '700',
    color: '#0f172a',
    marginBottom: 4,
    letterSpacing: 1,
  },
  titleEn: {
    fontSize: 32,
    fontWeight: '300',
    color: '#0ea5e9',
    marginBottom: 16,
    letterSpacing: 4,
  },
  subtitle: {
    fontSize: 22,
    fontWeight: '500',
    color: '#0ea5e9',
    letterSpacing: 0.8,
    marginTop: 16,
  },
  form: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 24,
    padding: 32,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 24,
    elevation: 4,
  },
  formTitle: {
    fontSize: 28,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 32,
    textAlign: 'right',
    letterSpacing: 0.5,
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    fontSize: 15,
    fontWeight: '500',
    color: '#64748b',
    marginBottom: 12,
    textAlign: 'right',
    letterSpacing: 0.3,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 16,
    padding: 18,
    fontSize: 16,
    color: '#0f172a',
    fontWeight: '400',
  },
  helpText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
    marginTop: 4,
    lineHeight: 16,
  },
  rememberMeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 8,
  },
  rememberMeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#cbd5e1',
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkboxChecked: {
    backgroundColor: '#0ea5e9',
    borderColor: '#0ea5e9',
  },
  rememberMeText: {
    fontSize: 14,
    color: '#475569',
    fontWeight: '500',
  },
  forgotPasswordButton: {
    marginTop: 0,
    marginBottom: 0,
  },
  forgotPasswordText: {
    color: '#0ea5e9',
    fontSize: 14,
    fontWeight: '600',
  },
  loginButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 20,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  loginButtonDisabled: {
    opacity: 0.6,
  },
  loginButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  registerButton: {
    backgroundColor: 'rgba(241, 245, 249, 0.8)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  registerButtonText: {
    color: '#0ea5e9',
    fontSize: 17,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  businessButton: {
    backgroundColor: 'rgba(238, 242, 255, 0.8)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginTop: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: '#c7d2fe',
  },
  businessButtonText: {
    color: '#6366f1',
    fontSize: 17,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  footer: {
    marginTop: 40,
    marginBottom: 20,
  },
  footerText: {
    fontSize: 13,
    color: '#94a3b8',
    textAlign: 'center',
    lineHeight: 20,
    fontWeight: '400',
    letterSpacing: 0.2,
  },
});
