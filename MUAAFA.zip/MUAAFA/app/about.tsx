import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Stack } from 'expo-router';
import { Heart, Users, Award } from 'lucide-react-native';

export default function AboutScreen() {
  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'من نحن',
          headerStyle: {
            backgroundColor: '#0ea5e9',
          },
          headerTintColor: '#ffffff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      />
      <View style={styles.container}>
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          <View style={styles.heroCard}>
            <Heart size={48} color="#0ea5e9" strokeWidth={2} fill="#0ea5e9" />
            <Text style={styles.heroTitle}>مُعافى | MUAAFA</Text>
            <Text style={styles.heroSubtitle}>رفيقك الصحي الذكي</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>من نحن</Text>
            <Text style={styles.sectionText}>
              مُعافى هو تطبيق صحي متكامل يجمع بين قوة الذكاء الاصطناعي والخبرة الطبية
              المتخصصة لتقديم استشارات صحية شاملة ومتاحة للجميع.
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>رؤيتنا</Text>
            <Text style={styles.sectionText}>
              نسعى لجعل الرعاية الصحية متاحة وسهلة للجميع من خلال التكنولوجيا الحديثة، مع
              الحفاظ على أعلى معايير الجودة والخصوصية.
            </Text>
          </View>

          <View style={styles.section}>
            <View style={styles.featureCard}>
              <Users size={32} color="#10b981" strokeWidth={2} />
              <Text style={styles.featureTitle}>فريق متخصص</Text>
              <Text style={styles.featureText}>
                نعمل مع نخبة من الأطباء المتخصصين في مختلف المجالات الطبية لضمان تقديم أفضل
                الاستشارات
              </Text>
            </View>

            <View style={styles.featureCard}>
              <Award size={32} color="#0ea5e9" strokeWidth={2} />
              <Text style={styles.featureTitle}>جودة مضمونة</Text>
              <Text style={styles.featureText}>
                نلتزم بأعلى معايير الجودة في تقديم الخدمات الصحية مع حماية خصوصية بياناتك
              </Text>
            </View>
          </View>

          <View style={styles.ownerCard}>
            <Text style={styles.ownerTitle}>الملكية وحقوق النشر</Text>
            <Text style={styles.ownerText}>
              جميع الحقوق محفوظة لتطبيق{' '}
              <Text style={styles.ownerName}>مُعافى | MUAAFA</Text>
            </Text>
            <Text style={styles.ownerCopyright}>© 2025 مُعافى - جميع الحقوق محفوظة</Text>
          </View>

          <View style={styles.disclaimerCard}>
            <Text style={styles.disclaimerTitle}>تنويه مهم</Text>
            <Text style={styles.disclaimerText}>
              مُعافى يقدم معلومات صحية عامة واستشارات أولية. لا يعتبر التطبيق بديلاً عن
              الفحص الطبي المباشر أو التشخيص من قبل طبيب مختص. في حالات الطوارئ الطبية، يرجى
              الاتصال بخدمات الطوارئ فوراً.
            </Text>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  heroCard: {
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 32,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  heroTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
    marginBottom: 8,
  },
  heroSubtitle: {
    fontSize: 16,
    color: '#64748b',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  sectionText: {
    fontSize: 16,
    color: '#475569',
    lineHeight: 26,
    textAlign: 'right',
  },
  featureCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  featureTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 12,
    marginBottom: 8,
  },
  featureText: {
    fontSize: 15,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 22,
  },
  ownerCard: {
    backgroundColor: '#e0f2fe',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#7dd3fc',
  },
  ownerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#075985',
    marginBottom: 12,
    textAlign: 'center',
  },
  ownerText: {
    fontSize: 16,
    color: '#0c4a6e',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 12,
  },
  ownerName: {
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  ownerCopyright: {
    fontSize: 14,
    color: '#475569',
    textAlign: 'center',
    fontWeight: '600',
  },
  disclaimerCard: {
    backgroundColor: '#fef3c7',
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: '#fde68a',
  },
  disclaimerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#92400e',
    marginBottom: 12,
    textAlign: 'right',
  },
  disclaimerText: {
    fontSize: 14,
    color: '#92400e',
    textAlign: 'right',
    lineHeight: 22,
  },
});
