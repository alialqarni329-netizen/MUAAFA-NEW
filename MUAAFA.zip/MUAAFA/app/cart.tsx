import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { ShoppingCart, Trash2, Plus, Minus, ChevronRight, Crown } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface CartItem {
  id: string;
  item_type: 'product' | 'subscription';
  item_id: string;
  price: number;
  quantity: number;
  metadata?: any;
  product?: {
    id: string;
    name: string;
    price: number;
    image_url: string;
  };
}

export default function CartScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCart();
  }, []);

  async function loadCart() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('cart_items')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;

      const items = data || [];
      const enrichedItems = await Promise.all(
        items.map(async (item) => {
          if (item.item_type === 'product') {
            const { data: product } = await supabase
              .from('products')
              .select('id, name, price, image_url')
              .eq('id', item.item_id)
              .maybeSingle();
            return { ...item, product };
          }
          return item;
        })
      );

      setCartItems(enrichedItems);
    } catch (error) {
      console.error('Error loading cart:', error);
    } finally {
      setLoading(false);
    }
  }

  async function updateQuantity(itemId: string, newQuantity: number) {
    if (newQuantity < 1) {
      removeItem(itemId);
      return;
    }

    try {
      const { error } = await supabase
        .from('cart_items')
        .update({ quantity: newQuantity })
        .eq('id', itemId);

      if (error) throw error;
      await loadCart();
    } catch (error) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'تعذر تحديث الكمية' : 'Failed to update quantity'
      );
    }
  }

  async function removeItem(itemId: string) {
    try {
      const { error } = await supabase
        .from('cart_items')
        .delete()
        .eq('id', itemId);

      if (error) throw error;
      await loadCart();
    } catch (error) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'تعذر حذف العنصر' : 'Failed to remove item'
      );
    }
  }

  const total = cartItems.reduce((sum, item) => {
    if (item.item_type === 'subscription') {
      return sum + (item.price || 0);
    }
    return sum + ((item.product?.price || item.price) || 0) * item.quantity;
  }, 0);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#10b981" />
      </View>
    );
  }

  const getItemName = (item: CartItem) => {
    if (item.item_type === 'subscription') {
      return item.metadata?.plan_name || (language === 'ar' ? 'اشتراك' : 'Subscription');
    }
    return item.product?.name || item.metadata?.name || (language === 'ar' ? 'منتج' : 'Product');
  };

  const getItemPrice = (item: CartItem) => {
    if (item.item_type === 'subscription') {
      const period = item.metadata?.billing_period;
      const periodText = period === 'yearly'
        ? (language === 'ar' ? '/سنوياً' : '/year')
        : (language === 'ar' ? '/شهرياً' : '/month');
      return `${(item.price || 0).toFixed(2)} ${language === 'ar' ? 'ريال' : 'SAR'}${periodText}`;
    }
    return `${((item.product?.price || item.price) || 0).toFixed(2)} ${language === 'ar' ? 'ريال' : 'SAR'}`;
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>{language === 'ar' ? 'السلة' : 'Cart'}</Text>
      </View>

      <ScrollView style={styles.content}>
        {cartItems.length === 0 ? (
          <View style={styles.emptyState}>
            <ShoppingCart size={64} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {language === 'ar' ? 'السلة فارغة' : 'Cart is empty'}
            </Text>
          </View>
        ) : (
          <>
            {cartItems.map((item) => (
              <View key={item.id} style={styles.cartItem}>
                {item.item_type === 'subscription' && (
                  <View style={styles.subscriptionBadge}>
                    <Crown size={14} color="#f59e0b" strokeWidth={2} />
                    <Text style={styles.subscriptionBadgeText}>
                      {language === 'ar' ? 'اشتراك' : 'Subscription'}
                    </Text>
                  </View>
                )}
                <View style={styles.itemInfo}>
                  <Text style={styles.itemName}>{getItemName(item)}</Text>
                  <Text style={styles.itemPrice}>{getItemPrice(item)}</Text>
                </View>
                <View style={styles.itemActions}>
                  {item.item_type === 'product' ? (
                    <>
                      <TouchableOpacity onPress={() => updateQuantity(item.id, item.quantity - 1)}>
                        <Minus size={20} color="#64748b" strokeWidth={2} />
                      </TouchableOpacity>
                      <Text style={styles.quantity}>{item.quantity}</Text>
                      <TouchableOpacity onPress={() => updateQuantity(item.id, item.quantity + 1)}>
                        <Plus size={20} color="#64748b" strokeWidth={2} />
                      </TouchableOpacity>
                    </>
                  ) : (
                    <View style={styles.subscriptionLabel}>
                      <Text style={styles.subscriptionLabelText}>1x</Text>
                    </View>
                  )}
                  <TouchableOpacity onPress={() => removeItem(item.id)} style={styles.deleteButton}>
                    <Trash2 size={20} color="#ef4444" strokeWidth={2} />
                  </TouchableOpacity>
                </View>
              </View>
            ))}

            <View style={styles.totalCard}>
              <Text style={styles.totalLabel}>
                {language === 'ar' ? 'المجموع:' : 'Total:'}
              </Text>
              <Text style={styles.totalAmount}>
                {total.toFixed(2)} {language === 'ar' ? 'ريال' : 'SAR'}
              </Text>
            </View>

            <TouchableOpacity
              style={styles.checkoutButton}
              onPress={() => router.push('/checkout')}>
              <Text style={styles.checkoutButtonText}>
                {language === 'ar' ? 'إتمام الطلب' : 'Checkout'}
              </Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
    gap: 16,
  },
  emptyText: {
    fontSize: 18,
    color: '#64748b',
  },
  cartItem: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  itemPrice: {
    fontSize: 14,
    color: '#0ea5e9',
    textAlign: 'right',
  },
  itemActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  quantity: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    minWidth: 30,
    textAlign: 'center',
  },
  deleteButton: {
    marginLeft: 8,
  },
  subscriptionBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#fef3c7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    zIndex: 1,
  },
  subscriptionBadgeText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#92400e',
  },
  subscriptionLabel: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#f1f5f9',
    borderRadius: 8,
  },
  subscriptionLabelText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  totalCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    marginTop: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  totalAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#10b981',
  },
  checkoutButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  checkoutButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
