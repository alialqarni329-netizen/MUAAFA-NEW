import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { CheckCircle, Package } from 'lucide-react-native';

export default function OrderSuccessScreen() {
  const router = useRouter();
  const { orderNumber } = useLocalSearchParams();

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <CheckCircle size={80} color="#10b981" strokeWidth={2} />
        </View>

        <Text style={styles.title}>تم إتمام الطلب بنجاح!</Text>
        <Text style={styles.subtitle}>شكراً لك على طلبك</Text>

        <View style={styles.orderCard}>
          <Package size={24} color="#0ea5e9" strokeWidth={2} />
          <Text style={styles.orderLabel}>رقم الطلب</Text>
          <Text style={styles.orderNumber}>{orderNumber}</Text>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoText}>• سيتم معالجة طلبك خلال 24 ساعة</Text>
          <Text style={styles.infoText}>• سيتم إرسال إشعار عند شحن الطلب</Text>
          <Text style={styles.infoText}>• يمكنك تتبع طلبك من سجل الطلبات</Text>
        </View>

        <TouchableOpacity
          style={styles.trackButton}
          onPress={() => router.push(`/track-order?orderNumber=${orderNumber}`)}>
          <Text style={styles.trackButtonText}>تتبع الطلب</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.homeButton}
          onPress={() => router.replace('/(tabs)')}>
          <Text style={styles.homeButtonText}>العودة للرئيسية</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    flex: 1,
    padding: 24,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 20,
  },
  iconContainer: {
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#10b981',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
  },
  orderCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginTop: 20,
    width: '100%',
  },
  orderLabel: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 8,
  },
  orderNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  infoCard: {
    backgroundColor: '#d1fae5',
    borderRadius: 12,
    padding: 16,
    gap: 8,
    width: '100%',
  },
  infoText: {
    fontSize: 14,
    color: '#065f46',
    textAlign: 'right',
    lineHeight: 22,
  },
  trackButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    width: '100%',
    marginTop: 20,
  },
  trackButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  homeButton: {
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    width: '100%',
  },
  homeButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
});
