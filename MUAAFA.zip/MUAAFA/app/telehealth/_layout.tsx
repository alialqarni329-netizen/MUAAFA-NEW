import { Stack } from 'expo-router/stack';

export default function TelehealthLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen name="book-appointment" />
      <Stack.Screen name="waiting-room" />
      <Stack.Screen name="post-session" />
    </Stack>
  );
}
