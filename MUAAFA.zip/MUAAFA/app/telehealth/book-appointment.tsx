import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { Video, MessageSquare, Calendar, Clock, ChevronRight } from 'lucide-react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Platform } from 'react-native';
import { scheduleAppointmentReminder, logNotification } from '@/lib/notifications';

interface Doctor {
  id: string;
  full_name: string;
  specialty: string;
  bio: string;
  rating?: number;
  is_available?: boolean;
}

export default function BookAppointmentScreen() {
  const router = useRouter();
  const { language } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [appointmentType, setAppointmentType] = useState<'video' | 'chat'>('video');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState('10:00');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [reason, setReason] = useState('');
  const [platform, setPlatform] = useState<'zoom' | 'teams'>('zoom');

  useEffect(() => {
    loadDoctors();
  }, []);

  async function loadDoctors() {
    try {
      const { data, error } = await supabase
        .from('doctors')
        .select('*')
        .eq('is_available', true)
        .order('full_name');

      if (data) {
        setDoctors(data);
        if (data.length > 0) {
          setSelectedDoctor(data[0]);
        }
      }
    } catch (error) {
      console.error('Error loading doctors:', error);
    }
  }

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30',
    '17:00', '17:30', '18:00', '18:30', '19:00', '19:30'
  ];

  async function handleBookAppointment() {
    if (!selectedDoctor) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'الرجاء اختيار طبيب' : 'Please select a doctor'
      );
      return;
    }

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const dateStr = selectedDate.toISOString().split('T')[0];

      let appointmentStatus = 'scheduled';
      let meetingCreated = false;

      const { data: appointment, error: appointmentError } = await supabase
        .from('appointments')
        .insert({
          user_id: user.id,
          doctor_id: selectedDoctor.id,
          appointment_type: appointmentType,
          scheduled_date: dateStr,
          scheduled_time: selectedTime,
          reason_for_visit: reason,
          status: appointmentStatus,
          privacy_consent_accepted: false,
        })
        .select()
        .single();

      if (appointmentError) throw appointmentError;

      if (appointmentType === 'video') {
        try {
          const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/create-meeting`;
          const { data: { session } } = await supabase.auth.getSession();

          const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${session?.access_token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              appointmentId: appointment.id,
              platform: platform,
              scheduledDate: dateStr,
              scheduledTime: selectedTime,
              duration: 30,
              topic: `${language === 'ar' ? 'استشارة طبية مع' : 'Medical Consultation with'} ${selectedDoctor.full_name}`,
            }),
          });

          if (response.ok) {
            meetingCreated = true;
          } else {
            await supabase
              .from('appointments')
              .update({ status: 'pending' })
              .eq('id', appointment.id);
            appointmentStatus = 'pending';
          }
        } catch (meetingError) {
          await supabase
            .from('appointments')
            .update({ status: 'pending' })
            .eq('id', appointment.id);
          appointmentStatus = 'pending';
        }
      }

      const [hours, minutes] = selectedTime.split(':').map(Number);
      const appointmentDateTime = new Date(selectedDate);
      appointmentDateTime.setHours(hours, minutes, 0, 0);

      try {
        await scheduleAppointmentReminder(
          selectedDoctor.full_name,
          appointmentDateTime,
          appointment.id
        );
      } catch (reminderError) {
      }

      try {
        await logNotification(
          user.id,
          'appointment',
          language === 'ar' ? 'تم حجز موعد جديد' : 'New Appointment Booked',
          `${language === 'ar' ? 'موعدك مع' : 'Your appointment with'} ${selectedDoctor.full_name} ${language === 'ar' ? 'في' : 'at'} ${selectedTime}`,
          { appointmentId: appointment.id }
        );
      } catch (notificationError) {
      }

      const successMessage = appointmentStatus === 'pending'
        ? language === 'ar'
          ? 'تم تأكيد حجزك بنجاح. سيتم تزويدك برابط الجلسة قريباً عبر الإشعارات.'
          : 'Your booking has been confirmed successfully. You will receive the session link shortly via notifications.'
        : language === 'ar'
          ? 'تم حجز موعدك بنجاح. سنرسل لك تذكيراً قبل الموعد بساعة.'
          : 'Your appointment has been booked successfully. We will send you a reminder 1 hour before the appointment.';

      Alert.alert(
        language === 'ar' ? 'تم الحجز بنجاح' : 'Booking Successful',
        successMessage,
        [
          {
            text: language === 'ar' ? 'حسناً' : 'OK',
            onPress: () => router.back(),
          },
        ]
      );
    } catch (error: any) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'فشل حجز الموعد' : 'Failed to book appointment')
      );
    } finally {
      setLoading(false);
    }
  }

  const onDateChange = (event: any, date?: Date) => {
    setShowDatePicker(Platform.OS === 'ios');
    if (date) {
      setSelectedDate(date);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronRight size={24} color="#ffffff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'حجز موعد جديد' : 'Book New Appointment'}
        </Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'نوع الجلسة' : 'Session Type'}
          </Text>
          <View style={styles.typeContainer}>
            <TouchableOpacity
              style={[styles.typeCard, appointmentType === 'video' && styles.typeCardActive]}
              onPress={() => setAppointmentType('video')}
            >
              <Video
                size={32}
                color={appointmentType === 'video' ? '#8b5cf6' : '#64748b'}
                strokeWidth={2}
              />
              <Text style={[styles.typeText, appointmentType === 'video' && styles.typeTextActive]}>
                {language === 'ar' ? 'جلسة فيديو' : 'Video Session'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.typeCard, appointmentType === 'chat' && styles.typeCardActive]}
              onPress={() => setAppointmentType('chat')}
            >
              <MessageSquare
                size={32}
                color={appointmentType === 'chat' ? '#8b5cf6' : '#64748b'}
                strokeWidth={2}
              />
              <Text style={[styles.typeText, appointmentType === 'chat' && styles.typeTextActive]}>
                {language === 'ar' ? 'محادثة نصية' : 'Text Chat'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {appointmentType === 'video' && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>
              {language === 'ar' ? 'منصة الاجتماع' : 'Meeting Platform'}
            </Text>
            <View style={styles.platformContainer}>
              <TouchableOpacity
                style={[styles.platformButton, platform === 'zoom' && styles.platformButtonActive]}
                onPress={() => setPlatform('zoom')}
              >
                <Text style={[styles.platformText, platform === 'zoom' && styles.platformTextActive]}>
                  Zoom
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.platformButton, platform === 'teams' && styles.platformButtonActive]}
                onPress={() => setPlatform('teams')}
              >
                <Text style={[styles.platformText, platform === 'teams' && styles.platformTextActive]}>
                  Microsoft Teams
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'اختر طبيباً' : 'Select Doctor'}
          </Text>
          {doctors.map((doctor) => (
            <TouchableOpacity
              key={doctor.id}
              style={[
                styles.doctorCard,
                selectedDoctor?.id === doctor.id && styles.doctorCardActive,
              ]}
              onPress={() => setSelectedDoctor(doctor)}
            >
              <View style={styles.doctorInfo}>
                <Text style={styles.doctorName}>{doctor.full_name}</Text>
                <Text style={styles.doctorSpecialty}>{doctor.specialty}</Text>
                {doctor.rating && (
                  <Text style={styles.doctorRating}>
                    ⭐ {doctor.rating.toFixed(1)}
                  </Text>
                )}
              </View>
              {selectedDoctor?.id === doctor.id && (
                <View style={styles.selectedBadge}>
                  <Text style={styles.selectedText}>✓</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'التاريخ والوقت' : 'Date & Time'}
          </Text>

          <TouchableOpacity
            style={styles.dateButton}
            onPress={() => setShowDatePicker(true)}
          >
            <Calendar size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.dateButtonText}>
              {selectedDate.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </Text>
          </TouchableOpacity>

          {showDatePicker && (
            <DateTimePicker
              value={selectedDate}
              mode="date"
              display="default"
              onChange={onDateChange}
              minimumDate={new Date()}
            />
          )}

          <View style={styles.timeSlots}>
            {timeSlots.map((time) => (
              <TouchableOpacity
                key={time}
                style={[styles.timeSlot, selectedTime === time && styles.timeSlotActive]}
                onPress={() => setSelectedTime(time)}
              >
                <Text style={[styles.timeSlotText, selectedTime === time && styles.timeSlotTextActive]}>
                  {time}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <TouchableOpacity
          style={[styles.bookButton, loading && styles.bookButtonDisabled]}
          onPress={handleBookAppointment}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#ffffff" />
          ) : (
            <Text style={styles.bookButtonText}>
              {language === 'ar' ? 'تأكيد الحجز' : 'Confirm Booking'}
            </Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#8b5cf6',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    marginLeft: 8,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    flex: 1,
    textAlign: 'right',
    marginRight: 8,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  typeContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  typeCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  typeCardActive: {
    borderColor: '#8b5cf6',
    backgroundColor: '#f5f3ff',
  },
  typeText: {
    marginTop: 8,
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  typeTextActive: {
    color: '#8b5cf6',
  },
  platformContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  platformButton: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  platformButtonActive: {
    borderColor: '#8b5cf6',
    backgroundColor: '#f5f3ff',
  },
  platformText: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  platformTextActive: {
    color: '#8b5cf6',
  },
  doctorCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  doctorCardActive: {
    borderColor: '#8b5cf6',
    backgroundColor: '#f5f3ff',
  },
  doctorInfo: {
    flex: 1,
  },
  doctorName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  doctorSpecialty: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
    marginBottom: 4,
  },
  doctorRating: {
    fontSize: 12,
    color: '#f59e0b',
    textAlign: 'right',
    fontWeight: '600',
  },
  selectedBadge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#8b5cf6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  dateButton: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  dateButtonText: {
    fontSize: 14,
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  timeSlots: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  timeSlot: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  timeSlotActive: {
    borderColor: '#8b5cf6',
    backgroundColor: '#f5f3ff',
  },
  timeSlotText: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  timeSlotTextActive: {
    color: '#8b5cf6',
  },
  bookButton: {
    backgroundColor: '#8b5cf6',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  bookButtonDisabled: {
    opacity: 0.6,
  },
  bookButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
