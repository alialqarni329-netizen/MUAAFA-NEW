import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, Modal } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { Video, Heart, Activity, CheckCircle, XCircle, Clock, Share2 } from 'lucide-react-native';
import * as Linking from 'expo-linking';
import * as WebBrowser from 'expo-web-browser';

interface Appointment {
  id: string;
  scheduled_date: string;
  scheduled_time: string;
  meeting_url: string;
  meeting_platform: string;
  reason_for_visit: string;
  medical_brief_sent: boolean;
  privacy_consent_accepted: boolean;
  doctors: {
    full_name: string;
    specialty: string;
  };
}

const healthTips = {
  ar: [
    'تأكد من وجودك في مكان هادئ وجيد الإضاءة',
    'جهز قائمة بالأسئلة التي تريد طرحها على الطبيب',
    'احتفظ بقائمة الأدوية الحالية في متناول يدك',
    'تأكد من استقرار اتصالك بالإنترنت',
    'اشرح أعراضك بوضوح ودقة للطبيب',
  ],
  en: [
    'Make sure you are in a quiet and well-lit place',
    'Prepare a list of questions you want to ask the doctor',
    'Keep your current medication list handy',
    'Ensure your internet connection is stable',
    'Explain your symptoms clearly and accurately to the doctor',
  ],
};

export default function WaitingRoomScreen() {
  const router = useRouter();
  const { appointmentId } = useLocalSearchParams();
  const { language } = useLanguage();
  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showBriefModal, setShowBriefModal] = useState(false);
  const [generatingBrief, setGeneratingBrief] = useState(false);
  const [canJoin, setCanJoin] = useState(false);

  useEffect(() => {
    loadAppointment();
    const tipInterval = setInterval(() => {
      setCurrentTipIndex((prev) => (prev + 1) % healthTips[language].length);
    }, 5000);

    return () => clearInterval(tipInterval);
  }, [appointmentId, language]);

  async function loadAppointment() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('appointments')
        .select(`
          *,
          doctors (
            full_name,
            specialty
          )
        `)
        .eq('id', appointmentId)
        .eq('user_id', user.id)
        .single();

      if (data) {
        setAppointment(data as any);
        setShowPrivacyModal(!data.privacy_consent_accepted);
        checkIfCanJoin(data);
      }
    } catch (error) {
      console.error('Error loading appointment:', error);
    } finally {
      setLoading(false);
    }
  }

  function checkIfCanJoin(apt: any) {
    const now = new Date();
    const appointmentDateTime = new Date(`${apt.scheduled_date}T${apt.scheduled_time}`);
    const timeDiff = appointmentDateTime.getTime() - now.getTime();
    const minutesDiff = Math.floor(timeDiff / 1000 / 60);

    setCanJoin(minutesDiff <= 15 && minutesDiff >= -30);
  }

  async function handleAcceptPrivacy() {
    try {
      const { error } = await supabase
        .from('appointments')
        .update({
          privacy_consent_accepted: true,
          privacy_consent_at: new Date().toISOString(),
        })
        .eq('id', appointmentId);

      if (!error) {
        setShowPrivacyModal(false);
        if (appointment) {
          setAppointment({ ...appointment, privacy_consent_accepted: true });
        }
      }
    } catch (error) {
      console.error('Error accepting privacy:', error);
    }
  }

  async function handleGenerateBrief() {
    setGeneratingBrief(true);
    try {
      const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/generate-medical-brief`;
      const { data: { session } } = await supabase.auth.getSession();

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          appointmentId: appointmentId,
          includeChat: true,
          includeFitness: true,
          includeMedicalHistory: true,
        }),
      });

      if (response.ok) {
        setShowBriefModal(false);
        Alert.alert(
          language === 'ar' ? 'نجح' : 'Success',
          language === 'ar'
            ? 'تم إرسال موجز مُعافى للطبيب بنجاح'
            : 'Muafa brief sent to doctor successfully'
        );
        loadAppointment();
      } else {
        throw new Error('Failed to generate brief');
      }
    } catch (error) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar'
          ? 'فشل في إنشاء الموجز الطبي'
          : 'Failed to generate medical brief'
      );
    } finally {
      setGeneratingBrief(false);
    }
  }

  async function handleJoinSession() {
    if (!appointment?.meeting_url) {
      Alert.alert(
        language === 'ar' ? 'قيد المعالجة' : 'Processing',
        language === 'ar'
          ? 'رابط الجلسة قيد الإعداد. سيتم إشعارك فور توفر الرابط. يرجى المحاولة مرة أخرى لاحقاً أو التحقق من الإشعارات.'
          : 'The session link is being prepared. You will be notified once the link is available. Please try again later or check your notifications.'
      );
      return;
    }

    try {
      await supabase
        .from('appointments')
        .update({
          joined_at: new Date().toISOString(),
          status: 'in_progress',
        })
        .eq('id', appointmentId);

      const canOpen = await Linking.canOpenURL(appointment.meeting_url);

      if (canOpen) {
        await Linking.openURL(appointment.meeting_url);
      } else {
        await WebBrowser.openBrowserAsync(appointment.meeting_url);
      }
    } catch (error) {
      console.error('Error joining session:', error);
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar'
          ? 'فشل في فتح الاجتماع. يرجى التحقق من اتصالك بالإنترنت والمحاولة مرة أخرى.'
          : 'Failed to open meeting. Please check your internet connection and try again.'
      );
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#8b5cf6" />
      </View>
    );
  }

  if (!appointment) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>
          {language === 'ar' ? 'لم يتم العثور على الموعد' : 'Appointment not found'}
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'غرفة الانتظار' : 'Waiting Room'}
        </Text>
        <Text style={styles.headerSubtitle}>
          {language === 'ar' ? 'جلستك قريباً' : 'Your session is coming up'}
        </Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.appointmentCard}>
          <View style={styles.doctorSection}>
            <Text style={styles.doctorName}>{appointment.doctors.full_name}</Text>
            <Text style={styles.doctorSpecialty}>{appointment.doctors.specialty}</Text>
          </View>

          <View style={styles.timeSection}>
            <Clock size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.timeText}>
              {new Date(`${appointment.scheduled_date}T${appointment.scheduled_time}`).toLocaleString(
                language === 'ar' ? 'ar-SA' : 'en-US',
                {
                  weekday: 'short',
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                }
              )}
            </Text>
          </View>

          {!appointment.meeting_url && (
            <View style={styles.pendingBanner}>
              <Activity size={16} color="#f59e0b" strokeWidth={2} />
              <Text style={styles.pendingText}>
                {language === 'ar'
                  ? 'جاري إعداد رابط الجلسة...'
                  : 'Session link is being prepared...'}
              </Text>
            </View>
          )}
        </View>

        <View style={styles.tipsCard}>
          <View style={styles.tipsHeader}>
            <Activity size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.tipsTitle}>
              {language === 'ar' ? 'نصائح مهمة' : 'Important Tips'}
            </Text>
          </View>
          <Text style={styles.tipText}>{healthTips[language][currentTipIndex]}</Text>
          <View style={styles.tipIndicators}>
            {healthTips[language].map((_, index) => (
              <View
                key={index}
                style={[
                  styles.tipIndicator,
                  index === currentTipIndex && styles.tipIndicatorActive,
                ]}
              />
            ))}
          </View>
        </View>

        {!appointment.medical_brief_sent && (
          <TouchableOpacity
            style={styles.briefCard}
            onPress={() => setShowBriefModal(true)}
          >
            <Share2 size={24} color="#8b5cf6" strokeWidth={2} />
            <View style={styles.briefContent}>
              <Text style={styles.briefTitle}>
                {language === 'ar' ? 'مشاركة موجز مُعافى' : 'Share Muafa Brief'}
              </Text>
              <Text style={styles.briefDescription}>
                {language === 'ar'
                  ? 'شارك ملخصاً ذكياً عن حالتك مع الطبيب قبل الجلسة'
                  : 'Share an intelligent summary of your condition with the doctor before the session'}
              </Text>
            </View>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
          </TouchableOpacity>
        )}

        {appointment.medical_brief_sent && (
          <View style={styles.briefSentCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.briefSentText}>
              {language === 'ar'
                ? 'تم إرسال موجز مُعافى للطبيب'
                : 'Muafa brief sent to doctor'}
            </Text>
          </View>
        )}

        <View style={styles.checksSection}>
          <Text style={styles.checksTitle}>
            {language === 'ar' ? 'جاهز للجلسة' : 'Ready for Session'}
          </Text>
          <View style={styles.checkItem}>
            <CheckCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.checkText}>
              {language === 'ar' ? 'الاتصال بالإنترنت' : 'Internet Connection'}
            </Text>
          </View>
          <View style={styles.checkItem}>
            <CheckCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.checkText}>
              {language === 'ar' ? 'الموافقة على الخصوصية' : 'Privacy Consent'}
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={[styles.joinButton, !canJoin && styles.joinButtonDisabled]}
          onPress={handleJoinSession}
          disabled={!canJoin}
        >
          <Video size={24} color="#ffffff" strokeWidth={2} />
          <Text style={styles.joinButtonText}>
            {canJoin
              ? language === 'ar'
                ? 'انضم إلى العيادة الآن'
                : 'Join Clinic Now'
              : language === 'ar'
              ? 'سيتم تفعيل الزر قبل 15 دقيقة من الموعد'
              : 'Button will activate 15 minutes before appointment'}
          </Text>
        </TouchableOpacity>
      </ScrollView>

      <Modal visible={showPrivacyModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {language === 'ar' ? 'إقرار الخصوصية' : 'Privacy Consent'}
            </Text>
            <Text style={styles.modalText}>
              {language === 'ar'
                ? 'أفهم أن هذه الجلسة تتم عبر منصة خارجية (Zoom/Teams) وأن بياناتي الطبية محمية بموجب سياسة خصوصية مُعافى. أوافق على إجراء هذه الجلسة وفقاً لشروط الخدمة.'
                : 'I understand that this session is conducted via an external platform (Zoom/Teams) and that my medical data is protected under Muafa privacy policy. I agree to conduct this session according to the terms of service.'}
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.acceptButton} onPress={handleAcceptPrivacy}>
                <Text style={styles.acceptButtonText}>
                  {language === 'ar' ? 'أوافق' : 'I Agree'}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.declineButton}
                onPress={() => router.back()}
              >
                <Text style={styles.declineButtonText}>
                  {language === 'ar' ? 'رفض' : 'Decline'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showBriefModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {language === 'ar' ? 'مشاركة موجز مُعافى' : 'Share Muafa Brief'}
            </Text>
            <Text style={styles.modalText}>
              {language === 'ar'
                ? 'سيتم مشاركة ملخص ذكي يتضمن:\n\n• آخر محادثاتك مع البوت الذكي\n• المؤشرات الحيوية من تبويب الفتنس\n• تاريخك الطبي والأدوية الحالية\n\nهذا سيساعد الطبيب على فهم حالتك بشكل أفضل قبل بدء الجلسة.'
                : 'An intelligent summary will be shared including:\n\n• Your recent conversations with the AI bot\n• Vital signs from the fitness tab\n• Your medical history and current medications\n\nThis will help the doctor better understand your condition before the session starts.'}
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.acceptButton}
                onPress={handleGenerateBrief}
                disabled={generatingBrief}
              >
                {generatingBrief ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.acceptButtonText}>
                    {language === 'ar' ? 'مشاركة الموجز' : 'Share Brief'}
                  </Text>
                )}
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.declineButton}
                onPress={() => setShowBriefModal(false)}
              >
                <Text style={styles.declineButtonText}>
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#8b5cf6',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'right',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#ddd6fe',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  appointmentCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  doctorSection: {
    marginBottom: 16,
  },
  doctorName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  doctorSpecialty: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'right',
  },
  timeSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  timeText: {
    fontSize: 14,
    color: '#475569',
  },
  pendingBanner: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
    backgroundColor: '#fffbeb',
    padding: 12,
    borderRadius: 8,
  },
  pendingText: {
    fontSize: 13,
    color: '#f59e0b',
    fontWeight: '600',
  },
  tipsCard: {
    backgroundColor: '#f5f3ff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  tipsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
    marginBottom: 12,
  },
  tipsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#8b5cf6',
  },
  tipText: {
    fontSize: 16,
    color: '#0f172a',
    textAlign: 'right',
    lineHeight: 24,
    marginBottom: 12,
  },
  tipIndicators: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  tipIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ddd6fe',
  },
  tipIndicatorActive: {
    backgroundColor: '#8b5cf6',
    width: 24,
  },
  briefCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#8b5cf6',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  briefContent: {
    flex: 1,
  },
  briefTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  briefDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  briefSentCard: {
    backgroundColor: '#f0fdf4',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#86efac',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
  },
  briefSentText: {
    fontSize: 14,
    color: '#166534',
    fontWeight: '600',
  },
  checksSection: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  checksTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 12,
  },
  checkItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 8,
    marginBottom: 8,
  },
  checkText: {
    fontSize: 14,
    color: '#475569',
  },
  joinButton: {
    backgroundColor: '#8b5cf6',
    borderRadius: 12,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  joinButtonDisabled: {
    backgroundColor: '#94a3b8',
  },
  joinButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  errorText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    marginTop: 40,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 16,
  },
  modalText: {
    fontSize: 16,
    color: '#475569',
    textAlign: 'right',
    lineHeight: 24,
    marginBottom: 24,
  },
  modalButtons: {
    gap: 12,
  },
  acceptButton: {
    backgroundColor: '#8b5cf6',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  acceptButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  declineButton: {
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  declineButtonText: {
    color: '#64748b',
    fontSize: 16,
    fontWeight: '600',
  },
});
