import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { FileText, Star, CheckCircle, Calendar, Upload } from 'lucide-react-native';
import * as DocumentPicker from 'expo-image-picker';

interface Appointment {
  id: string;
  doctor_id: string;
  scheduled_date: string;
  scheduled_time: string;
  doctors: {
    full_name: string;
    specialty: string;
  };
}

export default function PostSessionScreen() {
  const router = useRouter();
  const { appointmentId } = useLocalSearchParams();
  const { language } = useLanguage();
  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [treatmentPlan, setTreatmentPlan] = useState('');
  const [prescriptions, setPrescriptions] = useState<string[]>([]);
  const [followUpRequired, setFollowUpRequired] = useState(false);
  const [followUpDate, setFollowUpDate] = useState('');

  useEffect(() => {
    loadAppointment();
  }, [appointmentId]);

  async function loadAppointment() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('appointments')
        .select(`
          *,
          doctors (
            full_name,
            specialty
          )
        `)
        .eq('id', appointmentId)
        .eq('user_id', user.id)
        .single();

      if (data) {
        setAppointment(data as any);
      }
    } catch (error) {
      console.error('Error loading appointment:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit() {
    if (rating === 0) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'الرجاء تقييم الجلسة' : 'Please rate the session'
      );
      return;
    }

    setSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || !appointment) return;

      const { error: sessionError } = await supabase
        .from('post_session_notes')
        .insert({
          appointment_id: appointmentId,
          user_id: user.id,
          doctor_id: appointment.doctor_id,
          diagnosis: diagnosis,
          treatment_plan: treatmentPlan,
          prescriptions: prescriptions.map(p => ({ medication: p })),
          follow_up_required: followUpRequired,
          follow_up_date: followUpDate || null,
          patient_rating: rating,
          patient_feedback: feedback,
        });

      if (sessionError) throw sessionError;

      await supabase
        .from('appointments')
        .update({
          status: 'completed',
          ended_at: new Date().toISOString(),
        })
        .eq('id', appointmentId);

      Alert.alert(
        language === 'ar' ? 'شكراً' : 'Thank You',
        language === 'ar'
          ? 'تم حفظ ملاحظات الجلسة بنجاح. سنقوم بتحويل التوصيات إلى مهام في تقويمك.'
          : 'Session notes saved successfully. We will convert recommendations into tasks in your calendar.',
        [
          {
            text: language === 'ar' ? 'حسناً' : 'OK',
            onPress: () => router.push('/(tabs)/sessions'),
          },
        ]
      );
    } catch (error: any) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'فشل حفظ الملاحظات' : 'Failed to save notes')
      );
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#8b5cf6" />
      </View>
    );
  }

  if (!appointment) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>
          {language === 'ar' ? 'لم يتم العثور على الموعد' : 'Appointment not found'}
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'متابعة بعد الجلسة' : 'Post-Session Follow-up'}
        </Text>
        <Text style={styles.headerSubtitle}>
          {language === 'ar' ? 'شاركنا تفاصيل جلستك' : 'Share your session details'}
        </Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.doctorCard}>
          <Text style={styles.doctorName}>{appointment.doctors.full_name}</Text>
          <Text style={styles.doctorSpecialty}>{appointment.doctors.specialty}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'قيّم الجلسة' : 'Rate Session'}
          </Text>
          <View style={styles.ratingContainer}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity
                key={star}
                onPress={() => setRating(star)}
                style={styles.starButton}
              >
                <Star
                  size={40}
                  color={star <= rating ? '#fbbf24' : '#e2e8f0'}
                  fill={star <= rating ? '#fbbf24' : 'transparent'}
                  strokeWidth={2}
                />
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'ملاحظاتك' : 'Your Feedback'}
          </Text>
          <TextInput
            style={styles.textArea}
            placeholder={
              language === 'ar'
                ? 'شارك تجربتك مع الطبيب...'
                : 'Share your experience with the doctor...'
            }
            placeholderTextColor="#94a3b8"
            value={feedback}
            onChangeText={setFeedback}
            multiline
            numberOfLines={4}
            textAlign="right"
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'التشخيص' : 'Diagnosis'}
          </Text>
          <Text style={styles.helpText}>
            {language === 'ar'
              ? 'اكتب التشخيص الذي أخبرك به الطبيب'
              : 'Write the diagnosis the doctor told you'}
          </Text>
          <TextInput
            style={styles.textArea}
            placeholder={language === 'ar' ? 'التشخيص...' : 'Diagnosis...'}
            placeholderTextColor="#94a3b8"
            value={diagnosis}
            onChangeText={setDiagnosis}
            multiline
            numberOfLines={3}
            textAlign="right"
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'الخطة العلاجية' : 'Treatment Plan'}
          </Text>
          <Text style={styles.helpText}>
            {language === 'ar'
              ? 'اكتب التوصيات والخطة العلاجية'
              : 'Write recommendations and treatment plan'}
          </Text>
          <TextInput
            style={styles.textArea}
            placeholder={
              language === 'ar'
                ? 'الخطة العلاجية والتوصيات...'
                : 'Treatment plan and recommendations...'
            }
            placeholderTextColor="#94a3b8"
            value={treatmentPlan}
            onChangeText={setTreatmentPlan}
            multiline
            numberOfLines={4}
            textAlign="right"
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {language === 'ar' ? 'الأدوية الموصوفة' : 'Prescribed Medications'}
          </Text>
          {prescriptions.map((prescription, index) => (
            <View key={index} style={styles.prescriptionItem}>
              <Text style={styles.prescriptionText}>{prescription}</Text>
            </View>
          ))}
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => {
              Alert.prompt(
                language === 'ar' ? 'إضافة دواء' : 'Add Medication',
                language === 'ar' ? 'اسم الدواء' : 'Medication name',
                (text) => {
                  if (text) {
                    setPrescriptions([...prescriptions, text]);
                  }
                }
              );
            }}
          >
            <Text style={styles.addButtonText}>
              {language === 'ar' ? '+ إضافة دواء' : '+ Add Medication'}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <TouchableOpacity
            style={styles.followUpCard}
            onPress={() => setFollowUpRequired(!followUpRequired)}
          >
            <View style={styles.checkboxContainer}>
              <View
                style={[
                  styles.checkbox,
                  followUpRequired && styles.checkboxChecked,
                ]}
              >
                {followUpRequired && <CheckCircle size={20} color="#ffffff" strokeWidth={3} />}
              </View>
            </View>
            <Text style={styles.followUpText}>
              {language === 'ar'
                ? 'هل تحتاج لمتابعة مع الطبيب؟'
                : 'Do you need follow-up with the doctor?'}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.aiInfoCard}>
          <FileText size={24} color="#8b5cf6" strokeWidth={2} />
          <Text style={styles.aiInfoText}>
            {language === 'ar'
              ? 'سيقوم الذكاء الاصطناعي بتحويل الخطة العلاجية إلى مهام تذكيرية في تقويمك'
              : 'AI will convert the treatment plan into reminder tasks in your calendar'}
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.submitButton, submitting && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={submitting}
        >
          {submitting ? (
            <ActivityIndicator color="#ffffff" />
          ) : (
            <Text style={styles.submitButtonText}>
              {language === 'ar' ? 'حفظ الملاحظات' : 'Save Notes'}
            </Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#8b5cf6',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'right',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#ddd6fe',
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  doctorCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  doctorName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  doctorSpecialty: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  helpText: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
  },
  starButton: {
    padding: 4,
  },
  textArea: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    fontSize: 16,
    color: '#0f172a',
    minHeight: 100,
  },
  prescriptionItem: {
    backgroundColor: '#f1f5f9',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  prescriptionText: {
    fontSize: 14,
    color: '#0f172a',
    textAlign: 'right',
  },
  addButton: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 12,
    borderWidth: 2,
    borderColor: '#8b5cf6',
    borderStyle: 'dashed',
    alignItems: 'center',
  },
  addButtonText: {
    fontSize: 14,
    color: '#8b5cf6',
    fontWeight: '600',
  },
  followUpCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 12,
  },
  checkboxContainer: {
    marginLeft: 12,
  },
  checkbox: {
    width: 28,
    height: 28,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#cbd5e1',
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: {
    backgroundColor: '#8b5cf6',
    borderColor: '#8b5cf6',
  },
  followUpText: {
    fontSize: 16,
    color: '#0f172a',
    fontWeight: '600',
  },
  aiInfoCard: {
    backgroundColor: '#f5f3ff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  aiInfoText: {
    flex: 1,
    fontSize: 14,
    color: '#6d28d9',
    textAlign: 'right',
    lineHeight: 20,
  },
  submitButton: {
    backgroundColor: '#8b5cf6',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  errorText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    marginTop: 40,
  },
});
