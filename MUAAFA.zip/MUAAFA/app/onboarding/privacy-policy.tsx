import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { Shield, CheckCircle, AlertTriangle, Lock, Database, Users } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

export default function PrivacyPolicyScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [accepted, setAccepted] = useState(false);

  async function handleAccept() {
    if (!accepted) {
      Alert.alert('تنبيه', 'يرجى الموافقة على سياسة الخصوصية وشروط الاستخدام للمتابعة');
      return;
    }

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      const { error: statusError } = await supabase
        .from('user_onboarding_status')
        .update({
          privacy_policy_accepted: true,
          privacy_policy_accepted_at: new Date().toISOString(),
          onboarding_completed: true,
          onboarding_completed_at: new Date().toISOString(),
        })
        .eq('user_id', user.id);

      if (statusError) throw statusError;

      const { error: userError } = await supabase
        .from('users')
        .update({
          onboarding_completed: true,
        })
        .eq('id', user.id);

      if (userError) throw userError;

      setLoading(false);

      Alert.alert(
        'مرحباً بك في معافى! 🎉',
        'تم إكمال الإعداد بنجاح\n\nيمكنك الآن الاستفادة من جميع ميزات التطبيق',
        [
          {
            text: 'ابدأ الاستخدام',
            onPress: () => router.replace('/(tabs)')
          }
        ],
        { cancelable: false }
      );
    } catch (error: any) {
      setLoading(false);
      console.error('Error completing onboarding:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء إكمال الإعداد، يرجى المحاولة مرة أخرى');
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Shield size={48} color="#6366f1" strokeWidth={2} />
        <Text style={styles.title}>الخصوصية والأمان</Text>
        <Text style={styles.subtitle}>معلوماتك الصحية في أمان تام</Text>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '100%' }]} />
        </View>
        <Text style={styles.progressText}>الخطوة 3 من 3 - الخطوة الأخيرة!</Text>
      </View>

      <View style={styles.warningBox}>
        <AlertTriangle size={24} color="#f59e0b" strokeWidth={2} />
        <View style={styles.warningContent}>
          <Text style={styles.warningTitle}>تنويه طبي مهم</Text>
          <Text style={styles.warningText}>
            تطبيق معافى يقدم إرشادات ونصائح صحية عامة ولا يعتبر بديلاً عن الاستشارة الطبية المتخصصة.
            {'\n\n'}
            جميع المعلومات المقدمة هي لأغراض تثقيفية فقط ولا تشكل تشخيصاً طبياً.
            {'\n\n'}
            يرجى استشارة طبيبك المختص في حالة وجود أي أعراض أو مشاكل صحية.
          </Text>
        </View>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Lock size={24} color="#6366f1" strokeWidth={2} />
          <Text style={styles.sectionTitle}>حماية بياناتك</Text>
        </View>
        <Text style={styles.sectionText}>
          • جميع بياناتك الصحية مشفرة بأحدث معايير الأمان{'\n'}
          • يتم تخزين البيانات بشكل آمن على خوادم Supabase المعتمدة{'\n'}
          • نستخدم بروتوكولات HTTPS و SSL لحماية الاتصالات{'\n'}
          • لا يمكن الوصول لبياناتك إلا عبر حسابك الشخصي
        </Text>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Database size={24} color="#6366f1" strokeWidth={2} />
          <Text style={styles.sectionTitle}>استخدام البيانات</Text>
        </View>
        <Text style={styles.sectionText}>
          نستخدم معلوماتك الصحية فقط من أجل:{'\n\n'}
          • تخصيص النصائح والإرشادات الصحية لك{'\n'}
          • تقديم خطط لياقة مناسبة لحالتك{'\n'}
          • تذكيرك بمواعيد الأدوية والجلسات{'\n'}
          • تحسين تجربتك في التطبيق{'\n'}
          • تقديم إحصائيات عن تقدمك الصحي
        </Text>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Users size={24} color="#6366f1" strokeWidth={2} />
          <Text style={styles.sectionTitle}>مشاركة البيانات</Text>
        </View>
        <Text style={styles.sectionText}>
          نلتزم بعدم مشاركة بياناتك الصحية مع أي طرف ثالث إلا في الحالات التالية:{'\n\n'}
          • بموافقتك الصريحة والمسبقة{'\n'}
          • عند الضرورة القانونية فقط{'\n'}
          • مع مقدمي الرعاية الصحية (عند طلبك){'\n'}
          • لأغراض إحصائية مجهولة الهوية لتحسين الخدمة
        </Text>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Shield size={24} color="#6366f1" strokeWidth={2} />
          <Text style={styles.sectionTitle}>حقوقك</Text>
        </View>
        <Text style={styles.sectionText}>
          لديك الحق الكامل في:{'\n\n'}
          • الوصول إلى جميع بياناتك المخزنة{'\n'}
          • تعديل أو تحديث معلوماتك في أي وقت{'\n'}
          • حذف حسابك وبياناتك نهائياً{'\n'}
          • تصدير بياناتك الصحية{'\n'}
          • سحب موافقتك على معالجة البيانات
        </Text>
      </View>

      <View style={styles.technicalInfo}>
        <Text style={styles.technicalTitle}>المعلومات التقنية:</Text>
        <Text style={styles.technicalText}>
          • المنصة: Expo / React Native{'\n'}
          • قاعدة البيانات: Supabase (PostgreSQL){'\n'}
          • التشفير: AES-256 + TLS 1.3{'\n'}
          • الاستضافة: خوادم سحابية معتمدة{'\n'}
          • النسخ الاحتياطي: يومي وتلقائي
        </Text>
      </View>

      <TouchableOpacity
        style={[styles.acceptCheckbox, accepted && styles.acceptCheckboxActive]}
        onPress={() => setAccepted(!accepted)}>
        <View style={[styles.checkbox, accepted && styles.checkboxChecked]}>
          {accepted && <CheckCircle size={24} color="#ffffff" strokeWidth={3} />}
        </View>
        <Text style={styles.acceptText}>
          أوافق على سياسة الخصوصية وشروط الاستخدام وأؤكد قراءتي وفهمي لجميع البنود أعلاه
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.acceptButton, (!accepted || loading) && styles.acceptButtonDisabled]}
        onPress={handleAccept}
        disabled={!accepted || loading}>
        {loading ? (
          <ActivityIndicator color="#ffffff" />
        ) : (
          <>
            <CheckCircle size={24} color="#ffffff" strokeWidth={2} />
            <Text style={styles.acceptButtonText}>أوافق وأبدأ استخدام معافى</Text>
          </>
        )}
      </TouchableOpacity>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          بالموافقة، أنت توافق على{' '}
          <Text style={styles.footerLink}>سياسة الخصوصية</Text>
          {' و '}
          <Text style={styles.footerLink}>شروط الاستخدام</Text>
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 24,
    paddingBottom: 48,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 16,
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#e2e8f0',
    borderRadius: 2,
    overflow: 'hidden',
    marginTop: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#6366f1',
  },
  progressText: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 8,
  },
  warningBox: {
    flexDirection: 'row',
    backgroundColor: '#fffbeb',
    borderWidth: 2,
    borderColor: '#fbbf24',
    borderRadius: 16,
    padding: 20,
    gap: 16,
    marginBottom: 24,
  },
  warningContent: {
    flex: 1,
    gap: 8,
  },
  warningTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#92400e',
    textAlign: 'right',
  },
  warningText: {
    fontSize: 14,
    color: '#78350f',
    lineHeight: 22,
    textAlign: 'right',
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    gap: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  sectionText: {
    fontSize: 15,
    color: '#475569',
    lineHeight: 24,
    textAlign: 'right',
  },
  technicalInfo: {
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  technicalTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  technicalText: {
    fontSize: 13,
    color: '#64748b',
    lineHeight: 20,
    textAlign: 'right',
  },
  acceptCheckbox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#e2e8f0',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
  },
  acceptCheckboxActive: {
    backgroundColor: '#ede9fe',
    borderColor: '#6366f1',
  },
  checkbox: {
    width: 32,
    height: 32,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#cbd5e1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: {
    backgroundColor: '#6366f1',
    borderColor: '#6366f1',
  },
  acceptText: {
    flex: 1,
    fontSize: 15,
    color: '#475569',
    lineHeight: 22,
    textAlign: 'right',
    fontWeight: '500',
  },
  acceptButton: {
    backgroundColor: '#6366f1',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 16,
  },
  acceptButtonDisabled: {
    opacity: 0.5,
  },
  acceptButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  footer: {
    alignItems: 'center',
  },
  footerText: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 20,
  },
  footerLink: {
    color: '#6366f1',
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
});
