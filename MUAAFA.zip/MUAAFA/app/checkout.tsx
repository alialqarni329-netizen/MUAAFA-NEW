import { ScrollView, View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { ArrowRight, CreditCard, Shield, CheckCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface CartItem {
  id: string;
  medication_id: string;
  pharmacy_id: string;
  quantity: number;
  total_price: number;
  insurance_coverage_amount: number;
  patient_amount: number;
  medication: {
    name: string;
  };
  pharmacy: {
    business_name: string;
  };
}

export default function Checkout() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<'card' | 'apple_pay' | 'stc_pay' | 'mada'>('card');

  useEffect(() => {
    loadCart();
  }, []);

  async function loadCart() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('pharmacy_cart')
        .select(`
          *,
          medication:medications(name),
          pharmacy:business_registrations(business_name)
        `)
        .eq('user_id', user.id);

      if (error) throw error;
      setCartItems(data || []);
    } catch (error) {
      console.error('Error loading cart:', error);
    } finally {
      setLoading(false);
    }
  }

  function calculateTotals() {
    const subtotal = cartItems.reduce((sum, item) => sum + item.total_price, 0);
    const insurance = cartItems.reduce((sum, item) => sum + item.insurance_coverage_amount, 0);
    const total = cartItems.reduce((sum, item) => sum + item.patient_amount, 0);
    return { subtotal, insurance, total };
  }

  async function processPayment() {
    if (cartItems.length === 0) return;

    setProcessing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { subtotal, insurance, total } = calculateTotals();

      const { data: paymentData, error: paymentError } = await supabase
        .from('payments')
        .insert({
          user_id: user.id,
          payment_type: 'pharmacy',
          total_amount: subtotal,
          insurance_coverage: insurance,
          patient_paid: total,
          payment_method: selectedMethod,
          payment_status: 'completed',
          paid_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (paymentError) throw paymentError;

      const invoiceNumber = await generateInvoiceNumber();

      const { error: invoiceError } = await supabase
        .from('invoices')
        .insert({
          invoice_number: invoiceNumber,
          user_id: user.id,
          payment_id: paymentData.id,
          subtotal: subtotal,
          tax_amount: 0,
          total_amount: subtotal,
          insurance_coverage: insurance,
          amount_paid: total,
          provider_id: cartItems[0].pharmacy_id,
          provider_name: cartItems[0].pharmacy.business_name,
          provider_type: 'pharmacy',
          items: JSON.stringify(cartItems.map(item => ({
            name: item.medication.name,
            quantity: item.quantity,
            unit_price: item.total_price / item.quantity,
            total_price: item.total_price,
          }))),
          status: 'paid',
          paid_at: new Date().toISOString(),
        });

      if (invoiceError) throw invoiceError;

      const { error: deleteError } = await supabase
        .from('pharmacy_cart')
        .delete()
        .eq('user_id', user.id);

      if (deleteError) throw deleteError;

      Alert.alert(
        'نجحت العملية',
        'تم الدفع بنجاح. يمكنك الآن مراجعة فاتورتك.',
        [
          {
            text: 'مراجعة الفاتورة',
            onPress: () => router.push('/invoices'),
          },
        ]
      );
    } catch (error) {
      console.error('Error processing payment:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء معالجة الدفع');
    } finally {
      setProcessing(false);
    }
  }

  async function generateInvoiceNumber() {
    const { data, error } = await supabase.rpc('generate_invoice_number');
    if (error) throw error;
    return data;
  }

  const { subtotal, insurance, total } = calculateTotals();

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>إتمام الدفع</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ملخص الطلب</Text>

          {cartItems.map((item, index) => (
            <View key={item.id} style={styles.orderItem}>
              <Text style={styles.itemName}>{item.medication.name}</Text>
              <View style={styles.itemDetails}>
                <Text style={styles.itemQuantity}>الكمية: {item.quantity}</Text>
                <Text style={styles.itemPrice}>{item.total_price.toFixed(2)} ر.س</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>طريقة الدفع</Text>

          <TouchableOpacity
            style={[styles.paymentMethod, selectedMethod === 'card' && styles.selectedMethod]}
            onPress={() => setSelectedMethod('card')}
          >
            <CreditCard size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.methodText}>بطاقة ائتمانية</Text>
            {selectedMethod === 'card' && <CheckCircle size={20} color="#10b981" strokeWidth={2} />}
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.paymentMethod, selectedMethod === 'mada' && styles.selectedMethod]}
            onPress={() => setSelectedMethod('mada')}
          >
            <CreditCard size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.methodText}>مدى</Text>
            {selectedMethod === 'mada' && <CheckCircle size={20} color="#10b981" strokeWidth={2} />}
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.paymentMethod, selectedMethod === 'apple_pay' && styles.selectedMethod]}
            onPress={() => setSelectedMethod('apple_pay')}
          >
            <Shield size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.methodText}>Apple Pay</Text>
            {selectedMethod === 'apple_pay' && <CheckCircle size={20} color="#10b981" strokeWidth={2} />}
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.paymentMethod, selectedMethod === 'stc_pay' && styles.selectedMethod]}
            onPress={() => setSelectedMethod('stc_pay')}
          >
            <Shield size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.methodText}>STC Pay</Text>
            {selectedMethod === 'stc_pay' && <CheckCircle size={20} color="#10b981" strokeWidth={2} />}
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ملخص المبالغ</Text>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>المجموع الفرعي</Text>
            <Text style={styles.summaryValue}>{subtotal.toFixed(2)} ر.س</Text>
          </View>

          {insurance > 0 && (
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>تغطية التأمين</Text>
              <Text style={[styles.summaryValue, styles.insuranceValue]}>
                - {insurance.toFixed(2)} ر.س
              </Text>
            </View>
          )}

          <View style={styles.divider} />

          <View style={styles.summaryRow}>
            <Text style={styles.totalLabel}>المبلغ المستحق</Text>
            <Text style={styles.totalValue}>{total.toFixed(2)} ر.س</Text>
          </View>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.payButton, processing && styles.payButtonDisabled]}
          onPress={processPayment}
          disabled={processing}
        >
          {processing ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <>
              <CreditCard size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.payButtonText}>ادفع {total.toFixed(2)} ر.س</Text>
            </>
          )}
        </TouchableOpacity>

        <Text style={styles.secureText}>🔒 جميع المدفوعات آمنة ومشفرة</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    gap: 12,
  },
  backButton: {
    padding: 8,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  orderItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  itemName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  itemDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  itemQuantity: {
    fontSize: 12,
    color: '#64748b',
  },
  itemPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: '#3b82f6',
  },
  paymentMethod: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  selectedMethod: {
    borderColor: '#3b82f6',
    backgroundColor: '#eff6ff',
  },
  methodText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
  },
  insuranceValue: {
    color: '#10b981',
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 12,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  totalValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#3b82f6',
  },
  footer: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  payButton: {
    backgroundColor: '#3b82f6',
    paddingVertical: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  payButtonDisabled: {
    opacity: 0.6,
  },
  payButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  secureText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'center',
    marginTop: 12,
  },
});
