import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { Calendar, Clock, Video, MessageSquare, User, ChevronLeft, Star, CreditCard } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useLanguage } from '@/lib/i18n/LanguageContext';

interface Doctor {
  id: string;
  full_name: string;
  specialty: string;
  bio: string;
  rating: number;
  is_available: boolean;
  session_price: number;
}

export default function BookSessionScreen() {
  const router = useRouter();
  const { t, language } = useLanguage();
  const [step, setStep] = useState<'doctor' | 'type' | 'datetime' | 'notes'>('doctor');
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [sessionType, setSessionType] = useState<'video' | 'chat'>('video');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadDoctors();
  }, []);

  async function loadDoctors() {
    const { data, error } = await supabase
      .from('doctors')
      .select('*')
      .eq('is_available', true)
      .order('rating', { ascending: false });

    if (data) {
      setDoctors(data);
    }
  }

  const availableTimes = [
    '09:00', '10:00', '11:00', '12:00',
    '14:00', '15:00', '16:00', '17:00',
    '18:00', '19:00', '20:00'
  ];

  const getNextSevenDays = () => {
    const days = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      days.push(date.toISOString().split('T')[0]);
    }
    return days;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    };
    return date.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', options);
  };

  async function handleAddToCart() {
    if (!selectedDoctor || !selectedDate || !selectedTime) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        language === 'ar' ? 'يرجى ملء جميع الحقول المطلوبة' : 'Please fill all required fields'
      );
      return;
    }

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not found');

      const sessionPrice = selectedDoctor.session_price || 200;

      const { error } = await supabase
        .from('cart_items')
        .insert({
          user_id: user.id,
          item_type: 'session',
          item_id: selectedDoctor.id,
          quantity: 1,
          price: sessionPrice,
          metadata: {
            doctor_name: selectedDoctor.full_name,
            specialty: selectedDoctor.specialty,
            session_type: sessionType,
            scheduled_date: selectedDate,
            scheduled_time: selectedTime,
            notes: notes,
            type_label: sessionType === 'video'
              ? (language === 'ar' ? 'مكالمة فيديو' : 'Video Call')
              : (language === 'ar' ? 'محادثة نصية' : 'Text Chat')
          }
        });

      if (error) throw error;

      Alert.alert(
        language === 'ar' ? 'تمت الإضافة للسلة' : 'Added to Cart',
        language === 'ar'
          ? 'تم إضافة الجلسة للسلة. انتقل للسلة لإتمام الدفع.'
          : 'Session added to cart. Go to cart to complete payment.',
        [
          {
            text: language === 'ar' ? 'الذهاب للسلة' : 'Go to Cart',
            onPress: () => router.push('/cart')
          },
          {
            text: language === 'ar' ? 'حسناً' : 'OK',
            onPress: () => router.back()
          }
        ]
      );
    } catch (error: any) {
      Alert.alert(
        language === 'ar' ? 'خطأ' : 'Error',
        error.message || (language === 'ar' ? 'حدث خطأ أثناء الإضافة للسلة' : 'An error occurred while adding to cart')
      );
    } finally {
      setLoading(false);
    }
  }

  const renderDoctorSelection = () => (
    <View style={styles.stepContainer}>
      <Text style={styles.stepTitle}>
        {language === 'ar' ? 'اختر الطبيب' : 'Choose Doctor'}
      </Text>
      <ScrollView style={styles.optionsList}>
        {doctors.map((doctor) => (
          <TouchableOpacity
            key={doctor.id}
            style={[
              styles.doctorCard,
              selectedDoctor?.id === doctor.id && styles.selectedCard
            ]}
            onPress={() => {
              setSelectedDoctor(doctor);
              setStep('type');
            }}>
            <View style={styles.doctorInfo}>
              <View style={styles.doctorAvatar}>
                <User size={32} color="#0ea5e9" strokeWidth={2} />
              </View>
              <View style={styles.doctorDetails}>
                <Text style={styles.doctorName}>{doctor.full_name}</Text>
                <Text style={styles.doctorSpecialty}>{doctor.specialty}</Text>
                <View style={styles.ratingContainer}>
                  <Star size={16} color="#f59e0b" fill="#f59e0b" strokeWidth={2} />
                  <Text style={styles.ratingText}>{doctor.rating}</Text>
                </View>
              </View>
            </View>
            <ChevronLeft size={20} color="#94a3b8" strokeWidth={2} />
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );

  const renderTypeSelection = () => (
    <View style={styles.stepContainer}>
      <TouchableOpacity style={styles.backButton} onPress={() => setStep('doctor')}>
        <ChevronLeft size={24} color="#0ea5e9" strokeWidth={2} />
        <Text style={styles.backButtonText}>
          {language === 'ar' ? 'رجوع' : 'Back'}
        </Text>
      </TouchableOpacity>

      <Text style={styles.stepTitle}>
        {language === 'ar' ? 'نوع الجلسة' : 'Session Type'}
      </Text>

      <View style={styles.typeOptions}>
        <TouchableOpacity
          style={[
            styles.typeCard,
            sessionType === 'video' && styles.selectedCard
          ]}
          onPress={() => {
            setSessionType('video');
            setStep('datetime');
          }}>
          <Video size={48} color={sessionType === 'video' ? '#0ea5e9' : '#64748b'} strokeWidth={2} />
          <Text style={styles.typeTitle}>
            {language === 'ar' ? 'مكالمة فيديو' : 'Video Call'}
          </Text>
          <Text style={styles.typeDescription}>
            {language === 'ar' ? 'جلسة مرئية مباشرة مع الطبيب' : 'Live video session with doctor'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.typeCard,
            sessionType === 'chat' && styles.selectedCard
          ]}
          onPress={() => {
            setSessionType('chat');
            setStep('datetime');
          }}>
          <MessageSquare size={48} color={sessionType === 'chat' ? '#0ea5e9' : '#64748b'} strokeWidth={2} />
          <Text style={styles.typeTitle}>
            {language === 'ar' ? 'محادثة نصية' : 'Text Chat'}
          </Text>
          <Text style={styles.typeDescription}>
            {language === 'ar' ? 'محادثة نصية مع الطبيب' : 'Text conversation with doctor'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderDateTimeSelection = () => (
    <View style={styles.stepContainer}>
      <TouchableOpacity style={styles.backButton} onPress={() => setStep('type')}>
        <ChevronLeft size={24} color="#0ea5e9" strokeWidth={2} />
        <Text style={styles.backButtonText}>
          {language === 'ar' ? 'رجوع' : 'Back'}
        </Text>
      </TouchableOpacity>

      <Text style={styles.stepTitle}>
        {language === 'ar' ? 'التاريخ والوقت' : 'Date & Time'}
      </Text>

      <View style={styles.sectionContainer}>
        <Text style={styles.sectionLabel}>
          {language === 'ar' ? 'اختر التاريخ' : 'Choose Date'}
        </Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.dateScroll}>
          {getNextSevenDays().map((date) => (
            <TouchableOpacity
              key={date}
              style={[
                styles.dateButton,
                selectedDate === date && styles.selectedButton
              ]}
              onPress={() => setSelectedDate(date)}>
              <Text style={[
                styles.dateButtonText,
                selectedDate === date && styles.selectedButtonText
              ]}>
                {formatDate(date)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {selectedDate && (
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionLabel}>
            {language === 'ar' ? 'اختر الوقت' : 'Choose Time'}
          </Text>
          <View style={styles.timeGrid}>
            {availableTimes.map((time) => (
              <TouchableOpacity
                key={time}
                style={[
                  styles.timeButton,
                  selectedTime === time && styles.selectedButton
                ]}
                onPress={() => setSelectedTime(time)}>
                <Clock size={16} color={selectedTime === time ? '#ffffff' : '#64748b'} strokeWidth={2} />
                <Text style={[
                  styles.timeButtonText,
                  selectedTime === time && styles.selectedButtonText
                ]}>
                  {time}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {selectedDate && selectedTime && (
        <TouchableOpacity
          style={styles.continueButton}
          onPress={() => setStep('notes')}>
          <Text style={styles.continueButtonText}>
            {language === 'ar' ? 'متابعة' : 'Continue'}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );

  const renderNotesInput = () => (
    <View style={styles.stepContainer}>
      <TouchableOpacity style={styles.backButton} onPress={() => setStep('datetime')}>
        <ChevronLeft size={24} color="#0ea5e9" strokeWidth={2} />
        <Text style={styles.backButtonText}>
          {language === 'ar' ? 'رجوع' : 'Back'}
        </Text>
      </TouchableOpacity>

      <Text style={styles.stepTitle}>
        {language === 'ar' ? 'ملاحظات إضافية' : 'Additional Notes'}
      </Text>

      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>
          {language === 'ar' ? 'ملخص الحجز' : 'Booking Summary'}
        </Text>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>{language === 'ar' ? 'الطبيب:' : 'Doctor:'}</Text>
          <Text style={styles.summaryValue}>{selectedDoctor?.full_name}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>{language === 'ar' ? 'التخصص:' : 'Specialty:'}</Text>
          <Text style={styles.summaryValue}>{selectedDoctor?.specialty}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>{language === 'ar' ? 'النوع:' : 'Type:'}</Text>
          <Text style={styles.summaryValue}>
            {sessionType === 'video'
              ? (language === 'ar' ? 'مكالمة فيديو' : 'Video Call')
              : (language === 'ar' ? 'محادثة نصية' : 'Text Chat')}
          </Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>{language === 'ar' ? 'التاريخ:' : 'Date:'}</Text>
          <Text style={styles.summaryValue}>{formatDate(selectedDate)}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>{language === 'ar' ? 'الوقت:' : 'Time:'}</Text>
          <Text style={styles.summaryValue}>{selectedTime}</Text>
        </View>
        <View style={styles.priceDivider} />
        <View style={styles.summaryRow}>
          <Text style={styles.priceLabel}>{language === 'ar' ? 'السعر:' : 'Price:'}</Text>
          <Text style={styles.priceValue}>
            {(selectedDoctor?.session_price || 200).toFixed(2)} {language === 'ar' ? 'ر.س' : 'SAR'}
          </Text>
        </View>
      </View>

      <Text style={styles.notesLabel}>
        {language === 'ar' ? 'ملاحظات أو أعراض (اختياري)' : 'Notes or symptoms (optional)'}
      </Text>
      <TextInput
        style={styles.notesInput}
        placeholder={language === 'ar' ? 'اكتب ملاحظاتك هنا...' : 'Write your notes here...'}
        value={notes}
        onChangeText={setNotes}
        multiline
        numberOfLines={4}
        textAlign={language === 'ar' ? 'right' : 'left'}
      />

      <TouchableOpacity
        style={[styles.bookButton, loading && styles.buttonDisabled]}
        onPress={handleAddToCart}
        disabled={loading}>
        <CreditCard size={20} color="#ffffff" strokeWidth={2} />
        <Text style={styles.bookButtonText}>
          {loading
            ? (language === 'ar' ? 'جاري الإضافة...' : 'Adding...')
            : (language === 'ar' ? 'أضف للسلة وادفع' : 'Add to Cart & Pay')}
        </Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.headerBack}>
          <ChevronLeft size={24} color="#ffffff" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {language === 'ar' ? 'حجز جلسة جديدة' : 'Book New Session'}
        </Text>
      </View>

      <View style={styles.progressBar}>
        <View style={[styles.progressStep, step !== 'doctor' && styles.progressStepActive]} />
        <View style={[styles.progressStep, (step === 'datetime' || step === 'notes') && styles.progressStepActive]} />
        <View style={[styles.progressStep, step === 'notes' && styles.progressStepActive]} />
      </View>

      <ScrollView style={styles.content}>
        {step === 'doctor' && renderDoctorSelection()}
        {step === 'type' && renderTypeSelection()}
        {step === 'datetime' && renderDateTimeSelection()}
        {step === 'notes' && renderNotesInput()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#8b5cf6',
    paddingTop: 50,
    paddingBottom: 16,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerBack: {
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  progressBar: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 8,
    backgroundColor: '#ffffff',
  },
  progressStep: {
    flex: 1,
    height: 4,
    backgroundColor: '#e2e8f0',
    borderRadius: 2,
  },
  progressStepActive: {
    backgroundColor: '#8b5cf6',
  },
  content: {
    flex: 1,
  },
  stepContainer: {
    padding: 16,
  },
  stepTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 20,
    textAlign: 'right',
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  backButtonText: {
    fontSize: 16,
    color: '#0ea5e9',
    fontWeight: '600',
  },
  optionsList: {
    flex: 1,
  },
  doctorCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  selectedCard: {
    borderColor: '#8b5cf6',
    backgroundColor: '#f5f3ff',
  },
  doctorInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  doctorAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  doctorDetails: {
    flex: 1,
  },
  doctorName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  doctorSpecialty: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '600',
  },
  typeOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  typeCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  typeTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 12,
    marginBottom: 8,
  },
  typeDescription: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'center',
  },
  sectionContainer: {
    marginBottom: 24,
  },
  sectionLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  dateScroll: {
    marginBottom: 8,
  },
  dateButton: {
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 12,
    marginRight: 8,
    minWidth: 200,
  },
  selectedButton: {
    backgroundColor: '#8b5cf6',
    borderColor: '#8b5cf6',
  },
  dateButtonText: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '600',
  },
  selectedButtonText: {
    color: '#ffffff',
  },
  timeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  timeButton: {
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    minWidth: 100,
  },
  timeButtonText: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '600',
  },
  continueButton: {
    backgroundColor: '#8b5cf6',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 16,
  },
  continueButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  summaryCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  summaryValue: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '600',
  },
  notesLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  notesInput: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 12,
    minHeight: 100,
    textAlignVertical: 'top',
    marginBottom: 20,
  },
  bookButton: {
    backgroundColor: '#8b5cf6',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  bookButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  priceDivider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 12,
  },
  priceLabel: {
    fontSize: 16,
    color: '#0f172a',
    fontWeight: 'bold',
  },
  priceValue: {
    fontSize: 18,
    color: '#8b5cf6',
    fontWeight: 'bold',
  },
});
