import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { MessageCircle, HelpCircle, Book, Bot, Mail } from 'lucide-react-native';

export default function SupportScreen() {
  const router = useRouter();

  const handleAIAssistant = () => {
    router.push('/(tabs)');
  };

  const handleWhatsApp = () => {
    Linking.openURL('https://wa.me/966556236305');
  };

  const handleEmail = () => {
    Linking.openURL('mailto:muaafa@outlook.sa');
  };

  const handleX = () => {
    Linking.openURL('https://x.com/MuaafaHealth');
  };

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'خدمة العملاء',
          headerStyle: {
            backgroundColor: '#0ea5e9',
          },
          headerTintColor: '#ffffff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      />
      <View style={styles.container}>
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <MessageCircle size={48} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.headerTitle}>كيف يمكننا مساعدتك؟</Text>
            <Text style={styles.headerSubtitle}>اختر طريقة التواصل المناسبة لك</Text>
          </View>

          <TouchableOpacity style={styles.supportCard} onPress={handleAIAssistant}>
            <Bot size={32} color="#10b981" strokeWidth={2} />
            <View style={styles.supportContent}>
              <Text style={styles.supportTitle}>الطبيب الذكي</Text>
              <Text style={styles.supportDescription}>
                تحدث مع مساعدك الصحي الذكي للحصول على استشارات فورية
              </Text>
              <Text style={styles.supportStatus}>متاح: 24/7</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.supportCard} onPress={handleWhatsApp}>
            <MessageCircle size={32} color="#25D366" strokeWidth={2} />
            <View style={styles.supportContent}>
              <Text style={styles.supportTitle}>واتساب</Text>
              <Text style={styles.supportDescription}>
                تواصل معنا مباشرة عبر واتساب
              </Text>
              <Text style={styles.supportStatus}>0556236305</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.supportCard} onPress={handleEmail}>
            <Mail size={32} color="#0ea5e9" strokeWidth={2} />
            <View style={styles.supportContent}>
              <Text style={styles.supportTitle}>البريد الإلكتروني</Text>
              <Text style={styles.supportDescription}>
                للاستفسارات والدعم الفني
              </Text>
              <Text style={styles.supportStatus}>muaafa@outlook.sa</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.supportCard} onPress={handleX}>
            <View style={styles.xIconContainer}>
              <Text style={styles.xIcon}>𝕏</Text>
            </View>
            <View style={styles.supportContent}>
              <Text style={styles.supportTitle}>تابعنا على X</Text>
              <Text style={styles.supportDescription}>
                آخر الأخبار والتحديثات
              </Text>
              <Text style={styles.supportStatus}>@MuaafaHealth</Text>
            </View>
          </TouchableOpacity>

          <View style={styles.faqSection}>
            <Text style={styles.faqTitle}>الأسئلة الشائعة</Text>

            <View style={styles.faqCard}>
              <HelpCircle size={20} color="#0ea5e9" strokeWidth={2} />
              <View style={styles.faqContent}>
                <Text style={styles.faqQuestion}>كيف أقوم بتحديث معلوماتي الشخصية؟</Text>
                <Text style={styles.faqAnswer}>
                  انتقل إلى الإعدادات ثم المعلومات الشخصية، وقم بتحديث البيانات المطلوبة.
                </Text>
              </View>
            </View>

            <View style={styles.faqCard}>
              <HelpCircle size={20} color="#0ea5e9" strokeWidth={2} />
              <View style={styles.faqContent}>
                <Text style={styles.faqQuestion}>كيف ألغي اشتراكي؟</Text>
                <Text style={styles.faqAnswer}>
                  يمكنك إلغاء الاشتراك من خلال الإعدادات {'>'} إدارة الاشتراك {'>'} إلغاء
                  الاشتراك.
                </Text>
              </View>
            </View>

            <View style={styles.faqCard}>
              <HelpCircle size={20} color="#0ea5e9" strokeWidth={2} />
              <View style={styles.faqContent}>
                <Text style={styles.faqQuestion}>هل معلوماتي الصحية آمنة؟</Text>
                <Text style={styles.faqAnswer}>
                  نعم، جميع معلوماتك محمية بأعلى معايير الأمان والتشفير. راجع سياسة
                  الخصوصية لمزيد من التفاصيل.
                </Text>
              </View>
            </View>

            <View style={styles.faqCard}>
              <HelpCircle size={20} color="#0ea5e9" strokeWidth={2} />
              <View style={styles.faqContent}>
                <Text style={styles.faqQuestion}>كم مدة التجربة المجانية؟</Text>
                <Text style={styles.faqAnswer}>
                  الخطة المجانية تمنحك 10 دقائق يومياً للتحدث مع الطبيب الذكي، تتجدد تلقائياً كل يوم.
                </Text>
              </View>
            </View>

            <View style={styles.faqCard}>
              <HelpCircle size={20} color="#0ea5e9" strokeWidth={2} />
              <View style={styles.faqContent}>
                <Text style={styles.faqQuestion}>كيف أحجز جلسة استشارة عن بعد؟</Text>
                <Text style={styles.faqAnswer}>
                  اذهب إلى تبويب "الجلسات" واختر "حجز جلسة جديدة"، ثم اختر التخصص والطبيب والوقت المناسب.
                </Text>
              </View>
            </View>

            <View style={styles.faqCard}>
              <HelpCircle size={20} color="#0ea5e9" strokeWidth={2} />
              <View style={styles.faqContent}>
                <Text style={styles.faqQuestion}>هل يمكن الاعتماد على نصائح الطبيب الذكي؟</Text>
                <Text style={styles.faqAnswer}>
                  الطبيب الذكي يقدم معلومات موثوقة، لكنه لا يغني عن استشارة طبيب حقيقي في الحالات الطارئة أو التشخيصات المعقدة.
                </Text>
              </View>
            </View>
          </View>

          <TouchableOpacity style={styles.helpCenterButton} onPress={() => router.push('/help')}>
            <Book size={20} color="#ffffff" strokeWidth={2} />
            <Text style={styles.helpCenterButtonText}>زيارة مركز المساعدة الكامل</Text>
          </TouchableOpacity>

          <View style={styles.tipCard}>
            <Text style={styles.tipTitle}>نصيحة</Text>
            <Text style={styles.tipText}>
              قبل التواصل مع الدعم، تحقق من مركز المساعدة والأسئلة الشائعة - قد تجد الإجابة
              التي تبحث عنها!
            </Text>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
  },
  supportCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  supportContent: {
    flex: 1,
  },
  supportTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  supportDescription: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 8,
    textAlign: 'right',
    lineHeight: 20,
  },
  supportStatus: {
    fontSize: 13,
    color: '#10b981',
    fontWeight: '600',
    textAlign: 'right',
  },
  xIconContainer: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  xIcon: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#000000',
  },
  faqSection: {
    marginTop: 32,
  },
  faqTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  faqCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  faqContent: {
    flex: 1,
  },
  faqQuestion: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  faqAnswer: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
    lineHeight: 22,
  },
  tipCard: {
    backgroundColor: '#dbeafe',
    borderRadius: 12,
    padding: 20,
    marginTop: 24,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 12,
    textAlign: 'right',
  },
  tipText: {
    fontSize: 14,
    color: '#1e3a8a',
    textAlign: 'right',
    lineHeight: 22,
  },
  helpCenterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#0ea5e9',
    padding: 16,
    borderRadius: 12,
    marginTop: 24,
  },
  helpCenterButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
