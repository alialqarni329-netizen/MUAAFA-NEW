import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useState, useEffect } from 'react';
import { Stack, useRouter } from 'expo-router';
import { ClipboardList, Check } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

export default function QuestionnaireScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [formData, setFormData] = useState({
    age: '',
    gender: '',
    height: '',
    weight: '',
    hasChronicDiseases: false,
    chronicDiseases: '',
    hasAllergies: false,
    allergies: '',
    currentMedications: '',
    previousSurgeries: '',
    familyMedicalHistory: '',
    smokingStatus: false,
    alcoholConsumption: false,
    exerciseFrequency: 'متوسط',
    emergencyContactName: '',
    emergencyContactPhone: '',
  });

  useEffect(() => {
    checkUserSession();
  }, []);

  async function checkUserSession() {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً', [
          { text: 'حسناً', onPress: () => router.replace('/auth/login') }
        ]);
        return;
      }

      const { data: userData } = await supabase
        .from('users')
        .select('id')
        .eq('id', user.id)
        .maybeSingle();

      if (!userData) {
        Alert.alert('خطأ', 'لم يتم العثور على بيانات المستخدم. يرجى إعادة التسجيل.', [
          { text: 'حسناً', onPress: () => router.replace('/auth/register') }
        ]);
        return;
      }

      setChecking(false);
    } catch (error) {
      console.error('Error checking user:', error);
      Alert.alert('خطأ', 'حدث خطأ في التحقق من الجلسة');
      setChecking(false);
    }
  }

  async function handleSubmit() {
    if (!formData.age || !formData.gender) {
      Alert.alert('خطأ', 'يرجى إدخال العمر والجنس على الأقل');
      return;
    }

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً');
        setLoading(false);
        return;
      }

      const chronicDiseasesArray = formData.chronicDiseases
        .split(',')
        .map((d) => d.trim())
        .filter((d) => d);
      const allergiesArray = formData.allergies
        .split(',')
        .map((a) => a.trim())
        .filter((a) => a);
      const medicationsArray = formData.currentMedications
        .split(',')
        .map((m) => m.trim())
        .filter((m) => m);
      const surgeriesArray = formData.previousSurgeries
        .split(',')
        .map((s) => s.trim())
        .filter((s) => s);
      const familyHistoryArray = formData.familyMedicalHistory
        .split(',')
        .map((f) => f.trim())
        .filter((f) => f);

      const { error } = await supabase.from('medical_questionnaire').insert({
        user_id: user.id,
        age: parseInt(formData.age) || null,
        gender: formData.gender || null,
        height: parseFloat(formData.height) || null,
        weight: parseFloat(formData.weight) || null,
        chronic_diseases: chronicDiseasesArray.length > 0 ? chronicDiseasesArray : null,
        current_medications: medicationsArray.length > 0 ? medicationsArray : null,
        allergies: allergiesArray.length > 0 ? allergiesArray : null,
        previous_surgeries: surgeriesArray.length > 0 ? surgeriesArray : null,
        family_history: familyHistoryArray.length > 0 ? familyHistoryArray : null,
        lifestyle_smoking: formData.smokingStatus,
        lifestyle_alcohol: formData.alcoholConsumption,
        lifestyle_exercise: formData.exerciseFrequency || null,
        emergency_contact_name: formData.emergencyContactName || null,
        emergency_contact_phone: formData.emergencyContactPhone || null,
      });

      setLoading(false);

      if (error) {
        console.error('Questionnaire error:', error);
        Alert.alert('خطأ', `حدث خطأ أثناء حفظ البيانات: ${error.message}`);
      } else {
        Alert.alert('شكراً لك', 'تم حفظ الاستبيان الطبي بنجاح', [
          { text: 'متابعة', onPress: () => router.replace('/(tabs)') },
        ]);
      }
    } catch (error: any) {
      setLoading(false);
      console.error('Submit error:', error);
      Alert.alert('خطأ', 'حدث خطأ غير متوقع');
    }
  }

  if (checking) {
    return (
      <View style={styles.checkingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.checkingText}>جاري التحقق من الجلسة...</Text>
      </View>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'الاستبيان الطبي',
          headerStyle: { backgroundColor: '#0ea5e9' },
          headerTintColor: '#ffffff',
          headerTitleStyle: { fontWeight: 'bold' },
          headerLeft: () => null,
        }}
      />
      <View style={styles.container}>
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          <View style={styles.headerCard}>
            <ClipboardList size={48} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.headerTitle}>استبيان صحي شامل</Text>
            <Text style={styles.headerSubtitle}>
              ساعدنا في تقديم أفضل رعاية صحية لك من خلال الإجابة على هذه الأسئلة
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>المعلومات الأساسية</Text>

            <Text style={styles.label}>العمر <Text style={styles.required}>*</Text></Text>
            <TextInput
              style={styles.input}
              placeholder="أدخل عمرك"
              value={formData.age}
              onChangeText={(text) => setFormData({ ...formData, age: text })}
              keyboardType="number-pad"
              textAlign="right"
            />

            <Text style={styles.label}>الجنس <Text style={styles.required}>*</Text></Text>
            <View style={styles.optionsRow}>
              {[
                { value: 'male', label: 'ذكر' },
                { value: 'female', label: 'أنثى' },
              ].map((option) => (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.optionButton,
                    formData.gender === option.value && styles.optionButtonActive,
                  ]}
                  onPress={() => setFormData({ ...formData, gender: option.value })}>
                  <Text
                    style={[
                      styles.optionButtonText,
                      formData.gender === option.value && styles.optionButtonTextActive,
                    ]}>
                    {option.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.label}>الطول (سم)</Text>
            <TextInput
              style={styles.input}
              placeholder="مثال: 170"
              value={formData.height}
              onChangeText={(text) => setFormData({ ...formData, height: text })}
              keyboardType="decimal-pad"
              textAlign="right"
            />

            <Text style={styles.label}>الوزن (كجم)</Text>
            <TextInput
              style={styles.input}
              placeholder="مثال: 75"
              value={formData.weight}
              onChangeText={(text) => setFormData({ ...formData, weight: text })}
              keyboardType="decimal-pad"
              textAlign="right"
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>الأمراض المزمنة</Text>
            <View style={styles.checkboxRow}>
              <TouchableOpacity
                style={styles.checkbox}
                onPress={() =>
                  setFormData({ ...formData, hasChronicDiseases: !formData.hasChronicDiseases })
                }>
                {formData.hasChronicDiseases && <Check size={20} color="#10b981" strokeWidth={3} />}
              </TouchableOpacity>
              <Text style={styles.checkboxLabel}>لدي أمراض مزمنة</Text>
            </View>
            {formData.hasChronicDiseases && (
              <TextInput
                style={styles.input}
                placeholder="مثال: السكري، ضغط الدم، الربو (افصل بفاصلة)"
                value={formData.chronicDiseases}
                onChangeText={(text) => setFormData({ ...formData, chronicDiseases: text })}
                multiline
                textAlign="right"
              />
            )}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>الحساسية</Text>
            <View style={styles.checkboxRow}>
              <TouchableOpacity
                style={styles.checkbox}
                onPress={() => setFormData({ ...formData, hasAllergies: !formData.hasAllergies })}>
                {formData.hasAllergies && <Check size={20} color="#10b981" strokeWidth={3} />}
              </TouchableOpacity>
              <Text style={styles.checkboxLabel}>لدي حساسية</Text>
            </View>
            {formData.hasAllergies && (
              <TextInput
                style={styles.input}
                placeholder="مثال: البنسلين، الفول السوداني (افصل بفاصلة)"
                value={formData.allergies}
                onChangeText={(text) => setFormData({ ...formData, allergies: text })}
                multiline
                textAlign="right"
              />
            )}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>الأدوية الحالية</Text>
            <TextInput
              style={styles.input}
              placeholder="اذكر الأدوية التي تتناولها حالياً (افصل بفاصلة)"
              value={formData.currentMedications}
              onChangeText={(text) => setFormData({ ...formData, currentMedications: text })}
              multiline
              textAlign="right"
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>العمليات الجراحية السابقة</Text>
            <TextInput
              style={styles.input}
              placeholder="اذكر أي عمليات جراحية سابقة (افصل بفاصلة)"
              value={formData.previousSurgeries}
              onChangeText={(text) => setFormData({ ...formData, previousSurgeries: text })}
              multiline
              textAlign="right"
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>التاريخ المرضي العائلي</Text>
            <TextInput
              style={styles.input}
              placeholder="هل يعاني أحد من عائلتك من أمراض وراثية؟"
              value={formData.familyMedicalHistory}
              onChangeText={(text) => setFormData({ ...formData, familyMedicalHistory: text })}
              multiline
              textAlign="right"
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>نمط الحياة</Text>

            <View style={styles.checkboxRow}>
              <TouchableOpacity
                style={styles.checkbox}
                onPress={() => setFormData({ ...formData, smokingStatus: !formData.smokingStatus })}>
                {formData.smokingStatus && <Check size={20} color="#10b981" strokeWidth={3} />}
              </TouchableOpacity>
              <Text style={styles.checkboxLabel}>أدخن حالياً</Text>
            </View>

            <View style={styles.checkboxRow}>
              <TouchableOpacity
                style={styles.checkbox}
                onPress={() => setFormData({ ...formData, alcoholConsumption: !formData.alcoholConsumption })}>
                {formData.alcoholConsumption && <Check size={20} color="#10b981" strokeWidth={3} />}
              </TouchableOpacity>
              <Text style={styles.checkboxLabel}>أتناول الكحول</Text>
            </View>

            <Text style={styles.label}>النشاط البدني</Text>
            <View style={styles.optionsRow}>
              {[
                { value: 'خامل', label: 'خامل' },
                { value: 'خفيف', label: 'خفيف' },
                { value: 'متوسط', label: 'متوسط' },
                { value: 'نشط', label: 'نشط' },
                { value: 'نشط جداً', label: 'نشط جداً' },
              ].map((option) => (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.optionButtonSmall,
                    formData.exerciseFrequency === option.value && styles.optionButtonActive,
                  ]}
                  onPress={() =>
                    setFormData({
                      ...formData,
                      exerciseFrequency: option.value,
                    })
                  }>
                  <Text
                    style={[
                      styles.optionButtonText,
                      formData.exerciseFrequency === option.value && styles.optionButtonTextActive,
                    ]}>
                    {option.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>جهة الاتصال للطوارئ</Text>

            <Text style={styles.label}>اسم جهة الاتصال</Text>
            <TextInput
              style={styles.input}
              placeholder="مثال: أحمد محمد"
              value={formData.emergencyContactName}
              onChangeText={(text) => setFormData({ ...formData, emergencyContactName: text })}
              textAlign="right"
            />

            <Text style={styles.label}>رقم جوال جهة الاتصال</Text>
            <TextInput
              style={styles.input}
              placeholder="مثال: 0501234567"
              value={formData.emergencyContactPhone}
              onChangeText={(text) => setFormData({ ...formData, emergencyContactPhone: text })}
              keyboardType="phone-pad"
              textAlign="right"
            />
          </View>

          <TouchableOpacity
            style={[styles.submitButton, loading && styles.submitButtonDisabled]}
            onPress={handleSubmit}
            disabled={loading}>
            <Text style={styles.submitButtonText}>
              {loading ? 'جاري الحفظ...' : 'حفظ الاستبيان'}
            </Text>
          </TouchableOpacity>

          <View style={styles.notice}>
            <Text style={styles.noticeText}>
              جميع المعلومات محمية ومشفرة وفقاً لسياسة الخصوصية
            </Text>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { flex: 1 },
  scrollContent: { padding: 16, paddingBottom: 40 },
  checkingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  checkingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  required: {
    color: '#ef4444',
    fontWeight: 'bold',
  },
  headerCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 12,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 20,
  },
  section: { marginBottom: 24 },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    justifyContent: 'flex-end',
  },
  checkbox: {
    width: 24,
    height: 24,
    borderWidth: 2,
    borderColor: '#10b981',
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 12,
  },
  checkboxLabel: { fontSize: 16, color: '#0f172a', textAlign: 'right' },
  input: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
    minHeight: 50,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    marginTop: 12,
    textAlign: 'right',
  },
  optionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
    justifyContent: 'flex-end',
  },
  optionButton: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  optionButtonSmall: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  optionButtonActive: {
    backgroundColor: '#0ea5e9',
    borderColor: '#0ea5e9',
  },
  optionButtonText: { fontSize: 14, color: '#64748b', fontWeight: '600' },
  optionButtonTextActive: { color: '#ffffff' },
  sliderContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sliderButton: {
    width: 40,
    height: 40,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
  sliderButtonActive: {
    backgroundColor: '#0ea5e9',
    borderColor: '#0ea5e9',
  },
  sliderButtonText: { fontSize: 16, color: '#64748b', fontWeight: '600' },
  sliderButtonTextActive: { color: '#ffffff' },
  submitButton: {
    backgroundColor: '#0ea5e9',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  submitButtonDisabled: { opacity: 0.6 },
  submitButtonText: { color: '#ffffff', fontSize: 16, fontWeight: 'bold' },
  notice: {
    backgroundColor: '#e0f2fe',
    padding: 16,
    borderRadius: 12,
    marginTop: 16,
  },
  noticeText: {
    fontSize: 13,
    color: '#075985',
    textAlign: 'center',
    lineHeight: 20,
  },
});
