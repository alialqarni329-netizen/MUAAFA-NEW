import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { AlertCircle, Settings, Plus, Edit } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const CONTENT_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/content' },
  { name: 'bot', label: 'البوت الذكي', path: '/owner/content/bot' },
  { name: 'questions', label: 'الأسئلة', path: '/owner/content/questions' },
  { name: 'responses', label: 'الردود', path: '/owner/content/responses' },
  { name: 'forms', label: 'النماذج', path: '/owner/content/forms' },
  { name: 'policies', label: 'السياسات', path: '/owner/content/policies' },
  { name: 'limits', label: 'الحدود', path: '/owner/content/limits' },
  { name: 'review', label: 'المراجعة', path: '/owner/content/review' },
];

export default function Limits() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [limits, setLimits] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, active: 0 });

  useEffect(() => {
    loadLimits();
  }, []);

  async function loadLimits() {
    try {
      const { data, error } = await supabase
        .from('content_limits')
        .select('id, limit_type, limit_value, period, is_active, created_at, updated_at')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const { count: totalCount } = await supabase
        .from('content_limits')
        .select('*', { count: 'exact', head: true });

      const { count: activeCount } = await supabase
        .from('content_limits')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true);

      setLimits(data || []);
      setStats({ total: totalCount || 0, active: activeCount || 0 });
    } catch (error) {
      console.error('Error loading limits:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadLimits();
  }

  async function toggleLimitStatus(id: string, isActive: boolean) {
    try {
      await supabase
        .from('content_limits')
        .update({ is_active: !isActive })
        .eq('id', id);
      await loadLimits();
    } catch (error) {
      console.error('Error updating limit status:', error);
    }
  }

  async function deleteLimit(id: string) {
    try {
      await supabase
        .from('content_limits')
        .delete()
        .eq('id', id);
      await loadLimits();
    } catch (error) {
      console.error('Error deleting limit:', error);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الحدود...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <AlertCircle size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الحدود</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <Settings size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>الحدود النشطة</Text>
          </View>
        </View>
        <View style={styles.header}>
          <Text style={styles.sectionTitle}>حدود المحتوى</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.addButtonText}>إضافة حد</Text>
          </TouchableOpacity>
        </View>
        {limits.length > 0 ? (
          limits.map((limit: any) => (
            <View key={limit.id} style={styles.limitCard}>
              <View style={styles.limitHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.limitType}>{limit.limit_type}</Text>
                  <Text style={styles.limitValue}>الحد: {limit.limit_value} ({limit.period})</Text>
                </View>
                <TouchableOpacity onPress={() => toggleLimitStatus(limit.id, limit.is_active)} style={styles.actionButton}>
                  <Edit size={18} color="#f59e0b" strokeWidth={2} />
                </TouchableOpacity>
              </View>
              <View style={styles.limitFooter}>
                <View style={[styles.statusBadge, { backgroundColor: limit.is_active ? '#d1fae5' : '#fee2e2' }]}>
                  <Text style={[styles.statusText, { color: limit.is_active ? '#10b981' : '#ef4444' }]}>
                    {limit.is_active ? 'نشط' : 'معطل'}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => deleteLimit(limit.id)}
                  style={[styles.statusBadge, { backgroundColor: '#fee2e2' }]}>
                  <Text style={[styles.statusText, { color: '#ef4444' }]}>حذف</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <AlertCircle size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد حدود</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', textAlign: 'right' },
  addButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f59e0b', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, gap: 6 },
  addButtonText: { fontSize: 14, fontWeight: '600', color: '#ffffff' },
  limitCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  limitHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  limitType: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right', textTransform: 'capitalize' },
  limitValue: { fontSize: 12, color: '#64748b', textAlign: 'right', marginTop: 4 },
  actionButton: { padding: 8 },
  limitFooter: { flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'flex-end' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 11, fontWeight: '600' },
  settingCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', padding: 16, borderRadius: 12, gap: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  settingText: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right', flex: 1 },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
