import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { MessageSquare, Plus, Search, Edit } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const CONTENT_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/content' },
  { name: 'bot', label: 'البوت الذكي', path: '/owner/content/bot' },
  { name: 'questions', label: 'الأسئلة', path: '/owner/content/questions' },
  { name: 'responses', label: 'الردود', path: '/owner/content/responses' },
  { name: 'forms', label: 'النماذج', path: '/owner/content/forms' },
  { name: 'policies', label: 'السياسات', path: '/owner/content/policies' },
  { name: 'limits', label: 'الحدود', path: '/owner/content/limits' },
  { name: 'review', label: 'المراجعة', path: '/owner/content/review' },
];

export default function Responses() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [responses, setResponses] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, active: 0 });

  useEffect(() => {
    loadResponses();
  }, []);

  async function loadResponses() {
    try {
      const { data, error } = await supabase
        .from('questionnaire_responses')
        .select(`
          id,
          user_id,
          question_id,
          answer,
          created_at,
          health_questions:question_id (
            question_text,
            category
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const { count: totalCount } = await supabase
        .from('questionnaire_responses')
        .select('*', { count: 'exact', head: true });

      setResponses(data || []);
      setStats({ total: totalCount || 0, active: (data || []).length });
    } catch (error) {
      console.error('Error loading responses:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadResponses();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الردود...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <MessageSquare size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الردود</Text>
          </View>
        </View>
        <View style={styles.header}>
          <Text style={styles.sectionTitle}>ردود المستخدمين</Text>
        </View>
        {responses.length > 0 ? (
          responses.map((response: any) => (
            <View key={response.id} style={styles.responseCard}>
              <View style={styles.responseHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.questionTitle}>{response.health_questions?.question_text || 'سؤال'}</Text>
                  <Text style={styles.categoryLabel}>{response.health_questions?.category}</Text>
                </View>
              </View>
              <View style={styles.answerSection}>
                <Text style={styles.answerLabel}>الإجابة:</Text>
                <Text style={styles.answerText}>{response.answer}</Text>
              </View>
              <Text style={styles.timeStamp}>
                {new Date(response.created_at).toLocaleDateString('ar-SA')} {new Date(response.created_at).toLocaleTimeString('ar-SA')}
              </Text>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <MessageSquare size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد ردود</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', textAlign: 'right' },
  addButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#10b981', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, gap: 6 },
  addButtonText: { fontSize: 14, fontWeight: '600', color: '#ffffff' },
  responseCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  responseHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  questionTitle: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right' },
  categoryLabel: { fontSize: 12, color: '#64748b', textAlign: 'right', marginTop: 4 },
  answerSection: { backgroundColor: '#f0fdf4', padding: 12, borderRadius: 8, marginBottom: 8 },
  answerLabel: { fontSize: 12, fontWeight: '600', color: '#10b981', marginBottom: 4 },
  answerText: { fontSize: 14, color: '#0f172a', textAlign: 'right' },
  timeStamp: { fontSize: 11, color: '#94a3b8', textAlign: 'left' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
