import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { FileEdit, Plus, Edit } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const CONTENT_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/content' },
  { name: 'bot', label: 'البوت الذكي', path: '/owner/content/bot' },
  { name: 'questions', label: 'الأسئلة', path: '/owner/content/questions' },
  { name: 'responses', label: 'الردود', path: '/owner/content/responses' },
  { name: 'forms', label: 'النماذج', path: '/owner/content/forms' },
  { name: 'policies', label: 'السياسات', path: '/owner/content/policies' },
  { name: 'limits', label: 'الحدود', path: '/owner/content/limits' },
  { name: 'review', label: 'المراجعة', path: '/owner/content/review' },
];

export default function Forms() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [forms, setForms] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0 });

  useEffect(() => {
    loadForms();
  }, []);

  async function loadForms() {
    try {
      const { data, error } = await supabase
        .from('forms')
        .select('id, form_name, description, status, is_active, created_at, updated_at')
        .order('updated_at', { ascending: false });

      if (error) throw error;

      const { count: totalCount } = await supabase
        .from('forms')
        .select('*', { count: 'exact', head: true });

      setForms(data || []);
      setStats({ total: totalCount || 0 });
    } catch (error) {
      console.error('Error loading forms:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadForms();
  }

  async function toggleFormStatus(id: string, isActive: boolean) {
    try {
      await supabase
        .from('forms')
        .update({ is_active: !isActive })
        .eq('id', id);
      await loadForms();
    } catch (error) {
      console.error('Error updating form status:', error);
    }
  }

  async function deleteForm(id: string) {
    try {
      await supabase
        .from('forms')
        .delete()
        .eq('id', id);
      await loadForms();
    } catch (error) {
      console.error('Error deleting form:', error);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل النماذج...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#f3e8ff' }]}>
            <FileEdit size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي النماذج</Text>
          </View>
        </View>
        <View style={styles.header}>
          <Text style={styles.sectionTitle}>النماذج</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.addButtonText}>إضافة نموذج</Text>
          </TouchableOpacity>
        </View>
        {forms.length > 0 ? (
          forms.map((form: any) => (
            <View key={form.id} style={styles.formCard}>
              <View style={styles.formHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.formName}>{form.form_name || 'نموذج'}</Text>
                  {form.description && <Text style={styles.formDescription}>{form.description}</Text>}
                </View>
                <TouchableOpacity onPress={() => toggleFormStatus(form.id, form.is_active)} style={styles.actionButton}>
                  <Edit size={18} color="#8b5cf6" strokeWidth={2} />
                </TouchableOpacity>
              </View>
              <View style={styles.formFooter}>
                <View style={[styles.statusBadge, { backgroundColor: form.status === 'published' ? '#d1fae5' : '#fef3c7' }]}>
                  <Text style={[styles.statusText, { color: form.status === 'published' ? '#10b981' : '#f59e0b' }]}>
                    {form.status === 'published' ? 'منشور' : 'مسودة'}
                  </Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: form.is_active ? '#d1fae5' : '#fee2e2' }]}>
                  <Text style={[styles.statusText, { color: form.is_active ? '#10b981' : '#ef4444' }]}>
                    {form.is_active ? 'نشط' : 'معطل'}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => deleteForm(form.id)}
                  style={[styles.statusBadge, { backgroundColor: '#fee2e2' }]}>
                  <Text style={[styles.statusText, { color: '#ef4444' }]}>حذف</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <FileEdit size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد نماذج</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', textAlign: 'right' },
  addButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#8b5cf6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, gap: 6 },
  addButtonText: { fontSize: 14, fontWeight: '600', color: '#ffffff' },
  formCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  formHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  formName: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right' },
  formDescription: { fontSize: 12, color: '#64748b', textAlign: 'right', marginTop: 4 },
  actionButton: { padding: 8 },
  formFooter: { flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'flex-end' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 11, fontWeight: '600' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
