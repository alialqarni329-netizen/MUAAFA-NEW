import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Eye, CheckCircle, XCircle, Clock } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const CONTENT_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/content' },
  { name: 'bot', label: 'البوت الذكي', path: '/owner/content/bot' },
  { name: 'questions', label: 'الأسئلة', path: '/owner/content/questions' },
  { name: 'responses', label: 'الردود', path: '/owner/content/responses' },
  { name: 'forms', label: 'النماذج', path: '/owner/content/forms' },
  { name: 'policies', label: 'السياسات', path: '/owner/content/policies' },
  { name: 'limits', label: 'الحدود', path: '/owner/content/limits' },
  { name: 'review', label: 'المراجعة', path: '/owner/content/review' },
];

export default function Review() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [reviewItems, setReviewItems] = useState<any[]>([]);
  const [stats, setStats] = useState({ pending: 0, approved: 0, rejected: 0 });

  useEffect(() => {
    loadReviewItems();
  }, []);

  async function loadReviewItems() {
    try {
      const { data, error } = await supabase
        .from('content_reviews')
        .select('id, content_type, title, status, review_notes, revision_count, created_at, updated_at')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const { count: pendingCount } = await supabase
        .from('content_reviews')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      const { count: approvedCount } = await supabase
        .from('content_reviews')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'approved');

      const { count: rejectedCount } = await supabase
        .from('content_reviews')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'rejected');

      setReviewItems(data || []);
      setStats({
        pending: pendingCount || 0,
        approved: approvedCount || 0,
        rejected: rejectedCount || 0
      });
    } catch (error) {
      console.error('Error loading review items:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadReviewItems();
  }

  async function updateReviewStatus(id: string, newStatus: string) {
    try {
      await supabase
        .from('content_reviews')
        .update({ status: newStatus })
        .eq('id', id);
      await loadReviewItems();
    } catch (error) {
      console.error('Error updating review status:', error);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل قائمة المراجعة...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Clock size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>بانتظار المراجعة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <CheckCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.approved.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>موافق عليها</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <XCircle size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.rejected.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>مرفوضة</Text>
          </View>
        </View>
        <Text style={styles.sectionTitle}>قائمة المراجعة</Text>
        {reviewItems.length > 0 ? (
          reviewItems.map((item: any) => (
            <View key={item.id} style={styles.reviewCard}>
              <View style={styles.reviewHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.reviewTitle}>{item.title || 'عنصر'}</Text>
                  <View style={styles.reviewMeta}>
                    <Text style={styles.contentType}>{item.content_type}</Text>
                    {item.revision_count > 0 && (
                      <Text style={styles.revisionCount}>التعديلات: {item.revision_count}</Text>
                    )}
                  </View>
                </View>
                <View style={[styles.statusBadge, {
                  backgroundColor: item.status === 'pending' ? '#fef3c7' : item.status === 'approved' ? '#d1fae5' : '#fee2e2'
                }]}>
                  <Text style={[styles.statusText, {
                    color: item.status === 'pending' ? '#f59e0b' : item.status === 'approved' ? '#10b981' : '#ef4444'
                  }]}>
                    {item.status === 'pending' ? 'معلق' : item.status === 'approved' ? 'موافق' : 'مرفوض'}
                  </Text>
                </View>
              </View>
              {item.review_notes && (
                <View style={styles.notesSection}>
                  <Text style={styles.notesLabel}>الملاحظات:</Text>
                  <Text style={styles.notesText}>{item.review_notes}</Text>
                </View>
              )}
              {item.status === 'pending' && (
                <View style={styles.actionButtons}>
                  <TouchableOpacity
                    onPress={() => updateReviewStatus(item.id, 'approved')}
                    style={[styles.button, { backgroundColor: '#d1fae5' }]}>
                    <Text style={[styles.buttonText, { color: '#10b981' }]}>موافقة</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => updateReviewStatus(item.id, 'rejected')}
                    style={[styles.button, { backgroundColor: '#fee2e2' }]}>
                    <Text style={[styles.buttonText, { color: '#ef4444' }]}>رفض</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Eye size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد عناصر للمراجعة</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 12, textAlign: 'right' },
  reviewCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  reviewHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  reviewTitle: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right' },
  reviewMeta: { flexDirection: 'row', gap: 8, marginTop: 6 },
  contentType: { fontSize: 11, color: '#64748b', textTransform: 'capitalize' },
  revisionCount: { fontSize: 11, color: '#f59e0b', fontWeight: '600' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12 },
  statusText: { fontSize: 11, fontWeight: '600' },
  notesSection: { backgroundColor: '#f8fafc', padding: 12, borderRadius: 8, marginBottom: 12 },
  notesLabel: { fontSize: 12, fontWeight: '600', color: '#64748b', marginBottom: 4 },
  notesText: { fontSize: 13, color: '#0f172a', textAlign: 'right' },
  actionButtons: { flexDirection: 'row', gap: 8 },
  button: { flex: 1, paddingVertical: 8, borderRadius: 8, alignItems: 'center' },
  buttonText: { fontSize: 12, fontWeight: '600' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
