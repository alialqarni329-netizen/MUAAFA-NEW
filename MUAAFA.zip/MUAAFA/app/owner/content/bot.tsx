import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Bot, MessageSquare, TrendingUp, Settings } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const CONTENT_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/content' },
  { name: 'bot', label: 'البوت الذكي', path: '/owner/content/bot' },
  { name: 'questions', label: 'الأسئلة', path: '/owner/content/questions' },
  { name: 'responses', label: 'الردود', path: '/owner/content/responses' },
  { name: 'forms', label: 'النماذج', path: '/owner/content/forms' },
  { name: 'policies', label: 'السياسات', path: '/owner/content/policies' },
  { name: 'limits', label: 'الحدود', path: '/owner/content/limits' },
  { name: 'review', label: 'المراجعة', path: '/owner/content/review' },
];

export default function BotContent() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({ totalChats: 0, successfulReferrals: 0, conversionRate: 0 });

  useEffect(() => {
    loadBotStats();
  }, []);

  async function loadBotStats() {
    try {
      const { count: chatsCount } = await supabase
        .from('chat_conversations')
        .select('*', { count: 'exact', head: true });

      const { count: messagesCount } = await supabase
        .from('chat_messages')
        .select('*', { count: 'exact', head: true });

      const { count: aiResponsesCount } = await supabase
        .from('chat_messages')
        .select('*', { count: 'exact', head: true })
        .eq('sender_type', 'bot');

      const { count: userMessagesCount } = await supabase
        .from('chat_messages')
        .select('*', { count: 'exact', head: true })
        .eq('sender_type', 'user');

      const conversionRate = messagesCount > 0 ? ((aiResponsesCount || 0) / (messagesCount || 1)) * 100 : 0;

      setStats({
        totalChats: chatsCount || 0,
        successfulReferrals: aiResponsesCount || 0,
        conversionRate
      });
    } catch (error) {
      console.error('Error loading bot stats:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadBotStats();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل بيانات البوت...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <MessageSquare size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalChats.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي المحادثات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <Bot size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.successfulReferrals.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>تحويلات ناجحة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#f3e8ff' }]}>
            <TrendingUp size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.conversionRate.toFixed(1)}%</Text>
            <Text style={styles.statLabel}>معدل التحويل</Text>
          </View>
        </View>
        <View style={styles.settingsSection}>
          <Text style={styles.sectionTitle}>إعدادات البوت الذكي</Text>
          <TouchableOpacity style={styles.settingCard}>
            <Settings size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.settingText}>إعدادات الذكاء الاصطناعي</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingCard}>
            <MessageSquare size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.settingText}>سيناريوهات المحادثة</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  settingsSection: { marginTop: 20 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 12, textAlign: 'right' },
  settingCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, gap: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  settingText: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right', flex: 1 },
});
