import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { FileText, Bot, HelpCircle, MessageSquare, FileEdit, Shield, AlertCircle, Eye } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const CONTENT_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/content' },
  { name: 'bot', label: 'البوت الذكي', path: '/owner/content/bot' },
  { name: 'questions', label: 'الأسئلة', path: '/owner/content/questions' },
  { name: 'responses', label: 'الردود', path: '/owner/content/responses' },
  { name: 'forms', label: 'النماذج', path: '/owner/content/forms' },
  { name: 'policies', label: 'السياسات', path: '/owner/content/policies' },
  { name: 'limits', label: 'الحدود', path: '/owner/content/limits' },
  { name: 'review', label: 'المراجعة', path: '/owner/content/review' },
];

export default function ContentOverview() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    totalQuestions: 0,
    totalResponses: 0,
    totalForms: 0,
    pendingReview: 0,
    totalPolicies: 0,
    totalChats: 0
  });

  useEffect(() => {
    loadStats();
  }, []);

  async function loadStats() {
    try {
      const [questionsRes, responsesRes, formsRes, reviewRes, policiesRes, conversationsRes] = await Promise.all([
        supabase.from('health_questions').select('*', { count: 'exact', head: true }),
        supabase.from('questionnaire_responses').select('*', { count: 'exact', head: true }),
        supabase.from('forms').select('*', { count: 'exact', head: true }),
        supabase.from('content_reviews').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('legal_pages').select('*', { count: 'exact', head: true }),
        supabase.from('chat_conversations').select('*', { count: 'exact', head: true })
      ]);

      const questionsCount = questionsRes.count || 0;
      const responsesCount = responsesRes.count || 0;
      const formsCount = formsRes.count || 0;
      const pendingReview = reviewRes.count || 0;
      const policiesCount = policiesRes.count || 0;
      const conversationsCount = conversationsRes.count || 0;

      setStats({
        totalQuestions: questionsCount,
        totalResponses: responsesCount,
        totalForms: formsCount,
        pendingReview,
        totalPolicies: policiesCount,
        totalChats: conversationsCount
      });
    } catch (error) {
      console.error('Error loading content stats:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadStats();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل بيانات المحتوى...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <Text style={styles.pageTitle}>نظرة عامة على المحتوى</Text>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <HelpCircle size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalQuestions.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>الأسئلة الصحية</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <MessageSquare size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalChats.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>المحادثات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#f3e8ff' }]}>
            <FileEdit size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalForms.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>النماذج</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Eye size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pendingReview.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>بانتظار المراجعة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fce7f3' }]}>
            <Shield size={24} color="#ec4899" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalPolicies.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>السياسات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#ddd6fe' }]}>
            <FileText size={24} color="#6366f1" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalResponses.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>ردود المستخدمين</Text>
          </View>
        </View>
        <View style={styles.quickLinks}>
          <Text style={styles.sectionTitle}>الإدارة السريعة</Text>
          <View style={styles.linkCard}>
            <Bot size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.linkText}>إدارة البوت الذكي</Text>
          </View>
          <View style={styles.linkCard}>
            <HelpCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.linkText}>إدارة الأسئلة الصحية</Text>
          </View>
          <View style={styles.linkCard}>
            <Shield size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.linkText}>إدارة السياسات والشروط</Text>
          </View>
        </View>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  pageTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 16, textAlign: 'right' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 16, borderRadius: 12, alignItems: 'center', gap: 8 },
  statValue: { fontSize: 24, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 12, color: '#64748b', textAlign: 'center' },
  quickLinks: { marginTop: 20 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 12, textAlign: 'right' },
  linkCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, gap: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  linkText: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right', flex: 1 },
});
