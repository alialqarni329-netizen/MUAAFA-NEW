import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Shield, Plus, Edit } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const CONTENT_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/content' },
  { name: 'bot', label: 'البوت الذكي', path: '/owner/content/bot' },
  { name: 'questions', label: 'الأسئلة', path: '/owner/content/questions' },
  { name: 'responses', label: 'الردود', path: '/owner/content/responses' },
  { name: 'forms', label: 'النماذج', path: '/owner/content/forms' },
  { name: 'policies', label: 'السياسات', path: '/owner/content/policies' },
  { name: 'limits', label: 'الحدود', path: '/owner/content/limits' },
  { name: 'review', label: 'المراجعة', path: '/owner/content/review' },
];

export default function Policies() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [policies, setPolicies] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0 });

  useEffect(() => {
    loadPolicies();
  }, []);

  async function loadPolicies() {
    try {
      const { data, error } = await supabase
        .from('legal_pages')
        .select('id, page_type, title_ar, is_published, version, last_reviewed_at, updated_at')
        .order('updated_at', { ascending: false });

      if (error) throw error;

      const { count: totalCount } = await supabase
        .from('legal_pages')
        .select('*', { count: 'exact', head: true });

      setPolicies(data || []);
      setStats({ total: totalCount || 0 });
    } catch (error) {
      console.error('Error loading policies:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadPolicies();
  }

  async function togglePublish(id: string, isPublished: boolean) {
    try {
      await supabase
        .from('legal_pages')
        .update({ is_published: !isPublished, last_reviewed_at: new Date().toISOString() })
        .eq('id', id);
      await loadPolicies();
    } catch (error) {
      console.error('Error updating policy:', error);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل السياسات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Shield size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي السياسات</Text>
          </View>
        </View>
        <View style={styles.header}>
          <Text style={styles.sectionTitle}>السياسات والشروط</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.addButtonText}>إضافة سياسة</Text>
          </TouchableOpacity>
        </View>
        {policies.length > 0 ? (
          policies.map((policy: any) => (
            <View key={policy.id} style={styles.policyCard}>
              <View style={styles.policyHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.policyTitle}>{policy.title_ar || 'سياسة'}</Text>
                  <Text style={styles.policyType}>{policy.page_type}</Text>
                </View>
                <TouchableOpacity onPress={() => togglePublish(policy.id, policy.is_published)}>
                  <Edit size={18} color="#3b82f6" strokeWidth={2} />
                </TouchableOpacity>
              </View>
              <View style={styles.policyFooter}>
                <View style={[styles.statusBadge, { backgroundColor: policy.is_published ? '#d1fae5' : '#fee2e2' }]}>
                  <Text style={[styles.statusText, { color: policy.is_published ? '#10b981' : '#ef4444' }]}>
                    {policy.is_published ? 'منشورة' : 'مسودة'}
                  </Text>
                </View>
                <Text style={styles.versionText}>v{policy.version || '1.0'}</Text>
                {policy.last_reviewed_at && (
                  <Text style={styles.reviewedDate}>
                    آخر تحديث: {new Date(policy.last_reviewed_at).toLocaleDateString('ar-SA')}
                  </Text>
                )}
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Shield size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد سياسات</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', textAlign: 'right' },
  addButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#3b82f6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, gap: 6 },
  addButtonText: { fontSize: 14, fontWeight: '600', color: '#ffffff' },
  policyCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  policyHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  policyTitle: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right' },
  policyType: { fontSize: 12, color: '#64748b', textAlign: 'right', marginTop: 4, textTransform: 'capitalize' },
  policyFooter: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'flex-end' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 11, fontWeight: '600' },
  versionText: { fontSize: 11, color: '#64748b' },
  reviewedDate: { fontSize: 10, color: '#94a3b8' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
