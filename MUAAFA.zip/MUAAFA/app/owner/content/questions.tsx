import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { HelpCircle, Plus, Search, Edit } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const CONTENT_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/content' },
  { name: 'bot', label: 'البوت الذكي', path: '/owner/content/bot' },
  { name: 'questions', label: 'الأسئلة', path: '/owner/content/questions' },
  { name: 'responses', label: 'الردود', path: '/owner/content/responses' },
  { name: 'forms', label: 'النماذج', path: '/owner/content/forms' },
  { name: 'policies', label: 'السياسات', path: '/owner/content/policies' },
  { name: 'limits', label: 'الحدود', path: '/owner/content/limits' },
  { name: 'review', label: 'المراجعة', path: '/owner/content/review' },
];

export default function Questions() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [questions, setQuestions] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, active: 0, inactive: 0 });

  useEffect(() => {
    loadQuestions();
  }, []);

  async function loadQuestions() {
    try {
      const { data, error } = await supabase
        .from('health_questions')
        .select('id, question_text, category, is_required, is_active, display_order, created_at')
        .order('display_order', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: false });

      if (error) throw error;

      const { count: totalCount } = await supabase
        .from('health_questions')
        .select('*', { count: 'exact', head: true });

      const { count: activeCount } = await supabase
        .from('health_questions')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true);

      setQuestions(data || []);
      setStats({
        total: totalCount || 0,
        active: activeCount || 0,
        inactive: (totalCount || 0) - (activeCount || 0)
      });
    } catch (error) {
      console.error('Error loading questions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadQuestions();
  }

  async function toggleQuestionStatus(id: string, isActive: boolean) {
    try {
      await supabase
        .from('health_questions')
        .update({ is_active: !isActive })
        .eq('id', id);
      await loadQuestions();
    } catch (error) {
      console.error('Error updating question status:', error);
    }
  }

  async function deleteQuestion(id: string) {
    try {
      await supabase
        .from('health_questions')
        .delete()
        .eq('id', id);
      await loadQuestions();
    } catch (error) {
      console.error('Error deleting question:', error);
    }
  }

  const filteredQuestions = questions.filter(q => q.question_text?.toLowerCase().includes(searchQuery.toLowerCase()));

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الأسئلة...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المحتوى" tabs={CONTENT_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <HelpCircle size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الأسئلة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <HelpCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>نشطة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <HelpCircle size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.inactive.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>غير نشطة</Text>
          </View>
        </View>
        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput style={styles.searchInput} placeholder="البحث في الأسئلة..." placeholderTextColor="#94a3b8" value={searchQuery} onChangeText={setSearchQuery} textAlign="right" />
        </View>
        <View style={styles.header}>
          <Text style={styles.sectionTitle}>الأسئلة الصحية</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.addButtonText}>إضافة سؤال</Text>
          </TouchableOpacity>
        </View>
        {filteredQuestions.length > 0 ? (
          filteredQuestions.map((question) => (
            <View key={question.id} style={styles.questionCard}>
              <View style={styles.questionHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.questionText}>{question.question_text}</Text>
                  <Text style={styles.categoryText}>{question.category}</Text>
                </View>
                <TouchableOpacity onPress={() => toggleQuestionStatus(question.id, question.is_active)} style={styles.actionButton}>
                  <Edit size={18} color="#3b82f6" strokeWidth={2} />
                </TouchableOpacity>
              </View>
              <View style={styles.questionFooter}>
                <View style={[styles.statusBadge, { backgroundColor: question.is_active ? '#d1fae5' : '#fee2e2' }]}>
                  <Text style={[styles.statusText, { color: question.is_active ? '#10b981' : '#ef4444' }]}>
                    {question.is_active ? 'نشطة' : 'غير نشطة'}
                  </Text>
                </View>
                {question.is_required && (
                  <View style={styles.requiredBadge}>
                    <Text style={styles.requiredText}>مطلوبة</Text>
                  </View>
                )}
                <TouchableOpacity
                  onPress={() => deleteQuestion(question.id)}
                  style={[styles.statusBadge, { backgroundColor: '#fee2e2' }]}>
                  <Text style={[styles.statusText, { color: '#ef4444' }]}>حذف</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <HelpCircle size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد أسئلة</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 20, gap: 8, borderWidth: 1, borderColor: '#e2e8f0' },
  searchInput: { flex: 1, fontSize: 14, color: '#0f172a' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', textAlign: 'right' },
  addButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#3b82f6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, gap: 6 },
  addButtonText: { fontSize: 14, fontWeight: '600', color: '#ffffff' },
  questionCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  questionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 },
  questionText: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right', flex: 1 },
  categoryText: { fontSize: 12, color: '#64748b', textAlign: 'right', marginTop: 4 },
  actionButton: { padding: 8 },
  questionFooter: { flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'flex-end' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 11, fontWeight: '600' },
  requiredBadge: { backgroundColor: '#fef3c7', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  requiredText: { fontSize: 11, fontWeight: '600', color: '#f59e0b' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
