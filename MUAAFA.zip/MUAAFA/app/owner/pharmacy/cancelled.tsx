import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { XCircle, Search, DollarSign, AlertCircle, TrendingDown, Building2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PHARMACY_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/pharmacy' },
  { name: 'orders', label: 'الطلبات', path: '/owner/pharmacy/orders' },
  { name: 'completed', label: 'المكتملة', path: '/owner/pharmacy/completed' },
  { name: 'cancelled', label: 'الملغاة', path: '/owner/pharmacy/cancelled' },
  { name: 'medications', label: 'الأدوية', path: '/owner/pharmacy/medications' },
  { name: 'availability', label: 'التوفر', path: '/owner/pharmacy/availability' },
  { name: 'pricing', label: 'التسعير', path: '/owner/pharmacy/pricing' },
  { name: 'history', label: 'السجل', path: '/owner/pharmacy/history' },
];

const COMMISSION_RATE = 0.10;

interface CancelledOrder {
  id: string;
  order_id: string;
  pharmacy_id: string;
  status: string;
  rejection_reason: string;
  created_at: string;
  pharmacy?: {
    business_name_ar: string;
  };
}

export default function CancelledOrders() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [orders, setOrders] = useState<CancelledOrder[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<CancelledOrder[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    lostRevenue: 0,
    lostCommission: 0,
    topReason: '',
  });

  useEffect(() => {
    loadCancelledOrders();
  }, []);

  useEffect(() => {
    filterOrders();
  }, [searchQuery, orders]);

  async function loadCancelledOrders() {
    try {
      const { data: ordersData } = await supabase
        .from('pharmacy_order_requests')
        .select(`
          *,
          pharmacy:business_registrations!pharmacy_order_requests_pharmacy_id_fkey(business_name_ar)
        `)
        .eq('status', 'rejected')
        .order('created_at', { ascending: false });

      const cancelledOrders = ordersData || [];

      // Mock revenue calculation
      const estimatedOrderValue = 150;
      const lostRevenue = cancelledOrders.length * estimatedOrderValue;
      const lostCommission = lostRevenue * COMMISSION_RATE;

      // Find most common cancellation reason
      const reasons: { [key: string]: number } = {};
      cancelledOrders.forEach(order => {
        const reason = order.rejection_reason || 'غير محدد';
        reasons[reason] = (reasons[reason] || 0) + 1;
      });
      const topReason = Object.keys(reasons).sort((a, b) => reasons[b] - reasons[a])[0] || 'غير محدد';

      setStats({
        total: cancelledOrders.length,
        lostRevenue,
        lostCommission,
        topReason,
      });

      setOrders(cancelledOrders);
      setFilteredOrders(cancelledOrders);
    } catch (error) {
      console.error('Error loading cancelled orders:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterOrders() {
    if (!searchQuery.trim()) {
      setFilteredOrders(orders);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = orders.filter(
      order =>
        order.pharmacy?.business_name_ar?.toLowerCase().includes(query) ||
        order.order_id?.toLowerCase().includes(query) ||
        order.rejection_reason?.toLowerCase().includes(query)
    );
    setFilteredOrders(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadCancelledOrders();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل الطلبات الملغاة...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.commissionCard}>
          <Text style={styles.commissionTitle}>نموذج العمولة</Text>
          <View style={styles.commissionBreakdown}>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>عمولة المنصة:</Text>
              <Text style={styles.commissionPlatform}>10%</Text>
            </View>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>حصة الصيدلية:</Text>
              <Text style={styles.commissionPharmacy}>90%</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <XCircle size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الملغاة</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingDown size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.lostRevenue)}</Text>
            <Text style={styles.statLabel}>إيرادات مفقودة</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.lostCommission)}</Text>
            <Text style={styles.statLabel}>عمولة مفقودة (10%)</Text>
          </View>

          <View style={styles.statCard}>
            <AlertCircle size={22} color="#64748b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.topReason}</Text>
            <Text style={styles.statLabel}>السبب الأكثر شيوعاً</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في الطلبات الملغاة..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredOrders.length > 0 ? (
          filteredOrders.map((order) => (
            <View key={order.id} style={styles.orderCard}>
              <View style={styles.orderHeader}>
                <View style={styles.statusBadge}>
                  <XCircle size={14} color="#ef4444" strokeWidth={2} />
                  <Text style={styles.statusText}>ملغي</Text>
                </View>
                <Text style={styles.orderDate}>{formatDate(order.created_at)}</Text>
              </View>

              <View style={styles.orderDetails}>
                <View style={styles.pharmacyInfo}>
                  <Building2 size={16} color="#8b5cf6" strokeWidth={2} />
                  <Text style={styles.pharmacyName}>{order.pharmacy?.business_name_ar || 'غير محدد'}</Text>
                </View>

                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>رقم الطلب:</Text>
                  <Text style={styles.detailValue}>{order.order_id || '-'}</Text>
                </View>

                {order.rejection_reason && (
                  <View style={styles.reasonBox}>
                    <Text style={styles.reasonLabel}>سبب الإلغاء:</Text>
                    <Text style={styles.reasonText}>{order.rejection_reason}</Text>
                  </View>
                )}
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <XCircle size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد طلبات ملغاة'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  commissionCard: {
    backgroundColor: '#f0f9ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#3b82f6',
  },
  commissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
    textAlign: 'center',
    marginBottom: 12,
  },
  commissionBreakdown: {
    gap: 8,
  },
  commissionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  commissionLabel: {
    fontSize: 14,
    color: '#1e40af',
    fontWeight: '600',
  },
  commissionPlatform: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#3b82f6',
  },
  commissionPharmacy: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#10b981',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  orderCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fee2e2',
  },
  orderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#fef2f2',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: '#fee2e220',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ef4444',
  },
  orderDate: {
    fontSize: 11,
    color: '#94a3b8',
  },
  orderDetails: {
    gap: 10,
  },
  pharmacyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#f5f3ff',
    borderRadius: 8,
    alignSelf: 'flex-end',
  },
  pharmacyName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#7c3aed',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  reasonBox: {
    backgroundColor: '#fef2f2',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#fee2e2',
  },
  reasonLabel: {
    fontSize: 12,
    color: '#991b1b',
    fontWeight: '600',
    marginBottom: 4,
  },
  reasonText: {
    fontSize: 13,
    color: '#dc2626',
    lineHeight: 20,
    textAlign: 'right',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
