import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Package, Search, Clock, CheckCircle, XCircle, DollarSign, TrendingUp, Building2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PHARMACY_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/pharmacy' },
  { name: 'orders', label: 'الطلبات', path: '/owner/pharmacy/orders' },
  { name: 'completed', label: 'المكتملة', path: '/owner/pharmacy/completed' },
  { name: 'cancelled', label: 'الملغاة', path: '/owner/pharmacy/cancelled' },
  { name: 'medications', label: 'الأدوية', path: '/owner/pharmacy/medications' },
  { name: 'availability', label: 'التوفر', path: '/owner/pharmacy/availability' },
  { name: 'pricing', label: 'التسعير', path: '/owner/pharmacy/pricing' },
  { name: 'history', label: 'السجل', path: '/owner/pharmacy/history' },
];

const COMMISSION_RATE = 0.10;

interface Order {
  id: string;
  order_id: string;
  pharmacy_id: string;
  status: string;
  estimated_preparation_time: number;
  rejection_reason: string;
  accepted_at: string;
  ready_at: string;
  created_at: string;
  pharmacy?: {
    business_name_ar: string;
  };
}

export default function Orders() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'accepted' | 'rejected'>('all');
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    accepted: 0,
    rejected: 0,
    totalRevenue: 0,
    platformCommission: 0,
  });

  useEffect(() => {
    loadOrders();
  }, []);

  useEffect(() => {
    filterOrders();
  }, [searchQuery, filterStatus, orders]);

  async function loadOrders() {
    try {
      const { data: ordersData } = await supabase
        .from('pharmacy_order_requests')
        .select(`
          *,
          pharmacy:business_registrations!pharmacy_order_requests_pharmacy_id_fkey(business_name_ar)
        `)
        .order('created_at', { ascending: false });

      const allOrders = ordersData || [];

      const pending = allOrders.filter(o => o.status === 'pending').length;
      const accepted = allOrders.filter(o => o.status === 'accepted' || o.status === 'ready').length;
      const rejected = allOrders.filter(o => o.status === 'rejected').length;

      // Mock revenue calculation
      const mockOrderValue = 150;
      const totalRevenue = allOrders.length * mockOrderValue;
      const platformCommission = totalRevenue * COMMISSION_RATE;

      setStats({
        total: allOrders.length,
        pending,
        accepted,
        rejected,
        totalRevenue,
        platformCommission,
      });

      setOrders(allOrders);
      setFilteredOrders(allOrders);
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterOrders() {
    let filtered = orders;

    // Apply status filter
    if (filterStatus !== 'all') {
      if (filterStatus === 'accepted') {
        filtered = filtered.filter(o => o.status === 'accepted' || o.status === 'ready');
      } else {
        filtered = filtered.filter(o => o.status === filterStatus);
      }
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        order =>
          order.pharmacy?.business_name_ar?.toLowerCase().includes(query) ||
          order.order_id?.toLowerCase().includes(query)
      );
    }

    setFilteredOrders(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadOrders();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'accepted': return '#10b981';
      case 'ready': return '#10b981';
      case 'pending': return '#f59e0b';
      case 'rejected': return '#ef4444';
      default: return '#64748b';
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'accepted': return 'مقبول';
      case 'ready': return 'جاهز';
      case 'pending': return 'قيد الانتظار';
      case 'rejected': return 'ملغي';
      default: return status;
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'accepted': case 'ready': return CheckCircle;
      case 'pending': return Clock;
      case 'rejected': return XCircle;
      default: return Package;
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل الطلبات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.commissionCard}>
          <Text style={styles.commissionTitle}>نموذج العمولة</Text>
          <View style={styles.commissionBreakdown}>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>عمولة المنصة:</Text>
              <Text style={styles.commissionPlatform}>10%</Text>
            </View>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>حصة الصيدلية:</Text>
              <Text style={styles.commissionPharmacy}>90%</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Package size={22} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الطلبات</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending}</Text>
            <Text style={styles.statLabel}>قيد الانتظار</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.accepted}</Text>
            <Text style={styles.statLabel}>مقبولة</Text>
          </View>

          <View style={styles.statCard}>
            <XCircle size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.rejected}</Text>
            <Text style={styles.statLabel}>ملغاة</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.totalRevenue)}</Text>
            <Text style={styles.statLabel}>إجمالي الإيرادات</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.platformCommission)}</Text>
            <Text style={styles.statLabel}>عمولة المنصة (10%)</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في الطلبات..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'all' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('all')}>
            <Text style={[styles.filterText, filterStatus === 'all' && styles.filterTextActive]}>الكل</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'pending' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('pending')}>
            <Text style={[styles.filterText, filterStatus === 'pending' && styles.filterTextActive]}>قيد الانتظار</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'accepted' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('accepted')}>
            <Text style={[styles.filterText, filterStatus === 'accepted' && styles.filterTextActive]}>مقبولة</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'rejected' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('rejected')}>
            <Text style={[styles.filterText, filterStatus === 'rejected' && styles.filterTextActive]}>ملغاة</Text>
          </TouchableOpacity>
        </View>

        {filteredOrders.length > 0 ? (
          filteredOrders.map((order) => {
            const StatusIcon = getStatusIcon(order.status);
            const mockOrderValue = 150;
            const platformCommission = mockOrderValue * COMMISSION_RATE;
            const pharmacyShare = mockOrderValue * (1 - COMMISSION_RATE);

            return (
              <View key={order.id} style={styles.orderCard}>
                <View style={styles.orderHeader}>
                  <View style={[styles.statusBadge, { backgroundColor: getStatusColor(order.status) + '20' }]}>
                    <StatusIcon size={14} color={getStatusColor(order.status)} strokeWidth={2} />
                    <Text style={[styles.statusText, { color: getStatusColor(order.status) }]}>
                      {getStatusText(order.status)}
                    </Text>
                  </View>
                  <Text style={styles.orderDate}>{formatDate(order.created_at)}</Text>
                </View>

                <View style={styles.orderDetails}>
                  <View style={styles.pharmacyInfo}>
                    <Building2 size={16} color="#8b5cf6" strokeWidth={2} />
                    <Text style={styles.pharmacyName}>{order.pharmacy?.business_name_ar || 'غير محدد'}</Text>
                  </View>

                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>رقم الطلب:</Text>
                    <Text style={styles.detailValue}>{order.order_id || '-'}</Text>
                  </View>

                  {order.estimated_preparation_time && (
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>وقت التحضير المتوقع:</Text>
                      <Text style={styles.detailValue}>{order.estimated_preparation_time} دقيقة</Text>
                    </View>
                  )}

                  {order.rejection_reason && (
                    <View style={styles.reasonBox}>
                      <Text style={styles.reasonLabel}>سبب الإلغاء:</Text>
                      <Text style={styles.reasonText}>{order.rejection_reason}</Text>
                    </View>
                  )}

                  <View style={styles.commissionBox}>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>قيمة الطلب:</Text>
                      <Text style={styles.priceText}>{formatCurrency(mockOrderValue)}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>عمولة المنصة (10%):</Text>
                      <Text style={styles.commissionText}>{formatCurrency(platformCommission)}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>حصة الصيدلية (90%):</Text>
                      <Text style={styles.pharmacyShareText}>{formatCurrency(pharmacyShare)}</Text>
                    </View>
                  </View>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Package size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد طلبات'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  commissionCard: {
    backgroundColor: '#f0f9ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#3b82f6',
  },
  commissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
    textAlign: 'center',
    marginBottom: 12,
  },
  commissionBreakdown: {
    gap: 8,
  },
  commissionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  commissionLabel: {
    fontSize: 14,
    color: '#1e40af',
    fontWeight: '600',
  },
  commissionPlatform: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#3b82f6',
  },
  commissionPharmacy: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#10b981',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 10,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
  },
  filterButtonActive: {
    backgroundColor: '#8b5cf6',
  },
  filterText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
  },
  filterTextActive: {
    color: '#ffffff',
  },
  orderCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  orderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3e8ff',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  orderDate: {
    fontSize: 11,
    color: '#94a3b8',
  },
  orderDetails: {
    gap: 10,
  },
  pharmacyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#f5f3ff',
    borderRadius: 8,
    alignSelf: 'flex-end',
  },
  pharmacyName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#7c3aed',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  reasonBox: {
    backgroundColor: '#fef2f2',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#fee2e2',
  },
  reasonLabel: {
    fontSize: 12,
    color: '#991b1b',
    fontWeight: '600',
    marginBottom: 4,
  },
  reasonText: {
    fontSize: 13,
    color: '#dc2626',
    lineHeight: 20,
    textAlign: 'right',
  },
  commissionBox: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    gap: 8,
    marginTop: 4,
  },
  priceText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'left',
  },
  commissionText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#3b82f6',
    textAlign: 'left',
  },
  pharmacyShareText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#10b981',
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
