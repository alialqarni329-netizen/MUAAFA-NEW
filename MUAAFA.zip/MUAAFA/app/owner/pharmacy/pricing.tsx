import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { DollarSign, Search, TrendingUp, TrendingDown, Package, Building2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PHARMACY_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/pharmacy' },
  { name: 'orders', label: 'الطلبات', path: '/owner/pharmacy/orders' },
  { name: 'completed', label: 'المكتملة', path: '/owner/pharmacy/completed' },
  { name: 'cancelled', label: 'الملغاة', path: '/owner/pharmacy/cancelled' },
  { name: 'medications', label: 'الأدوية', path: '/owner/pharmacy/medications' },
  { name: 'availability', label: 'التوفر', path: '/owner/pharmacy/availability' },
  { name: 'pricing', label: 'التسعير', path: '/owner/pharmacy/pricing' },
  { name: 'history', label: 'السجل', path: '/owner/pharmacy/history' },
];

const COMMISSION_RATE = 0.10;

interface PricingItem {
  id: string;
  medicine_name: string;
  pharmacy_id: string;
  pharmacy_name: string;
  price: number;
  availability: boolean;
  last_updated: string;
}

export default function PharmacyPricing() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pricing, setPricing] = useState<PricingItem[]>([]);
  const [filteredPricing, setFilteredPricing] = useState<PricingItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'lowest' | 'highest' | 'recent'>('recent');
  const [stats, setStats] = useState({
    totalItems: 0,
    avgPrice: 0,
    lowestPrice: 0,
    highestPrice: 0,
    totalRevenue: 0,
    platformCommission: 0,
  });

  useEffect(() => {
    loadPricing();
  }, []);

  useEffect(() => {
    filterPricing();
  }, [searchQuery, sortBy, pricing]);

  async function loadPricing() {
    try {
      const { data: pricingData } = await supabase
        .from('pharmacy_prices')
        .select('*')
        .order('last_updated', { ascending: false });

      const allPricing = pricingData || [];

      const prices = allPricing.map(p => p.price || 0);
      const avgPrice = prices.length > 0 ? prices.reduce((a, b) => a + b, 0) / prices.length : 0;
      const lowestPrice = prices.length > 0 ? Math.min(...prices) : 0;
      const highestPrice = prices.length > 0 ? Math.max(...prices) : 0;

      // Mock revenue calculation
      const totalRevenue = allPricing.length * 150;
      const platformCommission = totalRevenue * COMMISSION_RATE;

      setStats({
        totalItems: allPricing.length,
        avgPrice,
        lowestPrice,
        highestPrice,
        totalRevenue,
        platformCommission,
      });

      setPricing(allPricing);
      setFilteredPricing(allPricing);
    } catch (error) {
      console.error('Error loading pricing:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterPricing() {
    let filtered = pricing;

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        item =>
          item.medicine_name?.toLowerCase().includes(query) ||
          item.pharmacy_name?.toLowerCase().includes(query)
      );
    }

    // Apply sorting
    filtered = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'lowest':
          return a.price - b.price;
        case 'highest':
          return b.price - a.price;
        case 'recent':
        default:
          return new Date(b.last_updated).getTime() - new Date(a.last_updated).getTime();
      }
    });

    setFilteredPricing(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadPricing();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 2,
    }).format(amount);
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل الأسعار...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.commissionCard}>
          <Text style={styles.commissionTitle}>نموذج العمولة</Text>
          <View style={styles.commissionBreakdown}>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>عمولة المنصة:</Text>
              <Text style={styles.commissionPlatform}>10%</Text>
            </View>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>حصة الصيدلية:</Text>
              <Text style={styles.commissionPharmacy}>90%</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Package size={22} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalItems}</Text>
            <Text style={styles.statLabel}>إجمالي الأصناف</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.avgPrice)}</Text>
            <Text style={styles.statLabel}>متوسط السعر</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingDown size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.lowestPrice)}</Text>
            <Text style={styles.statLabel}>أقل سعر</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.highestPrice)}</Text>
            <Text style={styles.statLabel}>أعلى سعر</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.totalRevenue)}</Text>
            <Text style={styles.statLabel}>إجمالي الإيرادات</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.platformCommission)}</Text>
            <Text style={styles.statLabel}>عمولة المنصة (10%)</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في الأسعار..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[styles.filterButton, sortBy === 'recent' && styles.filterButtonActive]}
            onPress={() => setSortBy('recent')}>
            <Text style={[styles.filterText, sortBy === 'recent' && styles.filterTextActive]}>الأحدث</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, sortBy === 'lowest' && styles.filterButtonActive]}
            onPress={() => setSortBy('lowest')}>
            <Text style={[styles.filterText, sortBy === 'lowest' && styles.filterTextActive]}>الأقل سعراً</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, sortBy === 'highest' && styles.filterButtonActive]}
            onPress={() => setSortBy('highest')}>
            <Text style={[styles.filterText, sortBy === 'highest' && styles.filterTextActive]}>الأعلى سعراً</Text>
          </TouchableOpacity>
        </View>

        {filteredPricing.length > 0 ? (
          filteredPricing.map((item) => {
            const platformCommission = item.price * COMMISSION_RATE;
            const pharmacyShare = item.price * (1 - COMMISSION_RATE);

            return (
              <View key={item.id} style={styles.pricingCard}>
                <View style={styles.pricingHeader}>
                  <View style={styles.medicineInfo}>
                    <Text style={styles.medicineName}>{item.medicine_name}</Text>
                    <View style={styles.pharmacyTag}>
                      <Building2 size={12} color="#8b5cf6" strokeWidth={2} />
                      <Text style={styles.pharmacyText}>{item.pharmacy_name}</Text>
                    </View>
                  </View>
                  {!item.availability && (
                    <View style={styles.unavailableBadge}>
                      <Text style={styles.unavailableText}>غير متوفر</Text>
                    </View>
                  )}
                </View>

                <View style={styles.pricingDetails}>
                  <View style={styles.priceBox}>
                    <Text style={styles.priceLabel}>السعر:</Text>
                    <Text style={styles.priceValue}>{formatCurrency(item.price)}</Text>
                  </View>

                  <View style={styles.commissionBox}>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>عمولة المنصة (10%):</Text>
                      <Text style={styles.commissionText}>{formatCurrency(platformCommission)}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>حصة الصيدلية (90%):</Text>
                      <Text style={styles.pharmacyShareText}>{formatCurrency(pharmacyShare)}</Text>
                    </View>
                  </View>

                  <View style={styles.detailRow}>
                    <Text style={styles.updateLabel}>آخر تحديث:</Text>
                    <Text style={styles.updateValue}>{formatDate(item.last_updated)}</Text>
                  </View>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <DollarSign size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد أسعار'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  commissionCard: {
    backgroundColor: '#f0f9ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#3b82f6',
  },
  commissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
    textAlign: 'center',
    marginBottom: 12,
  },
  commissionBreakdown: {
    gap: 8,
  },
  commissionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  commissionLabel: {
    fontSize: 14,
    color: '#1e40af',
    fontWeight: '600',
  },
  commissionPlatform: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#3b82f6',
  },
  commissionPharmacy: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#10b981',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 10,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
  },
  filterButtonActive: {
    backgroundColor: '#8b5cf6',
  },
  filterText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
  },
  filterTextActive: {
    color: '#ffffff',
  },
  pricingCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  pricingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3e8ff',
  },
  medicineInfo: {
    flex: 1,
  },
  medicineName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 6,
  },
  pharmacyTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 4,
    paddingHorizontal: 8,
    backgroundColor: '#f5f3ff',
    borderRadius: 6,
    alignSelf: 'flex-end',
  },
  pharmacyText: {
    fontSize: 11,
    color: '#7c3aed',
    fontWeight: '600',
  },
  unavailableBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    backgroundColor: '#fee2e220',
  },
  unavailableText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#ef4444',
  },
  pricingDetails: {
    gap: 10,
  },
  priceBox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#f0fdf4',
    padding: 12,
    borderRadius: 8,
  },
  priceLabel: {
    fontSize: 14,
    color: '#166534',
    fontWeight: '600',
  },
  priceValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#15803d',
  },
  commissionBox: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  commissionText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#3b82f6',
    textAlign: 'left',
  },
  pharmacyShareText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#10b981',
    textAlign: 'left',
  },
  updateLabel: {
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'right',
  },
  updateValue: {
    fontSize: 11,
    color: '#64748b',
    fontWeight: '600',
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
