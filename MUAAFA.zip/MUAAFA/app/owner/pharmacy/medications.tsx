import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Pill, Search, Package, AlertCircle, TrendingUp, Shield } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PHARMACY_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/pharmacy' },
  { name: 'orders', label: 'الطلبات', path: '/owner/pharmacy/orders' },
  { name: 'completed', label: 'المكتملة', path: '/owner/pharmacy/completed' },
  { name: 'cancelled', label: 'الملغاة', path: '/owner/pharmacy/cancelled' },
  { name: 'medications', label: 'الأدوية', path: '/owner/pharmacy/medications' },
  { name: 'availability', label: 'التوفر', path: '/owner/pharmacy/availability' },
  { name: 'pricing', label: 'التسعير', path: '/owner/pharmacy/pricing' },
  { name: 'history', label: 'السجل', path: '/owner/pharmacy/history' },
];

const COMMISSION_RATE = 0.10;

interface Medication {
  id: string;
  name: string;
  name_en: string;
  category: string;
  description: string;
  requires_prescription: boolean;
  created_at: string;
}

export default function Medications() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [filteredMedications, setFilteredMedications] = useState<Medication[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'prescription' | 'otc'>('all');
  const [stats, setStats] = useState({
    total: 0,
    prescription: 0,
    otc: 0,
    categories: 0,
  });

  useEffect(() => {
    loadMedications();
  }, []);

  useEffect(() => {
    filterMedications();
  }, [searchQuery, filterType, medications]);

  async function loadMedications() {
    try {
      const { data: medicationsData } = await supabase
        .from('medications')
        .select('*')
        .order('name', { ascending: true });

      const allMedications = medicationsData || [];
      const prescription = allMedications.filter(m => m.requires_prescription).length;
      const otc = allMedications.filter(m => !m.requires_prescription).length;
      const uniqueCategories = new Set(allMedications.map(m => m.category));

      setStats({
        total: allMedications.length,
        prescription,
        otc,
        categories: uniqueCategories.size,
      });

      setMedications(allMedications);
      setFilteredMedications(allMedications);
    } catch (error) {
      console.error('Error loading medications:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterMedications() {
    let filtered = medications;

    // Apply type filter
    if (filterType === 'prescription') {
      filtered = filtered.filter(m => m.requires_prescription);
    } else if (filterType === 'otc') {
      filtered = filtered.filter(m => !m.requires_prescription);
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        m =>
          m.name?.toLowerCase().includes(query) ||
          m.name_en?.toLowerCase().includes(query) ||
          m.category?.toLowerCase().includes(query)
      );
    }

    setFilteredMedications(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadMedications();
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل الأدوية...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.commissionCard}>
          <Text style={styles.commissionTitle}>نموذج العمولة</Text>
          <View style={styles.commissionBreakdown}>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>عمولة المنصة:</Text>
              <Text style={styles.commissionPlatform}>10%</Text>
            </View>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>حصة الصيدلية:</Text>
              <Text style={styles.commissionPharmacy}>90%</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Pill size={22} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الأدوية</Text>
          </View>

          <View style={styles.statCard}>
            <Shield size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.prescription}</Text>
            <Text style={styles.statLabel}>بوصفة طبية</Text>
          </View>

          <View style={styles.statCard}>
            <Package size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.otc}</Text>
            <Text style={styles.statLabel}>بدون وصفة</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.categories}</Text>
            <Text style={styles.statLabel}>الفئات</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في الأدوية..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[styles.filterButton, filterType === 'all' && styles.filterButtonActive]}
            onPress={() => setFilterType('all')}>
            <Text style={[styles.filterText, filterType === 'all' && styles.filterTextActive]}>الكل</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterType === 'prescription' && styles.filterButtonActive]}
            onPress={() => setFilterType('prescription')}>
            <Text style={[styles.filterText, filterType === 'prescription' && styles.filterTextActive]}>بوصفة</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterType === 'otc' && styles.filterButtonActive]}
            onPress={() => setFilterType('otc')}>
            <Text style={[styles.filterText, filterType === 'otc' && styles.filterTextActive]}>بدون وصفة</Text>
          </TouchableOpacity>
        </View>

        {filteredMedications.length > 0 ? (
          filteredMedications.map((medication) => (
            <View key={medication.id} style={styles.medicationCard}>
              <View style={styles.medicationHeader}>
                <View style={styles.leftSection}>
                  <Pill size={20} color="#8b5cf6" strokeWidth={2} />
                  <View style={styles.nameSection}>
                    <Text style={styles.medicationName}>{medication.name}</Text>
                    {medication.name_en && (
                      <Text style={styles.medicationNameEn}>{medication.name_en}</Text>
                    )}
                  </View>
                </View>
                {medication.requires_prescription && (
                  <View style={styles.prescriptionBadge}>
                    <Shield size={12} color="#ef4444" strokeWidth={2} />
                    <Text style={styles.prescriptionText}>وصفة</Text>
                  </View>
                )}
              </View>

              <View style={styles.medicationDetails}>
                <View style={styles.categoryTag}>
                  <Text style={styles.categoryText}>{medication.category || 'غير مصنف'}</Text>
                </View>

                {medication.description && (
                  <Text style={styles.descriptionText} numberOfLines={2}>
                    {medication.description}
                  </Text>
                )}

                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>تاريخ الإضافة:</Text>
                  <Text style={styles.detailValue}>{formatDate(medication.created_at)}</Text>
                </View>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Pill size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد أدوية'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  commissionCard: {
    backgroundColor: '#f0f9ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#3b82f6',
  },
  commissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
    textAlign: 'center',
    marginBottom: 12,
  },
  commissionBreakdown: {
    gap: 8,
  },
  commissionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  commissionLabel: {
    fontSize: 14,
    color: '#1e40af',
    fontWeight: '600',
  },
  commissionPlatform: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#3b82f6',
  },
  commissionPharmacy: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#10b981',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
  },
  filterButtonActive: {
    backgroundColor: '#8b5cf6',
  },
  filterText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
  },
  filterTextActive: {
    color: '#ffffff',
  },
  medicationCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  medicationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3e8ff',
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  nameSection: {
    flex: 1,
  },
  medicationName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  medicationNameEn: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  prescriptionBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    backgroundColor: '#fee2e220',
  },
  prescriptionText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#ef4444',
  },
  medicationDetails: {
    gap: 10,
  },
  categoryTag: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    backgroundColor: '#f5f3ff',
    borderRadius: 6,
    alignSelf: 'flex-end',
  },
  categoryText: {
    fontSize: 12,
    color: '#7c3aed',
    fontWeight: '600',
  },
  descriptionText: {
    fontSize: 13,
    color: '#64748b',
    lineHeight: 20,
    textAlign: 'right',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
