import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Package, Search, CheckCircle, XCircle, AlertTriangle, TrendingUp, Building2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PHARMACY_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/pharmacy' },
  { name: 'orders', label: 'الطلبات', path: '/owner/pharmacy/orders' },
  { name: 'completed', label: 'المكتملة', path: '/owner/pharmacy/completed' },
  { name: 'cancelled', label: 'الملغاة', path: '/owner/pharmacy/cancelled' },
  { name: 'medications', label: 'الأدوية', path: '/owner/pharmacy/medications' },
  { name: 'availability', label: 'التوفر', path: '/owner/pharmacy/availability' },
  { name: 'pricing', label: 'التسعير', path: '/owner/pharmacy/pricing' },
  { name: 'history', label: 'السجل', path: '/owner/pharmacy/history' },
];

const COMMISSION_RATE = 0.10;

interface InventoryItem {
  id: string;
  pharmacy_id: string;
  medication_id: string;
  price: number;
  stock_quantity: number;
  is_available: boolean;
  updated_at: string;
  pharmacy?: {
    business_name_ar: string;
  };
  medication?: {
    name: string;
    category: string;
  };
}

export default function MedicineAvailability() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [filteredInventory, setFilteredInventory] = useState<InventoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'available' | 'unavailable' | 'low'>('all');
  const [stats, setStats] = useState({
    total: 0,
    available: 0,
    unavailable: 0,
    lowStock: 0,
    averagePrice: 0,
  });

  useEffect(() => {
    loadInventory();
  }, []);

  useEffect(() => {
    filterInventory();
  }, [searchQuery, filterStatus, inventory]);

  async function loadInventory() {
    try {
      const { data: inventoryData } = await supabase
        .from('pharmacy_inventory')
        .select(`
          *,
          pharmacy:business_registrations!pharmacy_inventory_pharmacy_id_fkey(business_name_ar),
          medication:medications(name, category)
        `)
        .order('updated_at', { ascending: false });

      const items = inventoryData || [];

      const available = items.filter(item => item.is_available).length;
      const unavailable = items.filter(item => !item.is_available).length;
      const lowStock = items.filter(item => item.stock_quantity < 10 && item.is_available).length;
      const totalPrice = items.reduce((sum, item) => sum + (item.price || 0), 0);
      const avgPrice = items.length > 0 ? totalPrice / items.length : 0;

      setStats({
        total: items.length,
        available,
        unavailable,
        lowStock,
        averagePrice: avgPrice,
      });

      setInventory(items);
      setFilteredInventory(items);
    } catch (error) {
      console.error('Error loading inventory:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterInventory() {
    let filtered = inventory;

    // Apply status filter
    if (filterStatus === 'available') {
      filtered = filtered.filter(item => item.is_available);
    } else if (filterStatus === 'unavailable') {
      filtered = filtered.filter(item => !item.is_available);
    } else if (filterStatus === 'low') {
      filtered = filtered.filter(item => item.stock_quantity < 10 && item.is_available);
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        item =>
          item.medication?.name?.toLowerCase().includes(query) ||
          item.pharmacy?.business_name_ar?.toLowerCase().includes(query) ||
          item.medication?.category?.toLowerCase().includes(query)
      );
    }

    setFilteredInventory(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadInventory();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 2,
    }).format(amount);
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  function getStockStatus(item: InventoryItem) {
    if (!item.is_available) return { color: '#ef4444', text: 'غير متوفر', icon: XCircle };
    if (item.stock_quantity < 10) return { color: '#f59e0b', text: 'مخزون منخفض', icon: AlertTriangle };
    return { color: '#10b981', text: 'متوفر', icon: CheckCircle };
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل المخزون...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الصيدليات" tabs={PHARMACY_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.commissionCard}>
          <Text style={styles.commissionTitle}>نموذج العمولة</Text>
          <View style={styles.commissionBreakdown}>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>عمولة المنصة:</Text>
              <Text style={styles.commissionPlatform}>10%</Text>
            </View>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>حصة الصيدلية:</Text>
              <Text style={styles.commissionPharmacy}>90%</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Package size={22} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الأدوية</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.available}</Text>
            <Text style={styles.statLabel}>متوفرة</Text>
          </View>

          <View style={styles.statCard}>
            <XCircle size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.unavailable}</Text>
            <Text style={styles.statLabel}>غير متوفرة</Text>
          </View>

          <View style={styles.statCard}>
            <AlertTriangle size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.lowStock}</Text>
            <Text style={styles.statLabel}>مخزون منخفض</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.averagePrice)}</Text>
            <Text style={styles.statLabel}>متوسط السعر</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في المخزون..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'all' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('all')}>
            <Text style={[styles.filterText, filterStatus === 'all' && styles.filterTextActive]}>الكل</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'available' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('available')}>
            <Text style={[styles.filterText, filterStatus === 'available' && styles.filterTextActive]}>متوفر</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'unavailable' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('unavailable')}>
            <Text style={[styles.filterText, filterStatus === 'unavailable' && styles.filterTextActive]}>غير متوفر</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'low' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('low')}>
            <Text style={[styles.filterText, filterStatus === 'low' && styles.filterTextActive]}>مخزون منخفض</Text>
          </TouchableOpacity>
        </View>

        {filteredInventory.length > 0 ? (
          filteredInventory.map((item) => {
            const status = getStockStatus(item);
            const StatusIcon = status.icon;
            const platformCommission = item.price * COMMISSION_RATE;
            const pharmacyShare = item.price * (1 - COMMISSION_RATE);

            return (
              <View key={item.id} style={styles.itemCard}>
                <View style={styles.itemHeader}>
                  <View style={[styles.statusBadge, { backgroundColor: status.color + '20' }]}>
                    <StatusIcon size={14} color={status.color} strokeWidth={2} />
                    <Text style={[styles.statusText, { color: status.color }]}>{status.text}</Text>
                  </View>
                  <Text style={styles.itemDate}>{formatDate(item.updated_at)}</Text>
                </View>

                <View style={styles.itemDetails}>
                  <Text style={styles.medicationName}>{item.medication?.name || 'غير محدد'}</Text>
                  <Text style={styles.medicationCategory}>{item.medication?.category || '-'}</Text>

                  <View style={styles.pharmacyInfo}>
                    <Building2 size={14} color="#8b5cf6" strokeWidth={2} />
                    <Text style={styles.pharmacyName}>{item.pharmacy?.business_name_ar || 'غير محدد'}</Text>
                  </View>

                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>الكمية المتوفرة:</Text>
                    <Text style={[styles.detailValue, item.stock_quantity < 10 && { color: '#f59e0b' }]}>
                      {item.stock_quantity} وحدة
                    </Text>
                  </View>

                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>السعر:</Text>
                    <Text style={styles.priceText}>{formatCurrency(item.price)}</Text>
                  </View>

                  <View style={styles.commissionBox}>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>عمولة المنصة (10%):</Text>
                      <Text style={styles.commissionText}>{formatCurrency(platformCommission)}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>حصة الصيدلية (90%):</Text>
                      <Text style={styles.pharmacyShareText}>{formatCurrency(pharmacyShare)}</Text>
                    </View>
                  </View>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Package size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد أدوية في المخزون'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  commissionCard: {
    backgroundColor: '#f0f9ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#3b82f6',
  },
  commissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
    textAlign: 'center',
    marginBottom: 12,
  },
  commissionBreakdown: {
    gap: 8,
  },
  commissionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  commissionLabel: {
    fontSize: 14,
    color: '#1e40af',
    fontWeight: '600',
  },
  commissionPlatform: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#3b82f6',
  },
  commissionPharmacy: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#10b981',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
  },
  filterButtonActive: {
    backgroundColor: '#8b5cf6',
  },
  filterText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
  },
  filterTextActive: {
    color: '#ffffff',
  },
  itemCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  itemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3e8ff',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  itemDate: {
    fontSize: 11,
    color: '#94a3b8',
  },
  itemDetails: {
    gap: 8,
  },
  medicationName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  medicationCategory: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
    marginBottom: 4,
  },
  pharmacyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 10,
    backgroundColor: '#f5f3ff',
    borderRadius: 6,
    alignSelf: 'flex-end',
  },
  pharmacyName: {
    fontSize: 12,
    color: '#7c3aed',
    fontWeight: '600',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  priceText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'left',
  },
  commissionBox: {
    backgroundColor: '#f8fafc',
    padding: 10,
    borderRadius: 8,
    gap: 6,
    marginTop: 4,
  },
  commissionText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#3b82f6',
    textAlign: 'left',
  },
  pharmacyShareText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#10b981',
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
