import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Shield, Phone, Mail, Users, DollarSign, FileText } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const BUSINESS_TABS = [
  { name: 'all', label: 'جميع الشركات', path: '/owner/business' },
  { name: 'pharmacies', label: 'الصيدليات', path: '/owner/business/pharmacies' },
  { name: 'hospitals', label: 'المستشفيات', path: '/owner/business/hospitals' },
  { name: 'insurance', label: 'شركات التأمين', path: '/owner/business/insurance' },
  { name: 'requests', label: 'طلبات التسجيل', path: '/owner/business/requests' },
  { name: 'status', label: 'حالة الشركات', path: '/owner/business/status' },
  { name: 'employees', label: 'الموظفون', path: '/owner/business/employees' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/business/activity' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/business/permissions' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/business/settings' },
];

interface Insurance {
  id: string;
  business_name: string;
  business_email: string;
  business_phone: string;
  coverage_percentage: number;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  created_at: string;
  total_claims?: number;
  total_coverage?: number;
}

export default function InsuranceCompanies() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [insuranceCompanies, setInsuranceCompanies] = useState<Insurance[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    pending: 0,
    totalClaims: 0,
    totalCoverage: 0,
  });

  useEffect(() => {
    loadInsuranceCompanies();
  }, []);

  async function loadInsuranceCompanies() {
    try {
      const { data: insuranceData } = await supabase
        .from('business_registrations')
        .select('*')
        .eq('business_type', 'insurance')
        .order('created_at', { ascending: false });

      const insuranceWithStats = await Promise.all(
        (insuranceData || []).map(async (insurance) => {
          const { count: claimsCount } = await supabase
            .from('insurance_claims')
            .select('*', { count: 'exact', head: true })
            .eq('insurance_provider_id', insurance.id);

          const { data: claims } = await supabase
            .from('insurance_claims')
            .select('approved_amount')
            .eq('insurance_provider_id', insurance.id)
            .eq('status', 'approved');

          const totalCoverage = claims?.reduce((sum, c) => sum + (c.approved_amount || 0), 0) || 0;

          return {
            ...insurance,
            total_claims: claimsCount || 0,
            total_coverage: totalCoverage,
          };
        })
      );

      setInsuranceCompanies(insuranceWithStats);

      setStats({
        total: insuranceWithStats.length,
        active: insuranceWithStats.filter(i => i.status === 'approved').length,
        pending: insuranceWithStats.filter(i => i.status === 'pending').length,
        totalClaims: insuranceWithStats.reduce((sum, i) => sum + (i.total_claims || 0), 0),
        totalCoverage: insuranceWithStats.reduce((sum, i) => sum + (i.total_coverage || 0), 0),
      });
    } catch (error) {
      console.error('Error loading insurance companies:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadInsuranceCompanies();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="شركات التأمين" tabs={BUSINESS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#0ea5e9" />
          <Text style={styles.loadingText}>جاري تحميل البيانات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="شركات التأمين" tabs={BUSINESS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Shield size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الشركات</Text>
          </View>

          <View style={styles.statCard}>
            <Users size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active}</Text>
            <Text style={styles.statLabel}>نشط</Text>
          </View>

          <View style={styles.statCard}>
            <FileText size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalClaims}</Text>
            <Text style={styles.statLabel}>إجمالي المطالبات</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalCoverage.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي التغطية</Text>
          </View>
        </View>

        {insuranceCompanies.length > 0 ? (
          insuranceCompanies.map((insurance) => (
            <View key={insurance.id} style={styles.insuranceCard}>
              <View style={styles.insuranceHeader}>
                <Shield size={20} color="#3b82f6" strokeWidth={2} />
                <Text style={styles.insuranceName}>{insurance.business_name}</Text>
              </View>

              <View style={styles.insuranceDetails}>
                <View style={styles.detailRow}>
                  <Mail size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailValue}>{insurance.business_email}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Phone size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailValue}>{insurance.business_phone}</Text>
                </View>
                <View style={styles.divider} />
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>نسبة التغطية:</Text>
                  <Text style={styles.detailValue}>{insurance.coverage_percentage || 0}%</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>المطالبات:</Text>
                  <Text style={styles.detailValue}>{insurance.total_claims || 0}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>إجمالي التغطية:</Text>
                  <Text style={styles.detailValue}>{(insurance.total_coverage || 0).toLocaleString('ar-SA')} ر.س</Text>
                </View>
              </View>

              <View style={[
                styles.statusBadge,
                { backgroundColor: insurance.status === 'approved' ? '#d1fae5' : '#fef3c7' }
              ]}>
                <Text style={[
                  styles.statusText,
                  { color: insurance.status === 'approved' ? '#065f46' : '#92400e' }
                ]}>
                  {insurance.status === 'approved' ? 'معتمدة' : insurance.status === 'pending' ? 'معلقة' : 'مرفوضة'}
                </Text>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Shield size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا توجد شركات تأمين مسجلة</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  insuranceCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  insuranceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  insuranceName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  insuranceDetails: {
    gap: 8,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    flex: 1,
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    flex: 2,
    textAlign: 'right',
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 8,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
});
