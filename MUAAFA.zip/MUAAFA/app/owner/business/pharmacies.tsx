import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity, Alert, Modal } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Building2, Search, MapPin, TrendingUp, DollarSign, Package, FileCheck } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const BUSINESS_TABS = [
  { name: 'index', label: 'نظرة عامة', path: '/owner/business' },
  { name: 'employees', label: 'الموظفين', path: '/owner/business/employees' },
  { name: 'pharmacies', label: 'الصيدليات', path: '/owner/business/pharmacies' },
  { name: 'hospitals', label: 'المستشفيات', path: '/owner/business/hospitals' },
  { name: 'insurance', label: 'التأمينات', path: '/owner/business/insurance' },
  { name: 'requests', label: 'الطلبات', path: '/owner/business/requests' },
  { name: 'status', label: 'الحالة', path: '/owner/business/status' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/business/permissions' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/business/settings' },
];

interface Pharmacy {
  id: string;
  business_name_ar: string;
  business_name_en: string;
  commercial_registration: string;
  address: string;
  city: string;
  monthly_revenue: number;
  platform_commission: number;
  status: string;
  created_at: string;
}

export default function RegisteredPharmacies() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [filteredPharmacies, setFilteredPharmacies] = useState<Pharmacy[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showInventoryModal, setShowInventoryModal] = useState(false);
  const [showSettlementModal, setShowSettlementModal] = useState(false);
  const [selectedPharmacy, setSelectedPharmacy] = useState<Pharmacy | null>(null);
  const [stats, setStats] = useState({
    total: 0,
    totalRevenue: 0,
    totalCommission: 0,
    pendingSettlement: 0,
  });

  const commissionRate = 0.10;

  useEffect(() => {
    loadPharmacies();
  }, []);

  useEffect(() => {
    filterPharmacies();
  }, [searchQuery, pharmacies]);

  async function loadPharmacies() {
    try {
      const { data } = await supabase
        .from('business_registrations')
        .select('*')
        .eq('business_type', 'pharmacy')
        .order('created_at', { ascending: false });

      const pharmaciesData = data || [];

      const totalRevenue = pharmaciesData.reduce((sum, p) => sum + (p.monthly_revenue || 0), 0);
      const totalCommission = totalRevenue * commissionRate;

      setPharmacies(pharmaciesData);
      setFilteredPharmacies(pharmaciesData);

      setStats({
        total: pharmaciesData.length,
        totalRevenue,
        totalCommission,
        pendingSettlement: pharmaciesData.filter(p => p.status === 'pending_settlement').length,
      });
    } catch (error) {
      console.error('Error loading pharmacies:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterPharmacies() {
    if (!searchQuery.trim()) {
      setFilteredPharmacies(pharmacies);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = pharmacies.filter(
      p =>
        p.business_name_ar?.toLowerCase().includes(query) ||
        p.business_name_en?.toLowerCase().includes(query) ||
        p.commercial_registration?.includes(query) ||
        p.city?.toLowerCase().includes(query)
    );
    setFilteredPharmacies(filtered);
  }

  function handleInventoryLink(pharmacy: Pharmacy) {
    setSelectedPharmacy(pharmacy);
    setShowInventoryModal(true);
  }

  function handleSettlement(pharmacy: Pharmacy) {
    setSelectedPharmacy(pharmacy);
    setShowSettlementModal(true);
  }

  async function handleConfirmSettlement() {
    if (!selectedPharmacy) return;

    Alert.alert('نجح', 'تم تسجيل التحويل بنجاح');
    setShowSettlementModal(false);
    await loadPharmacies();
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadPharmacies();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الصيدليات المسجلة" tabs={BUSINESS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل الصيدليات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الصيدليات المسجلة" tabs={BUSINESS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Building2 size={22} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الصيدليات</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.totalRevenue)}</Text>
            <Text style={styles.statLabel}>مبيعات الشهر</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{formatCurrency(stats.totalCommission)}</Text>
            <Text style={styles.statLabel}>عمولة المنصة (10%)</Text>
          </View>

          <View style={styles.statCard}>
            <FileCheck size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pendingSettlement}</Text>
            <Text style={styles.statLabel}>بانتظار التسوية</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث بالاسم أو السجل التجاري أو المدينة..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredPharmacies.length > 0 ? (
          filteredPharmacies.map((pharmacy) => {
            const revenue = pharmacy.monthly_revenue || 0;
            const commission = revenue * commissionRate;

            return (
              <View key={pharmacy.id} style={styles.pharmacyCard}>
                <View style={styles.pharmacyHeader}>
                  <Building2 size={20} color="#8b5cf6" strokeWidth={2} />
                  <View style={styles.pharmacyInfo}>
                    <Text style={styles.pharmacyName}>{pharmacy.business_name_ar}</Text>
                    <Text style={styles.pharmacyNameEn}>{pharmacy.business_name_en || '-'}</Text>
                  </View>
                </View>

                <View style={styles.pharmacyDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>السجل التجاري:</Text>
                    <Text style={styles.detailValue}>{pharmacy.commercial_registration || '-'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <MapPin size={14} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailValue}>{pharmacy.city || 'غير محدد'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>مبيعات الشهر:</Text>
                    <Text style={styles.revenueText}>{formatCurrency(revenue)}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>عمولة المنصة (10%):</Text>
                    <Text style={styles.commissionText}>{formatCurrency(commission)}</Text>
                  </View>
                </View>

                <View style={styles.actionsRow}>
                  <TouchableOpacity
                    style={[styles.actionButton, { backgroundColor: '#f3e8ff' }]}
                    onPress={() => handleInventoryLink(pharmacy)}>
                    <Package size={16} color="#7c3aed" strokeWidth={2} />
                    <Text style={[styles.actionText, { color: '#7c3aed' }]}>ربط مخزون</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.actionButton, { backgroundColor: '#dbeafe' }]}
                    onPress={() => handleSettlement(pharmacy)}>
                    <FileCheck size={16} color="#1e40af" strokeWidth={2} />
                    <Text style={[styles.actionText, { color: '#1e40af' }]}>تصفية حساب</Text>
                  </TouchableOpacity>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Building2 size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد صيدليات مسجلة'}
            </Text>
          </View>
        )}
      </ScrollView>

      <Modal visible={showInventoryModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>ربط مخزون الصيدلية</Text>
            <Text style={styles.modalSubtitle}>{selectedPharmacy?.business_name_ar}</Text>

            <Text style={styles.modalDescription}>
              يمكن للصيدلية رفع قائمة الأدوية المتوفرة وأسعارها عبر:
            </Text>

            <View style={styles.optionsList}>
              <View style={styles.optionItem}>
                <Text style={styles.optionText}>1. رفع ملف Excel</Text>
              </View>
              <View style={styles.optionItem}>
                <Text style={styles.optionText}>2. ربط API المخزون</Text>
              </View>
              <View style={styles.optionItem}>
                <Text style={styles.optionText}>3. الإدخال اليدوي</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.modalButton} onPress={() => {
              Alert.alert('نجح', 'تم إرسال رابط ربط المخزون للصيدلية');
              setShowInventoryModal(false);
            }}>
              <Text style={styles.modalButtonText}>إرسال رابط الربط</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.modalCancelButton} onPress={() => setShowInventoryModal(false)}>
              <Text style={styles.modalCancelText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={showSettlementModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>تصفية حساب الصيدلية</Text>
            <Text style={styles.modalSubtitle}>{selectedPharmacy?.business_name_ar}</Text>

            {selectedPharmacy && (
              <View style={styles.settlementDetails}>
                <View style={styles.settlementRow}>
                  <Text style={styles.settlementLabel}>إجمالي المبيعات:</Text>
                  <Text style={styles.settlementValue}>
                    {formatCurrency(selectedPharmacy.monthly_revenue || 0)}
                  </Text>
                </View>
                <View style={styles.settlementRow}>
                  <Text style={styles.settlementLabel}>عمولة المنصة (10%):</Text>
                  <Text style={styles.settlementHighlight}>
                    {formatCurrency((selectedPharmacy.monthly_revenue || 0) * 0.10)}
                  </Text>
                </View>
                <View style={styles.divider} />
                <View style={styles.settlementRow}>
                  <Text style={styles.settlementLabel}>المبلغ المستحق للصيدلية:</Text>
                  <Text style={styles.settlementTotal}>
                    {formatCurrency((selectedPharmacy.monthly_revenue || 0) * 0.90)}
                  </Text>
                </View>
              </View>
            )}

            <TouchableOpacity style={styles.modalButton} onPress={handleConfirmSettlement}>
              <Text style={styles.modalButtonText}>تأكيد التحويل</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.modalCancelButton} onPress={() => setShowSettlementModal(false)}>
              <Text style={styles.modalCancelText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  pharmacyCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  pharmacyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3e8ff',
  },
  pharmacyInfo: {
    flex: 1,
  },
  pharmacyName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  pharmacyNameEn: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  pharmacyDetails: {
    gap: 8,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  revenueText: {
    fontSize: 14,
    color: '#10b981',
    fontWeight: 'bold',
    textAlign: 'left',
  },
  commissionText: {
    fontSize: 14,
    color: '#3b82f6',
    fontWeight: 'bold',
    textAlign: 'left',
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    padding: 10,
    borderRadius: 8,
  },
  actionText: {
    fontSize: 13,
    fontWeight: '600',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 8,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 16,
  },
  modalDescription: {
    fontSize: 14,
    color: '#475569',
    textAlign: 'right',
    marginBottom: 12,
  },
  optionsList: {
    gap: 8,
    marginBottom: 20,
  },
  optionItem: {
    padding: 12,
    backgroundColor: '#f8fafc',
    borderRadius: 8,
  },
  optionText: {
    fontSize: 14,
    color: '#0f172a',
    textAlign: 'right',
  },
  settlementDetails: {
    backgroundColor: '#f8fafc',
    padding: 16,
    borderRadius: 10,
    marginBottom: 20,
  },
  settlementRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  settlementLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  settlementValue: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '600',
  },
  settlementHighlight: {
    fontSize: 14,
    color: '#3b82f6',
    fontWeight: 'bold',
  },
  settlementTotal: {
    fontSize: 16,
    color: '#10b981',
    fontWeight: 'bold',
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 8,
  },
  modalButton: {
    backgroundColor: '#3b82f6',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  modalButtonText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#ffffff',
  },
  modalCancelButton: {
    backgroundColor: '#f1f5f9',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#475569',
  },
});
