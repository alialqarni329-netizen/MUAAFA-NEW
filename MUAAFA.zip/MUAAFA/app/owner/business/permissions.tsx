import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Switch,
} from 'react-native';
import { useState, useEffect } from 'react';
import { Stack } from 'expo-router';
import { Shield, Save, Search, Building2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface BusinessPermission {
  id: string;
  business_id: string;
  business_name: string;
  max_employees: number;
  max_orders_per_month: number;
  max_storage_mb: number;
  can_use_ai_bot: boolean;
  can_access_analytics: boolean;
  can_export_data: boolean;
  can_customize_branding: boolean;
  can_access_api: boolean;
  priority_support: boolean;
  dedicated_account_manager: boolean;
  custom_integrations: boolean;
}

export default function BusinessPermissions() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [businesses, setBusinesses] = useState<BusinessPermission[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBusiness, setSelectedBusiness] = useState<BusinessPermission | null>(null);

  useEffect(() => {
    loadBusinesses();
  }, []);

  async function loadBusinesses() {
    try {
      const { data, error } = await supabase
        .from('business_registrations')
        .select(`
          id,
          business_name,
          business_permissions (
            id,
            max_employees,
            max_orders_per_month,
            max_storage_mb,
            can_use_ai_bot,
            can_access_analytics,
            can_export_data,
            can_customize_branding,
            can_access_api,
            priority_support,
            dedicated_account_manager,
            custom_integrations
          )
        `)
        .eq('approval_status', 'approved')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedBusinesses = data.map((b: any) => ({
        business_id: b.id,
        business_name: b.business_name,
        id: b.business_permissions?.[0]?.id || '',
        max_employees: b.business_permissions?.[0]?.max_employees || 50,
        max_orders_per_month: b.business_permissions?.[0]?.max_orders_per_month || 1000,
        max_storage_mb: b.business_permissions?.[0]?.max_storage_mb || 1024,
        can_use_ai_bot: b.business_permissions?.[0]?.can_use_ai_bot ?? true,
        can_access_analytics: b.business_permissions?.[0]?.can_access_analytics ?? true,
        can_export_data: b.business_permissions?.[0]?.can_export_data ?? true,
        can_customize_branding: b.business_permissions?.[0]?.can_customize_branding ?? false,
        can_access_api: b.business_permissions?.[0]?.can_access_api ?? false,
        priority_support: b.business_permissions?.[0]?.priority_support ?? false,
        dedicated_account_manager: b.business_permissions?.[0]?.dedicated_account_manager ?? false,
        custom_integrations: b.business_permissions?.[0]?.custom_integrations ?? false,
      }));

      setBusinesses(formattedBusinesses);
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل تحميل بيانات الشركات');
    } finally {
      setLoading(false);
    }
  }

  async function savePermissions() {
    if (!selectedBusiness) return;

    setSaving(true);

    try {
      const { error } = await supabase.from('business_permissions').upsert({
        business_id: selectedBusiness.business_id,
        max_employees: selectedBusiness.max_employees,
        max_orders_per_month: selectedBusiness.max_orders_per_month,
        max_storage_mb: selectedBusiness.max_storage_mb,
        can_use_ai_bot: selectedBusiness.can_use_ai_bot,
        can_access_analytics: selectedBusiness.can_access_analytics,
        can_export_data: selectedBusiness.can_export_data,
        can_customize_branding: selectedBusiness.can_customize_branding,
        can_access_api: selectedBusiness.can_access_api,
        priority_support: selectedBusiness.priority_support,
        dedicated_account_manager: selectedBusiness.dedicated_account_manager,
        custom_integrations: selectedBusiness.custom_integrations,
        permissions_updated_at: new Date().toISOString(),
      }, {
        onConflict: 'business_id'
      });

      if (error) throw error;

      Alert.alert('نجح', 'تم حفظ الصلاحيات بنجاح');
      setSelectedBusiness(null);
      loadBusinesses();
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الصلاحيات');
    } finally {
      setSaving(false);
    }
  }

  const filteredBusinesses = businesses.filter((b) =>
    b.business_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  if (selectedBusiness) {
    return (
      <>
        <Stack.Screen
          options={{
            headerShown: true,
            title: `صلاحيات: ${selectedBusiness.business_name}`,
            headerStyle: { backgroundColor: '#0ea5e9' },
            headerTintColor: '#ffffff',
            headerTitleStyle: { fontWeight: 'bold' },
          }}
        />
        <View style={styles.container}>
          <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>الحدود والقيود</Text>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>الحد الأقصى للموظفين</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.max_employees.toString()}
                  onChangeText={(text) =>
                    setSelectedBusiness({
                      ...selectedBusiness,
                      max_employees: parseInt(text) || 0,
                    })
                  }
                  keyboardType="number-pad"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>الحد الأقصى للطلبات شهرياً</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.max_orders_per_month.toString()}
                  onChangeText={(text) =>
                    setSelectedBusiness({
                      ...selectedBusiness,
                      max_orders_per_month: parseInt(text) || 0,
                    })
                  }
                  keyboardType="number-pad"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>مساحة التخزين (MB)</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.max_storage_mb.toString()}
                  onChangeText={(text) =>
                    setSelectedBusiness({
                      ...selectedBusiness,
                      max_storage_mb: parseInt(text) || 0,
                    })
                  }
                  keyboardType="number-pad"
                  textAlign="right"
                />
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>الميزات الأساسية</Text>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.can_use_ai_bot}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, can_use_ai_bot: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>استخدام البوت الذكي</Text>
              </View>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.can_access_analytics}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, can_access_analytics: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>الوصول للتحليلات</Text>
              </View>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.can_export_data}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, can_export_data: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>تصدير البيانات</Text>
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>الميزات المتقدمة</Text>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.can_customize_branding}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, can_customize_branding: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>تخصيص العلامة التجارية</Text>
              </View>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.can_access_api}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, can_access_api: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>الوصول للـ API</Text>
              </View>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.custom_integrations}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, custom_integrations: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>التكاملات المخصصة</Text>
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>الدعم الخاص</Text>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.priority_support}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, priority_support: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>دعم ذو أولوية</Text>
              </View>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.dedicated_account_manager}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, dedicated_account_manager: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>مدير حساب مخصص</Text>
              </View>
            </View>

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={[styles.saveButton, saving && styles.saveButtonDisabled]}
                onPress={savePermissions}
                disabled={saving}>
                {saving ? (
                  <ActivityIndicator size="small" color="#ffffff" />
                ) : (
                  <>
                    <Save size={20} color="#ffffff" strokeWidth={2} />
                    <Text style={styles.saveButtonText}>حفظ التغييرات</Text>
                  </>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setSelectedBusiness(null)}>
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'صلاحيات الشركات',
          headerStyle: { backgroundColor: '#0ea5e9' },
          headerTintColor: '#ffffff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      />
      <View style={styles.container}>
        <View style={styles.header}>
          <View style={styles.searchContainer}>
            <Search size={20} color="#64748b" strokeWidth={2} />
            <TextInput
              style={styles.searchInput}
              placeholder="ابحث عن شركة..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              textAlign="right"
            />
          </View>
        </View>

        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          {filteredBusinesses.length === 0 ? (
            <View style={styles.emptyState}>
              <Building2 size={64} color="#cbd5e1" strokeWidth={1.5} />
              <Text style={styles.emptyText}>لا توجد شركات</Text>
            </View>
          ) : (
            filteredBusinesses.map((business) => (
              <TouchableOpacity
                key={business.business_id}
                style={styles.businessCard}
                onPress={() => setSelectedBusiness(business)}>
                <View style={styles.businessHeader}>
                  <Shield size={24} color="#0ea5e9" strokeWidth={2} />
                  <Text style={styles.businessName}>{business.business_name}</Text>
                </View>

                <View style={styles.businessStats}>
                  <View style={styles.stat}>
                    <Text style={styles.statValue}>{business.max_employees}</Text>
                    <Text style={styles.statLabel}>موظف</Text>
                  </View>
                  <View style={styles.stat}>
                    <Text style={styles.statValue}>{business.max_orders_per_month}</Text>
                    <Text style={styles.statLabel}>طلب/شهر</Text>
                  </View>
                  <View style={styles.stat}>
                    <Text style={styles.statValue}>{business.max_storage_mb} MB</Text>
                    <Text style={styles.statLabel}>تخزين</Text>
                  </View>
                </View>

                <View style={styles.featureTags}>
                  {business.can_use_ai_bot && (
                    <View style={styles.tag}>
                      <Text style={styles.tagText}>AI Bot</Text>
                    </View>
                  )}
                  {business.priority_support && (
                    <View style={[styles.tag, styles.tagPremium]}>
                      <Text style={styles.tagTextPremium}>دعم متميز</Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 12,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 16,
    color: '#94a3b8',
  },
  businessCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  businessHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  businessName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  businessStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
    paddingVertical: 12,
    backgroundColor: '#f8fafc',
    borderRadius: 12,
  },
  stat: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  featureTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tag: {
    backgroundColor: '#e0f2fe',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  tagText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#0369a1',
  },
  tagPremium: {
    backgroundColor: '#fef3c7',
  },
  tagTextPremium: {
    fontSize: 12,
    fontWeight: '600',
    color: '#92400e',
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  switchLabel: {
    fontSize: 16,
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
    marginRight: 12,
  },
  buttonContainer: {
    gap: 12,
    marginTop: 8,
  },
  saveButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cancelButton: {
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#64748b',
    fontSize: 16,
    fontWeight: '600',
  },
});
