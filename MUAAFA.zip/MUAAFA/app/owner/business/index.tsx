import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Building2, CheckCircle, Clock, XCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const BUSINESS_TABS = [
  { name: 'all', label: 'جميع الشركات', path: '/owner/business' },
  { name: 'pharmacies', label: 'الصيدليات', path: '/owner/business/pharmacies' },
  { name: 'hospitals', label: 'المستشفيات', path: '/owner/business/hospitals' },
  { name: 'insurance', label: 'شركات التأمين', path: '/owner/business/insurance' },
  { name: 'requests', label: 'طلبات التسجيل', path: '/owner/business/requests' },
  { name: 'status', label: 'حالة الشركات', path: '/owner/business/status' },
  { name: 'employees', label: 'الموظفون', path: '/owner/business/employees' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/business/activity' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/business/permissions' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/business/settings' },
];

interface Business {
  id: string;
  business_name: string;
  business_type: string;
  business_email: string;
  business_phone: string;
  status: string;
  created_at: string;
}

interface BusinessStats {
  total: number;
  active: number;
  pending: number;
  rejected: number;
}

export default function AllBusinesses() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [stats, setStats] = useState<BusinessStats>({
    total: 0,
    active: 0,
    pending: 0,
    rejected: 0,
  });

  useEffect(() => {
    loadBusinesses();
  }, []);

  async function loadBusinesses() {
    try {
      const [allRes, activeRes, pendingRes, rejectedRes, businessesData] = await Promise.all([
        supabase.from('business_registrations').select('*', { count: 'exact', head: true }),
        supabase.from('business_registrations').select('*', { count: 'exact', head: true }).eq('status', 'approved'),
        supabase.from('business_registrations').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('business_registrations').select('*', { count: 'exact', head: true }).eq('status', 'rejected'),
        supabase.from('business_registrations').select('*').order('created_at', { ascending: false }).limit(20),
      ]);

      setStats({
        total: allRes.count || 0,
        active: activeRes.count || 0,
        pending: pendingRes.count || 0,
        rejected: rejectedRes.count || 0,
      });

      setBusinesses(businessesData.data || []);
    } catch (error) {
      console.error('Error loading businesses:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadBusinesses();
    setRefreshing(false);
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'approved': return <CheckCircle size={16} color="#10b981" strokeWidth={2} />;
      case 'pending': return <Clock size={16} color="#f59e0b" strokeWidth={2} />;
      case 'rejected': return <XCircle size={16} color="#ef4444" strokeWidth={2} />;
      default: return null;
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'approved': return 'موافق عليها';
      case 'pending': return 'قيد المراجعة';
      case 'rejected': return 'مرفوضة';
      default: return status;
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الشركات" tabs={BUSINESS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الشركات" tabs={BUSINESS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Building2 size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الشركات</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active}</Text>
            <Text style={styles.statLabel}>نشطة</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Clock size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending}</Text>
            <Text style={styles.statLabel}>قيد المراجعة</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <XCircle size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.rejected}</Text>
            <Text style={styles.statLabel}>مرفوضة</Text>
          </View>
        </View>

        {businesses.length > 0 ? (
          businesses.map((business) => (
            <View key={business.id} style={styles.businessCard}>
              <View style={styles.businessHeader}>
                <View style={styles.businessInfo}>
                  <Text style={styles.businessName}>{business.business_name}</Text>
                  <Text style={styles.businessType}>{business.business_type}</Text>
                </View>
                <View style={styles.statusBadge}>
                  {getStatusIcon(business.status)}
                  <Text style={styles.statusText}>{getStatusText(business.status)}</Text>
                </View>
              </View>
              <View style={styles.businessDetails}>
                <Text style={styles.detailText}>📧 {business.business_email}</Text>
                <Text style={styles.detailText}>📱 {business.business_phone}</Text>
                <Text style={styles.detailText}>📅 {new Date(business.created_at).toLocaleDateString('ar-SA')}</Text>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Building2 size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyTitle}>لا توجد شركات مسجلة بعد</Text>
            <Text style={styles.emptyText}>عدد الشركات: 0</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    gap: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'center',
  },
  businessCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  businessHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  businessInfo: {
    flex: 1,
  },
  businessName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  businessType: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'right',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
  },
  statusText: {
    fontSize: 12,
    color: '#0f172a',
  },
  businessDetails: {
    gap: 6,
  },
  detailText: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
    gap: 12,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  emptyText: {
    fontSize: 14,
    color: '#64748b',
  },
});
