import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, TextInput, Modal, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Clock, CheckCircle, XCircle, FileText, Calendar, Mail, Phone, Building2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const BUSINESS_TABS = [
  { name: 'all', label: 'جميع الشركات', path: '/owner/business' },
  { name: 'pharmacies', label: 'الصيدليات', path: '/owner/business/pharmacies' },
  { name: 'hospitals', label: 'المستشفيات', path: '/owner/business/hospitals' },
  { name: 'insurance', label: 'شركات التأمين', path: '/owner/business/insurance' },
  { name: 'requests', label: 'طلبات التسجيل', path: '/owner/business/requests' },
  { name: 'status', label: 'حالة الشركات', path: '/owner/business/status' },
  { name: 'employees', label: 'الموظفون', path: '/owner/business/employees' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/business/activity' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/business/permissions' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/business/settings' },
];

interface BusinessRequest {
  id: string;
  business_name: string;
  email: string;
  phone: string;
  commercial_registration: string;
  status: string;
  created_at: string;
  user_id: string;
  rejection_reason?: string;
  approval_notes?: string;
}

export default function BusinessRequests() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [requests, setRequests] = useState<BusinessRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<BusinessRequest | null>(null);
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [showRejectionModal, setShowRejectionModal] = useState(false);
  const [approvalNotes, setApprovalNotes] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    loadRequests();
  }, []);

  async function loadRequests() {
    try {
      const { data, error } = await supabase
        .from('business_registrations')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRequests(data || []);
    } catch (error) {
      // Silently handle error
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadRequests();
    setRefreshing(false);
  }

  function openApprovalModal(request: BusinessRequest) {
    setSelectedRequest(request);
    setApprovalNotes('');
    setShowApprovalModal(true);
  }

  function openRejectionModal(request: BusinessRequest) {
    setSelectedRequest(request);
    setRejectionReason('');
    setShowRejectionModal(true);
  }

  async function approveRequest() {
    if (!selectedRequest) return;

    setActionLoading(true);
    try {
      const { data: userData, error: userError } = await supabase.auth.getUser();

      if (userError) {
        Alert.alert('خطأ', 'فشل التحقق من المستخدم');
        setActionLoading(false);
        return;
      }

      const userId = userData?.user?.id;
      if (!userId) {
        Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً');
        setActionLoading(false);
        return;
      }

      const updateData: any = {
        status: 'approved',
        reviewed_by: userId,
        reviewed_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      if (approvalNotes && approvalNotes.trim()) {
        updateData.approval_notes = approvalNotes.trim();
      }

      const { error } = await supabase
        .from('business_registrations')
        .update(updateData)
        .eq('id', selectedRequest.id);

      if (error) {
        Alert.alert('خطأ', `فشل تحديث الطلب: ${error.message}`);
        setActionLoading(false);
        return;
      }

      Alert.alert('نجح', 'تم الموافقة على الطلب بنجاح');
      setShowApprovalModal(false);
      await loadRequests();
    } catch (error: any) {
      Alert.alert('خطأ', `حدث خطأ غير متوقع: ${error?.message || 'خطأ غير معروف'}`);
    } finally {
      setActionLoading(false);
    }
  }

  async function rejectRequest() {
    if (!selectedRequest || !rejectionReason.trim()) {
      Alert.alert('تنبيه', 'يرجى إدخال سبب الرفض');
      return;
    }

    setActionLoading(true);
    try {
      const { data: userData, error: userError } = await supabase.auth.getUser();

      if (userError) {
        Alert.alert('خطأ', 'فشل التحقق من المستخدم');
        setActionLoading(false);
        return;
      }

      const userId = userData?.user?.id;
      if (!userId) {
        Alert.alert('خطأ', 'يجب تسجيل الدخول أولاً');
        setActionLoading(false);
        return;
      }

      const { error } = await supabase
        .from('business_registrations')
        .update({
          status: 'rejected',
          reviewed_by: userId,
          reviewed_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          rejection_reason: rejectionReason.trim(),
        })
        .eq('id', selectedRequest.id);

      if (error) {
        Alert.alert('خطأ', `فشل تحديث الطلب: ${error.message}`);
        setActionLoading(false);
        return;
      }

      Alert.alert('نجح', 'تم رفض الطلب');
      setShowRejectionModal(false);
      await loadRequests();
    } catch (error: any) {
      Alert.alert('خطأ', `حدث خطأ غير متوقع: ${error?.message || 'خطأ غير معروف'}`);
    } finally {
      setActionLoading(false);
    }
  }

  function formatDate(dateString: string) {
    return new Date(dateString).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الشركات" tabs={BUSINESS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الشركات" tabs={BUSINESS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>طلبات التسجيل المعلقة</Text>
            <Text style={styles.subtitle}>الطلبات التي تحتاج إلى مراجعة وموافقة</Text>
          </View>
          <View style={styles.countBadge}>
            <Text style={styles.countText}>{requests.length}</Text>
          </View>
        </View>

        {requests.length > 0 ? (
          requests.map((request) => (
            <View key={request.id} style={styles.requestCard}>
              <View style={styles.requestHeader}>
                <View style={styles.businessIcon}>
                  <Building2 size={24} color="#3b82f6" strokeWidth={2} />
                </View>
                <View style={styles.requestInfo}>
                  <Text style={styles.businessName}>{request.business_name}</Text>
                  <Text style={styles.businessType}>س.ت: {request.commercial_registration}</Text>
                </View>
                <View style={styles.statusBadge}>
                  <Clock size={14} color="#f59e0b" strokeWidth={2} />
                  <Text style={styles.statusText}>معلق</Text>
                </View>
              </View>

              <View style={styles.requestDetails}>
                <View style={styles.detailRow}>
                  <Mail size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>{request.email}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Phone size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>{request.phone}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Calendar size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>{formatDate(request.created_at)}</Text>
                </View>
              </View>

              <View style={styles.actionButtons}>
                <TouchableOpacity
                  style={[styles.actionButton, styles.rejectButton]}
                  onPress={() => openRejectionModal(request)}
                >
                  <XCircle size={18} color="#ffffff" strokeWidth={2} />
                  <Text style={styles.buttonText}>رفض</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.actionButton, styles.approveButton]}
                  onPress={() => openApprovalModal(request)}
                >
                  <CheckCircle size={18} color="#ffffff" strokeWidth={2} />
                  <Text style={styles.buttonText}>موافقة</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Clock size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyTitle}>لا توجد طلبات معلقة</Text>
            <Text style={styles.emptyText}>عدد الطلبات المعلقة: 0</Text>
          </View>
        )}
      </ScrollView>

      {/* Approval Modal */}
      <Modal visible={showApprovalModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>الموافقة على طلب التسجيل</Text>
            <Text style={styles.modalSubtitle}>{selectedRequest?.business_name}</Text>

            <TextInput
              style={styles.textArea}
              placeholder="ملاحظات الموافقة (اختياري)"
              multiline
              numberOfLines={4}
              value={approvalNotes}
              onChangeText={setApprovalNotes}
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowApprovalModal(false)}
                disabled={actionLoading}
              >
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.modalButton, styles.confirmButton]}
                onPress={approveRequest}
                disabled={actionLoading}
              >
                {actionLoading ? (
                  <ActivityIndicator size="small" color="#ffffff" />
                ) : (
                  <Text style={styles.confirmButtonText}>تأكيد الموافقة</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Rejection Modal */}
      <Modal visible={showRejectionModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>رفض طلب التسجيل</Text>
            <Text style={styles.modalSubtitle}>{selectedRequest?.business_name}</Text>

            <TextInput
              style={styles.textArea}
              placeholder="سبب الرفض (مطلوب) *"
              multiline
              numberOfLines={4}
              value={rejectionReason}
              onChangeText={setRejectionReason}
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowRejectionModal(false)}
                disabled={actionLoading}
              >
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.modalButton, styles.rejectModalButton]}
                onPress={rejectRequest}
                disabled={actionLoading}
              >
                {actionLoading ? (
                  <ActivityIndicator size="small" color="#ffffff" />
                ) : (
                  <Text style={styles.confirmButtonText}>تأكيد الرفض</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'right',
  },
  countBadge: {
    backgroundColor: '#f59e0b',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  countText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  requestCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 12,
  },
  businessIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#dbeafe',
    justifyContent: 'center',
    alignItems: 'center',
  },
  requestInfo: {
    flex: 1,
  },
  businessName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  businessType: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: '#fef3c7',
  },
  statusText: {
    fontSize: 12,
    color: '#0f172a',
    fontWeight: '500',
  },
  requestDetails: {
    gap: 8,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    justifyContent: 'flex-end',
  },
  detailText: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: 8,
  },
  approveButton: {
    backgroundColor: '#10b981',
  },
  rejectButton: {
    backgroundColor: '#ef4444',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
    gap: 12,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  emptyText: {
    fontSize: 14,
    color: '#64748b',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 500,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 16,
    textAlign: 'right',
  },
  textArea: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    color: '#0f172a',
    textAlign: 'right',
    minHeight: 100,
    marginBottom: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {
    backgroundColor: '#f1f5f9',
  },
  cancelButtonText: {
    color: '#64748b',
    fontSize: 14,
    fontWeight: '600',
  },
  confirmButton: {
    backgroundColor: '#10b981',
  },
  rejectModalButton: {
    backgroundColor: '#ef4444',
  },
  confirmButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
});
