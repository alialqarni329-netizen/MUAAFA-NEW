import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Switch,
} from 'react-native';
import { useState, useEffect } from 'react';
import { Stack } from 'expo-router';
import { Settings, Save, Search, Building2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface BusinessSettings {
  id: string;
  business_id: string;
  business_name: string;
  logo_url: string | null;
  brand_color: string;
  theme: string;
  contact_email: string | null;
  contact_phone: string | null;
  contact_address: string | null;
  website_url: string | null;
  tax_number: string | null;
  tax_name: string | null;
  tax_address: string | null;
  email_notifications: boolean;
  sms_notifications: boolean;
  push_notifications: boolean;
  invoice_prefix: string;
  invoice_footer: string | null;
  payment_terms: string;
  timezone: string;
  language: string;
}

export default function BusinessSettingsScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [businesses, setBusinesses] = useState<BusinessSettings[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBusiness, setSelectedBusiness] = useState<BusinessSettings | null>(null);

  useEffect(() => {
    loadBusinesses();
  }, []);

  async function loadBusinesses() {
    try {
      const { data, error } = await supabase
        .from('business_registrations')
        .select(`
          id,
          business_name,
          business_settings (
            id,
            logo_url,
            brand_color,
            theme,
            contact_email,
            contact_phone,
            contact_address,
            website_url,
            tax_number,
            tax_name,
            tax_address,
            email_notifications,
            sms_notifications,
            push_notifications,
            invoice_prefix,
            invoice_footer,
            payment_terms,
            timezone,
            language
          )
        `)
        .eq('approval_status', 'approved')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedBusinesses = data.map((b: any) => ({
        business_id: b.id,
        business_name: b.business_name,
        id: b.business_settings?.[0]?.id || '',
        logo_url: b.business_settings?.[0]?.logo_url || null,
        brand_color: b.business_settings?.[0]?.brand_color || '#0ea5e9',
        theme: b.business_settings?.[0]?.theme || 'light',
        contact_email: b.business_settings?.[0]?.contact_email || null,
        contact_phone: b.business_settings?.[0]?.contact_phone || null,
        contact_address: b.business_settings?.[0]?.contact_address || null,
        website_url: b.business_settings?.[0]?.website_url || null,
        tax_number: b.business_settings?.[0]?.tax_number || null,
        tax_name: b.business_settings?.[0]?.tax_name || null,
        tax_address: b.business_settings?.[0]?.tax_address || null,
        email_notifications: b.business_settings?.[0]?.email_notifications ?? true,
        sms_notifications: b.business_settings?.[0]?.sms_notifications ?? false,
        push_notifications: b.business_settings?.[0]?.push_notifications ?? true,
        invoice_prefix: b.business_settings?.[0]?.invoice_prefix || 'INV',
        invoice_footer: b.business_settings?.[0]?.invoice_footer || null,
        payment_terms: b.business_settings?.[0]?.payment_terms || 'Net 30',
        timezone: b.business_settings?.[0]?.timezone || 'Asia/Riyadh',
        language: b.business_settings?.[0]?.language || 'ar',
      }));

      setBusinesses(formattedBusinesses);
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل تحميل بيانات الشركات');
    } finally {
      setLoading(false);
    }
  }

  async function saveSettings() {
    if (!selectedBusiness) return;

    setSaving(true);

    try {
      const { error } = await supabase.from('business_settings').upsert(
        {
          business_id: selectedBusiness.business_id,
          logo_url: selectedBusiness.logo_url,
          brand_color: selectedBusiness.brand_color,
          theme: selectedBusiness.theme,
          contact_email: selectedBusiness.contact_email,
          contact_phone: selectedBusiness.contact_phone,
          contact_address: selectedBusiness.contact_address,
          website_url: selectedBusiness.website_url,
          tax_number: selectedBusiness.tax_number,
          tax_name: selectedBusiness.tax_name,
          tax_address: selectedBusiness.tax_address,
          email_notifications: selectedBusiness.email_notifications,
          sms_notifications: selectedBusiness.sms_notifications,
          push_notifications: selectedBusiness.push_notifications,
          invoice_prefix: selectedBusiness.invoice_prefix,
          invoice_footer: selectedBusiness.invoice_footer,
          payment_terms: selectedBusiness.payment_terms,
          timezone: selectedBusiness.timezone,
          language: selectedBusiness.language,
        },
        {
          onConflict: 'business_id',
        }
      );

      if (error) throw error;

      Alert.alert('نجح', 'تم حفظ الإعدادات بنجاح');
      setSelectedBusiness(null);
      loadBusinesses();
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات');
    } finally {
      setSaving(false);
    }
  }

  const filteredBusinesses = businesses.filter((b) =>
    b.business_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  if (selectedBusiness) {
    return (
      <>
        <Stack.Screen
          options={{
            headerShown: true,
            title: `إعدادات: ${selectedBusiness.business_name}`,
            headerStyle: { backgroundColor: '#0ea5e9' },
            headerTintColor: '#ffffff',
            headerTitleStyle: { fontWeight: 'bold' },
          }}
        />
        <View style={styles.container}>
          <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>العلامة التجارية</Text>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>رابط الشعار (Logo URL)</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.logo_url || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, logo_url: text || null })
                  }
                  placeholder="https://example.com/logo.png"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>اللون الأساسي</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.brand_color}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, brand_color: text })
                  }
                  placeholder="#0ea5e9"
                  textAlign="right"
                />
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>معلومات التواصل</Text>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>البريد الإلكتروني</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.contact_email || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, contact_email: text || null })
                  }
                  placeholder="contact@example.com"
                  keyboardType="email-address"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>رقم الهاتف</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.contact_phone || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, contact_phone: text || null })
                  }
                  placeholder="+966 50 123 4567"
                  keyboardType="phone-pad"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>العنوان</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={selectedBusiness.contact_address || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, contact_address: text || null })
                  }
                  placeholder="الرياض، المملكة العربية السعودية"
                  multiline
                  numberOfLines={3}
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>الموقع الإلكتروني</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.website_url || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, website_url: text || null })
                  }
                  placeholder="https://example.com"
                  keyboardType="url"
                  textAlign="right"
                />
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>المعلومات الضريبية</Text>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>الرقم الضريبي</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.tax_number || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, tax_number: text || null })
                  }
                  placeholder="300000000000003"
                  keyboardType="number-pad"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>الاسم الضريبي</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.tax_name || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, tax_name: text || null })
                  }
                  placeholder="شركة مثال للتجارة"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>العنوان الضريبي</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={selectedBusiness.tax_address || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, tax_address: text || null })
                  }
                  multiline
                  numberOfLines={3}
                  textAlign="right"
                />
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>إعدادات الإشعارات</Text>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.email_notifications}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, email_notifications: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>إشعارات البريد الإلكتروني</Text>
              </View>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.sms_notifications}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, sms_notifications: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>إشعارات الرسائل النصية</Text>
              </View>

              <View style={styles.switchRow}>
                <Switch
                  value={selectedBusiness.push_notifications}
                  onValueChange={(value) =>
                    setSelectedBusiness({ ...selectedBusiness, push_notifications: value })
                  }
                  trackColor={{ false: '#cbd5e1', true: '#0ea5e9' }}
                  thumbColor="#ffffff"
                />
                <Text style={styles.switchLabel}>الإشعارات الفورية</Text>
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>إعدادات الفواتير</Text>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>بادئة الفاتورة</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.invoice_prefix}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, invoice_prefix: text })
                  }
                  placeholder="INV"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>شروط الدفع</Text>
                <TextInput
                  style={styles.input}
                  value={selectedBusiness.payment_terms}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, payment_terms: text })
                  }
                  placeholder="Net 30"
                  textAlign="right"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>تذييل الفاتورة</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={selectedBusiness.invoice_footer || ''}
                  onChangeText={(text) =>
                    setSelectedBusiness({ ...selectedBusiness, invoice_footer: text || null })
                  }
                  placeholder="شكراً لتعاملكم معنا"
                  multiline
                  numberOfLines={3}
                  textAlign="right"
                />
              </View>
            </View>

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={[styles.saveButton, saving && styles.saveButtonDisabled]}
                onPress={saveSettings}
                disabled={saving}>
                {saving ? (
                  <ActivityIndicator size="small" color="#ffffff" />
                ) : (
                  <>
                    <Save size={20} color="#ffffff" strokeWidth={2} />
                    <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>
                  </>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setSelectedBusiness(null)}>
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'إعدادات الشركات',
          headerStyle: { backgroundColor: '#0ea5e9' },
          headerTintColor: '#ffffff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      />
      <View style={styles.container}>
        <View style={styles.header}>
          <View style={styles.searchContainer}>
            <Search size={20} color="#64748b" strokeWidth={2} />
            <TextInput
              style={styles.searchInput}
              placeholder="ابحث عن شركة..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              textAlign="right"
            />
          </View>
        </View>

        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          {filteredBusinesses.length === 0 ? (
            <View style={styles.emptyState}>
              <Building2 size={64} color="#cbd5e1" strokeWidth={1.5} />
              <Text style={styles.emptyText}>لا توجد شركات</Text>
            </View>
          ) : (
            filteredBusinesses.map((business) => (
              <TouchableOpacity
                key={business.business_id}
                style={styles.businessCard}
                onPress={() => setSelectedBusiness(business)}>
                <View style={styles.businessHeader}>
                  <Settings size={24} color="#0ea5e9" strokeWidth={2} />
                  <Text style={styles.businessName}>{business.business_name}</Text>
                </View>

                <View style={styles.businessInfo}>
                  {business.contact_email && (
                    <Text style={styles.infoText}>📧 {business.contact_email}</Text>
                  )}
                  {business.contact_phone && (
                    <Text style={styles.infoText}>📱 {business.contact_phone}</Text>
                  )}
                  {business.website_url && (
                    <Text style={styles.infoText}>🌐 {business.website_url}</Text>
                  )}
                </View>

                <View style={styles.featureTags}>
                  {business.email_notifications && (
                    <View style={styles.tag}>
                      <Text style={styles.tagText}>Email</Text>
                    </View>
                  )}
                  {business.sms_notifications && (
                    <View style={styles.tag}>
                      <Text style={styles.tagText}>SMS</Text>
                    </View>
                  )}
                  {business.push_notifications && (
                    <View style={styles.tag}>
                      <Text style={styles.tagText}>Push</Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 12,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 16,
    color: '#94a3b8',
  },
  businessCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  businessHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  businessName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  businessInfo: {
    marginBottom: 12,
    gap: 6,
  },
  infoText: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  featureTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tag: {
    backgroundColor: '#e0f2fe',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  tagText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#0369a1',
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  switchLabel: {
    fontSize: 16,
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
    marginRight: 12,
  },
  buttonContainer: {
    gap: 12,
    marginTop: 8,
  },
  saveButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cancelButton: {
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#64748b',
    fontSize: 16,
    fontWeight: '600',
  },
});
