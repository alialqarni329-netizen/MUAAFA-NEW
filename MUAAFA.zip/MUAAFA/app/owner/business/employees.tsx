import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity, Alert, Modal } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Users, Search, Building2, Briefcase, Phone, Clock, Plus, Shield } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const BUSINESS_TABS = [
  { name: 'index', label: 'نظرة عامة', path: '/owner/business' },
  { name: 'employees', label: 'الموظفين', path: '/owner/business/employees' },
  { name: 'pharmacies', label: 'الصيدليات', path: '/owner/business/pharmacies' },
  { name: 'hospitals', label: 'المستشفيات', path: '/owner/business/hospitals' },
  { name: 'insurance', label: 'التأمينات', path: '/owner/business/insurance' },
  { name: 'requests', label: 'الطلبات', path: '/owner/business/requests' },
  { name: 'status', label: 'الحالة', path: '/owner/business/status' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/business/permissions' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/business/settings' },
];

interface Employee {
  id: string;
  full_name: string;
  phone_number: string;
  role: string;
  position: string;
  last_seen_at: string;
  created_at: string;
  business_registrations?: {
    business_name_ar: string;
    business_type: string;
  };
}

export default function BusinessEmployees() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [stats, setStats] = useState({
    total: 0,
    pharmacyStaff: 0,
    hospitalStaff: 0,
    activeToday: 0,
  });

  const [newEmployee, setNewEmployee] = useState({
    name: '',
    phone: '',
    company: '',
    position: '',
    role: 'employee',
  });

  useEffect(() => {
    loadEmployees();
  }, []);

  useEffect(() => {
    filterEmployees();
  }, [searchQuery, employees]);

  async function loadEmployees() {
    try {
      const { data } = await supabase
        .from('users')
        .select(`
          *,
          business_registrations(business_name_ar, business_type)
        `)
        .eq('role', 'employee')
        .order('created_at', { ascending: false });

      const employeesData = data || [];
      const today = new Date().toISOString().split('T')[0];

      setEmployees(employeesData);
      setFilteredEmployees(employeesData);

      const activeToday = employeesData.filter(e =>
        e.last_seen_at && e.last_seen_at.startsWith(today)
      ).length;

      setStats({
        total: employeesData.length,
        pharmacyStaff: employeesData.filter(e =>
          e.business_registrations?.business_type === 'pharmacy'
        ).length,
        hospitalStaff: employeesData.filter(e =>
          e.business_registrations?.business_type === 'hospital'
        ).length,
        activeToday,
      });
    } catch (error) {
      console.error('Error loading employees:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterEmployees() {
    if (!searchQuery.trim()) {
      setFilteredEmployees(employees);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = employees.filter(
      e =>
        e.full_name?.toLowerCase().includes(query) ||
        e.phone_number?.includes(query) ||
        e.business_registrations?.business_name_ar?.toLowerCase().includes(query)
    );
    setFilteredEmployees(filtered);
  }

  async function handleAddEmployee() {
    if (!newEmployee.name || !newEmployee.phone || !newEmployee.company) {
      Alert.alert('تنبيه', 'الرجاء ملء جميع الحقول المطلوبة');
      return;
    }

    try {
      Alert.alert('نجح', 'تم إضافة الموظف بنجاح');
      setShowAddModal(false);
      setNewEmployee({ name: '', phone: '', company: '', position: '', role: 'employee' });
      await loadEmployees();
    } catch (error) {
      Alert.alert('خطأ', 'فشلت إضافة الموظف');
    }
  }

  function handleManagePermissions(employee: Employee) {
    setSelectedEmployee(employee);
    setShowPermissionsModal(true);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadEmployees();
  }

  function getLastSeenText(lastSeen: string) {
    if (!lastSeen) return 'لم يسجل دخول';

    const lastSeenDate = new Date(lastSeen);
    const now = new Date();
    const diffMinutes = Math.floor((now.getTime() - lastSeenDate.getTime()) / (1000 * 60));

    if (diffMinutes < 5) return 'نشط الآن';
    if (diffMinutes < 60) return `منذ ${diffMinutes} دقيقة`;
    if (diffMinutes < 1440) return `منذ ${Math.floor(diffMinutes / 60)} ساعة`;
    return `منذ ${Math.floor(diffMinutes / 1440)} يوم`;
  }

  if (loading) {
    return (
      <OwnerTabLayout title="موظفو الشركات" tabs={BUSINESS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الموظفين...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="موظفو الشركات" tabs={BUSINESS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Users size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الموظفين</Text>
          </View>

          <View style={styles.statCard}>
            <Building2 size={22} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pharmacyStaff}</Text>
            <Text style={styles.statLabel}>صيدليات</Text>
          </View>

          <View style={styles.statCard}>
            <Building2 size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.hospitalStaff}</Text>
            <Text style={styles.statLabel}>مستشفيات</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.activeToday}</Text>
            <Text style={styles.statLabel}>نشط اليوم</Text>
          </View>
        </View>

        <View style={styles.actionsRow}>
          <View style={styles.searchBox}>
            <Search size={20} color="#64748b" strokeWidth={2} />
            <TextInput
              style={styles.searchInput}
              placeholder="البحث بالاسم أو الجوال أو الشركة..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholderTextColor="#94a3b8"
            />
          </View>
          <TouchableOpacity style={styles.addButton} onPress={() => setShowAddModal(true)}>
            <Plus size={20} color="#ffffff" strokeWidth={2} />
          </TouchableOpacity>
        </View>

        {filteredEmployees.length > 0 ? (
          filteredEmployees.map((employee) => (
            <View key={employee.id} style={styles.employeeCard}>
              <View style={styles.employeeHeader}>
                <Users size={18} color="#3b82f6" strokeWidth={2} />
                <View style={styles.employeeInfo}>
                  <Text style={styles.employeeName}>{employee.full_name || 'بدون اسم'}</Text>
                  <Text style={styles.companyName}>
                    {employee.business_registrations?.business_name_ar || 'لا توجد شركة'}
                  </Text>
                </View>
              </View>

              <View style={styles.employeeDetails}>
                <View style={styles.detailRow}>
                  <Briefcase size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>{employee.position || 'موظف'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Phone size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>{employee.phone_number || '-'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Clock size={14} color="#64748b" strokeWidth={2} />
                  <Text style={[styles.detailText, {
                    color: getLastSeenText(employee.last_seen_at) === 'نشط الآن' ? '#10b981' : '#64748b'
                  }]}>
                    {getLastSeenText(employee.last_seen_at)}
                  </Text>
                </View>
              </View>

              <TouchableOpacity
                style={styles.permissionsButton}
                onPress={() => handleManagePermissions(employee)}>
                <Shield size={16} color="#3b82f6" strokeWidth={2} />
                <Text style={styles.permissionsText}>تحديد الصلاحية</Text>
              </TouchableOpacity>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Users size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا يوجد موظفين'}
            </Text>
          </View>
        )}
      </ScrollView>

      <Modal visible={showAddModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>إضافة موظف جديد</Text>

            <TextInput
              style={styles.input}
              placeholder="الاسم الكامل"
              value={newEmployee.name}
              onChangeText={(text) => setNewEmployee({...newEmployee, name: text})}
              placeholderTextColor="#94a3b8"
              textAlign="right"
            />

            <TextInput
              style={styles.input}
              placeholder="رقم الجوال"
              value={newEmployee.phone}
              onChangeText={(text) => setNewEmployee({...newEmployee, phone: text})}
              keyboardType="phone-pad"
              placeholderTextColor="#94a3b8"
              textAlign="right"
            />

            <TextInput
              style={styles.input}
              placeholder="الشركة التابع لها"
              value={newEmployee.company}
              onChangeText={(text) => setNewEmployee({...newEmployee, company: text})}
              placeholderTextColor="#94a3b8"
              textAlign="right"
            />

            <TextInput
              style={styles.input}
              placeholder="المنصب"
              value={newEmployee.position}
              onChangeText={(text) => setNewEmployee({...newEmployee, position: text})}
              placeholderTextColor="#94a3b8"
              textAlign="right"
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setShowAddModal(false)}>
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={handleAddEmployee}>
                <Text style={styles.saveButtonText}>إضافة</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showPermissionsModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>تحديد صلاحيات الموظف</Text>
            <Text style={styles.modalSubtitle}>{selectedEmployee?.full_name}</Text>

            <View style={styles.permissionsList}>
              <View style={styles.permissionItem}>
                <Text style={styles.permissionLabel}>عرض الطلبات</Text>
                <View style={styles.toggleActive} />
              </View>
              <View style={styles.permissionItem}>
                <Text style={styles.permissionLabel}>تعديل الطلبات</Text>
                <View style={styles.toggleInactive} />
              </View>
              <View style={styles.permissionItem}>
                <Text style={styles.permissionLabel}>عرض التقارير المالية</Text>
                <View style={styles.toggleInactive} />
              </View>
              <View style={styles.permissionItem}>
                <Text style={styles.permissionLabel}>إدارة المخزون</Text>
                <View style={styles.toggleActive} />
              </View>
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setShowPermissionsModal(false)}>
                <Text style={styles.cancelButtonText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={() => {
                Alert.alert('نجح', 'تم تحديث الصلاحيات');
                setShowPermissionsModal(false);
              }}>
                <Text style={styles.saveButtonText}>حفظ</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '22%',
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
  },
  addButton: {
    backgroundColor: '#3b82f6',
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  employeeCard: {
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  employeeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  employeeInfo: {
    flex: 1,
  },
  employeeName: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  companyName: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  employeeDetails: {
    gap: 6,
    marginBottom: 10,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  permissionsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#dbeafe',
    padding: 10,
    borderRadius: 8,
  },
  permissionsText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1e40af',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 8,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 16,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 10,
    padding: 12,
    fontSize: 14,
    color: '#0f172a',
    marginBottom: 12,
  },
  permissionsList: {
    gap: 10,
    marginBottom: 20,
  },
  permissionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#f8fafc',
    borderRadius: 8,
  },
  permissionLabel: {
    fontSize: 14,
    color: '#0f172a',
    textAlign: 'right',
  },
  toggleActive: {
    width: 44,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#10b981',
  },
  toggleInactive: {
    width: 44,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#e2e8f0',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  cancelButton: {
    flex: 1,
    padding: 12,
    borderRadius: 10,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
  },
  saveButton: {
    flex: 1,
    padding: 12,
    borderRadius: 10,
    backgroundColor: '#3b82f6',
    alignItems: 'center',
  },
  saveButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
});
