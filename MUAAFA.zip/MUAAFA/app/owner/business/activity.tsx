import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Activity, DollarSign, Package, Clock, Calendar, Building2, Search, AlertCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const BUSINESS_TABS = [
  { name: 'all', label: 'جميع الشركات', path: '/owner/business' },
  { name: 'hospitals', label: 'المستشفيات', path: '/owner/business/hospitals' },
  { name: 'pharmacies', label: 'الصيدليات', path: '/owner/business/pharmacies' },
  { name: 'insurance', label: 'التأمين', path: '/owner/business/insurance' },
  { name: 'requests', label: 'الطلبات', path: '/owner/business/requests' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/business/activity' },
  { name: 'status', label: 'حالة التفعيل', path: '/owner/business/status' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/business/permissions' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/business/settings' },
  { name: 'employees', label: 'الموظفين', path: '/owner/business/employees' },
];

interface ActivityLog {
  id: string;
  business_id: string;
  business_name: string;
  business_type: string;
  action_type: string;
  action_details: string;
  old_value?: string;
  new_value?: string;
  ip_address?: string;
  created_at: string;
}

export default function BusinessActivity() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [filteredActivities, setFilteredActivities] = useState<ActivityLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'price_change' | 'schedule_change' | 'product_change'>('all');

  useEffect(() => {
    loadActivityLogs();
  }, []);

  useEffect(() => {
    filterActivities();
  }, [searchQuery, filterType, activities]);

  async function loadActivityLogs() {
    try {
      const { data: registrations } = await supabase
        .from('business_registrations')
        .select('id, business_name, business_type')
        .eq('status', 'approved');

      const mockActivities: ActivityLog[] = [
        {
          id: '1',
          business_id: 'b1',
          business_name: 'صيدلية النهدي - الرياض',
          business_type: 'pharmacy',
          action_type: 'price_change',
          action_details: 'تغيير سعر دواء باراسيتامول',
          old_value: '15 ر.س',
          new_value: '18 ر.س',
          ip_address: '192.168.1.100',
          created_at: new Date(Date.now() - 3600000).toISOString(),
        },
        {
          id: '2',
          business_id: 'h1',
          business_name: 'مستشفى الملك فيصل',
          business_type: 'hospital',
          action_type: 'schedule_change',
          action_details: 'تحديث أوقات دوام د. أحمد محمد',
          old_value: '9:00 ص - 5:00 م',
          new_value: '8:00 ص - 4:00 م',
          ip_address: '192.168.1.105',
          created_at: new Date(Date.now() - 7200000).toISOString(),
        },
        {
          id: '3',
          business_id: 'p1',
          business_name: 'صيدلية الدواء',
          business_type: 'pharmacy',
          action_type: 'product_change',
          action_details: 'إضافة منتج جديد: فيتامين D3',
          new_value: 'متوفر - 25 ر.س',
          ip_address: '192.168.1.110',
          created_at: new Date(Date.now() - 10800000).toISOString(),
        },
        {
          id: '4',
          business_id: 'h2',
          business_name: 'مستشفى سليمان الحبيب',
          business_type: 'hospital',
          action_type: 'price_change',
          action_details: 'تغيير سعر الكشف العام',
          old_value: '200 ر.س',
          new_value: '250 ر.س',
          ip_address: '192.168.1.115',
          created_at: new Date(Date.now() - 14400000).toISOString(),
        },
        {
          id: '5',
          business_id: 'p2',
          business_name: 'صيدلية رعاية',
          business_type: 'pharmacy',
          action_type: 'price_change',
          action_details: 'تعديل أسعار مجموعة أدوية السكري',
          old_value: 'متفاوتة',
          new_value: 'زيادة 5%',
          ip_address: '192.168.1.120',
          created_at: new Date(Date.now() - 18000000).toISOString(),
        },
      ];

      setActivities(mockActivities);
      setFilteredActivities(mockActivities);
    } catch (error) {
      console.error('Error loading activity logs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterActivities() {
    let filtered = activities;

    if (filterType !== 'all') {
      filtered = filtered.filter(a => a.action_type === filterType);
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        a =>
          a.business_name.toLowerCase().includes(query) ||
          a.action_details.toLowerCase().includes(query)
      );
    }

    setFilteredActivities(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadActivityLogs();
  }

  function getActionIcon(type: string) {
    switch (type) {
      case 'price_change':
        return <DollarSign size={18} color="#f59e0b" strokeWidth={2} />;
      case 'schedule_change':
        return <Clock size={18} color="#8b5cf6" strokeWidth={2} />;
      case 'product_change':
        return <Package size={18} color="#3b82f6" strokeWidth={2} />;
      default:
        return <Activity size={18} color="#64748b" strokeWidth={2} />;
    }
  }

  function getActionBg(type: string) {
    switch (type) {
      case 'price_change':
        return '#fef3c7';
      case 'schedule_change':
        return '#f3e8ff';
      case 'product_change':
        return '#dbeafe';
      default:
        return '#f1f5f9';
    }
  }

  function getActionLabel(type: string) {
    switch (type) {
      case 'price_change':
        return 'تغيير سعر';
      case 'schedule_change':
        return 'تحديث جدول';
      case 'product_change':
        return 'تغيير منتج';
      default:
        return 'نشاط';
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="سجل نشاط الشركة" tabs={BUSINESS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل السجل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="سجل نشاط الشركة" tabs={BUSINESS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.header}>
          <AlertCircle size={20} color="#3b82f6" strokeWidth={2} />
          <Text style={styles.headerText}>
            يراقب هذا السجل أي تغيير تقوم به الشركات لضمان عدم التلاعب بالعمولات
          </Text>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث باسم الشركة أو النشاط..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[styles.filterBtn, filterType === 'all' && styles.filterBtnActive]}
            onPress={() => setFilterType('all')}>
            <Text style={[styles.filterText, filterType === 'all' && styles.filterTextActive]}>
              الكل
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterBtn, filterType === 'price_change' && styles.filterBtnActive]}
            onPress={() => setFilterType('price_change')}>
            <DollarSign size={14} color={filterType === 'price_change' ? '#ffffff' : '#64748b'} strokeWidth={2} />
            <Text style={[styles.filterText, filterType === 'price_change' && styles.filterTextActive]}>
              تغيير سعر
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterBtn, filterType === 'schedule_change' && styles.filterBtnActive]}
            onPress={() => setFilterType('schedule_change')}>
            <Clock size={14} color={filterType === 'schedule_change' ? '#ffffff' : '#64748b'} strokeWidth={2} />
            <Text style={[styles.filterText, filterType === 'schedule_change' && styles.filterTextActive]}>
              تحديث جدول
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterBtn, filterType === 'product_change' && styles.filterBtnActive]}
            onPress={() => setFilterType('product_change')}>
            <Package size={14} color={filterType === 'product_change' ? '#ffffff' : '#64748b'} strokeWidth={2} />
            <Text style={[styles.filterText, filterType === 'product_change' && styles.filterTextActive]}>
              تغيير منتج
            </Text>
          </TouchableOpacity>
        </View>

        {filteredActivities.length > 0 ? (
          filteredActivities.map((activity) => (
            <View key={activity.id} style={styles.activityCard}>
              <View style={styles.activityHeader}>
                <View style={[styles.actionIcon, { backgroundColor: getActionBg(activity.action_type) }]}>
                  {getActionIcon(activity.action_type)}
                </View>
                <View style={styles.activityInfo}>
                  <View style={styles.businessRow}>
                    <Building2 size={14} color="#64748b" strokeWidth={2} />
                    <Text style={styles.businessName}>{activity.business_name}</Text>
                    <View style={styles.typeBadge}>
                      <Text style={styles.typeText}>
                        {activity.business_type === 'hospital' ? 'مستشفى' : 'صيدلية'}
                      </Text>
                    </View>
                  </View>
                  <View style={styles.actionBadge}>
                    <Text style={styles.actionBadgeText}>{getActionLabel(activity.action_type)}</Text>
                  </View>
                </View>
              </View>

              <View style={styles.activityBody}>
                <Text style={styles.actionDetails}>{activity.action_details}</Text>

                {activity.old_value && (
                  <View style={styles.changeBox}>
                    <View style={styles.changeRow}>
                      <Text style={styles.changeLabel}>القيمة السابقة:</Text>
                      <Text style={styles.oldValue}>{activity.old_value}</Text>
                    </View>
                    {activity.new_value && (
                      <View style={styles.changeRow}>
                        <Text style={styles.changeLabel}>القيمة الجديدة:</Text>
                        <Text style={styles.newValue}>{activity.new_value}</Text>
                      </View>
                    )}
                  </View>
                )}

                {!activity.old_value && activity.new_value && (
                  <View style={styles.valueBox}>
                    <Text style={styles.newValue}>{activity.new_value}</Text>
                  </View>
                )}

                <View style={styles.activityFooter}>
                  <Text style={styles.timestamp}>
                    {new Date(activity.created_at).toLocaleString('ar-SA', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                  {activity.ip_address && (
                    <Text style={styles.ipAddress}>IP: {activity.ip_address}</Text>
                  )}
                </View>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Activity size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery || filterType !== 'all' ? 'لا توجد نتائج' : 'لا توجد أنشطة مسجلة'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#dbeafe',
    padding: 12,
    borderRadius: 10,
    marginBottom: 16,
  },
  headerText: {
    flex: 1,
    fontSize: 13,
    color: '#1e40af',
    textAlign: 'right',
    lineHeight: 20,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
    flexWrap: 'wrap',
  },
  filterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  filterBtnActive: {
    backgroundColor: '#3b82f6',
    borderColor: '#3b82f6',
  },
  filterText: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
  },
  filterTextActive: {
    color: '#ffffff',
  },
  activityCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  activityHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 12,
  },
  actionIcon: {
    width: 36,
    height: 36,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  activityInfo: {
    flex: 1,
  },
  businessRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  businessName: {
    flex: 1,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  typeBadge: {
    backgroundColor: '#f1f5f9',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  typeText: {
    fontSize: 10,
    color: '#64748b',
    fontWeight: '600',
  },
  actionBadge: {
    alignSelf: 'flex-end',
  },
  actionBadgeText: {
    fontSize: 11,
    color: '#3b82f6',
    fontWeight: '600',
  },
  activityBody: {
    gap: 10,
  },
  actionDetails: {
    fontSize: 13,
    color: '#334155',
    textAlign: 'right',
    lineHeight: 20,
  },
  changeBox: {
    backgroundColor: '#f8fafc',
    padding: 10,
    borderRadius: 8,
    gap: 6,
  },
  changeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  changeLabel: {
    fontSize: 12,
    color: '#64748b',
  },
  oldValue: {
    fontSize: 12,
    color: '#ef4444',
    fontWeight: '600',
  },
  newValue: {
    fontSize: 12,
    color: '#10b981',
    fontWeight: '600',
  },
  valueBox: {
    backgroundColor: '#f0fdf4',
    padding: 8,
    borderRadius: 6,
  },
  activityFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  timestamp: {
    fontSize: 11,
    color: '#94a3b8',
  },
  ipAddress: {
    fontSize: 11,
    color: '#94a3b8',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
