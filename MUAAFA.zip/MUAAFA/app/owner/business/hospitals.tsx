import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Building2, MapPin, Users, DollarSign, Phone, Mail } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const BUSINESS_TABS = [
  { name: 'all', label: 'جميع الشركات', path: '/owner/business' },
  { name: 'pharmacies', label: 'الصيدليات', path: '/owner/business/pharmacies' },
  { name: 'hospitals', label: 'المستشفيات', path: '/owner/business/hospitals' },
  { name: 'insurance', label: 'شركات التأمين', path: '/owner/business/insurance' },
  { name: 'requests', label: 'طلبات التسجيل', path: '/owner/business/requests' },
  { name: 'status', label: 'حالة الشركات', path: '/owner/business/status' },
  { name: 'employees', label: 'الموظفون', path: '/owner/business/employees' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/business/activity' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/business/permissions' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/business/settings' },
];

interface Hospital {
  id: string;
  business_name: string;
  business_email: string;
  business_phone: string;
  address: string;
  city: string;
  commission_rate: number;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  created_at: string;
  total_patients?: number;
  total_revenue?: number;
}

export default function Hospitals() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    pending: 0,
    totalRevenue: 0,
  });

  useEffect(() => {
    loadHospitals();
  }, []);

  async function loadHospitals() {
    try {
      const { data: hospitalData } = await supabase
        .from('business_registrations')
        .select('*')
        .eq('business_type', 'hospital')
        .order('created_at', { ascending: false });

      const hospitalsWithStats = await Promise.all(
        (hospitalData || []).map(async (hospital) => {
          const { count: patientCount } = await supabase
            .from('sessions')
            .select('*', { count: 'exact', head: true })
            .eq('hospital_id', hospital.id);

          const { data: payments } = await supabase
            .from('payments')
            .select('amount')
            .eq('business_id', hospital.id);

          const totalRevenue = payments?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0;

          return {
            ...hospital,
            total_patients: patientCount || 0,
            total_revenue: totalRevenue,
          };
        })
      );

      setHospitals(hospitalsWithStats);

      setStats({
        total: hospitalsWithStats.length,
        active: hospitalsWithStats.filter(h => h.status === 'approved').length,
        pending: hospitalsWithStats.filter(h => h.status === 'pending').length,
        totalRevenue: hospitalsWithStats.reduce((sum, h) => sum + (h.total_revenue || 0), 0),
      });
    } catch (error) {
      console.error('Error loading hospitals:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadHospitals();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المستشفيات" tabs={BUSINESS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#0ea5e9" />
          <Text style={styles.loadingText}>جاري تحميل البيانات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المستشفيات" tabs={BUSINESS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Building2 size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المستشفيات</Text>
          </View>

          <View style={styles.statCard}>
            <Users size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active}</Text>
            <Text style={styles.statLabel}>نشط</Text>
          </View>

          <View style={styles.statCard}>
            <MapPin size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending}</Text>
            <Text style={styles.statLabel}>معلق</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalRevenue.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الإيرادات</Text>
          </View>
        </View>

        {hospitals.length > 0 ? (
          hospitals.map((hospital) => (
            <View key={hospital.id} style={styles.hospitalCard}>
              <View style={styles.hospitalHeader}>
                <Building2 size={20} color="#3b82f6" strokeWidth={2} />
                <Text style={styles.hospitalName}>{hospital.business_name}</Text>
              </View>

              <View style={styles.hospitalDetails}>
                <View style={styles.detailRow}>
                  <Mail size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailValue}>{hospital.business_email}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Phone size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailValue}>{hospital.business_phone}</Text>
                </View>
                {hospital.address && (
                  <View style={styles.detailRow}>
                    <MapPin size={14} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailValue}>{hospital.address}</Text>
                  </View>
                )}
                <View style={styles.divider} />
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>نسبة العمولة:</Text>
                  <Text style={styles.detailValue}>{hospital.commission_rate || 0}%</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>المرضى:</Text>
                  <Text style={styles.detailValue}>{hospital.total_patients || 0}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>الإيرادات:</Text>
                  <Text style={styles.detailValue}>{(hospital.total_revenue || 0).toLocaleString('ar-SA')} ر.س</Text>
                </View>
              </View>

              <View style={[
                styles.statusBadge,
                { backgroundColor: hospital.status === 'approved' ? '#d1fae5' : '#fef3c7' }
              ]}>
                <Text style={[
                  styles.statusText,
                  { color: hospital.status === 'approved' ? '#065f46' : '#92400e' }
                ]}>
                  {hospital.status === 'approved' ? 'معتمد' : hospital.status === 'pending' ? 'معلق' : 'مرفوض'}
                </Text>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Building2 size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا توجد مستشفيات مسجلة</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  hospitalCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  hospitalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  hospitalName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  hospitalDetails: {
    gap: 8,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    flex: 1,
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    flex: 2,
    textAlign: 'right',
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 8,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
});
