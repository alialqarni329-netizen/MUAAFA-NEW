import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Wifi, WifiOff, Building2, Clock, CheckCircle, XCircle, AlertTriangle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const BUSINESS_TABS = [
  { name: 'all', label: 'جميع الشركات', path: '/owner/business' },
  { name: 'hospitals', label: 'المستشفيات', path: '/owner/business/hospitals' },
  { name: 'pharmacies', label: 'الصيدليات', path: '/owner/business/pharmacies' },
  { name: 'insurance', label: 'التأمين', path: '/owner/business/insurance' },
  { name: 'requests', label: 'الطلبات', path: '/owner/business/requests' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/business/activity' },
  { name: 'status', label: 'حالة التفعيل', path: '/owner/business/status' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/business/permissions' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/business/settings' },
  { name: 'employees', label: 'الموظفين', path: '/owner/business/employees' },
];

interface BusinessStatus {
  id: string;
  name: string;
  type: string;
  status: 'online' | 'offline' | 'warning';
  last_ping: string;
  uptime_percentage: number;
}

export default function ActivationStatus() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [businesses, setBusinesses] = useState<BusinessStatus[]>([]);
  const [filterStatus, setFilterStatus] = useState<'all' | 'online' | 'offline' | 'warning'>('all');

  useEffect(() => {
    loadBusinessStatuses();
  }, []);

  async function loadBusinessStatuses() {
    try {
      const mockBusinesses: BusinessStatus[] = [
        {
          id: '1',
          name: 'صيدلية النهدي - الرياض',
          type: 'pharmacy',
          status: 'online',
          last_ping: new Date(Date.now() - 60000).toISOString(),
          uptime_percentage: 99.5,
        },
        {
          id: '2',
          name: 'مستشفى الملك فيصل',
          type: 'hospital',
          status: 'online',
          last_ping: new Date(Date.now() - 120000).toISOString(),
          uptime_percentage: 98.2,
        },
        {
          id: '3',
          name: 'صيدلية الدواء',
          type: 'pharmacy',
          status: 'warning',
          last_ping: new Date(Date.now() - 900000).toISOString(),
          uptime_percentage: 85.3,
        },
        {
          id: '4',
          name: 'مستشفى سليمان الحبيب',
          type: 'hospital',
          status: 'offline',
          last_ping: new Date(Date.now() - 3600000).toISOString(),
          uptime_percentage: 75.0,
        },
        {
          id: '5',
          name: 'صيدلية رعاية',
          type: 'pharmacy',
          status: 'online',
          last_ping: new Date(Date.now() - 30000).toISOString(),
          uptime_percentage: 100,
        },
      ];

      setBusinesses(mockBusinesses);
    } catch (error) {
      console.error('Error loading business statuses:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadBusinessStatuses();
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'online':
        return <CheckCircle size={18} color="#10b981" strokeWidth={2} />;
      case 'offline':
        return <XCircle size={18} color="#ef4444" strokeWidth={2} />;
      case 'warning':
        return <AlertTriangle size={18} color="#f59e0b" strokeWidth={2} />;
      default:
        return null;
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'online':
        return { bg: '#d1fae5', text: '#065f46', border: '#10b981' };
      case 'offline':
        return { bg: '#fee2e2', text: '#991b1b', border: '#ef4444' };
      case 'warning':
        return { bg: '#fef3c7', text: '#92400e', border: '#f59e0b' };
      default:
        return { bg: '#f1f5f9', text: '#64748b', border: '#cbd5e1' };
    }
  }

  function getStatusLabel(status: string) {
    switch (status) {
      case 'online':
        return 'متصل';
      case 'offline':
        return 'غير متصل';
      case 'warning':
        return 'تحذير';
      default:
        return 'غير معروف';
    }
  }

  function getTimeSince(date: string) {
    const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return `منذ ${seconds} ثانية`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    const hours = Math.floor(minutes / 60);
    return `منذ ${hours} ساعة`;
  }

  const filteredBusinesses = businesses.filter(
    b => filterStatus === 'all' || b.status === filterStatus
  );

  const stats = {
    online: businesses.filter(b => b.status === 'online').length,
    offline: businesses.filter(b => b.status === 'offline').length,
    warning: businesses.filter(b => b.status === 'warning').length,
  };

  if (loading) {
    return (
      <OwnerTabLayout title="حالة التفعيل" tabs={BUSINESS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الحالات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="حالة التفعيل" tabs={BUSINESS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Wifi size={20} color="#10b981" strokeWidth={2} />
            <Text style={[styles.statValue, { color: '#10b981' }]}>{stats.online}</Text>
            <Text style={styles.statLabel}>متصل</Text>
          </View>

          <View style={styles.statCard}>
            <AlertTriangle size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={[styles.statValue, { color: '#f59e0b' }]}>{stats.warning}</Text>
            <Text style={styles.statLabel}>تحذير</Text>
          </View>

          <View style={styles.statCard}>
            <WifiOff size={20} color="#ef4444" strokeWidth={2} />
            <Text style={[styles.statValue, { color: '#ef4444' }]}>{stats.offline}</Text>
            <Text style={styles.statLabel}>غير متصل</Text>
          </View>
        </View>

        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[styles.filterBtn, filterStatus === 'all' && styles.filterBtnActive]}
            onPress={() => setFilterStatus('all')}>
            <Text style={[styles.filterText, filterStatus === 'all' && styles.filterTextActive]}>
              الكل
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterBtn, filterStatus === 'online' && styles.filterBtnActive]}
            onPress={() => setFilterStatus('online')}>
            <Wifi size={14} color={filterStatus === 'online' ? '#ffffff' : '#10b981'} strokeWidth={2} />
            <Text style={[styles.filterText, filterStatus === 'online' && styles.filterTextActive]}>
              متصل
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterBtn, filterStatus === 'warning' && styles.filterBtnActive]}
            onPress={() => setFilterStatus('warning')}>
            <AlertTriangle size={14} color={filterStatus === 'warning' ? '#ffffff' : '#f59e0b'} strokeWidth={2} />
            <Text style={[styles.filterText, filterStatus === 'warning' && styles.filterTextActive]}>
              تحذير
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterBtn, filterStatus === 'offline' && styles.filterBtnActive]}
            onPress={() => setFilterStatus('offline')}>
            <WifiOff size={14} color={filterStatus === 'offline' ? '#ffffff' : '#ef4444'} strokeWidth={2} />
            <Text style={[styles.filterText, filterStatus === 'offline' && styles.filterTextActive]}>
              غير متصل
            </Text>
          </TouchableOpacity>
        </View>

        {filteredBusinesses.map((business) => {
          const colors = getStatusColor(business.status);
          return (
            <View key={business.id} style={[styles.businessCard, { borderColor: colors.border }]}>
              <View style={styles.businessHeader}>
                <View style={[styles.statusDot, { backgroundColor: colors.border }]} />
                <View style={styles.businessInfo}>
                  <View style={styles.nameRow}>
                    <Building2 size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.businessName}>{business.name}</Text>
                  </View>
                  <View style={styles.typeBadge}>
                    <Text style={styles.typeText}>
                      {business.type === 'hospital' ? 'مستشفى' : 'صيدلية'}
                    </Text>
                  </View>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
                  {getStatusIcon(business.status)}
                  <Text style={[styles.statusText, { color: colors.text }]}>
                    {getStatusLabel(business.status)}
                  </Text>
                </View>
              </View>

              <View style={styles.businessBody}>
                <View style={styles.metaRow}>
                  <Clock size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.metaText}>آخر اتصال: {getTimeSince(business.last_ping)}</Text>
                </View>

                <View style={styles.uptimeRow}>
                  <Text style={styles.uptimeLabel}>وقت التشغيل:</Text>
                  <View style={styles.uptimeBar}>
                    <View style={[styles.uptimeFill, { width: `${business.uptime_percentage}%` }]} />
                  </View>
                  <Text style={styles.uptimeText}>{business.uptime_percentage}%</Text>
                </View>
              </View>
            </View>
          );
        })}

        {filteredBusinesses.length === 0 && (
          <View style={styles.emptyState}>
            <WifiOff size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا توجد شركات بهذه الحالة</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 22,
    fontWeight: 'bold',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
  },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
    flexWrap: 'wrap',
  },
  filterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  filterBtnActive: {
    backgroundColor: '#3b82f6',
    borderColor: '#3b82f6',
  },
  filterText: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
  },
  filterTextActive: {
    color: '#ffffff',
  },
  businessCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    borderWidth: 2,
  },
  businessHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 12,
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginTop: 4,
  },
  businessInfo: {
    flex: 1,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  businessName: {
    flex: 1,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  typeBadge: {
    alignSelf: 'flex-end',
    backgroundColor: '#f1f5f9',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  typeText: {
    fontSize: 10,
    color: '#64748b',
    fontWeight: '600',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  businessBody: {
    gap: 10,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  uptimeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  uptimeLabel: {
    fontSize: 12,
    color: '#64748b',
  },
  uptimeBar: {
    flex: 1,
    height: 8,
    backgroundColor: '#f1f5f9',
    borderRadius: 4,
    overflow: 'hidden',
  },
  uptimeFill: {
    height: '100%',
    backgroundColor: '#10b981',
  },
  uptimeText: {
    fontSize: 12,
    color: '#0f172a',
    fontWeight: '600',
    minWidth: 40,
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
