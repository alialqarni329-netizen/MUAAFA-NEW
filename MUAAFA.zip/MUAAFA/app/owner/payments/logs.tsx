import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { FileText, CheckCircle, XCircle, Clock, Info, Search, Zap } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PAYMENTS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/payments' },
  { name: 'successful', label: 'الناجحة', path: '/owner/payments/successful' },
  { name: 'failed', label: 'الفاشلة', path: '/owner/payments/failed' },
  { name: 'invoices', label: 'الفواتير', path: '/owner/payments/invoices' },
  { name: 'refunds', label: 'المرتجعات', path: '/owner/payments/refunds' },
  { name: 'gateways', label: 'البوابات', path: '/owner/payments/gateways' },
  { name: 'tax', label: 'الضرائب', path: '/owner/payments/tax' },
  { name: 'logs', label: 'السجل', path: '/owner/payments/logs' },
];

interface PaymentLog {
  id: string;
  payment_id: string;
  action: string;
  status: string;
  details: string;
  gateway?: string;
  amount?: number;
  created_at: string;
  users?: { full_name: string };
}

export default function TransactionLogs() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [logs, setLogs] = useState<PaymentLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    todayCount: 0,
    successCount: 0,
    failureCount: 0,
  });

  useEffect(() => {
    loadLogs();
  }, []);

  async function loadLogs() {
    try {
      // Try to get logs from payment_logs table, fallback to transaction logs
      const { data: logsData, error } = await supabase
        .from('payment_transactions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(200);

      // Transform to payment log format
      const transformedLogs = (logsData || []).map(log => ({
        id: log.id,
        payment_id: log.subscription_id || log.id,
        action: log.payment_method || 'payment',
        status: log.payment_status || 'pending',
        details: `معاملة بقيمة ${log.amount} ${log.currency || 'SAR'}`,
        gateway: 'ZidPay',
        amount: log.amount,
        created_at: log.created_at,
      }));

      const today = new Date().toISOString().split('T')[0];

      setLogs(transformedLogs);

      const todayLogs = transformedLogs.filter(log => log.created_at.startsWith(today));

      setStats({
        total: transformedLogs.length,
        todayCount: todayLogs.length,
        successCount: transformedLogs.filter(log => log.status === 'completed' || log.status === 'paid').length,
        failureCount: transformedLogs.filter(log => log.status === 'failed').length,
      });
    } catch (error) {
      console.error('Error loading logs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadLogs();
  }

  const filteredLogs = logs.filter(log =>
    log.action?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.details?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.gateway?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  function getStatusIcon(status: string) {
    switch (status) {
      case 'completed':
      case 'paid':
      case 'success':
        return <CheckCircle size={16} color="#10b981" strokeWidth={2} />;
      case 'failed':
      case 'error':
        return <XCircle size={16} color="#ef4444" strokeWidth={2} />;
      case 'pending':
        return <Clock size={16} color="#f59e0b" strokeWidth={2} />;
      default:
        return <Info size={16} color="#3b82f6" strokeWidth={2} />;
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'completed':
      case 'paid':
      case 'success':
        return { bg: '#d1fae5', text: '#065f46' };
      case 'failed':
      case 'error':
        return { bg: '#fee2e2', text: '#991b1b' };
      case 'pending':
        return { bg: '#fef3c7', text: '#92400e' };
      default:
        return { bg: '#dbeafe', text: '#1e40af' };
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'completed':
      case 'paid': return 'مكتمل';
      case 'failed': return 'فاشل';
      case 'pending': return 'معلق';
      default: return status;
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="سجل العمليات" tabs={PAYMENTS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#64748b" />
          <Text style={styles.loadingText}>جاري تحميل السجلات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="سجل العمليات" tabs={PAYMENTS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <FileText size={24} color="#64748b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي السجلات</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayCount}</Text>
            <Text style={styles.statLabel}>سجلات اليوم</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.successCount}</Text>
            <Text style={styles.statLabel}>ناجحة</Text>
          </View>

          <View style={styles.statCard}>
            <XCircle size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.failureCount}</Text>
            <Text style={styles.statLabel}>فاشلة</Text>
          </View>
        </View>

        <View style={styles.gatewayInfo}>
          <Zap size={20} color="#8b5cf6" strokeWidth={2} />
          <View style={styles.gatewayInfoContent}>
            <Text style={styles.gatewayInfoTitle}>بوابة ZidPay النشطة</Text>
            <Text style={styles.gatewayInfoText}>
              جميع المعاملات تتم عبر بوابة ZidPay الآمنة مع عمولة 10%
            </Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="بحث في السجلات..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {filteredLogs.length > 0 ? (
          filteredLogs.map((log) => {
            const colors = getStatusColor(log.status);
            return (
              <View key={log.id} style={styles.logCard}>
                <View style={styles.logHeader}>
                  {getStatusIcon(log.status)}
                  <Text style={styles.action}>{log.action}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
                    <Text style={[styles.statusText, { color: colors.text }]}>
                      {getStatusText(log.status)}
                    </Text>
                  </View>
                </View>

                <View style={styles.logDetails}>
                  <Text style={styles.details}>{log.details}</Text>
                  <View style={styles.meta}>
                    {log.gateway && (
                      <>
                        <View style={styles.gatewayBadge}>
                          <Text style={styles.gatewayBadgeText}>{log.gateway}</Text>
                        </View>
                        <Text style={styles.metaText}>•</Text>
                      </>
                    )}
                    {log.amount && (
                      <>
                        <Text style={styles.metaAmount}>{log.amount.toLocaleString('ar-SA')} ر.س</Text>
                        <Text style={styles.metaText}>•</Text>
                      </>
                    )}
                    <Text style={styles.metaText}>
                      {new Date(log.created_at).toLocaleString('ar-SA', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </Text>
                  </View>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <FileText size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد سجلات'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  gatewayInfo: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    backgroundColor: '#f3e8ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  gatewayInfoContent: {
    flex: 1,
  },
  gatewayInfoTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#6b21a8',
    marginBottom: 4,
    textAlign: 'right',
  },
  gatewayInfoText: {
    fontSize: 13,
    color: '#7c3aed',
    lineHeight: 20,
    textAlign: 'right',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  logCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  logHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  action: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
  logDetails: {
    gap: 6,
  },
  details: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
    lineHeight: 20,
  },
  meta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    justifyContent: 'flex-end',
    flexWrap: 'wrap',
  },
  metaText: {
    fontSize: 12,
    color: '#94a3b8',
  },
  metaAmount: {
    fontSize: 12,
    fontWeight: '600',
    color: '#10b981',
  },
  gatewayBadge: {
    backgroundColor: '#f3e8ff',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  gatewayBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#8b5cf6',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
