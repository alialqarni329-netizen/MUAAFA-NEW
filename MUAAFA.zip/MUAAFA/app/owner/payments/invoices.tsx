import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { FileText, Calendar, DollarSign, Search, User } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PAYMENTS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/payments' },
  { name: 'successful', label: 'الناجحة', path: '/owner/payments/successful' },
  { name: 'failed', label: 'الفاشلة', path: '/owner/payments/failed' },
  { name: 'invoices', label: 'الفواتير', path: '/owner/payments/invoices' },
  { name: 'refunds', label: 'المرتجعات', path: '/owner/payments/refunds' },
  { name: 'gateways', label: 'البوابات', path: '/owner/payments/gateways' },
  { name: 'tax', label: 'الضرائب', path: '/owner/payments/tax' },
  { name: 'logs', label: 'السجل', path: '/owner/payments/logs' },
];

const COMMISSION_RATE = 0.10;
const TAX_RATE = 0.15;

interface Invoice {
  id: string;
  invoice_number: string;
  user_id: string;
  subtotal: number;
  tax_amount: number;
  total_amount: number;
  status: string;
  created_at: string;
  paid_at?: string;
  users?: { full_name: string; email: string };
}

export default function Invoices() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    totalAmount: 0,
    totalTax: 0,
    platformCommission: 0,
    todayCount: 0,
  });

  useEffect(() => {
    loadInvoices();
  }, []);

  async function loadInvoices() {
    try {
      const { data } = await supabase
        .from('invoices')
        .select('*, users(full_name, email)')
        .order('created_at', { ascending: false })
        .limit(100);

      const invoicesData = data || [];
      const today = new Date().toISOString().split('T')[0];

      setInvoices(invoicesData);

      const todayInvoices = invoicesData.filter(inv =>
        inv.created_at.startsWith(today)
      );

      const totalAmount = invoicesData.reduce((sum, inv) => sum + (inv.total_amount || 0), 0);
      const commission = totalAmount * COMMISSION_RATE;

      setStats({
        total: invoicesData.length,
        totalAmount,
        totalTax: invoicesData.reduce((sum, inv) => sum + (inv.tax_amount || 0), 0),
        platformCommission: commission,
        todayCount: todayInvoices.length,
      });
    } catch (error) {
      console.error('Error loading invoices:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadInvoices();
  }

  const filteredInvoices = invoices.filter(invoice =>
    invoice.invoice_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    invoice.users?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    invoice.users?.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  function getStatusColor(status: string) {
    switch (status) {
      case 'paid': return { bg: '#d1fae5', text: '#065f46' };
      case 'issued': return { bg: '#fef3c7', text: '#92400e' };
      case 'cancelled': return { bg: '#fee2e2', text: '#991b1b' };
      default: return { bg: '#f1f5f9', text: '#475569' };
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'paid': return 'مدفوعة';
      case 'issued': return 'صادرة';
      case 'cancelled': return 'ملغية';
      default: return status;
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الفواتير" tabs={PAYMENTS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الفواتير...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الفواتير" tabs={PAYMENTS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <FileText size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الفواتير</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalAmount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>المبلغ الإجمالي (ر.س)</Text>
          </View>

          <View style={styles.statCard}>
            <Calendar size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayCount}</Text>
            <Text style={styles.statLabel}>فواتير اليوم</Text>
          </View>

          <View style={styles.statCard}>
            <FileText size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalTax.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>الضريبة (15%)</Text>
          </View>
        </View>

        <View style={styles.commissionCard}>
          <Text style={styles.commissionTitle}>تفاصيل العمولة والضريبة</Text>
          <View style={styles.commissionDetails}>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>عمولة المنصة (10%):</Text>
              <Text style={styles.commissionValue}>{stats.platformCommission.toLocaleString('ar-SA')} ر.س</Text>
            </View>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>الضريبة المضافة (15%):</Text>
              <Text style={styles.commissionValue}>{stats.totalTax.toLocaleString('ar-SA')} ر.س</Text>
            </View>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="بحث برقم الفاتورة أو الاسم..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {filteredInvoices.length > 0 ? (
          filteredInvoices.map((invoice) => {
            const colors = getStatusColor(invoice.status);
            const commission = invoice.total_amount * COMMISSION_RATE;
            const providerAmount = invoice.total_amount - commission;

            return (
              <View key={invoice.id} style={styles.invoiceCard}>
                <View style={styles.cardHeader}>
                  <FileText size={20} color="#3b82f6" strokeWidth={2} />
                  <Text style={styles.invoiceNumber}>#{invoice.invoice_number}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
                    <Text style={[styles.statusText, { color: colors.text }]}>
                      {getStatusText(invoice.status)}
                    </Text>
                  </View>
                </View>

                <View style={styles.invoiceDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>العميل:</Text>
                    <Text style={styles.detailValue}>{invoice.users?.full_name || 'مستخدم'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>البريد:</Text>
                    <Text style={styles.detailValue}>{invoice.users?.email || '-'}</Text>
                  </View>
                  <View style={styles.separator} />
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>المبلغ الفرعي:</Text>
                    <Text style={styles.detailValue}>{invoice.subtotal.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>الضريبة (15%):</Text>
                    <Text style={styles.detailValue}>{invoice.tax_amount.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>المبلغ الإجمالي:</Text>
                    <Text style={styles.amount}>{invoice.total_amount.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.separator} />
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>عمولة المنصة (10%):</Text>
                    <Text style={styles.detailValue}>{commission.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>صافي مقدم الخدمة:</Text>
                    <Text style={[styles.detailValue, { color: '#10b981', fontWeight: 'bold' }]}>
                      {providerAmount.toLocaleString('ar-SA')} ر.س
                    </Text>
                  </View>
                  <View style={styles.separator} />
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>تاريخ الإصدار:</Text>
                    <Text style={styles.detailValue}>
                      {new Date(invoice.created_at).toLocaleDateString('ar-SA', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </Text>
                  </View>
                  {invoice.paid_at && (
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>تاريخ الدفع:</Text>
                      <Text style={styles.detailValue}>
                        {new Date(invoice.paid_at).toLocaleDateString('ar-SA', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </Text>
                    </View>
                  )}
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <FileText size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد فواتير'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  commissionCard: {
    backgroundColor: '#dbeafe',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#93c5fd',
  },
  commissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 12,
    textAlign: 'right',
  },
  commissionDetails: {
    gap: 8,
  },
  commissionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  commissionLabel: {
    fontSize: 14,
    color: '#1e40af',
    textAlign: 'right',
  },
  commissionValue: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#1e3a8a',
    textAlign: 'left',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  invoiceCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#dbeafe',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  invoiceNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#3b82f6',
    flex: 1,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  invoiceDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  amount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#10b981',
    textAlign: 'left',
  },
  separator: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 4,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
