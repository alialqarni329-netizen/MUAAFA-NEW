import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { CheckCircle, TrendingUp, CreditCard, Calendar, Search, DollarSign } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PAYMENTS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/payments' },
  { name: 'successful', label: 'الناجحة', path: '/owner/payments/successful' },
  { name: 'failed', label: 'الفاشلة', path: '/owner/payments/failed' },
  { name: 'invoices', label: 'الفواتير', path: '/owner/payments/invoices' },
  { name: 'refunds', label: 'المرتجعات', path: '/owner/payments/refunds' },
  { name: 'gateways', label: 'البوابات', path: '/owner/payments/gateways' },
  { name: 'tax', label: 'الضرائب', path: '/owner/payments/tax' },
  { name: 'logs', label: 'السجل', path: '/owner/payments/logs' },
];

const COMMISSION_RATE = 0.10; // 10% platform commission

interface Payment {
  id: string;
  user_id: string;
  total_amount: number;
  patient_paid: number;
  payment_method: string;
  payment_gateway: string;
  created_at: string;
  users?: { full_name: string; email: string };
}

export default function SuccessfulPayments() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    totalAmount: 0,
    platformCommission: 0,
    providerRevenue: 0,
    todayAmount: 0,
    todayCount: 0,
  });

  useEffect(() => {
    loadSuccessfulPayments();
  }, []);

  async function loadSuccessfulPayments() {
    try {
      const { data } = await supabase
        .from('payments')
        .select('*, users(full_name, email)')
        .in('payment_status', ['completed', 'paid'])
        .order('created_at', { ascending: false })
        .limit(100);

      const paymentsData = data || [];
      const today = new Date().toISOString().split('T')[0];

      setPayments(paymentsData);

      const todayPayments = paymentsData.filter(p =>
        p.created_at.startsWith(today)
      );

      const totalAmount = paymentsData.reduce((sum, p) => sum + (p.total_amount || 0), 0);
      const commission = totalAmount * COMMISSION_RATE;

      setStats({
        total: paymentsData.length,
        totalAmount,
        platformCommission: commission,
        providerRevenue: totalAmount - commission,
        todayCount: todayPayments.length,
        todayAmount: todayPayments.reduce((sum, p) => sum + (p.total_amount || 0), 0),
      });
    } catch (error) {
      console.error('Error loading successful payments:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadSuccessfulPayments();
  }

  const filteredPayments = payments.filter(payment =>
    payment.users?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    payment.users?.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    payment.payment_gateway?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <OwnerTabLayout title="المدفوعات الناجحة" tabs={PAYMENTS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#10b981" />
          <Text style={styles.loadingText}>جاري تحميل المدفوعات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="المدفوعات الناجحة" tabs={PAYMENTS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المدفوعات</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalAmount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>المبلغ الإجمالي (ر.س)</Text>
          </View>

          <View style={styles.statCard}>
            <Calendar size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayCount}</Text>
            <Text style={styles.statLabel}>مدفوعات اليوم</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayAmount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إيرادات اليوم (ر.س)</Text>
          </View>
        </View>

        <View style={styles.commissionCard}>
          <View style={styles.commissionHeader}>
            <CreditCard size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.commissionTitle}>تفاصيل العمولة (10%)</Text>
          </View>
          <View style={styles.commissionDetails}>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>عمولة المنصة:</Text>
              <Text style={styles.commissionValue}>{stats.platformCommission.toLocaleString('ar-SA')} ر.س</Text>
            </View>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>صافي إيرادات مقدم الخدمة:</Text>
              <Text style={[styles.commissionValue, { color: '#10b981' }]}>
                {stats.providerRevenue.toLocaleString('ar-SA')} ر.س
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="بحث بالاسم أو البريد أو البوابة..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {filteredPayments.length > 0 ? (
          filteredPayments.map((payment) => {
            const commission = payment.total_amount * COMMISSION_RATE;
            const providerAmount = payment.total_amount - commission;

            return (
              <View key={payment.id} style={styles.paymentCard}>
                <View style={styles.cardHeader}>
                  <CheckCircle size={20} color="#10b981" strokeWidth={2} />
                  <View style={styles.headerInfo}>
                    <Text style={styles.userName}>{payment.users?.full_name || 'مستخدم'}</Text>
                    <Text style={styles.userEmail}>{payment.users?.email || '-'}</Text>
                  </View>
                </View>

                <View style={styles.paymentDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>المبلغ الإجمالي:</Text>
                    <Text style={styles.amount}>{payment.total_amount.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>عمولة المنصة (10%):</Text>
                    <Text style={styles.detailValue}>{commission.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>صافي مقدم الخدمة:</Text>
                    <Text style={[styles.detailValue, { color: '#10b981', fontWeight: 'bold' }]}>
                      {providerAmount.toLocaleString('ar-SA')} ر.س
                    </Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>البوابة:</Text>
                    <Text style={styles.gatewayBadge}>{payment.payment_gateway || 'ZidPay'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>الطريقة:</Text>
                    <Text style={styles.detailValue}>{payment.payment_method || '-'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>التاريخ:</Text>
                    <Text style={styles.detailValue}>
                      {new Date(payment.created_at).toLocaleString('ar-SA', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </Text>
                  </View>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <CheckCircle size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد مدفوعات ناجحة'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  commissionCard: {
    backgroundColor: '#d1fae5',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#6ee7b7',
  },
  commissionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  commissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#065f46',
  },
  commissionDetails: {
    gap: 8,
  },
  commissionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
  },
  commissionLabel: {
    fontSize: 14,
    color: '#047857',
    textAlign: 'right',
  },
  commissionValue: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#065f46',
    textAlign: 'left',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  paymentCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#d1fae5',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  headerInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  userEmail: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  paymentDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  amount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#10b981',
    textAlign: 'left',
  },
  gatewayBadge: {
    fontSize: 13,
    fontWeight: '600',
    color: '#8b5cf6',
    backgroundColor: '#f3e8ff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
