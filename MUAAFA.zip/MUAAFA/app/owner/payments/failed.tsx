import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { XCircle, AlertTriangle, TrendingDown, Search } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PAYMENTS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/payments' },
  { name: 'successful', label: 'الناجحة', path: '/owner/payments/successful' },
  { name: 'failed', label: 'الفاشلة', path: '/owner/payments/failed' },
  { name: 'invoices', label: 'الفواتير', path: '/owner/payments/invoices' },
  { name: 'refunds', label: 'المرتجعات', path: '/owner/payments/refunds' },
  { name: 'gateways', label: 'البوابات', path: '/owner/payments/gateways' },
  { name: 'tax', label: 'الضرائب', path: '/owner/payments/tax' },
  { name: 'logs', label: 'السجل', path: '/owner/payments/logs' },
];

interface FailedPayment {
  id: string;
  user_id: string;
  total_amount: number;
  payment_method: string;
  payment_gateway: string;
  failure_reason?: string;
  created_at: string;
  failed_at?: string;
  users?: { full_name: string; email: string };
}

export default function FailedPayments() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [payments, setPayments] = useState<FailedPayment[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    totalAmount: 0,
    todayCount: 0,
  });

  useEffect(() => {
    loadFailedPayments();
  }, []);

  async function loadFailedPayments() {
    try {
      const { data } = await supabase
        .from('payments')
        .select('*, users(full_name, email)')
        .eq('payment_status', 'failed')
        .order('created_at', { ascending: false })
        .limit(100);

      const paymentsData = data || [];
      const today = new Date().toISOString().split('T')[0];

      setPayments(paymentsData);

      const todayPayments = paymentsData.filter(p =>
        p.created_at.startsWith(today)
      );

      setStats({
        total: paymentsData.length,
        totalAmount: paymentsData.reduce((sum, p) => sum + (p.total_amount || 0), 0),
        todayCount: todayPayments.length,
      });
    } catch (error) {
      console.error('Error loading failed payments:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadFailedPayments();
  }

  const filteredPayments = payments.filter(payment =>
    payment.users?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    payment.users?.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    payment.failure_reason?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <OwnerTabLayout title="المدفوعات الفاشلة" tabs={PAYMENTS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#ef4444" />
          <Text style={styles.loadingText}>جاري تحميل المدفوعات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="المدفوعات الفاشلة" tabs={PAYMENTS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <XCircle size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الفاشلة</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingDown size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalAmount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>المبلغ المفقود (ر.س)</Text>
          </View>

          <View style={styles.statCard}>
            <AlertTriangle size={24} color="#f97316" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayCount}</Text>
            <Text style={styles.statLabel}>فاشلة اليوم</Text>
          </View>
        </View>

        <View style={styles.alertCard}>
          <AlertTriangle size={20} color="#dc2626" strokeWidth={2} />
          <View style={styles.alertContent}>
            <Text style={styles.alertTitle}>تنبيه: المدفوعات الفاشلة</Text>
            <Text style={styles.alertText}>
              هذه المدفوعات فشلت ولم يتم خصم أي عمولة منها. يرجى مراجعة الأسباب ومعالجة المشاكل.
            </Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="بحث بالاسم أو البريد أو السبب..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {filteredPayments.length > 0 ? (
          filteredPayments.map((payment) => (
            <View key={payment.id} style={styles.paymentCard}>
              <View style={styles.cardHeader}>
                <XCircle size={20} color="#ef4444" strokeWidth={2} />
                <View style={styles.headerInfo}>
                  <Text style={styles.userName}>{payment.users?.full_name || 'مستخدم'}</Text>
                  <Text style={styles.userEmail}>{payment.users?.email || '-'}</Text>
                </View>
              </View>

              <View style={styles.paymentDetails}>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>المبلغ:</Text>
                  <Text style={styles.amount}>{payment.total_amount.toLocaleString('ar-SA')} ر.س</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>البوابة:</Text>
                  <Text style={styles.gatewayBadge}>{payment.payment_gateway || 'ZidPay'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>الطريقة:</Text>
                  <Text style={styles.detailValue}>{payment.payment_method || '-'}</Text>
                </View>
                {payment.failure_reason && (
                  <View style={styles.errorBox}>
                    <AlertTriangle size={14} color="#ef4444" strokeWidth={2} />
                    <Text style={styles.errorText}>{payment.failure_reason}</Text>
                  </View>
                )}
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>التاريخ:</Text>
                  <Text style={styles.detailValue}>
                    {new Date(payment.failed_at || payment.created_at).toLocaleString('ar-SA', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <XCircle size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد مدفوعات فاشلة'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  alertCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    backgroundColor: '#fee2e2',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  alertContent: {
    flex: 1,
  },
  alertTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#991b1b',
    marginBottom: 4,
    textAlign: 'right',
  },
  alertText: {
    fontSize: 13,
    color: '#dc2626',
    lineHeight: 20,
    textAlign: 'right',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  paymentCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fee2e2',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  headerInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  userEmail: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  paymentDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  amount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ef4444',
    textAlign: 'left',
  },
  gatewayBadge: {
    fontSize: 13,
    fontWeight: '600',
    color: '#8b5cf6',
    backgroundColor: '#f3e8ff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#fee2e2',
    padding: 10,
    borderRadius: 8,
    marginTop: 4,
  },
  errorText: {
    fontSize: 12,
    color: '#991b1b',
    flex: 1,
    textAlign: 'right',
    lineHeight: 18,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
