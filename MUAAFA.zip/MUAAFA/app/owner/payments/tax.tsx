import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Percent, TrendingUp, Calendar, DollarSign, FileText } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PAYMENTS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/payments' },
  { name: 'successful', label: 'الناجحة', path: '/owner/payments/successful' },
  { name: 'failed', label: 'الفاشلة', path: '/owner/payments/failed' },
  { name: 'invoices', label: 'الفواتير', path: '/owner/payments/invoices' },
  { name: 'refunds', label: 'المرتجعات', path: '/owner/payments/refunds' },
  { name: 'gateways', label: 'البوابات', path: '/owner/payments/gateways' },
  { name: 'tax', label: 'الضرائب', path: '/owner/payments/tax' },
  { name: 'logs', label: 'السجل', path: '/owner/payments/logs' },
];

const TAX_RATE = 0.15; // 15% VAT
const COMMISSION_RATE = 0.10; // 10% platform commission

export default function TaxReports() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    totalRevenue: 0,
    totalTax: 0,
    platformCommission: 0,
    providerRevenue: 0,
    todayRevenue: 0,
    todayTax: 0,
    monthRevenue: 0,
    monthTax: 0,
    quarterRevenue: 0,
    quarterTax: 0,
  });

  useEffect(() => {
    loadTaxData();
  }, []);

  async function loadTaxData() {
    try {
      const { data } = await supabase
        .from('payments')
        .select('total_amount, created_at, payment_status')
        .in('payment_status', ['completed', 'paid']);

      const paymentsData = data || [];

      const today = new Date().toISOString().split('T')[0];
      const currentMonth = new Date().toISOString().slice(0, 7);
      const currentQuarter = getCurrentQuarter();

      const totalRevenue = paymentsData.reduce((sum, p) => sum + (p.total_amount || 0), 0);
      const commission = totalRevenue * COMMISSION_RATE;

      const todayPayments = paymentsData.filter(p => p.created_at.startsWith(today));
      const todayRevenue = todayPayments.reduce((sum, p) => sum + (p.total_amount || 0), 0);

      const monthPayments = paymentsData.filter(p => p.created_at.startsWith(currentMonth));
      const monthRevenue = monthPayments.reduce((sum, p) => sum + (p.total_amount || 0), 0);

      const quarterPayments = paymentsData.filter(p => {
        const paymentQuarter = getQuarter(new Date(p.created_at));
        return paymentQuarter === currentQuarter;
      });
      const quarterRevenue = quarterPayments.reduce((sum, p) => sum + (p.total_amount || 0), 0);

      setStats({
        totalRevenue,
        totalTax: totalRevenue * TAX_RATE,
        platformCommission: commission,
        providerRevenue: totalRevenue - commission,
        todayRevenue,
        todayTax: todayRevenue * TAX_RATE,
        monthRevenue,
        monthTax: monthRevenue * TAX_RATE,
        quarterRevenue,
        quarterTax: quarterRevenue * TAX_RATE,
      });
    } catch (error) {
      console.error('Error loading tax data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function getCurrentQuarter() {
    const month = new Date().getMonth();
    return Math.floor(month / 3) + 1;
  }

  function getQuarter(date: Date) {
    const month = date.getMonth();
    return Math.floor(month / 3) + 1;
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadTaxData();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الضرائب" tabs={PAYMENTS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#f59e0b" />
          <Text style={styles.loadingText}>جاري تحميل البيانات الضريبية...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الضرائب" tabs={PAYMENTS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.taxRateCard}>
          <Percent size={32} color="#f59e0b" strokeWidth={2} />
          <View style={styles.taxRateInfo}>
            <Text style={styles.taxRateText}>نسبة الضريبة (VAT)</Text>
            <Text style={styles.taxRateValue}>15%</Text>
          </View>
        </View>

        <View style={styles.commissionCard}>
          <DollarSign size={24} color="#8b5cf6" strokeWidth={2} />
          <View style={styles.commissionInfo}>
            <Text style={styles.commissionText}>عمولة المنصة</Text>
            <Text style={styles.commissionValue}>10%</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الإجماليات</Text>
          <View style={styles.taxCard}>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>الإيرادات الإجمالية:</Text>
              <Text style={styles.taxValue}>{stats.totalRevenue.toLocaleString('ar-SA')} ر.س</Text>
            </View>
            <View style={styles.separator} />
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>الضريبة المضافة (15%):</Text>
              <Text style={[styles.taxValue, { color: '#f59e0b' }]}>
                {stats.totalTax.toLocaleString('ar-SA')} ر.س
              </Text>
            </View>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>عمولة المنصة (10%):</Text>
              <Text style={[styles.taxValue, { color: '#8b5cf6' }]}>
                {stats.platformCommission.toLocaleString('ar-SA')} ر.س
              </Text>
            </View>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>صافي إيرادات مقدم الخدمة:</Text>
              <Text style={[styles.taxValue, { color: '#10b981' }]}>
                {stats.providerRevenue.toLocaleString('ar-SA')} ر.س
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Calendar size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.sectionTitle}>اليوم</Text>
          </View>
          <View style={styles.taxCard}>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>الإيرادات:</Text>
              <Text style={styles.taxValue}>{stats.todayRevenue.toLocaleString('ar-SA')} ر.س</Text>
            </View>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>الضريبة (15%):</Text>
              <Text style={[styles.taxValue, { color: '#f59e0b' }]}>
                {stats.todayTax.toLocaleString('ar-SA')} ر.س
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Calendar size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.sectionTitle}>الشهر الحالي</Text>
          </View>
          <View style={styles.taxCard}>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>الإيرادات:</Text>
              <Text style={styles.taxValue}>{stats.monthRevenue.toLocaleString('ar-SA')} ر.س</Text>
            </View>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>الضريبة (15%):</Text>
              <Text style={[styles.taxValue, { color: '#f59e0b' }]}>
                {stats.monthTax.toLocaleString('ar-SA')} ر.س
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <TrendingUp size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.sectionTitle}>الربع الحالي (Q{getCurrentQuarter()})</Text>
          </View>
          <View style={styles.taxCard}>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>الإيرادات:</Text>
              <Text style={styles.taxValue}>{stats.quarterRevenue.toLocaleString('ar-SA')} ر.س</Text>
            </View>
            <View style={styles.taxRow}>
              <Text style={styles.taxLabel}>الضريبة (15%):</Text>
              <Text style={[styles.taxValue, { color: '#f59e0b' }]}>
                {stats.quarterTax.toLocaleString('ar-SA')} ر.س
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.infoBox}>
          <FileText size={20} color="#0369a1" strokeWidth={2} />
          <View style={styles.infoContent}>
            <Text style={styles.infoTitle}>معلومة مهمة</Text>
            <Text style={styles.infoText}>
              يتم احتساب ضريبة القيمة المضافة (15%) على إجمالي المبلغ، وتخصم عمولة المنصة (10%) من المبلغ الإجمالي قبل تحويله لمقدم الخدمة.
            </Text>
          </View>
        </View>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  taxRateCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#fef3c7',
    padding: 24,
    borderRadius: 16,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#fbbf24',
  },
  taxRateInfo: {
    flex: 1,
  },
  taxRateText: {
    fontSize: 16,
    color: '#78350f',
    marginBottom: 4,
    fontWeight: '600',
    textAlign: 'right',
  },
  taxRateValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#f59e0b',
    textAlign: 'right',
  },
  commissionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#f3e8ff',
    padding: 20,
    borderRadius: 12,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  commissionInfo: {
    flex: 1,
  },
  commissionText: {
    fontSize: 15,
    color: '#6b21a8',
    marginBottom: 4,
    fontWeight: '600',
    textAlign: 'right',
  },
  commissionValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#8b5cf6',
    textAlign: 'right',
  },
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  taxCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  taxRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  separator: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 4,
  },
  taxLabel: {
    fontSize: 15,
    color: '#64748b',
    textAlign: 'right',
  },
  taxValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'left',
  },
  infoBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    backgroundColor: '#e0f2fe',
    padding: 16,
    borderRadius: 12,
    marginTop: 8,
    borderWidth: 1,
    borderColor: '#7dd3fc',
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0369a1',
    marginBottom: 4,
    textAlign: 'right',
  },
  infoText: {
    fontSize: 13,
    color: '#0c4a6e',
    lineHeight: 20,
    textAlign: 'right',
  },
});
