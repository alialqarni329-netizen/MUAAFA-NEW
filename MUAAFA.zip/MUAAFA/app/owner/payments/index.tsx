import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { DollarSign, CheckCircle, XCircle, Clock, CreditCard, TrendingUp } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PAYMENTS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/payments' },
  { name: 'successful', label: 'الناجحة', path: '/owner/payments/successful' },
  { name: 'failed', label: 'الفاشلة', path: '/owner/payments/failed' },
  { name: 'invoices', label: 'الفواتير', path: '/owner/payments/invoices' },
  { name: 'refunds', label: 'المرتجعات', path: '/owner/payments/refunds' },
  { name: 'gateways', label: 'البوابات', path: '/owner/payments/gateways' },
  { name: 'tax', label: 'الضرائب', path: '/owner/payments/tax' },
  { name: 'logs', label: 'السجل', path: '/owner/payments/logs' },
];

const COMMISSION_RATE = 0.10; // 10% platform commission

interface Payment {
  id: string;
  user_id: string;
  total_amount: number;
  patient_paid: number;
  payment_status: string;
  payment_method: string;
  payment_gateway: string;
  created_at: string;
  users?: { full_name: string; email: string };
}

export default function AllPayments() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    completed: 0,
    failed: 0,
    pending: 0,
    totalAmount: 0,
    completedAmount: 0,
    platformCommission: 0,
    providerRevenue: 0,
  });

  useEffect(() => {
    loadPayments();
  }, []);

  async function loadPayments() {
    try {
      const [paymentsRes, statsRes] = await Promise.all([
        supabase
          .from('payments')
          .select('*, users(full_name, email)')
          .order('created_at', { ascending: false })
          .limit(50),

        supabase.from('payments').select('total_amount, patient_paid, payment_status'),
      ]);

      const paymentsData = paymentsRes.data || [];
      const allPayments = statsRes.data || [];

      setPayments(paymentsData);

      const completedPayments = allPayments.filter(p => p.payment_status === 'completed' || p.payment_status === 'paid');
      const completedAmount = completedPayments.reduce((sum, p) => sum + (p.total_amount || 0), 0);
      const commission = completedAmount * COMMISSION_RATE;

      setStats({
        total: allPayments.length,
        completed: completedPayments.length,
        failed: allPayments.filter(p => p.payment_status === 'failed').length,
        pending: allPayments.filter(p => p.payment_status === 'pending').length,
        totalAmount: allPayments.reduce((sum, p) => sum + (p.total_amount || 0), 0),
        completedAmount,
        platformCommission: commission,
        providerRevenue: completedAmount - commission,
      });
    } catch (error) {
      console.error('Error loading payments:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadPayments();
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'completed':
      case 'paid': return { bg: '#d1fae5', text: '#065f46' };
      case 'failed': return { bg: '#fee2e2', text: '#991b1b' };
      case 'pending': return { bg: '#fef3c7', text: '#92400e' };
      case 'refunded': return { bg: '#dbeafe', text: '#1e40af' };
      default: return { bg: '#f1f5f9', text: '#475569' };
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'completed':
      case 'paid': return 'مكتمل';
      case 'failed': return 'فاشل';
      case 'pending': return 'معلق';
      case 'refunded': return 'مسترد';
      default: return status;
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'completed':
      case 'paid': return <CheckCircle size={14} color="#065f46" strokeWidth={2} />;
      case 'failed': return <XCircle size={14} color="#991b1b" strokeWidth={2} />;
      case 'pending': return <Clock size={14} color="#92400e" strokeWidth={2} />;
      default: return <DollarSign size={14} color="#475569" strokeWidth={2} />;
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة المدفوعات" tabs={PAYMENTS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#10b981" />
          <Text style={styles.loadingText}>جاري تحميل المدفوعات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة المدفوعات" tabs={PAYMENTS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <DollarSign size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المدفوعات</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.completed}</Text>
            <Text style={styles.statLabel}>مكتملة</Text>
          </View>

          <View style={styles.statCard}>
            <XCircle size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.failed}</Text>
            <Text style={styles.statLabel}>فاشلة</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.completedAmount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الإيرادات (ر.س)</Text>
          </View>
        </View>

        <View style={styles.commissionCard}>
          <View style={styles.commissionHeader}>
            <CreditCard size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.commissionTitle}>تفاصيل العمولة (10%)</Text>
          </View>
          <View style={styles.commissionDetails}>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>عمولة المنصة:</Text>
              <Text style={styles.commissionValue}>{stats.platformCommission.toLocaleString('ar-SA')} ر.س</Text>
            </View>
            <View style={styles.commissionRow}>
              <Text style={styles.commissionLabel}>صافي إيرادات مقدم الخدمة:</Text>
              <Text style={[styles.commissionValue, { color: '#10b981' }]}>
                {stats.providerRevenue.toLocaleString('ar-SA')} ر.س
              </Text>
            </View>
          </View>
        </View>

        {payments.length > 0 ? (
          payments.map((payment) => {
            const colors = getStatusColor(payment.payment_status);
            const commission = payment.total_amount * COMMISSION_RATE;
            const providerAmount = payment.total_amount - commission;

            return (
              <View key={payment.id} style={styles.paymentCard}>
                <View style={styles.paymentHeader}>
                  <View style={styles.paymentInfo}>
                    <Text style={styles.userName}>{payment.users?.full_name || 'مستخدم'}</Text>
                    <Text style={styles.userEmail}>{payment.users?.email || '-'}</Text>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
                    {getStatusIcon(payment.payment_status)}
                    <Text style={[styles.statusText, { color: colors.text }]}>
                      {getStatusText(payment.payment_status)}
                    </Text>
                  </View>
                </View>

                <View style={styles.paymentDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>المبلغ الإجمالي:</Text>
                    <Text style={styles.amount}>{payment.total_amount.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>عمولة المنصة (10%):</Text>
                    <Text style={styles.detailValue}>{commission.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>صافي مقدم الخدمة:</Text>
                    <Text style={[styles.detailValue, { color: '#10b981', fontWeight: 'bold' }]}>
                      {providerAmount.toLocaleString('ar-SA')} ر.س
                    </Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>البوابة:</Text>
                    <Text style={styles.detailValue}>{payment.payment_gateway || 'ZidPay'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>الطريقة:</Text>
                    <Text style={styles.detailValue}>{payment.payment_method || '-'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>التاريخ:</Text>
                    <Text style={styles.detailValue}>
                      {new Date(payment.created_at).toLocaleDateString('ar-SA', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </Text>
                  </View>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <CreditCard size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا توجد مدفوعات</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  commissionCard: {
    backgroundColor: '#f8f4ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  commissionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  commissionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#6b21a8',
  },
  commissionDetails: {
    gap: 8,
  },
  commissionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
  },
  commissionLabel: {
    fontSize: 14,
    color: '#7c3aed',
    textAlign: 'right',
  },
  commissionValue: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#8b5cf6',
    textAlign: 'left',
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  paymentCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  paymentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  paymentInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  userEmail: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  paymentDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  amount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#10b981',
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
});
