import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { RotateCcw, TrendingDown, Clock, CheckCircle, Search, AlertCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PAYMENTS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/payments' },
  { name: 'successful', label: 'الناجحة', path: '/owner/payments/successful' },
  { name: 'failed', label: 'الفاشلة', path: '/owner/payments/failed' },
  { name: 'invoices', label: 'الفواتير', path: '/owner/payments/invoices' },
  { name: 'refunds', label: 'المرتجعات', path: '/owner/payments/refunds' },
  { name: 'gateways', label: 'البوابات', path: '/owner/payments/gateways' },
  { name: 'tax', label: 'الضرائب', path: '/owner/payments/tax' },
  { name: 'logs', label: 'السجل', path: '/owner/payments/logs' },
];

interface Refund {
  id: string;
  payment_id: string;
  user_id: string;
  amount: number;
  reason: string;
  status: string;
  created_at: string;
  processed_at?: string;
  users?: { full_name: string; email: string };
}

export default function Refunds() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [refunds, setRefunds] = useState<Refund[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    completed: 0,
    rejected: 0,
    totalAmount: 0,
    processedAmount: 0,
  });

  useEffect(() => {
    loadRefunds();
  }, []);

  async function loadRefunds() {
    try {
      // Try to get refunds from payment_refunds table if it exists
      const { data, error } = await supabase
        .from('payment_refunds')
        .select('*, users(full_name, email)')
        .order('created_at', { ascending: false })
        .limit(100);

      // If table doesn't exist, create mock data structure
      const refundsData = error ? [] : (data || []);

      setRefunds(refundsData);

      setStats({
        total: refundsData.length,
        pending: refundsData.filter(r => r.status === 'pending').length,
        completed: refundsData.filter(r => r.status === 'completed').length,
        rejected: refundsData.filter(r => r.status === 'rejected').length,
        totalAmount: refundsData.reduce((sum, r) => sum + (r.amount || 0), 0),
        processedAmount: refundsData.filter(r => r.status === 'completed').reduce((sum, r) => sum + (r.amount || 0), 0),
      });
    } catch (error) {
      console.error('Error loading refunds:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadRefunds();
  }

  const filteredRefunds = refunds.filter(refund =>
    refund.users?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    refund.users?.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    refund.reason?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  function getStatusColor(status: string) {
    switch (status) {
      case 'completed': return { bg: '#d1fae5', text: '#065f46' };
      case 'pending': return { bg: '#fef3c7', text: '#92400e' };
      case 'rejected': return { bg: '#fee2e2', text: '#991b1b' };
      default: return { bg: '#f1f5f9', text: '#475569' };
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'completed': return 'مكتمل';
      case 'pending': return 'معلق';
      case 'rejected': return 'مرفوض';
      default: return status;
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="المرتجعات" tabs={PAYMENTS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#f59e0b" />
          <Text style={styles.loadingText}>جاري تحميل المرتجعات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="المرتجعات" tabs={PAYMENTS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <RotateCcw size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المرتجعات</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending}</Text>
            <Text style={styles.statLabel}>معلقة</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.completed}</Text>
            <Text style={styles.statLabel}>مكتملة</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingDown size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalAmount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>المبلغ المسترد (ر.س)</Text>
          </View>
        </View>

        <View style={styles.infoCard}>
          <AlertCircle size={20} color="#2563eb" strokeWidth={2} />
          <View style={styles.infoContent}>
            <Text style={styles.infoTitle}>معلومة: المرتجعات والعمولة</Text>
            <Text style={styles.infoText}>
              عند إتمام عملية المرتجع، يتم استرداد عمولة المنصة (10%) مع المبلغ المسترد للعميل.
            </Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="بحث بالاسم أو البريد أو السبب..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {filteredRefunds.length > 0 ? (
          filteredRefunds.map((refund) => {
            const colors = getStatusColor(refund.status);
            const commission = refund.amount * 0.10;

            return (
              <View key={refund.id} style={styles.refundCard}>
                <View style={styles.cardHeader}>
                  <RotateCcw size={20} color="#f59e0b" strokeWidth={2} />
                  <View style={styles.headerInfo}>
                    <Text style={styles.userName}>{refund.users?.full_name || 'مستخدم'}</Text>
                    <Text style={styles.userEmail}>{refund.users?.email || '-'}</Text>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
                    <Text style={[styles.statusText, { color: colors.text }]}>
                      {getStatusText(refund.status)}
                    </Text>
                  </View>
                </View>

                <View style={styles.refundDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>مبلغ المرتجع:</Text>
                    <Text style={styles.amount}>{refund.amount.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>عمولة مستردة (10%):</Text>
                    <Text style={styles.detailValue}>{commission.toLocaleString('ar-SA')} ر.س</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>السبب:</Text>
                    <Text style={[styles.detailValue, styles.reasonText]} numberOfLines={2}>
                      {refund.reason || '-'}
                    </Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>تاريخ الطلب:</Text>
                    <Text style={styles.detailValue}>
                      {new Date(refund.created_at).toLocaleDateString('ar-SA', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </Text>
                  </View>
                  {refund.processed_at && (
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>تاريخ المعالجة:</Text>
                      <Text style={styles.detailValue}>
                        {new Date(refund.processed_at).toLocaleDateString('ar-SA', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </Text>
                    </View>
                  )}
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <RotateCcw size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد مرتجعات'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    backgroundColor: '#dbeafe',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#93c5fd',
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 4,
    textAlign: 'right',
  },
  infoText: {
    fontSize: 13,
    color: '#1e3a8a',
    lineHeight: 20,
    textAlign: 'right',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  refundCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fef3c7',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  headerInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  userEmail: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  refundDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  amount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#f59e0b',
    textAlign: 'left',
  },
  reasonText: {
    flex: 1,
    marginLeft: 12,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
