import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { CreditCard, TrendingUp, Activity, CheckCircle, Zap, DollarSign } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const PAYMENTS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/payments' },
  { name: 'successful', label: 'الناجحة', path: '/owner/payments/successful' },
  { name: 'failed', label: 'الفاشلة', path: '/owner/payments/failed' },
  { name: 'invoices', label: 'الفواتير', path: '/owner/payments/invoices' },
  { name: 'refunds', label: 'المرتجعات', path: '/owner/payments/refunds' },
  { name: 'gateways', label: 'البوابات', path: '/owner/payments/gateways' },
  { name: 'tax', label: 'الضرائب', path: '/owner/payments/tax' },
  { name: 'logs', label: 'السجل', path: '/owner/payments/logs' },
];

const COMMISSION_RATE = 0.10;

interface GatewayStats {
  gateway: string;
  total: number;
  successful: number;
  failed: number;
  totalAmount: number;
  commission: number;
  providerRevenue: number;
}

export default function PaymentGateways() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [gateways, setGateways] = useState<GatewayStats[]>([]);
  const [stats, setStats] = useState({
    totalGateways: 0,
    totalPayments: 0,
    totalAmount: 0,
    totalCommission: 0,
  });

  useEffect(() => {
    loadGatewayStats();
  }, []);

  async function loadGatewayStats() {
    try {
      const { data } = await supabase
        .from('payments')
        .select('payment_gateway, total_amount, payment_status');

      const paymentsData = data || [];

      const gatewayMap = new Map<string, GatewayStats>();

      paymentsData.forEach((payment) => {
        const method = payment.payment_gateway || 'ZidPay';

        if (!gatewayMap.has(method)) {
          gatewayMap.set(method, {
            gateway: method,
            total: 0,
            successful: 0,
            failed: 0,
            totalAmount: 0,
            commission: 0,
            providerRevenue: 0,
          });
        }

        const stats = gatewayMap.get(method)!;
        stats.total++;

        if (payment.payment_status === 'completed' || payment.payment_status === 'paid') {
          stats.successful++;
          const amount = payment.total_amount || 0;
          stats.totalAmount += amount;
          stats.commission += amount * COMMISSION_RATE;
          stats.providerRevenue += amount * (1 - COMMISSION_RATE);
        } else if (payment.payment_status === 'failed') {
          stats.failed++;
        }
      });

      const gatewayStats = Array.from(gatewayMap.values()).sort((a, b) => b.total - a.total);

      setGateways(gatewayStats);

      setStats({
        totalGateways: gatewayStats.length,
        totalPayments: paymentsData.length,
        totalAmount: gatewayStats.reduce((sum, g) => sum + g.totalAmount, 0),
        totalCommission: gatewayStats.reduce((sum, g) => sum + g.commission, 0),
      });
    } catch (error) {
      console.error('Error loading gateway stats:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadGatewayStats();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="بوابات الدفع" tabs={PAYMENTS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل الإحصائيات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="بوابات الدفع" tabs={PAYMENTS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.zidpayCard}>
          <View style={styles.zidpayHeader}>
            <Zap size={28} color="#8b5cf6" strokeWidth={2} />
            <View style={styles.zidpayInfo}>
              <Text style={styles.zidpayTitle}>ZidPay</Text>
              <Text style={styles.zidpaySubtitle}>البوابة الرئيسية للمدفوعات</Text>
            </View>
            <View style={styles.activeBadge}>
              <Text style={styles.activeText}>نشط</Text>
            </View>
          </View>
          <View style={styles.zidpayDetails}>
            <Text style={styles.zidpayDesc}>
              بوابة دفع آمنة ومتكاملة مع عمولة منصة 10% على جميع العمليات الناجحة
            </Text>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <CreditCard size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalGateways}</Text>
            <Text style={styles.statLabel}>البوابات النشطة</Text>
          </View>

          <View style={styles.statCard}>
            <Activity size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalPayments}</Text>
            <Text style={styles.statLabel}>إجمالي العمليات</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalAmount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>الإيرادات (ر.س)</Text>
          </View>

          <View style={styles.statCard}>
            <DollarSign size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalCommission.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>عمولة المنصة (ر.س)</Text>
          </View>
        </View>

        {gateways.length > 0 ? (
          gateways.map((gateway) => (
            <View key={gateway.gateway} style={styles.gatewayCard}>
              <View style={styles.cardHeader}>
                <CreditCard size={20} color="#8b5cf6" strokeWidth={2} />
                <Text style={styles.gatewayName}>{gateway.gateway}</Text>
              </View>

              <View style={styles.statsRow}>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>{gateway.total}</Text>
                  <Text style={styles.statLabel2}>إجمالي</Text>
                </View>

                <View style={styles.statItem}>
                  <Text style={[styles.statNumber, { color: '#10b981' }]}>{gateway.successful}</Text>
                  <Text style={styles.statLabel2}>ناجح</Text>
                </View>

                <View style={styles.statItem}>
                  <Text style={[styles.statNumber, { color: '#ef4444' }]}>{gateway.failed}</Text>
                  <Text style={styles.statLabel2}>فاشل</Text>
                </View>

                <View style={styles.statItem}>
                  <Text style={[styles.statNumber, { color: '#8b5cf6' }]}>
                    {gateway.totalAmount.toLocaleString('ar-SA')}
                  </Text>
                  <Text style={styles.statLabel2}>ر.س</Text>
                </View>
              </View>

              <View style={styles.commissionRow}>
                <View style={styles.commissionItem}>
                  <Text style={styles.commissionLabel}>عمولة المنصة (10%):</Text>
                  <Text style={styles.commissionValue}>{gateway.commission.toLocaleString('ar-SA')} ر.س</Text>
                </View>
                <View style={styles.commissionItem}>
                  <Text style={styles.commissionLabel}>صافي مقدم الخدمة:</Text>
                  <Text style={[styles.commissionValue, { color: '#10b981' }]}>
                    {gateway.providerRevenue.toLocaleString('ar-SA')} ر.س
                  </Text>
                </View>
              </View>

              <View style={styles.progressBar}>
                <View
                  style={[
                    styles.progressFill,
                    {
                      width: `${gateway.total > 0 ? (gateway.successful / gateway.total) * 100 : 0}%`,
                      backgroundColor: '#10b981',
                    },
                  ]}
                />
              </View>
              <Text style={styles.successRate}>
                معدل النجاح: {gateway.total > 0 ? Math.round((gateway.successful / gateway.total) * 100) : 0}%
              </Text>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <CreditCard size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا توجد بوابات دفع</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  zidpayCard: {
    backgroundColor: '#f3e8ff',
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#c4b5fd',
  },
  zidpayHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  zidpayInfo: {
    flex: 1,
  },
  zidpayTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#6b21a8',
  },
  zidpaySubtitle: {
    fontSize: 13,
    color: '#7c3aed',
    marginTop: 2,
  },
  activeBadge: {
    backgroundColor: '#10b981',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  activeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  zidpayDetails: {
    marginTop: 8,
  },
  zidpayDesc: {
    fontSize: 14,
    color: '#7c3aed',
    lineHeight: 20,
    textAlign: 'right',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  gatewayCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  gatewayName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel2: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
  },
  commissionRow: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    gap: 8,
  },
  commissionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  commissionLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  commissionValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#8b5cf6',
    textAlign: 'left',
  },
  progressBar: {
    height: 6,
    backgroundColor: '#f1f5f9',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  successRate: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'center',
    fontWeight: '600',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
});
