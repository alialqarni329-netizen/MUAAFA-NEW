import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { BarChart3, DollarSign, TrendingUp, Users, Building2, ShoppingBag, CreditCard, Activity } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const ANALYTICS_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/analytics' },
  { name: 'revenue', label: 'الإيرادات', path: '/owner/analytics/revenue' },
  { name: 'subscriptions', label: 'الاشتراكات', path: '/owner/analytics/subscriptions' },
  { name: 'business', label: 'الشركات', path: '/owner/analytics/business' },
  { name: 'usage', label: 'الاستخدام', path: '/owner/analytics/usage' },
  { name: 'export-pdf', label: 'تصدير PDF', path: '/owner/analytics/export-pdf' },
  { name: 'export-excel', label: 'تصدير Excel', path: '/owner/analytics/export-excel' },
];

interface AnalyticsOverview {
  totalRevenue: number;
  platformCommission: number;
  providersShare: number;
  totalUsers: number;
  activeBusinesses: number;
  totalSubscriptions: number;
  totalTransactions: number;
  averageTransactionValue: number;
}

interface RevenueByPeriod {
  period: string;
  revenue: number;
  commission: number;
}

export default function AnalyticsOverview() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [analytics, setAnalytics] = useState<AnalyticsOverview>({
    totalRevenue: 0,
    platformCommission: 0,
    providersShare: 0,
    totalUsers: 0,
    activeBusinesses: 0,
    totalSubscriptions: 0,
    totalTransactions: 0,
    averageTransactionValue: 0,
  });
  const [weeklyRevenue, setWeeklyRevenue] = useState<RevenueByPeriod[]>([]);

  useEffect(() => {
    loadAnalytics();
  }, []);

  async function loadAnalytics() {
    try {
      // Get total revenue from payments
      const { data: paymentsData } = await supabase
        .from('payments')
        .select('amount')
        .eq('status', 'completed');

      const totalRevenue = paymentsData?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0;
      const platformCommission = totalRevenue * 0.10;
      const providersShare = totalRevenue * 0.90;

      // Get users count
      const { count: usersCount } = await supabase
        .from('users')
        .select('*', { count: 'exact', head: true });

      // Get active businesses
      const { count: businessesCount } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Get active subscriptions
      const { count: subscriptionsCount } = await supabase
        .from('subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Get total transactions
      const { count: transactionsCount } = await supabase
        .from('payments')
        .select('*', { count: 'exact', head: true });

      const averageTransactionValue = transactionsCount > 0 ? totalRevenue / transactionsCount : 0;

      setAnalytics({
        totalRevenue,
        platformCommission,
        providersShare,
        totalUsers: usersCount || 0,
        activeBusinesses: businessesCount || 0,
        totalSubscriptions: subscriptionsCount || 0,
        totalTransactions: transactionsCount || 0,
        averageTransactionValue,
      });

      // Get weekly revenue data
      const weeklyData: RevenueByPeriod[] = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        date.setHours(0, 0, 0, 0);
        const nextDate = new Date(date);
        nextDate.setDate(nextDate.getDate() + 1);

        const { data: dayPayments } = await supabase
          .from('payments')
          .select('amount')
          .eq('status', 'completed')
          .gte('created_at', date.toISOString())
          .lt('created_at', nextDate.toISOString());

        const dayRevenue = dayPayments?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0;
        const dayCommission = dayRevenue * 0.10;

        const periodLabel = i === 0 ? 'اليوم' : i === 1 ? 'أمس' : `${i} أيام`;
        weeklyData.push({ period: periodLabel, revenue: dayRevenue, commission: dayCommission });
      }
      setWeeklyRevenue(weeklyData);

    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadAnalytics();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  if (loading) {
    return (
      <OwnerTabLayout title="التحليلات والتقارير" tabs={ANALYTICS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل التحليلات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  const maxWeeklyRevenue = Math.max(...weeklyRevenue.map(w => w.revenue), 1);

  return (
    <OwnerTabLayout title="التحليلات والتقارير" tabs={ANALYTICS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <Text style={styles.pageTitle}>نظرة عامة على الأداء</Text>

        <View style={styles.mainStatsGrid}>
          <View style={[styles.mainStatCard, { backgroundColor: '#dbeafe', borderColor: '#3b82f6' }]}>
            <DollarSign size={28} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.mainStatValue}>{formatCurrency(analytics.totalRevenue)}</Text>
            <Text style={styles.mainStatLabel}>إجمالي الإيرادات</Text>
          </View>

          <View style={[styles.mainStatCard, { backgroundColor: '#d1fae5', borderColor: '#10b981' }]}>
            <TrendingUp size={28} color="#10b981" strokeWidth={2} />
            <Text style={styles.mainStatValue}>{formatCurrency(analytics.platformCommission)}</Text>
            <Text style={styles.mainStatLabel}>عمولة المنصة (10%)</Text>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Users size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{analytics.totalUsers.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي المستخدمين</Text>
          </View>

          <View style={styles.statCard}>
            <Building2 size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{analytics.activeBusinesses.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>الشركات النشطة</Text>
          </View>

          <View style={styles.statCard}>
            <CreditCard size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{analytics.totalSubscriptions.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>الاشتراكات النشطة</Text>
          </View>

          <View style={styles.statCard}>
            <ShoppingBag size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{analytics.totalTransactions.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي المعاملات</Text>
          </View>
        </View>

        <View style={styles.chartCard}>
          <View style={styles.chartHeader}>
            <BarChart3 size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.chartTitle}>الإيرادات الأسبوعية</Text>
          </View>
          <View style={styles.barChart}>
            {weeklyRevenue.map((item, index) => {
              const barHeight = (item.revenue / maxWeeklyRevenue) * 100;
              return (
                <View key={index} style={styles.barContainer}>
                  <View style={styles.barWrapper}>
                    <View style={[styles.bar, { height: `${barHeight}%` }]} />
                  </View>
                  <Text style={styles.barValue}>{(item.revenue / 1000).toFixed(1)}k</Text>
                  <Text style={styles.barLabel}>{item.period}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.commissionCard}>
          <View style={styles.commissionHeader}>
            <Activity size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.commissionTitle}>توزيع الإيرادات (نموذج العمولة 10%)</Text>
          </View>

          <View style={styles.commissionRow}>
            <View style={styles.commissionItem}>
              <View style={[styles.commissionBadge, { backgroundColor: '#d1fae5' }]}>
                <DollarSign size={16} color="#10b981" strokeWidth={2} />
              </View>
              <View style={styles.commissionInfo}>
                <Text style={styles.commissionLabel}>عمولة المنصة</Text>
                <Text style={styles.commissionValue}>{formatCurrency(analytics.platformCommission)}</Text>
                <Text style={styles.commissionPercent}>10% من الإجمالي</Text>
              </View>
            </View>
          </View>

          <View style={styles.commissionDivider} />

          <View style={styles.commissionRow}>
            <View style={styles.commissionItem}>
              <View style={[styles.commissionBadge, { backgroundColor: '#dbeafe' }]}>
                <Building2 size={16} color="#3b82f6" strokeWidth={2} />
              </View>
              <View style={styles.commissionInfo}>
                <Text style={styles.commissionLabel}>حصة مقدمي الخدمة</Text>
                <Text style={styles.commissionValue}>{formatCurrency(analytics.providersShare)}</Text>
                <Text style={styles.commissionPercent}>90% من الإجمالي</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>متوسط قيمة المعاملة</Text>
          <Text style={styles.infoValue}>{formatCurrency(analytics.averageTransactionValue)}</Text>
        </View>

      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  pageTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  mainStatsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  mainStatCard: {
    flex: 1,
    padding: 20,
    borderRadius: 16,
    borderWidth: 2,
    alignItems: 'center',
    gap: 8,
  },
  mainStatValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
  },
  mainStatLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'center',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 8,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'center',
  },
  chartCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  chartHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  barChart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 140,
    gap: 4,
  },
  barContainer: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  barWrapper: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-end',
  },
  bar: {
    width: '100%',
    backgroundColor: '#3b82f6',
    borderRadius: 4,
    minHeight: 4,
  },
  barValue: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  barLabel: {
    fontSize: 9,
    color: '#64748b',
    textAlign: 'center',
  },
  commissionCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  commissionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  commissionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  commissionRow: {
    marginBottom: 12,
  },
  commissionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  commissionBadge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  commissionInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  commissionLabel: {
    fontSize: 13,
    color: '#64748b',
    marginBottom: 4,
  },
  commissionValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 2,
  },
  commissionPercent: {
    fontSize: 11,
    color: '#94a3b8',
  },
  commissionDivider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 12,
  },
  infoCard: {
    backgroundColor: '#f8fafc',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    alignItems: 'center',
  },
  infoTitle: {
    fontSize: 13,
    color: '#64748b',
    marginBottom: 8,
  },
  infoValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
  },
});
