import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { DollarSign, TrendingUp, Calendar, Building2, Pill, ArrowUpRight, ArrowDownRight, PieChart } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const ANALYTICS_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/analytics' },
  { name: 'revenue', label: 'الإيرادات', path: '/owner/analytics/revenue' },
  { name: 'business', label: 'الشركات', path: '/owner/analytics/business' },
  { name: 'usage', label: 'الاستخدام', path: '/owner/analytics/usage' },
  { name: 'export-pdf', label: 'تصدير PDF', path: '/owner/analytics/export-pdf' },
  { name: 'export-excel', label: 'تصدير Excel', path: '/owner/analytics/export-excel' },
];

interface RevenueData {
  totalRevenue: number;
  platformCommission: number;
  providersShare: number;
  monthlyRevenue: number;
  weeklyRevenue: number;
  todayRevenue: number;
  hospitalRevenue: number;
  pharmacyRevenue: number;
  sessionRevenue: number;
  growthRate: number;
  pharmacyCommission: number;
  sessionCommission: number;
}

interface MonthlyData {
  month: string;
  revenue: number;
  commission: number;
}

interface Transaction {
  id: string;
  amount: number;
  type: string;
  business_name: string;
  created_at: string;
  status: string;
}

export default function RevenueAnalytics() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [dateRange, setDateRange] = useState<'week' | 'month' | 'year'>('month');
  const [revenueData, setRevenueData] = useState<RevenueData>({
    totalRevenue: 0,
    platformCommission: 0,
    providersShare: 0,
    monthlyRevenue: 0,
    weeklyRevenue: 0,
    todayRevenue: 0,
    hospitalRevenue: 0,
    pharmacyRevenue: 0,
    sessionRevenue: 0,
    growthRate: 0,
    pharmacyCommission: 0,
    sessionCommission: 0,
  });
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([]);
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    loadRevenueData();
  }, [dateRange]);

  async function loadRevenueData() {
    try {
      const now = new Date();

      // Get all time revenue
      const { data: allPayments } = await supabase
        .from('payments')
        .select('total_amount, payment_type, created_at, payment_status')
        .eq('payment_status', 'completed');

      const totalRevenue = allPayments?.reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;
      const platformCommission = totalRevenue * 0.10;
      const providersShare = totalRevenue * 0.90;

      // Get today's revenue
      const todayStart = new Date(now);
      todayStart.setHours(0, 0, 0, 0);
      const { data: todayPayments } = await supabase
        .from('payments')
        .select('total_amount')
        .eq('payment_status', 'completed')
        .gte('created_at', todayStart.toISOString());
      const todayRevenue = todayPayments?.reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;

      // Get weekly revenue
      const weekStart = new Date(now);
      weekStart.setDate(weekStart.getDate() - 7);
      weekStart.setHours(0, 0, 0, 0);
      const { data: weekPayments } = await supabase
        .from('payments')
        .select('total_amount')
        .eq('payment_status', 'completed')
        .gte('created_at', weekStart.toISOString());
      const weeklyRevenue = weekPayments?.reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;

      // Get monthly revenue
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const { data: monthPayments } = await supabase
        .from('payments')
        .select('total_amount')
        .eq('payment_status', 'completed')
        .gte('created_at', monthStart.toISOString());
      const monthlyRevenue = monthPayments?.reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;

      // Get previous month revenue for growth rate
      const prevMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const prevMonthEnd = new Date(now.getFullYear(), now.getMonth(), 1);
      const { data: prevMonthPayments } = await supabase
        .from('payments')
        .select('total_amount')
        .eq('payment_status', 'completed')
        .gte('created_at', prevMonthStart.toISOString())
        .lt('created_at', prevMonthEnd.toISOString());
      const prevMonthRevenue = prevMonthPayments?.reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;
      const growthRate = prevMonthRevenue > 0 ? ((monthlyRevenue - prevMonthRevenue) / prevMonthRevenue) * 100 : 0;

      // Revenue by payment type
      const appointmentRevenue = allPayments?.filter(p => p.payment_type === 'appointment').reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;
      const pharmacyOrderRevenue = allPayments?.filter(p => p.payment_type === 'pharmacy_order').reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;

      // For business types, we'll calculate based on all payments
      const hospitalRevenue = appointmentRevenue;
      const pharmacyRevenue = pharmacyOrderRevenue;

      // Calculate commission based on new model:
      // 10% for sessions/hospitals, 7% for pharmacy
      const sessionCommission = hospitalRevenue * 0.10;
      const pharmacyCommission = pharmacyRevenue * 0.07;
      const totalCommission = sessionCommission + pharmacyCommission;
      const totalProvidersShare = totalRevenue - totalCommission;

      setRevenueData({
        totalRevenue,
        platformCommission: totalCommission,
        providersShare: totalProvidersShare,
        monthlyRevenue,
        weeklyRevenue,
        todayRevenue,
        hospitalRevenue,
        pharmacyRevenue,
        sessionRevenue: appointmentRevenue,
        growthRate,
        pharmacyCommission,
        sessionCommission,
      });

      // Get monthly data for chart
      const months: MonthlyData[] = [];
      for (let i = 5; i >= 0; i--) {
        const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const nextMonth = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);

        const { data: monthData } = await supabase
          .from('payments')
          .select('total_amount')
          .eq('payment_status', 'completed')
          .gte('created_at', monthDate.toISOString())
          .lt('created_at', nextMonth.toISOString());

        const revenue = monthData?.reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;
        const commission = revenue * 0.09;

        const monthName = monthDate.toLocaleDateString('ar-SA', { month: 'short' });
        months.push({ month: monthName, revenue, commission });
      }
      setMonthlyData(months);

      // Get recent transactions
      const { data: transactions } = await supabase
        .from('payments')
        .select('id, total_amount, payment_type, created_at, payment_status')
        .order('created_at', { ascending: false })
        .limit(10);

      setRecentTransactions(
        (transactions || []).map(t => ({
          id: t.id,
          amount: Number(t.total_amount) || 0,
          type: t.payment_type || 'دفع',
          business_name: 'عميل',
          created_at: t.created_at,
          status: t.payment_status || 'completed',
        }))
      );

    } catch (error) {
      console.error('Error loading revenue data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadRevenueData();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  function formatDate(dateString: string) {
    return new Date(dateString).toLocaleDateString('ar-SA', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="التحليلات والتقارير" tabs={ANALYTICS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#10b981" />
          <Text style={styles.loadingText}>جاري تحميل تحليلات الإيرادات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  const maxMonthlyRevenue = Math.max(...monthlyData.map(m => m.revenue), 1);
  const totalBusinessRevenue = revenueData.hospitalRevenue + revenueData.pharmacyRevenue;
  const hospitalPercent = totalBusinessRevenue > 0 ? (revenueData.hospitalRevenue / totalBusinessRevenue) * 100 : 0;
  const pharmacyPercent = totalBusinessRevenue > 0 ? (revenueData.pharmacyRevenue / totalBusinessRevenue) * 100 : 0;

  return (
    <OwnerTabLayout title="التحليلات والتقارير" tabs={ANALYTICS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <Text style={styles.pageTitle}>تحليلات الإيرادات والعمولات</Text>

        <View style={styles.mainCard}>
          <DollarSign size={32} color="#10b981" strokeWidth={2} />
          <Text style={styles.mainValue}>{formatCurrency(revenueData.totalRevenue)}</Text>
          <Text style={styles.mainLabel}>إجمالي الإيرادات</Text>
        </View>

        <View style={styles.commissionSection}>
          <Text style={styles.sectionTitle}>توزيع العمولات (التطبيق مجاني)</Text>

          <View style={styles.commissionInfoBox}>
            <Text style={styles.commissionInfoText}>✅ التطبيق مجاني بالكامل للمستخدمين</Text>
            <Text style={styles.commissionInfoText}>📊 نظام العمولة على المعاملات:</Text>
          </View>

          <View style={styles.commissionCard}>
            <View style={styles.commissionRow}>
              <View style={[styles.commissionBadge, { backgroundColor: '#dbeafe' }]}>
                <Calendar size={20} color="#3b82f6" strokeWidth={2} />
              </View>
              <View style={styles.commissionInfo}>
                <Text style={styles.commissionLabel}>عمولة الجلسات والمستشفيات</Text>
                <Text style={styles.commissionValue}>{formatCurrency(revenueData.sessionCommission)}</Text>
                <View style={styles.percentBadge}>
                  <Text style={styles.percentText}>10%</Text>
                </View>
              </View>
            </View>
          </View>

          <View style={styles.commissionCard}>
            <View style={styles.commissionRow}>
              <View style={[styles.commissionBadge, { backgroundColor: '#dcfce7' }]}>
                <Pill size={20} color="#10b981" strokeWidth={2} />
              </View>
              <View style={styles.commissionInfo}>
                <Text style={styles.commissionLabel}>عمولة الصيدليات</Text>
                <Text style={styles.commissionValue}>{formatCurrency(revenueData.pharmacyCommission)}</Text>
                <View style={[styles.percentBadge, { backgroundColor: '#dcfce7' }]}>
                  <Text style={[styles.percentText, { color: '#10b981' }]}>7%</Text>
                </View>
              </View>
            </View>
          </View>

          <View style={styles.totalCommissionCard}>
            <View style={styles.commissionRow}>
              <View style={[styles.commissionBadge, { backgroundColor: '#fef3c7' }]}>
                <TrendingUp size={20} color="#f59e0b" strokeWidth={2} />
              </View>
              <View style={styles.commissionInfo}>
                <Text style={styles.commissionLabel}>إجمالي العمولة</Text>
                <Text style={styles.commissionValue}>{formatCurrency(revenueData.platformCommission)}</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.periodStatsGrid}>
          <View style={styles.periodCard}>
            <Calendar size={18} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.periodValue}>{formatCurrency(revenueData.todayRevenue)}</Text>
            <Text style={styles.periodLabel}>اليوم</Text>
          </View>

          <View style={styles.periodCard}>
            <Calendar size={18} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.periodValue}>{formatCurrency(revenueData.weeklyRevenue)}</Text>
            <Text style={styles.periodLabel}>هذا الأسبوع</Text>
          </View>

          <View style={styles.periodCard}>
            <Calendar size={18} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.periodValue}>{formatCurrency(revenueData.monthlyRevenue)}</Text>
            <Text style={styles.periodLabel}>هذا الشهر</Text>
          </View>

          <View style={styles.periodCard}>
            {revenueData.growthRate >= 0 ? (
              <ArrowUpRight size={18} color="#10b981" strokeWidth={2} />
            ) : (
              <ArrowDownRight size={18} color="#ef4444" strokeWidth={2} />
            )}
            <Text style={[styles.periodValue, { color: revenueData.growthRate >= 0 ? '#10b981' : '#ef4444' }]}>
              {Math.abs(revenueData.growthRate).toFixed(1)}%
            </Text>
            <Text style={styles.periodLabel}>معدل النمو</Text>
          </View>
        </View>

        <View style={styles.chartCard}>
          <View style={styles.chartHeader}>
            <TrendingUp size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.chartTitle}>الإيرادات الشهرية (آخر 6 أشهر)</Text>
          </View>
          <View style={styles.barChart}>
            {monthlyData.map((item, index) => {
              const barHeight = (item.revenue / maxMonthlyRevenue) * 100;
              return (
                <View key={index} style={styles.barContainer}>
                  <View style={styles.barWrapper}>
                    <View style={[styles.bar, { height: `${barHeight}%` }]} />
                  </View>
                  <Text style={styles.barValue}>{(item.revenue / 1000).toFixed(0)}k</Text>
                  <Text style={styles.barLabel}>{item.month}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.distributionCard}>
          <View style={styles.chartHeader}>
            <PieChart size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.chartTitle}>توزيع الإيرادات حسب نوع الشركة</Text>
          </View>

          <View style={styles.distributionRow}>
            <View style={styles.distributionItem}>
              <Building2 size={18} color="#3b82f6" strokeWidth={2} />
              <Text style={styles.distributionLabel}>المستشفيات</Text>
            </View>
            <Text style={styles.distributionPercent}>{hospitalPercent.toFixed(1)}%</Text>
          </View>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${hospitalPercent}%`, backgroundColor: '#3b82f6' }]} />
          </View>
          <Text style={styles.distributionValue}>{formatCurrency(revenueData.hospitalRevenue)}</Text>

          <View style={styles.distributionDivider} />

          <View style={styles.distributionRow}>
            <View style={styles.distributionItem}>
              <Pill size={18} color="#8b5cf6" strokeWidth={2} />
              <Text style={styles.distributionLabel}>الصيدليات</Text>
            </View>
            <Text style={styles.distributionPercent}>{pharmacyPercent.toFixed(1)}%</Text>
          </View>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${pharmacyPercent}%`, backgroundColor: '#8b5cf6' }]} />
          </View>
          <Text style={styles.distributionValue}>{formatCurrency(revenueData.pharmacyRevenue)}</Text>
        </View>

        <View style={styles.transactionsSection}>
          <Text style={styles.sectionTitle}>آخر المعاملات</Text>
          {recentTransactions.map((transaction) => (
            <View key={transaction.id} style={styles.transactionCard}>
              <View style={styles.transactionIcon}>
                <DollarSign size={16} color="#10b981" strokeWidth={2} />
              </View>
              <View style={styles.transactionInfo}>
                <Text style={styles.transactionType}>{transaction.type}</Text>
                <Text style={styles.transactionDate}>{formatDate(transaction.created_at)}</Text>
              </View>
              <View style={styles.transactionAmount}>
                <Text style={styles.transactionValue}>{formatCurrency(transaction.amount)}</Text>
                <Text style={styles.transactionCommission}>عمولة: {formatCurrency(transaction.amount * 0.10)}</Text>
              </View>
            </View>
          ))}
        </View>

      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  pageTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  mainCard: {
    backgroundColor: '#ffffff',
    padding: 24,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#d1fae5',
    alignItems: 'center',
    marginBottom: 20,
  },
  mainValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#10b981',
    marginTop: 12,
  },
  mainLabel: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  commissionSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  commissionCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  commissionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  commissionBadge: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  commissionInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  commissionLabel: {
    fontSize: 13,
    color: '#64748b',
    marginBottom: 4,
  },
  commissionInfoBox: {
    backgroundColor: '#eff6ff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  commissionInfoText: {
    fontSize: 13,
    color: '#1e40af',
    textAlign: 'right',
    marginBottom: 4,
  },
  totalCommissionCard: {
    backgroundColor: '#fffbeb',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#fef3c7',
    marginTop: 8,
  },
  commissionValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  percentBadge: {
    backgroundColor: '#d1fae5',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  percentText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#10b981',
  },
  periodStatsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  periodCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 8,
  },
  periodValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  periodLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'center',
  },
  chartCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  chartHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  barChart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 140,
    gap: 4,
  },
  barContainer: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  barWrapper: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-end',
  },
  bar: {
    width: '100%',
    backgroundColor: '#10b981',
    borderRadius: 4,
    minHeight: 4,
  },
  barValue: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  barLabel: {
    fontSize: 9,
    color: '#64748b',
    textAlign: 'center',
  },
  distributionCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  distributionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  distributionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  distributionLabel: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '600',
  },
  distributionPercent: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  progressBar: {
    height: 24,
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 4,
  },
  progressFill: {
    height: '100%',
  },
  distributionValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#64748b',
    textAlign: 'right',
    marginBottom: 16,
  },
  distributionDivider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginBottom: 16,
  },
  transactionsSection: {
    marginBottom: 20,
  },
  transactionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 8,
    gap: 12,
  },
  transactionIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: '#d1fae5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  transactionInfo: {
    flex: 1,
  },
  transactionType: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 2,
    textAlign: 'right',
  },
  transactionDate: {
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'right',
  },
  transactionAmount: {
    alignItems: 'flex-end',
  },
  transactionValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 2,
  },
  transactionCommission: {
    fontSize: 10,
    color: '#10b981',
    fontWeight: '600',
  },
});
