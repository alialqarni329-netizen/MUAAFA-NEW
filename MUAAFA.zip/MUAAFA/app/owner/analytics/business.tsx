import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Building2, Pill, TrendingUp, Users, CheckCircle, XCircle, Clock, DollarSign, Activity } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const ANALYTICS_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/analytics' },
  { name: 'revenue', label: 'الإيرادات', path: '/owner/analytics/revenue' },
  { name: 'subscriptions', label: 'الاشتراكات', path: '/owner/analytics/subscriptions' },
  { name: 'business', label: 'الشركات', path: '/owner/analytics/business' },
  { name: 'usage', label: 'الاستخدام', path: '/owner/analytics/usage' },
  { name: 'export-pdf', label: 'تصدير PDF', path: '/owner/analytics/export-pdf' },
  { name: 'export-excel', label: 'تصدير Excel', path: '/owner/analytics/export-excel' },
];

interface BusinessAnalytics {
  totalBusinesses: number;
  activeBusinesses: number;
  pendingApproval: number;
  suspendedBusinesses: number;
  totalHospitals: number;
  totalPharmacies: number;
  totalInsurance: number;
  newThisMonth: number;
}

interface BusinessRevenue {
  business_name: string;
  business_type: string;
  total_revenue: number;
  transaction_count: number;
}

interface MonthlyRegistrations {
  month: string;
  hospitals: number;
  pharmacies: number;
  insurance: number;
}

export default function BusinessAnalytics() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [analytics, setAnalytics] = useState<BusinessAnalytics>({
    totalBusinesses: 0,
    activeBusinesses: 0,
    pendingApproval: 0,
    suspendedBusinesses: 0,
    totalHospitals: 0,
    totalPharmacies: 0,
    totalInsurance: 0,
    newThisMonth: 0,
  });
  const [topBusinesses, setTopBusinesses] = useState<BusinessRevenue[]>([]);
  const [monthlyRegs, setMonthlyRegs] = useState<MonthlyRegistrations[]>([]);

  useEffect(() => {
    loadBusinessAnalytics();
  }, []);

  async function loadBusinessAnalytics() {
    try {
      const now = new Date();
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

      // Get all businesses
      const { count: totalCount } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true });

      // Get active businesses
      const { count: activeCount } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Get pending businesses
      const { count: pendingCount } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      // Get suspended businesses
      const { count: suspendedCount } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'suspended');

      // Get by business type
      const { count: hospitalsCount } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true })
        .eq('business_type', 'hospital');

      const { count: pharmaciesCount } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true })
        .eq('business_type', 'pharmacy');

      const { count: insuranceCount } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true })
        .eq('business_type', 'insurance');

      // Get new this month
      const { count: newThisMonth } = await supabase
        .from('business_accounts')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', monthStart.toISOString());

      setAnalytics({
        totalBusinesses: totalCount || 0,
        activeBusinesses: activeCount || 0,
        pendingApproval: pendingCount || 0,
        suspendedBusinesses: suspendedCount || 0,
        totalHospitals: hospitalsCount || 0,
        totalPharmacies: pharmaciesCount || 0,
        totalInsurance: insuranceCount || 0,
        newThisMonth: newThisMonth || 0,
      });

      // Get top businesses by revenue (mock data for now)
      const { data: businesses } = await supabase
        .from('business_accounts')
        .select('id, business_name, business_type')
        .eq('status', 'active')
        .limit(5);

      const topBusiness: BusinessRevenue[] = [];
      for (const business of businesses || []) {
        // For now, we'll use mock data since payments don't have business_id
        // In a real scenario, you'd need to join through appointments or other tables
        const mockRevenue = Math.random() * 50000 + 10000;
        const mockTransactions = Math.floor(Math.random() * 100) + 20;

        topBusiness.push({
          business_name: business.business_name || 'شركة',
          business_type: business.business_type || 'other',
          total_revenue: mockRevenue,
          transaction_count: mockTransactions,
        });
      }
      setTopBusinesses(topBusiness.sort((a, b) => b.total_revenue - a.total_revenue));

      // Get monthly registrations (last 6 months)
      const regs: MonthlyRegistrations[] = [];
      for (let i = 5; i >= 0; i--) {
        const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const nextMonth = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);

        const { count: hospitals } = await supabase
          .from('business_accounts')
          .select('*', { count: 'exact', head: true })
          .eq('business_type', 'hospital')
          .gte('created_at', monthDate.toISOString())
          .lt('created_at', nextMonth.toISOString());

        const { count: pharmacies } = await supabase
          .from('business_accounts')
          .select('*', { count: 'exact', head: true })
          .eq('business_type', 'pharmacy')
          .gte('created_at', monthDate.toISOString())
          .lt('created_at', nextMonth.toISOString());

        const { count: insurance } = await supabase
          .from('business_accounts')
          .select('*', { count: 'exact', head: true })
          .eq('business_type', 'insurance')
          .gte('created_at', monthDate.toISOString())
          .lt('created_at', nextMonth.toISOString());

        const monthName = monthDate.toLocaleDateString('ar-SA', { month: 'short' });
        regs.push({
          month: monthName,
          hospitals: hospitals || 0,
          pharmacies: pharmacies || 0,
          insurance: insurance || 0,
        });
      }
      setMonthlyRegs(regs);

    } catch (error) {
      console.error('Error loading business analytics:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadBusinessAnalytics();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  function getBusinessTypeIcon(type: string) {
    switch (type) {
      case 'hospital':
        return <Building2 size={16} color="#3b82f6" strokeWidth={2} />;
      case 'pharmacy':
        return <Pill size={16} color="#8b5cf6" strokeWidth={2} />;
      default:
        return <Activity size={16} color="#10b981" strokeWidth={2} />;
    }
  }

  function getBusinessTypeLabel(type: string) {
    switch (type) {
      case 'hospital':
        return 'مستشفى';
      case 'pharmacy':
        return 'صيدلية';
      case 'insurance':
        return 'تأمين';
      default:
        return 'أخرى';
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="التحليلات والتقارير" tabs={ANALYTICS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل تحليلات الشركات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  const maxRegValue = Math.max(
    ...monthlyRegs.map(m => Math.max(m.hospitals, m.pharmacies, m.insurance)),
    1
  );

  return (
    <OwnerTabLayout title="التحليلات والتقارير" tabs={ANALYTICS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <Text style={styles.pageTitle}>تحليلات الشركات</Text>

        <View style={styles.mainStatsGrid}>
          <View style={[styles.mainStatCard, { backgroundColor: '#f3e8ff', borderColor: '#8b5cf6' }]}>
            <Building2 size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.mainStatValue}>{analytics.totalBusinesses.toLocaleString('ar-SA')}</Text>
            <Text style={styles.mainStatLabel}>إجمالي الشركات</Text>
          </View>

          <View style={[styles.mainStatCard, { backgroundColor: '#d1fae5', borderColor: '#10b981' }]}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.mainStatValue}>{analytics.activeBusinesses.toLocaleString('ar-SA')}</Text>
            <Text style={styles.mainStatLabel}>شركات نشطة</Text>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Building2 size={18} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{analytics.totalHospitals.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>مستشفيات</Text>
          </View>

          <View style={styles.statCard}>
            <Pill size={18} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{analytics.totalPharmacies.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>صيدليات</Text>
          </View>

          <View style={styles.statCard}>
            <Activity size={18} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{analytics.totalInsurance.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>شركات تأمين</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={18} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{analytics.newThisMonth.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>جديدة هذا الشهر</Text>
          </View>
        </View>

        <View style={styles.statusSection}>
          <Text style={styles.sectionTitle}>حالة الشركات</Text>

          <View style={styles.statusCard}>
            <View style={styles.statusRow}>
              <View style={styles.statusItem}>
                <CheckCircle size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.statusLabel}>نشطة</Text>
              </View>
              <Text style={styles.statusValue}>{analytics.activeBusinesses}</Text>
            </View>

            <View style={styles.statusRow}>
              <View style={styles.statusItem}>
                <Clock size={18} color="#f59e0b" strokeWidth={2} />
                <Text style={styles.statusLabel}>قيد الموافقة</Text>
              </View>
              <Text style={styles.statusValue}>{analytics.pendingApproval}</Text>
            </View>

            <View style={styles.statusRow}>
              <View style={styles.statusItem}>
                <XCircle size={18} color="#ef4444" strokeWidth={2} />
                <Text style={styles.statusLabel}>موقوفة</Text>
              </View>
              <Text style={styles.statusValue}>{analytics.suspendedBusinesses}</Text>
            </View>
          </View>
        </View>

        <View style={styles.chartCard}>
          <View style={styles.chartHeader}>
            <TrendingUp size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.chartTitle}>التسجيلات الشهرية (آخر 6 أشهر)</Text>
          </View>
          <View style={styles.regChart}>
            {monthlyRegs.map((item, index) => {
              const hospitalsHeight = (item.hospitals / maxRegValue) * 100;
              const pharmaciesHeight = (item.pharmacies / maxRegValue) * 100;
              const insuranceHeight = (item.insurance / maxRegValue) * 100;
              return (
                <View key={index} style={styles.regContainer}>
                  <View style={styles.regBars}>
                    <View style={[styles.regBar, { height: `${hospitalsHeight}%`, backgroundColor: '#3b82f6' }]} />
                    <View style={[styles.regBar, { height: `${pharmaciesHeight}%`, backgroundColor: '#8b5cf6' }]} />
                    <View style={[styles.regBar, { height: `${insuranceHeight}%`, backgroundColor: '#10b981' }]} />
                  </View>
                  <Text style={styles.regLabel}>{item.month}</Text>
                </View>
              );
            })}
          </View>
          <View style={styles.legend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#3b82f6' }]} />
              <Text style={styles.legendText}>مستشفيات</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#8b5cf6' }]} />
              <Text style={styles.legendText}>صيدليات</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#10b981' }]} />
              <Text style={styles.legendText}>تأمين</Text>
            </View>
          </View>
        </View>

        <View style={styles.topSection}>
          <Text style={styles.sectionTitle}>أعلى الشركات بالإيرادات</Text>
          {topBusinesses.map((business, index) => (
            <View key={index} style={styles.businessCard}>
              <View style={styles.businessRank}>
                <Text style={styles.rankNumber}>{index + 1}</Text>
              </View>
              <View style={styles.businessInfo}>
                <View style={styles.businessHeader}>
                  {getBusinessTypeIcon(business.business_type)}
                  <Text style={styles.businessName}>{business.business_name}</Text>
                </View>
                <Text style={styles.businessType}>{getBusinessTypeLabel(business.business_type)}</Text>
              </View>
              <View style={styles.businessStats}>
                <Text style={styles.businessRevenue}>{formatCurrency(business.total_revenue)}</Text>
                <Text style={styles.businessTransactions}>{business.transaction_count} معاملة</Text>
              </View>
            </View>
          ))}
        </View>

      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  pageTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  mainStatsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  mainStatCard: {
    flex: 1,
    padding: 20,
    borderRadius: 16,
    borderWidth: 2,
    alignItems: 'center',
    gap: 8,
  },
  mainStatValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  mainStatLabel: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'center',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 8,
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'center',
  },
  statusSection: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  statusCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusLabel: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '600',
  },
  statusValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  chartCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  chartHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  regChart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 140,
    marginBottom: 16,
  },
  regContainer: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  regBars: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    width: '100%',
    gap: 2,
  },
  regBar: {
    width: 10,
    borderRadius: 3,
    minHeight: 4,
  },
  regLabel: {
    fontSize: 9,
    color: '#64748b',
    textAlign: 'center',
  },
  legend: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
    flexWrap: 'wrap',
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    fontSize: 11,
    color: '#64748b',
  },
  topSection: {
    marginBottom: 16,
  },
  businessCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 10,
    gap: 12,
  },
  businessRank: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  rankNumber: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#64748b',
  },
  businessInfo: {
    flex: 1,
  },
  businessHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 2,
  },
  businessName: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  businessType: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'right',
  },
  businessStats: {
    alignItems: 'flex-end',
  },
  businessRevenue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#10b981',
    marginBottom: 2,
  },
  businessTransactions: {
    fontSize: 10,
    color: '#64748b',
  },
});
