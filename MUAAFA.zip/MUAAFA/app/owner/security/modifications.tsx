import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Edit, User, Clock, FileEdit } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SECURITY_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/security' },
  { name: 'failed-logins', label: 'محاولات فاشلة', path: '/owner/security/failed-logins' },
  { name: 'ip-restrictions', label: 'تقييد IP', path: '/owner/security/ip-restrictions' },
  { name: 'sessions', label: 'الجلسات', path: '/owner/security/session-management' },
  { name: 'modifications', label: 'التعديلات', path: '/owner/security/modifications' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/security/permissions' },
];

interface AuditLog {
  id: string;
  event_type: string;
  event_description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  resolved: boolean;
  resolved_at?: string;
  resolved_by?: string;
  metadata?: any;
  created_at: string;
}

export default function Modifications() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modifications, setModifications] = useState<AuditLog[]>([]);
  const [stats, setStats] = useState({ total: 0, today: 0, critical: 0, unresolved: 0 });

  useEffect(() => {
    loadModifications();
  }, []);

  async function loadModifications() {
    try {
      const { data, error } = await supabase
        .from('security_audit_log')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;

      const logs = data || [];
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      const todayCount = logs.filter(l => new Date(l.created_at) >= today).length;
      const criticalCount = logs.filter(l => l.severity === 'critical').length;
      const unresolvedCount = logs.filter(l => !l.resolved).length;

      setModifications(logs);
      setStats({
        total: logs.length,
        today: todayCount,
        critical: criticalCount,
        unresolved: unresolvedCount
      });
    } catch (error) {
      console.error('Error loading modifications:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadModifications();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل سجل التعديلات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#f3e8ff' }]}>
            <Edit size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي السجلات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Clock size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.today.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>اليوم</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <FileEdit size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.critical.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>حرجة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fecaca' }]}>
            <AlertTriangle size={20} color="#dc2626" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.unresolved.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>غير محلولة</Text>
          </View>
        </View>
        <Text style={styles.sectionTitle}>سجل الأمان والتعديلات</Text>
        {modifications.length > 0 ? (
          modifications.map((mod) => {
            const severityColor =
              mod.severity === 'critical' ? '#dc2626' :
              mod.severity === 'high' ? '#ef4444' :
              mod.severity === 'medium' ? '#f59e0b' :
              '#3b82f6';
            const severityBg =
              mod.severity === 'critical' ? '#fee2e2' :
              mod.severity === 'high' ? '#fecaca' :
              mod.severity === 'medium' ? '#fef3c7' :
              '#dbeafe';
            return (
            <View key={mod.id} style={styles.modCard}>
              <View style={styles.modHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.modAction}>{mod.event_type || 'حدث'}</Text>
                  {mod.event_description && <Text style={styles.modDescription}>{mod.event_description}</Text>}
                </View>
                <View style={[styles.severityBadge, { backgroundColor: severityBg }]}>
                  <Text style={[styles.severityText, { color: severityColor }]}>
                    {mod.severity === 'critical' ? 'حرج' :
                     mod.severity === 'high' ? 'عالي' :
                     mod.severity === 'medium' ? 'متوسط' :
                     'منخفض'}
                  </Text>
                </View>
              </View>
              <View style={styles.modDetails}>
                <View style={styles.detailRow}>
                  <Clock size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>
                    {new Date(mod.created_at).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </View>
                {!mod.resolved ? (
                  <View style={[styles.statusBadge, { backgroundColor: '#fee2e2' }]}>
                    <Text style={[styles.statusText, { color: '#ef4444' }]}>غير محلولة</Text>
                  </View>
                ) : (
                  <View style={[styles.statusBadge, { backgroundColor: '#d1fae5' }]}>
                    <Text style={[styles.statusText, { color: '#10b981' }]}>محلولة</Text>
                  </View>
                )}
              </View>
            </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Edit size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد سجلات</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 12, textAlign: 'right' },
  modCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  modHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 12 },
  modAction: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right' },
  modDescription: { fontSize: 12, color: '#64748b', marginTop: 4, textAlign: 'right' },
  severityBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  severityText: { fontSize: 11, fontWeight: '600' },
  modDetails: { gap: 8 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  detailText: { fontSize: 13, color: '#64748b', textAlign: 'right' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, alignSelf: 'flex-start' },
  statusText: { fontSize: 11, fontWeight: '600' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
