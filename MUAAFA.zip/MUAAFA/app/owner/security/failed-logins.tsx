import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { ShieldAlert, AlertTriangle, User, MapPin, Clock, Search, TrendingUp } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SECURITY_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/security' },
  { name: 'failed-logins', label: 'محاولات فاشلة', path: '/owner/security/failed-logins' },
  { name: 'ip-restrictions', label: 'تقييد IP', path: '/owner/security/ip-restrictions' },
  { name: 'sessions', label: 'الجلسات', path: '/owner/security/session-management' },
  { name: 'modifications', label: 'التعديلات', path: '/owner/security/modifications' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/security/permissions' },
];

interface FailedLoginAttempt {
  id: string;
  user_email: string;
  ip_address: string;
  user_agent?: string;
  reason?: string;
  attempt_count: number;
  last_attempted_at: string;
  created_at: string;
}

export default function FailedLogins() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [failedAttempts, setFailedAttempts] = useState<FailedLoginAttempt[]>([]);
  const [stats, setStats] = useState({ total: 0, today: 0, thisWeek: 0, blocked: 0, suspicious: 0 });

  useEffect(() => {
    loadFailedLogins();
  }, []);

  async function loadFailedLogins() {
    try {
      // Fetch all failed login attempts
      const { data: attempts, error: attemptsError } = await supabase
        .from('failed_login_attempts')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (attemptsError) throw attemptsError;

      // Calculate statistics
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);

      const todayAttempts = (attempts || []).filter(a => new Date(a.created_at) >= today);
      const weekAttempts = (attempts || []).filter(a => new Date(a.created_at) >= weekAgo);
      const suspiciousAttempts = (attempts || []).filter(a => a.attempt_count >= 5);

      // Get blocked IPs count
      const { count: blockedCount } = await supabase
        .from('ip_restrictions')
        .select('*', { count: 'exact', head: true })
        .eq('type', 'block');

      setFailedAttempts(attempts || []);
      setStats({
        total: attempts?.length || 0,
        today: todayAttempts.length,
        thisWeek: weekAttempts.length,
        blocked: blockedCount || 0,
        suspicious: suspiciousAttempts.length
      });
    } catch (error) {
      console.error('Error loading failed logins:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadFailedLogins();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل محاولات الدخول الفاشلة...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <ShieldAlert size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي المحاولات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <AlertTriangle size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.today.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>اليوم</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#f3e8ff' }]}>
            <TrendingUp size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.suspicious.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>مريبة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <ShieldAlert size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.blocked.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>IP محظور</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput style={styles.searchInput} placeholder="البحث في محاولات الدخول..." placeholderTextColor="#94a3b8" value={searchQuery} onChangeText={setSearchQuery} textAlign="right" />
        </View>

        <Text style={styles.sectionTitle}>محاولات الدخول الفاشلة</Text>

        {failedAttempts.length > 0 ? (
          failedAttempts
            .filter(attempt =>
              !searchQuery ||
              attempt.user_email.toLowerCase().includes(searchQuery.toLowerCase()) ||
              attempt.ip_address.includes(searchQuery)
            )
            .map((attempt) => (
            <View key={attempt.id} style={styles.attemptCard}>
              <View style={styles.attemptHeader}>
                <View style={styles.attemptInfo}>
                  <User size={18} color="#ef4444" strokeWidth={2} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.attemptEmail}>{attempt.user_email || 'بريد غير معروف'}</Text>
                    {attempt.attempt_count > 1 && (
                      <Text style={styles.attemptCount}>عدد المحاولات: {attempt.attempt_count}</Text>
                    )}
                  </View>
                </View>
                <View style={[styles.dangerBadge, attempt.attempt_count >= 5 ? { backgroundColor: '#fee2e2' } : { backgroundColor: '#fef3c7' }]}>
                  <AlertTriangle size={14} color={attempt.attempt_count >= 5 ? '#ef4444' : '#f59e0b'} strokeWidth={2} />
                  <Text style={[styles.dangerText, attempt.attempt_count >= 5 ? { color: '#ef4444' } : { color: '#f59e0b' }]}>
                    {attempt.attempt_count >= 5 ? 'مريب' : 'فشل'}
                  </Text>
                </View>
              </View>
              <View style={styles.attemptDetails}>
                <View style={styles.detailRow}>
                  <MapPin size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>IP: {attempt.ip_address || 'غير متوفر'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Clock size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>
                    {new Date(attempt.created_at).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </View>
                {attempt.last_attempted_at && (
                  <View style={styles.detailRow}>
                    <Clock size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailText}>آخر محاولة: {new Date(attempt.last_attempted_at).toLocaleTimeString('ar-SA')}</Text>
                  </View>
                )}
              </View>
              {attempt.reason && (
                <Text style={styles.attemptReason}>{attempt.reason}</Text>
              )}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <ShieldAlert size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد محاولات دخول فاشلة</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 20, gap: 8, borderWidth: 1, borderColor: '#e2e8f0' },
  searchInput: { flex: 1, fontSize: 14, color: '#0f172a' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 12, textAlign: 'right' },
  attemptCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#fee2e2' },
  attemptHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  attemptInfo: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
  attemptEmail: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right' },
  attemptCount: { fontSize: 12, color: '#64748b', marginTop: 4 },
  dangerBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  dangerText: { fontSize: 11, fontWeight: '600' },
  attemptDetails: { gap: 8 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  detailText: { fontSize: 13, color: '#64748b', textAlign: 'right' },
  attemptReason: { fontSize: 13, color: '#ef4444', marginTop: 8, padding: 8, backgroundColor: '#fef2f2', borderRadius: 8, textAlign: 'right' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
