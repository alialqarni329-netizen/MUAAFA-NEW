import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Shield, User, CheckCircle, XCircle, Plus } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SECURITY_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/security' },
  { name: 'failed-logins', label: 'محاولات فاشلة', path: '/owner/security/failed-logins' },
  { name: 'ip-restrictions', label: 'تقييد IP', path: '/owner/security/ip-restrictions' },
  { name: 'sessions', label: 'الجلسات', path: '/owner/security/session-management' },
  { name: 'modifications', label: 'التعديلات', path: '/owner/security/modifications' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/security/permissions' },
];

interface Permission {
  id: string;
  user_id?: string;
  camera_permission?: boolean;
  location_permission?: boolean;
  notifications_permission?: boolean;
  photos_permission?: boolean;
  camera_granted_at?: string;
  location_granted_at?: string;
  notifications_granted_at?: string;
  photos_granted_at?: string;
  created_at: string;
  updated_at: string;
}

interface BusinessPermission {
  id: string;
  business_id: string;
  max_employees?: number;
  max_orders_per_month?: number;
  can_use_ai_bot?: boolean;
  can_access_analytics?: boolean;
  can_export_data?: boolean;
  can_access_api?: boolean;
  priority_support?: boolean;
  created_at: string;
}

export default function Permissions() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [permissions, setPermissions] = useState<(Permission | BusinessPermission)[]>([]);
  const [stats, setStats] = useState({ total: 0, enabled: 0, disabled: 0, business: 0 });

  useEffect(() => {
    loadPermissions();
  }, []);

  async function loadPermissions() {
    try {
      // Load user permissions
      const { data: userPerms, error: userError } = await supabase
        .from('user_permissions')
        .select('*')
        .order('created_at', { ascending: false });

      if (userError) throw userError;

      // Load business permissions
      const { data: businessPerms, error: businessError } = await supabase
        .from('business_permissions')
        .select('*')
        .order('created_at', { ascending: false });

      if (businessError) throw businessError;

      const allPermissions = [...(userPerms || []), ...(businessPerms || [])];
      const enabledCount = (userPerms || []).filter(p =>
        p.camera_permission || p.location_permission || p.notifications_permission || p.photos_permission
      ).length;
      const disabledCount = (userPerms || []).length - enabledCount;

      setPermissions(allPermissions);
      setStats({
        total: allPermissions.length,
        enabled: enabledCount,
        disabled: disabledCount,
        business: (businessPerms || []).length
      });
    } catch (error) {
      console.error('Error loading permissions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadPermissions();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الصلاحيات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Shield size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الصلاحيات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <CheckCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.enabled.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>مفعلة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <XCircle size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.disabled.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>معطلة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Shield size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.business.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>تجارية</Text>
          </View>
        </View>
        <View style={styles.header}>
          <Text style={styles.sectionTitle}>الصلاحيات الأمنية</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.addButtonText}>إضافة</Text>
          </TouchableOpacity>
        </View>
        {permissions.length > 0 ? (
          permissions.map((perm: any) => {
            const isUserPermission = 'camera_permission' in perm;
            return (
            <View key={perm.id} style={styles.permCard}>
              <View style={styles.permHeader}>
                <View style={styles.permInfo}>
                  <User size={18} color={isUserPermission ? '#3b82f6' : '#f59e0b'} strokeWidth={2} />
                  <Text style={styles.permName}>
                    {isUserPermission ? 'صلاحيات المستخدم' : 'صلاحيات الأعمال'}
                  </Text>
                </View>
                <CheckCircle size={18} color="#10b981" strokeWidth={2} />
              </View>
              {isUserPermission ? (
                <View style={styles.permsList}>
                  {perm.camera_permission && <Text style={styles.permItem}>الكاميرا</Text>}
                  {perm.location_permission && <Text style={styles.permItem}>الموقع</Text>}
                  {perm.notifications_permission && <Text style={styles.permItem}>الإشعارات</Text>}
                  {perm.photos_permission && <Text style={styles.permItem}>الصور</Text>}
                </View>
              ) : (
                <View style={styles.permsList}>
                  {perm.can_use_ai_bot && <Text style={styles.permItem}>استخدام AI Bot</Text>}
                  {perm.can_access_analytics && <Text style={styles.permItem}>الوصول للتحليلات</Text>}
                  {perm.can_export_data && <Text style={styles.permItem}>تصدير البيانات</Text>}
                  {perm.can_access_api && <Text style={styles.permItem}>الوصول للـ API</Text>}
                  {perm.priority_support && <Text style={styles.permItem}>الدعم الأولوي</Text>}
                </View>
              )}
              <Text style={styles.permDate}>
                منذ: {new Date(perm.created_at).toLocaleDateString('ar-SA')}
              </Text>
            </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Shield size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد صلاحيات</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', textAlign: 'right' },
  addButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#3b82f6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, gap: 6 },
  addButtonText: { fontSize: 14, fontWeight: '600', color: '#ffffff' },
  permCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  permHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  permInfo: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
  permName: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right', flex: 1 },
  permsList: { marginVertical: 12, paddingLeft: 24, gap: 6 },
  permItem: { fontSize: 13, color: '#64748b', textAlign: 'right' },
  permDate: { fontSize: 12, color: '#94a3b8', marginTop: 8, textAlign: 'right' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
