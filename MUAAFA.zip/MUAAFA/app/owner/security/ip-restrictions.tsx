import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Shield, Globe, Ban, Plus, Search } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SECURITY_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/security' },
  { name: 'failed-logins', label: 'محاولات فاشلة', path: '/owner/security/failed-logins' },
  { name: 'ip-restrictions', label: 'تقييد IP', path: '/owner/security/ip-restrictions' },
  { name: 'sessions', label: 'الجلسات', path: '/owner/security/session-management' },
  { name: 'modifications', label: 'التعديلات', path: '/owner/security/modifications' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/security/permissions' },
];

interface IPRestriction {
  id: string;
  ip_address: string;
  type: 'allow' | 'block';
  reason?: string;
  expires_at?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export default function IPRestrictions() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [restrictions, setRestrictions] = useState<IPRestriction[]>([]);
  const [stats, setStats] = useState({ total: 0, blocked: 0, allowed: 0, temporary: 0, active: 0 });

  useEffect(() => {
    loadRestrictions();
  }, []);

  async function loadRestrictions() {
    try {
      const { data, error } = await supabase
        .from('ip_restrictions')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const restrictions = data || [];
      const blockedCount = restrictions.filter(r => r.type === 'block').length;
      const allowedCount = restrictions.filter(r => r.type === 'allow').length;
      const temporaryCount = restrictions.filter(r => r.expires_at && new Date(r.expires_at) > new Date()).length;
      const activeCount = restrictions.filter(r => !r.expires_at || new Date(r.expires_at) > new Date()).length;

      setRestrictions(restrictions);
      setStats({
        total: restrictions.length,
        blocked: blockedCount,
        allowed: allowedCount,
        temporary: temporaryCount,
        active: activeCount
      });
    } catch (error) {
      console.error('Error loading IP restrictions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadRestrictions();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل قيود IP...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Globe size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>نشطة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <Ban size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.blocked.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>محظور</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <Shield size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.allowed.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>مسموح</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Globe size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.temporary.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>مؤقت</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput style={styles.searchInput} placeholder="البحث في قيود IP..." placeholderTextColor="#94a3b8" value={searchQuery} onChangeText={setSearchQuery} textAlign="right" />
        </View>

        <View style={styles.header}>
          <Text style={styles.sectionTitle}>قيود عناوين IP</Text>
          <TouchableOpacity style={styles.addButton}>
            <Plus size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.addButtonText}>إضافة قيد</Text>
          </TouchableOpacity>
        </View>

        {restrictions.length > 0 ? (
          restrictions
            .filter(r =>
              !searchQuery ||
              r.ip_address.includes(searchQuery) ||
              (r.reason && r.reason.toLowerCase().includes(searchQuery.toLowerCase()))
            )
            .map((restriction) => {
            const isExpired = restriction.expires_at && new Date(restriction.expires_at) < new Date();
            const typeColor = restriction.type === 'block' ? '#ef4444' : '#10b981';
            return (
            <View key={restriction.id} style={styles.restrictionCard}>
              <View style={styles.restrictionHeader}>
                <View style={styles.restrictionInfo}>
                  <Globe size={18} color={isExpired ? '#cbd5e1' : typeColor} strokeWidth={2} />
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.restrictionIP, isExpired && { color: '#cbd5e1' }]}>{restriction.ip_address}</Text>
                    {isExpired && <Text style={styles.expiredText}>منتهية الصلاحية</Text>}
                  </View>
                </View>
                <View style={[styles.typeBadge, { backgroundColor: typeColor + '20' }]}>
                  <Text style={[styles.typeText, { color: typeColor }]}>
                    {restriction.type === 'block' ? 'محظور' : 'مسموح'}
                  </Text>
                </View>
              </View>
              {restriction.reason && (
                <Text style={styles.restrictionReason}>{restriction.reason}</Text>
              )}
              <View style={styles.dateContainer}>
                <Text style={styles.restrictionDate}>
                  تم الإضافة: {new Date(restriction.created_at).toLocaleDateString('ar-SA')}
                </Text>
                {restriction.expires_at && (
                  <Text style={[styles.restrictionDate, isExpired && { color: '#ef4444' }]}>
                    الانتهاء: {new Date(restriction.expires_at).toLocaleDateString('ar-SA')}
                  </Text>
                )}
              </View>
            </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Globe size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد قيود IP</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 20, gap: 8, borderWidth: 1, borderColor: '#e2e8f0' },
  searchInput: { flex: 1, fontSize: 14, color: '#0f172a' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', textAlign: 'right' },
  addButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#3b82f6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, gap: 6 },
  addButtonText: { fontSize: 14, fontWeight: '600', color: '#ffffff' },
  restrictionCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  restrictionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  restrictionInfo: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
  restrictionIP: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right' },
  expiredText: { fontSize: 11, color: '#ef4444', marginTop: 4 },
  typeBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12 },
  typeText: { fontSize: 11, fontWeight: '600' },
  restrictionReason: { fontSize: 13, color: '#64748b', marginBottom: 8, textAlign: 'right' },
  dateContainer: { gap: 4 },
  restrictionDate: { fontSize: 12, color: '#94a3b8', textAlign: 'right' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
