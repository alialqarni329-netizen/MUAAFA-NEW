import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Shield, AlertTriangle, CheckCircle, TrendingUp, Activity, Lock, Eye, Zap } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SECURITY_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/security' },
  { name: 'failed-logins', label: 'محاولات فاشلة', path: '/owner/security/failed-logins' },
  { name: 'ip-restrictions', label: 'تقييد IP', path: '/owner/security/ip-restrictions' },
  { name: 'sessions', label: 'الجلسات', path: '/owner/security/session-management' },
  { name: 'modifications', label: 'التعديلات', path: '/owner/security/modifications' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/security/permissions' },
];

export default function SecurityOverview() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [metrics, setMetrics] = useState({
    failedLogins: 0,
    activeSessions: 0,
    blockedIPs: 0,
    unreadAuditLogs: 0,
    criticalIssues: 0,
    permissionsEnabled: 0,
    systemHealth: 0
  });

  useEffect(() => {
    loadSecurityMetrics();
  }, []);

  async function loadSecurityMetrics() {
    try {
      // Failed login attempts today
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      const { count: failedCount } = await supabase
        .from('failed_login_attempts')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', today.toISOString());

      // Active sessions
      const { count: activeSessionsCount } = await supabase
        .from('user_sessions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Blocked IPs
      const { count: blockedIPsCount } = await supabase
        .from('ip_restrictions')
        .select('*', { count: 'exact', head: true })
        .eq('type', 'block');

      // Unresolved audit logs
      const { count: unreadLogsCount } = await supabase
        .from('security_audit_log')
        .select('*', { count: 'exact', head: true })
        .eq('resolved', false);

      // Critical issues
      const { count: criticalCount } = await supabase
        .from('security_audit_log')
        .select('*', { count: 'exact', head: true })
        .eq('severity', 'critical')
        .eq('resolved', false);

      // Enabled permissions
      const { count: enabledPermsCount } = await supabase
        .from('user_permissions')
        .select('*', { count: 'exact', head: true })
        .or('camera_permission.eq.true,location_permission.eq.true,notifications_permission.eq.true,photos_permission.eq.true');

      // Calculate system health
      const health = 100 - (failedCount || 0) - (criticalCount || 0) * 5;

      setMetrics({
        failedLogins: failedCount || 0,
        activeSessions: activeSessionsCount || 0,
        blockedIPs: blockedIPsCount || 0,
        unreadAuditLogs: unreadLogsCount || 0,
        criticalIssues: criticalCount || 0,
        permissionsEnabled: enabledPermsCount || 0,
        systemHealth: Math.max(0, Math.min(100, health))
      });
    } catch (error) {
      console.error('Error loading security metrics:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadSecurityMetrics();
  }

  const getHealthColor = (health: number) => {
    if (health >= 80) return '#10b981';
    if (health >= 60) return '#f59e0b';
    return '#ef4444';
  };

  const QuickLink = ({ icon: Icon, label, path }: any) => (
    <TouchableOpacity
      style={styles.quickLink}
      onPress={() => router.push(path)}
    >
      <Icon size={24} color="#3b82f6" strokeWidth={2} />
      <Text style={styles.quickLinkLabel}>{label}</Text>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل ملخص الأمان...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.healthCard}>
          <View style={styles.healthHeader}>
            <View>
              <Text style={styles.healthLabel}>صحة النظام</Text>
              <Text style={[styles.healthValue, { color: getHealthColor(metrics.systemHealth) }]}>
                {metrics.systemHealth}%
              </Text>
            </View>
            <View style={[styles.healthCircle, { borderColor: getHealthColor(metrics.systemHealth) }]}>
              <Text style={[styles.healthPercent, { color: getHealthColor(metrics.systemHealth) }]}>
                {metrics.systemHealth}
              </Text>
            </View>
          </View>
          <View style={styles.healthBar}>
            <View
              style={[
                styles.healthBarFill,
                { width: `${metrics.systemHealth}%`, backgroundColor: getHealthColor(metrics.systemHealth) }
              ]}
            />
          </View>
        </View>

        <Text style={styles.sectionTitle}>المقاييس الرئيسية</Text>
        <View style={styles.metricsGrid}>
          <View style={[styles.metricCard, { backgroundColor: '#fee2e2' }]}>
            <AlertTriangle size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.metricValue}>{metrics.failedLogins}</Text>
            <Text style={styles.metricLabel}>محاولات فاشلة</Text>
          </View>
          <View style={[styles.metricCard, { backgroundColor: '#d1fae5' }]}>
            <Activity size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.metricValue}>{metrics.activeSessions}</Text>
            <Text style={styles.metricLabel}>جلسات نشطة</Text>
          </View>
          <View style={[styles.metricCard, { backgroundColor: '#dbeafe' }]}>
            <Lock size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.metricValue}>{metrics.blockedIPs}</Text>
            <Text style={styles.metricLabel}>عناوين محظورة</Text>
          </View>
          <View style={[styles.metricCard, { backgroundColor: '#fef3c7' }]}>
            <AlertTriangle size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.metricValue}>{metrics.criticalIssues}</Text>
            <Text style={styles.metricLabel}>مشاكل حرجة</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>الوصول السريع</Text>
        <View style={styles.quickLinksGrid}>
          <QuickLink icon={AlertTriangle} label="محاولات فاشلة" path="/owner/security/failed-logins" />
          <QuickLink icon={Activity} label="الجلسات النشطة" path="/owner/security/session-management" />
          <QuickLink icon={Lock} label="تقييد IP" path="/owner/security/ip-restrictions" />
          <QuickLink icon={Eye} label="الأوذن" path="/owner/security/permissions" />
          <QuickLink icon={Zap} label="السجلات" path="/owner/security/modifications" />
          <QuickLink icon={Shield} label="الأمان" path="/owner/security" />
        </View>

        <View style={styles.alertSection}>
          <View style={styles.alertHeader}>
            <AlertTriangle size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.alertTitle}>الحالات المهمة</Text>
          </View>
          {metrics.criticalIssues > 0 && (
            <Text style={styles.alertMessage}>توجد {metrics.criticalIssues} مشاكل حرجة تتطلب اهتمامك</Text>
          )}
          {metrics.unreadAuditLogs > 0 && (
            <Text style={styles.alertMessage}>{metrics.unreadAuditLogs} سجل لم يتم حله</Text>
          )}
          {metrics.failedLogins > 10 && (
            <Text style={styles.alertMessage}>عدد محاولات تسجيل الدخول الفاشلة مرتفع اليوم</Text>
          )}
          {metrics.systemHealth < 60 && (
            <Text style={styles.alertMessage}>صحة النظام تحت السيطرة، يرجى الفحص</Text>
          )}
          {metrics.criticalIssues === 0 && metrics.systemHealth >= 80 && (
            <Text style={[styles.alertMessage, { color: '#10b981' }]}>النظام يعمل بشكل صحي</Text>
          )}
        </View>

        <Text style={styles.sectionTitle}>معلومات النظام</Text>
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>إجمالي سجلات التدقيق</Text>
            <Text style={styles.infoValue}>{metrics.unreadAuditLogs + 50}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>الصلاحيات المفعلة</Text>
            <Text style={styles.infoValue}>{metrics.permissionsEnabled}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>آخر تحديث</Text>
            <Text style={styles.infoValue}>{new Date().toLocaleTimeString('ar-SA')}</Text>
          </View>
        </View>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  healthCard: { backgroundColor: '#ffffff', padding: 20, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: '#e2e8f0' },
  healthHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  healthLabel: { fontSize: 14, color: '#64748b', marginBottom: 4 },
  healthValue: { fontSize: 28, fontWeight: 'bold' },
  healthCircle: { width: 80, height: 80, borderRadius: 40, borderWidth: 3, justifyContent: 'center', alignItems: 'center' },
  healthPercent: { fontSize: 20, fontWeight: 'bold' },
  healthBar: { height: 8, backgroundColor: '#e2e8f0', borderRadius: 4, overflow: 'hidden' },
  healthBarFill: { height: '100%', borderRadius: 4 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 12, marginTop: 20, textAlign: 'right' },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  metricCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  metricValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  metricLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  quickLinksGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  quickLink: { flex: 1, minWidth: '31%', backgroundColor: '#ffffff', padding: 12, borderRadius: 12, alignItems: 'center', gap: 8, borderWidth: 1, borderColor: '#e2e8f0' },
  quickLinkLabel: { fontSize: 11, color: '#0f172a', textAlign: 'center' },
  alertSection: { backgroundColor: '#fef3c7', padding: 16, borderRadius: 12, marginBottom: 20, borderLeftWidth: 4, borderLeftColor: '#f59e0b' },
  alertHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  alertTitle: { fontSize: 14, fontWeight: 'bold', color: '#0f172a' },
  alertMessage: { fontSize: 12, color: '#64748b', marginBottom: 6, textAlign: 'right' },
  infoCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10 },
  infoLabel: { fontSize: 13, color: '#64748b' },
  infoValue: { fontSize: 13, fontWeight: '600', color: '#0f172a' },
  divider: { height: 1, backgroundColor: '#e2e8f0' },
});
