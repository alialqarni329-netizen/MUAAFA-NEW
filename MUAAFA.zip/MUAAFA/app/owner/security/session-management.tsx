import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Monitor, Smartphone, User, MapPin, Clock, Search } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SECURITY_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/security' },
  { name: 'failed-logins', label: 'محاولات فاشلة', path: '/owner/security/failed-logins' },
  { name: 'ip-restrictions', label: 'تقييد IP', path: '/owner/security/ip-restrictions' },
  { name: 'sessions', label: 'الجلسات', path: '/owner/security/session-management' },
  { name: 'modifications', label: 'التعديلات', path: '/owner/security/modifications' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/security/permissions' },
];

interface UserSession {
  id: string;
  user_id: string;
  user_email: string;
  ip_address: string;
  device_type?: string;
  device_fingerprint?: string;
  browser?: string;
  os?: string;
  status: 'active' | 'inactive' | 'expired';
  last_activity_at: string;
  created_at: string;
  expires_at?: string;
}

export default function SessionManagement() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [stats, setStats] = useState({ total: 0, active: 0, inactive: 0, expired: 0, averageAge: 0 });

  useEffect(() => {
    loadSessions();
  }, []);

  async function loadSessions() {
    try {
      const { data, error } = await supabase
        .from('user_sessions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;

      const sessions = data || [];
      const activeCount = sessions.filter(s => s.status === 'active').length;
      const inactiveCount = sessions.filter(s => s.status === 'inactive').length;
      const expiredCount = sessions.filter(s => s.status === 'expired').length;

      // Calculate average session age
      const now = new Date();
      const avgAge = sessions.reduce((sum, s) => {
        const age = (now.getTime() - new Date(s.created_at).getTime()) / (1000 * 60);
        return sum + age;
      }, 0) / Math.max(sessions.length, 1);

      setSessions(sessions);
      setStats({
        total: sessions.length,
        active: activeCount,
        inactive: inactiveCount,
        expired: expiredCount,
        averageAge: Math.round(avgAge)
      });
    } catch (error) {
      console.error('Error loading sessions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadSessions();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الجلسات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الأمان" tabs={SECURITY_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Monitor size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الجلسات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <Monitor size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>نشطة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <Monitor size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.expired.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>منتهية</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Monitor size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.averageAge}</Text>
            <Text style={styles.statLabel}>متوسط العمر (دقائق)</Text>
          </View>
        </View>
        <Text style={styles.sectionTitle}>الجلسات النشطة</Text>
        {sessions.length > 0 ? (
          sessions
            .filter(session => session.status === 'active')
            .map((session) => {
            const statusColor = session.status === 'active' ? '#10b981' : session.status === 'expired' ? '#ef4444' : '#f59e0b';
            return (
            <View key={session.id} style={styles.sessionCard}>
              <View style={styles.sessionHeader}>
                <View style={styles.deviceInfo}>
                  <Smartphone size={18} color={statusColor} strokeWidth={2} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.sessionDevice}>{session.device_type || 'جهاز'}</Text>
                    {session.browser && <Text style={styles.sessionBrowser}>{session.browser}</Text>}
                  </View>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: statusColor + '20' }]}>
                  <Text style={[styles.statusText, { color: statusColor }]}>
                    {session.status === 'active' ? 'نشط' : session.status === 'expired' ? 'منتهي' : 'غير نشط'}
                  </Text>
                </View>
              </View>
              <View style={styles.sessionDetails}>
                <View style={styles.detailRow}>
                  <User size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>{session.user_email || 'مستخدم'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <MapPin size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>IP: {session.ip_address || 'غير متوفر'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Clock size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.detailText}>
                    {new Date(session.created_at).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </View>
                {session.last_activity_at && (
                  <View style={styles.detailRow}>
                    <Clock size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailText}>آخر نشاط: {new Date(session.last_activity_at).toLocaleTimeString('ar-SA')}</Text>
                  </View>
                )}
              </View>
            </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Monitor size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد جلسات نشطة</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 12, textAlign: 'right' },
  sessionCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  sessionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  deviceInfo: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
  sessionDevice: { fontSize: 15, fontWeight: '600', color: '#0f172a', textAlign: 'right' },
  sessionBrowser: { fontSize: 12, color: '#64748b', marginTop: 4 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12 },
  statusText: { fontSize: 11, fontWeight: '600' },
  sessionDetails: { gap: 8 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  detailText: { fontSize: 13, color: '#64748b', textAlign: 'right' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
