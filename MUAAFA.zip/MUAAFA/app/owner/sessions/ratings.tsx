import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Star, Search, Calendar, User, MessageSquare, TrendingUp, Award, ThumbsUp } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SESSIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/sessions' },
  { name: 'active', label: 'النشطة', path: '/owner/sessions/active' },
  { name: 'completed', label: 'المكتملة', path: '/owner/sessions/completed' },
  { name: 'providers', label: 'المقدمين', path: '/owner/sessions/providers' },
  { name: 'complaints', label: 'الشكاوى', path: '/owner/sessions/complaints' },
  { name: 'ratings', label: 'التقييمات', path: '/owner/sessions/ratings' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/sessions/settings' },
];

interface Rating {
  id: string;
  appointment_id: string;
  user_id: string;
  doctor_id: string;
  patient_rating: number;
  patient_feedback: string;
  created_at: string;
  patient_name?: string;
  doctor_name?: string;
  appointment_type?: string;
}

export default function SessionRatings() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [ratings, setRatings] = useState<Rating[]>([]);
  const [filteredRatings, setFilteredRatings] = useState<Rating[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRating, setFilterRating] = useState<'all' | '5' | '4' | '3' | 'low'>('all');
  const [stats, setStats] = useState({
    total: 0,
    avgRating: 0,
    fiveStars: 0,
    withFeedback: 0,
  });

  useEffect(() => {
    loadRatings();
  }, []);

  useEffect(() => {
    filterRatingsData();
  }, [searchQuery, filterRating, ratings]);

  async function loadRatings() {
    try {
      const { data: notesData } = await supabase
        .from('post_session_notes')
        .select(`
          *,
          appointment:appointments(
            appointment_type,
            user_id,
            doctor_id
          ),
          patient:users!post_session_notes_user_id_fkey(full_name),
          doctor:doctors!post_session_notes_doctor_id_fkey(full_name)
        `)
        .not('patient_rating', 'is', null)
        .order('created_at', { ascending: false });

      const ratingsData = (notesData || []).map(note => ({
        id: note.id,
        appointment_id: note.appointment_id,
        user_id: note.user_id,
        doctor_id: note.doctor_id,
        patient_rating: note.patient_rating,
        patient_feedback: note.patient_feedback,
        created_at: note.created_at,
        patient_name: note.patient?.full_name || 'غير محدد',
        doctor_name: note.doctor?.full_name || 'غير محدد',
        appointment_type: note.appointment?.appointment_type,
      }));

      const totalRatings = ratingsData.length;
      const sumRatings = ratingsData.reduce((sum, r) => sum + (r.patient_rating || 0), 0);
      const avgRating = totalRatings > 0 ? sumRatings / totalRatings : 0;
      const fiveStarsCount = ratingsData.filter(r => r.patient_rating === 5).length;
      const withFeedbackCount = ratingsData.filter(r => r.patient_feedback?.trim()).length;

      setStats({
        total: totalRatings,
        avgRating: Math.round(avgRating * 10) / 10,
        fiveStars: fiveStarsCount,
        withFeedback: withFeedbackCount,
      });

      setRatings(ratingsData);
      setFilteredRatings(ratingsData);
    } catch (error) {
      console.error('Error loading ratings:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterRatingsData() {
    let filtered = ratings;

    // Apply rating filter
    if (filterRating !== 'all') {
      if (filterRating === 'low') {
        filtered = filtered.filter(r => r.patient_rating <= 2);
      } else {
        const ratingValue = parseInt(filterRating);
        filtered = filtered.filter(r => r.patient_rating === ratingValue);
      }
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        rating =>
          rating.patient_name?.toLowerCase().includes(query) ||
          rating.doctor_name?.toLowerCase().includes(query) ||
          rating.patient_feedback?.toLowerCase().includes(query)
      );
    }

    setFilteredRatings(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadRatings();
  }

  function renderStars(rating: number) {
    return (
      <View style={styles.starsContainer}>
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            size={16}
            color="#f59e0b"
            strokeWidth={2}
            fill={star <= rating ? '#f59e0b' : 'none'}
          />
        ))}
      </View>
    );
  }

  function getRatingColor(rating: number) {
    if (rating >= 4) return '#10b981';
    if (rating === 3) return '#f59e0b';
    return '#ef4444';
  }

  function formatDateTime(dateTime: string) {
    return new Date(dateTime).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل التقييمات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Star size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي التقييمات</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.avgRating.toFixed(1)}</Text>
            <Text style={styles.statLabel}>متوسط التقييم</Text>
          </View>

          <View style={styles.statCard}>
            <Award size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.fiveStars}</Text>
            <Text style={styles.statLabel}>5 نجوم</Text>
          </View>

          <View style={styles.statCard}>
            <MessageSquare size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.withFeedback}</Text>
            <Text style={styles.statLabel}>مع تعليق</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في التقييمات..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.filterContainer}
          contentContainerStyle={styles.filterContent}>
          <TouchableOpacity
            style={[styles.filterButton, filterRating === 'all' && styles.filterButtonActive]}
            onPress={() => setFilterRating('all')}>
            <Text style={[styles.filterButtonText, filterRating === 'all' && styles.filterButtonTextActive]}>
              الكل
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterRating === '5' && styles.filterButtonActive]}
            onPress={() => setFilterRating('5')}>
            <Star size={14} color={filterRating === '5' ? '#ffffff' : '#f59e0b'} strokeWidth={2} fill={filterRating === '5' ? '#ffffff' : '#f59e0b'} />
            <Text style={[styles.filterButtonText, filterRating === '5' && styles.filterButtonTextActive]}>
              5 نجوم
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterRating === '4' && styles.filterButtonActive]}
            onPress={() => setFilterRating('4')}>
            <Star size={14} color={filterRating === '4' ? '#ffffff' : '#f59e0b'} strokeWidth={2} fill={filterRating === '4' ? '#ffffff' : '#f59e0b'} />
            <Text style={[styles.filterButtonText, filterRating === '4' && styles.filterButtonTextActive]}>
              4 نجوم
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterRating === '3' && styles.filterButtonActive]}
            onPress={() => setFilterRating('3')}>
            <Star size={14} color={filterRating === '3' ? '#ffffff' : '#f59e0b'} strokeWidth={2} fill={filterRating === '3' ? '#ffffff' : '#f59e0b'} />
            <Text style={[styles.filterButtonText, filterRating === '3' && styles.filterButtonTextActive]}>
              3 نجوم
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterRating === 'low' && styles.filterButtonActive]}
            onPress={() => setFilterRating('low')}>
            <Text style={[styles.filterButtonText, filterRating === 'low' && styles.filterButtonTextActive]}>
              منخفضة
            </Text>
          </TouchableOpacity>
        </ScrollView>

        {filteredRatings.length > 0 ? (
          filteredRatings.map((rating) => (
            <View key={rating.id} style={styles.ratingCard}>
              <View style={styles.ratingHeader}>
                <View style={styles.ratingBadge}>
                  {renderStars(rating.patient_rating)}
                  <Text style={[styles.ratingValue, { color: getRatingColor(rating.patient_rating) }]}>
                    {rating.patient_rating}/5
                  </Text>
                </View>
              </View>

              <View style={styles.ratingDetails}>
                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <User size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>المريض:</Text>
                  </View>
                  <Text style={styles.detailValue}>{rating.patient_name}</Text>
                </View>

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <User size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>الطبيب:</Text>
                  </View>
                  <Text style={styles.detailValue}>{rating.doctor_name}</Text>
                </View>

                {rating.appointment_type && (
                  <View style={styles.detailRow}>
                    <View style={styles.detailLeft}>
                      <MessageSquare size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailLabel}>نوع الجلسة:</Text>
                    </View>
                    <Text style={styles.detailValue}>{rating.appointment_type}</Text>
                  </View>
                )}

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <Calendar size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>تاريخ التقييم:</Text>
                  </View>
                  <Text style={styles.detailValue}>{formatDateTime(rating.created_at)}</Text>
                </View>
              </View>

              {rating.patient_feedback && (
                <View style={[styles.feedbackBox, { backgroundColor: getRatingColor(rating.patient_rating) + '10' }]}>
                  <View style={styles.feedbackHeader}>
                    <MessageSquare size={14} color={getRatingColor(rating.patient_rating)} strokeWidth={2} />
                    <Text style={[styles.feedbackLabel, { color: getRatingColor(rating.patient_rating) }]}>
                      تعليق المريض:
                    </Text>
                  </View>
                  <Text style={styles.feedbackText}>{rating.patient_feedback}</Text>
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Star size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery || filterRating !== 'all' ? 'لا توجد نتائج للبحث' : 'لا توجد تقييمات'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  filterContainer: {
    marginBottom: 16,
  },
  filterContent: {
    gap: 8,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
  },
  filterButtonActive: {
    backgroundColor: '#3b82f6',
  },
  filterButtonText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748b',
  },
  filterButtonTextActive: {
    color: '#ffffff',
  },
  ratingCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fef3c7',
  },
  ratingHeader: {
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  starsContainer: {
    flexDirection: 'row',
    gap: 4,
  },
  ratingValue: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  ratingDetails: {
    gap: 10,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
  },
  detailValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'left',
  },
  feedbackBox: {
    padding: 12,
    borderRadius: 8,
  },
  feedbackHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  feedbackLabel: {
    fontSize: 12,
    fontWeight: '600',
  },
  feedbackText: {
    fontSize: 13,
    color: '#0f172a',
    lineHeight: 20,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
