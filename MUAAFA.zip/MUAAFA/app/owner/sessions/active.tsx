import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Video, Clock, User, Search, Filter, Calendar, MapPin } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SESSIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/sessions' },
  { name: 'active', label: 'النشطة', path: '/owner/sessions/active' },
  { name: 'completed', label: 'المكتملة', path: '/owner/sessions/completed' },
  { name: 'providers', label: 'المقدمين', path: '/owner/sessions/providers' },
  { name: 'complaints', label: 'الشكاوى', path: '/owner/sessions/complaints' },
  { name: 'ratings', label: 'التقييمات', path: '/owner/sessions/ratings' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/sessions/settings' },
];

interface ActiveSession {
  id: string;
  user_id: string;
  doctor_id: string;
  appointment_type: string;
  status: string;
  scheduled_date: string;
  scheduled_time: string;
  duration_minutes: number;
  meeting_platform: string;
  meeting_url: string;
  reason_for_visit: string;
  joined_at: string;
  patient_name?: string;
  doctor_name?: string;
}

export default function ActiveSessions() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [sessions, setSessions] = useState<ActiveSession[]>([]);
  const [filteredSessions, setFilteredSessions] = useState<ActiveSession[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    inProgress: 0,
    scheduled: 0,
    waiting: 0,
    avgDuration: 0,
  });

  useEffect(() => {
    loadActiveSessions();
  }, []);

  useEffect(() => {
    filterSessions();
  }, [searchQuery, sessions]);

  async function loadActiveSessions() {
    try {
      // Get active appointments (in_progress, scheduled, or waiting)
      const { data: appointmentsData } = await supabase
        .from('appointments')
        .select(`
          *,
          patient:users!appointments_user_id_fkey(full_name),
          doctor:doctors(full_name)
        `)
        .in('status', ['in_progress', 'scheduled', 'waiting'])
        .order('scheduled_date', { ascending: true })
        .order('scheduled_time', { ascending: true });

      const sessions = (appointmentsData || []).map(apt => ({
        ...apt,
        patient_name: apt.patient?.full_name || 'غير محدد',
        doctor_name: apt.doctor?.full_name || 'غير محدد',
      }));

      const inProgressCount = sessions.filter(s => s.status === 'in_progress').length;
      const scheduledCount = sessions.filter(s => s.status === 'scheduled').length;
      const waitingCount = sessions.filter(s => s.status === 'waiting').length;
      const totalDuration = sessions.reduce((sum, s) => sum + (s.duration_minutes || 0), 0);

      setStats({
        inProgress: inProgressCount,
        scheduled: scheduledCount,
        waiting: waitingCount,
        avgDuration: sessions.length > 0 ? Math.round(totalDuration / sessions.length) : 0,
      });

      setSessions(sessions);
      setFilteredSessions(sessions);
    } catch (error) {
      console.error('Error loading active sessions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterSessions() {
    if (!searchQuery.trim()) {
      setFilteredSessions(sessions);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = sessions.filter(
      session =>
        session.patient_name?.toLowerCase().includes(query) ||
        session.doctor_name?.toLowerCase().includes(query) ||
        session.appointment_type?.toLowerCase().includes(query) ||
        session.reason_for_visit?.toLowerCase().includes(query)
    );
    setFilteredSessions(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadActiveSessions();
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'in_progress': return '#10b981';
      case 'scheduled': return '#f59e0b';
      case 'waiting': return '#3b82f6';
      default: return '#64748b';
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'in_progress': return 'جارية الآن';
      case 'scheduled': return 'مجدولة';
      case 'waiting': return 'في الانتظار';
      default: return status;
    }
  }

  function formatTime(time: string) {
    if (!time) return '';
    const [hours, minutes] = time.split(':');
    return `${hours}:${minutes}`;
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الجلسات النشطة...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Video size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.inProgress}</Text>
            <Text style={styles.statLabel}>جارية الآن</Text>
          </View>

          <View style={styles.statCard}>
            <Calendar size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.scheduled}</Text>
            <Text style={styles.statLabel}>مجدولة</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.waiting}</Text>
            <Text style={styles.statLabel}>في الانتظار</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.avgDuration}</Text>
            <Text style={styles.statLabel}>متوسط المدة (دقيقة)</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في الجلسات النشطة..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredSessions.length > 0 ? (
          filteredSessions.map((session) => (
            <View key={session.id} style={styles.sessionCard}>
              <View style={styles.sessionHeader}>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(session.status) + '20' }]}>
                  <Video size={14} color={getStatusColor(session.status)} strokeWidth={2} />
                  <Text style={[styles.statusText, { color: getStatusColor(session.status) }]}>
                    {getStatusText(session.status)}
                  </Text>
                </View>
                <Text style={styles.sessionType}>{session.appointment_type || 'استشارة'}</Text>
              </View>

              <View style={styles.sessionDetails}>
                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <User size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>المريض:</Text>
                  </View>
                  <Text style={styles.detailValue}>{session.patient_name}</Text>
                </View>

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <User size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>الطبيب:</Text>
                  </View>
                  <Text style={styles.detailValue}>{session.doctor_name}</Text>
                </View>

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <Calendar size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>التاريخ:</Text>
                  </View>
                  <Text style={styles.detailValue}>
                    {formatDate(session.scheduled_date)} - {formatTime(session.scheduled_time)}
                  </Text>
                </View>

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <Clock size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>المدة:</Text>
                  </View>
                  <Text style={styles.detailValue}>{session.duration_minutes || 30} دقيقة</Text>
                </View>

                {session.meeting_platform && (
                  <View style={styles.detailRow}>
                    <View style={styles.detailLeft}>
                      <Video size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailLabel}>المنصة:</Text>
                    </View>
                    <Text style={styles.detailValue}>{session.meeting_platform}</Text>
                  </View>
                )}

                {session.reason_for_visit && (
                  <View style={styles.reasonBox}>
                    <Text style={styles.reasonLabel}>سبب الزيارة:</Text>
                    <Text style={styles.reasonText}>{session.reason_for_visit}</Text>
                  </View>
                )}

                {session.status === 'in_progress' && session.joined_at && (
                  <View style={styles.liveIndicator}>
                    <View style={styles.liveDot} />
                    <Text style={styles.liveText}>
                      بدأت منذ {Math.round((Date.now() - new Date(session.joined_at).getTime()) / 60000)} دقيقة
                    </Text>
                  </View>
                )}
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Video size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد جلسات نشطة حالياً'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  sessionCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#dbeafe',
  },
  sessionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  sessionType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  sessionDetails: {
    gap: 10,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
  },
  detailValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'left',
  },
  reasonBox: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    marginTop: 4,
  },
  reasonLabel: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 4,
  },
  reasonText: {
    fontSize: 13,
    color: '#0f172a',
    lineHeight: 20,
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingTop: 8,
    marginTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  liveDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10b981',
  },
  liveText: {
    fontSize: 12,
    color: '#10b981',
    fontWeight: '600',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
