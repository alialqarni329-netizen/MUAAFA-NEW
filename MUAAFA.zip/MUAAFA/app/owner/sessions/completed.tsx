import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { CheckCircle, Clock, User, Search, Calendar, FileText, Star, TrendingUp } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SESSIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/sessions' },
  { name: 'active', label: 'النشطة', path: '/owner/sessions/active' },
  { name: 'completed', label: 'المكتملة', path: '/owner/sessions/completed' },
  { name: 'providers', label: 'المقدمين', path: '/owner/sessions/providers' },
  { name: 'complaints', label: 'الشكاوى', path: '/owner/sessions/complaints' },
  { name: 'ratings', label: 'التقييمات', path: '/owner/sessions/ratings' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/sessions/settings' },
];

interface CompletedSession {
  id: string;
  user_id: string;
  doctor_id: string;
  appointment_type: string;
  status: string;
  scheduled_date: string;
  scheduled_time: string;
  duration_minutes: number;
  actual_duration_minutes: number;
  ended_at: string;
  notes: string;
  patient_name?: string;
  doctor_name?: string;
}

export default function CompletedSessions() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [sessions, setSessions] = useState<CompletedSession[]>([]);
  const [filteredSessions, setFilteredSessions] = useState<CompletedSession[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    thisWeek: 0,
    thisMonth: 0,
    avgDuration: 0,
  });

  useEffect(() => {
    loadCompletedSessions();
  }, []);

  useEffect(() => {
    filterSessions();
  }, [searchQuery, sessions]);

  async function loadCompletedSessions() {
    try {
      const { data: appointmentsData } = await supabase
        .from('appointments')
        .select(`
          *,
          patient:users!appointments_user_id_fkey(full_name),
          doctor:doctors(full_name)
        `)
        .eq('status', 'completed')
        .order('ended_at', { ascending: false })
        .limit(100);

      const sessions = (appointmentsData || []).map(apt => ({
        ...apt,
        patient_name: apt.patient?.full_name || 'غير محدد',
        doctor_name: apt.doctor?.full_name || 'غير محدد',
      }));

      // Calculate stats
      const now = new Date();
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

      const thisWeekCount = sessions.filter(s => new Date(s.ended_at) >= weekAgo).length;
      const thisMonthCount = sessions.filter(s => new Date(s.ended_at) >= monthAgo).length;
      const totalDuration = sessions.reduce((sum, s) => sum + (s.actual_duration_minutes || s.duration_minutes || 0), 0);

      setStats({
        total: sessions.length,
        thisWeek: thisWeekCount,
        thisMonth: thisMonthCount,
        avgDuration: sessions.length > 0 ? Math.round(totalDuration / sessions.length) : 0,
      });

      setSessions(sessions);
      setFilteredSessions(sessions);
    } catch (error) {
      console.error('Error loading completed sessions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterSessions() {
    if (!searchQuery.trim()) {
      setFilteredSessions(sessions);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = sessions.filter(
      session =>
        session.patient_name?.toLowerCase().includes(query) ||
        session.doctor_name?.toLowerCase().includes(query) ||
        session.appointment_type?.toLowerCase().includes(query) ||
        session.notes?.toLowerCase().includes(query)
    );
    setFilteredSessions(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadCompletedSessions();
  }

  function formatTime(time: string) {
    if (!time) return '';
    const [hours, minutes] = time.split(':');
    return `${hours}:${minutes}`;
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  function formatDateTime(dateTime: string) {
    return new Date(dateTime).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الجلسات المكتملة...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المكتملة</Text>
          </View>

          <View style={styles.statCard}>
            <TrendingUp size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.thisWeek}</Text>
            <Text style={styles.statLabel}>هذا الأسبوع</Text>
          </View>

          <View style={styles.statCard}>
            <Calendar size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.thisMonth}</Text>
            <Text style={styles.statLabel}>هذا الشهر</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.avgDuration}</Text>
            <Text style={styles.statLabel}>متوسط المدة (دقيقة)</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في الجلسات المكتملة..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredSessions.length > 0 ? (
          filteredSessions.map((session) => (
            <View key={session.id} style={styles.sessionCard}>
              <View style={styles.sessionHeader}>
                <View style={styles.completedBadge}>
                  <CheckCircle size={14} color="#10b981" strokeWidth={2} />
                  <Text style={styles.completedText}>مكتملة</Text>
                </View>
                <Text style={styles.sessionType}>{session.appointment_type || 'استشارة'}</Text>
              </View>

              <View style={styles.sessionDetails}>
                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <User size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>المريض:</Text>
                  </View>
                  <Text style={styles.detailValue}>{session.patient_name}</Text>
                </View>

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <User size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>الطبيب:</Text>
                  </View>
                  <Text style={styles.detailValue}>{session.doctor_name}</Text>
                </View>

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <Calendar size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>موعد الجلسة:</Text>
                  </View>
                  <Text style={styles.detailValue}>
                    {formatDate(session.scheduled_date)} - {formatTime(session.scheduled_time)}
                  </Text>
                </View>

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <Clock size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>المدة الفعلية:</Text>
                  </View>
                  <Text style={styles.detailValue}>
                    {session.actual_duration_minutes || session.duration_minutes || 30} دقيقة
                  </Text>
                </View>

                {session.ended_at && (
                  <View style={styles.detailRow}>
                    <View style={styles.detailLeft}>
                      <CheckCircle size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailLabel}>انتهت في:</Text>
                    </View>
                    <Text style={styles.detailValue}>{formatDateTime(session.ended_at)}</Text>
                  </View>
                )}

                {session.notes && (
                  <View style={styles.notesBox}>
                    <View style={styles.notesHeader}>
                      <FileText size={14} color="#64748b" strokeWidth={2} />
                      <Text style={styles.notesLabel}>ملاحظات الجلسة:</Text>
                    </View>
                    <Text style={styles.notesText}>{session.notes}</Text>
                  </View>
                )}
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <CheckCircle size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد جلسات مكتملة'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  sessionCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#d1fae5',
  },
  sessionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  sessionType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: '#d1fae520',
  },
  completedText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#10b981',
  },
  sessionDetails: {
    gap: 10,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
  },
  detailValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'left',
  },
  notesBox: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    marginTop: 4,
  },
  notesHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  notesLabel: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
  },
  notesText: {
    fontSize: 13,
    color: '#0f172a',
    lineHeight: 20,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
