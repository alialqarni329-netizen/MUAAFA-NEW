import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { User, Search, Star, Calendar, CheckCircle, TrendingUp, Award, Clock } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SESSIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/sessions' },
  { name: 'active', label: 'النشطة', path: '/owner/sessions/active' },
  { name: 'completed', label: 'المكتملة', path: '/owner/sessions/completed' },
  { name: 'providers', label: 'المقدمين', path: '/owner/sessions/providers' },
  { name: 'complaints', label: 'الشكاوى', path: '/owner/sessions/complaints' },
  { name: 'ratings', label: 'التقييمات', path: '/owner/sessions/ratings' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/sessions/settings' },
];

interface Provider {
  id: string;
  full_name: string;
  specialty: string;
  bio: string;
  rating: number;
  is_available: boolean;
  total_sessions?: number;
  completed_sessions?: number;
  active_sessions?: number;
}

export default function ServiceProviders() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [filteredProviders, setFilteredProviders] = useState<Provider[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    available: 0,
    avgRating: 0,
    topPerformer: 0,
  });

  useEffect(() => {
    loadProviders();
  }, []);

  useEffect(() => {
    filterProviders();
  }, [searchQuery, providers]);

  async function loadProviders() {
    try {
      // Get all doctors
      const { data: doctorsData } = await supabase
        .from('doctors')
        .select('*')
        .order('full_name', { ascending: true });

      const doctors = doctorsData || [];

      // Get appointment counts for each doctor
      const providersWithStats = await Promise.all(
        doctors.map(async (doctor) => {
          const { data: appointments } = await supabase
            .from('appointments')
            .select('status')
            .eq('doctor_id', doctor.id);

          const allAppointments = appointments || [];
          const completedCount = allAppointments.filter(a => a.status === 'completed').length;
          const activeCount = allAppointments.filter(a =>
            a.status === 'in_progress' || a.status === 'scheduled' || a.status === 'waiting'
          ).length;

          return {
            ...doctor,
            total_sessions: allAppointments.length,
            completed_sessions: completedCount,
            active_sessions: activeCount,
          };
        })
      );

      const availableCount = providersWithStats.filter(p => p.is_available).length;
      const totalRating = providersWithStats.reduce((sum, p) => sum + (Number(p.rating) || 0), 0);
      const avgRating = providersWithStats.length > 0 ? totalRating / providersWithStats.length : 0;
      const topPerformer = Math.max(...providersWithStats.map(p => p.completed_sessions || 0));

      setStats({
        total: providersWithStats.length,
        available: availableCount,
        avgRating: Math.round(avgRating * 10) / 10,
        topPerformer: topPerformer,
      });

      setProviders(providersWithStats);
      setFilteredProviders(providersWithStats);
    } catch (error) {
      console.error('Error loading providers:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterProviders() {
    if (!searchQuery.trim()) {
      setFilteredProviders(providers);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = providers.filter(
      provider =>
        provider.full_name?.toLowerCase().includes(query) ||
        provider.specialty?.toLowerCase().includes(query) ||
        provider.bio?.toLowerCase().includes(query)
    );
    setFilteredProviders(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadProviders();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل مقدمي الخدمة...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <User size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المقدمين</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.available}</Text>
            <Text style={styles.statLabel}>متاح حالياً</Text>
          </View>

          <View style={styles.statCard}>
            <Star size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.avgRating.toFixed(1)}</Text>
            <Text style={styles.statLabel}>متوسط التقييم</Text>
          </View>

          <View style={styles.statCard}>
            <Award size={24} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.topPerformer}</Text>
            <Text style={styles.statLabel}>الأعلى جلسات</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في مقدمي الخدمة..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredProviders.length > 0 ? (
          filteredProviders.map((provider) => (
            <View key={provider.id} style={styles.providerCard}>
              <View style={styles.providerHeader}>
                <View style={styles.providerInfo}>
                  <View style={styles.avatarContainer}>
                    <User size={24} color="#3b82f6" strokeWidth={2} />
                  </View>
                  <View style={styles.providerNameSection}>
                    <Text style={styles.providerName}>{provider.full_name}</Text>
                    <Text style={styles.providerSpecialty}>{provider.specialty || 'غير محدد'}</Text>
                  </View>
                </View>

                <View style={styles.statusSection}>
                  <View style={[styles.statusBadge, {
                    backgroundColor: provider.is_available ? '#d1fae520' : '#f1f5f9'
                  }]}>
                    <View style={[styles.statusDot, {
                      backgroundColor: provider.is_available ? '#10b981' : '#64748b'
                    }]} />
                    <Text style={[styles.statusText, {
                      color: provider.is_available ? '#10b981' : '#64748b'
                    }]}>
                      {provider.is_available ? 'متاح' : 'غير متاح'}
                    </Text>
                  </View>
                </View>
              </View>

              {provider.bio && (
                <Text style={styles.providerBio} numberOfLines={2}>
                  {provider.bio}
                </Text>
              )}

              <View style={styles.ratingRow}>
                <View style={styles.ratingContainer}>
                  <Star size={16} color="#f59e0b" strokeWidth={2} fill="#f59e0b" />
                  <Text style={styles.ratingText}>
                    {provider.rating ? Number(provider.rating).toFixed(1) : '0.0'}
                  </Text>
                </View>
              </View>

              <View style={styles.statsRow}>
                <View style={styles.statItem}>
                  <Calendar size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.statItemLabel}>إجمالي الجلسات:</Text>
                  <Text style={styles.statItemValue}>{provider.total_sessions || 0}</Text>
                </View>

                <View style={styles.statItem}>
                  <CheckCircle size={16} color="#10b981" strokeWidth={2} />
                  <Text style={styles.statItemLabel}>المكتملة:</Text>
                  <Text style={styles.statItemValue}>{provider.completed_sessions || 0}</Text>
                </View>

                <View style={styles.statItem}>
                  <Clock size={16} color="#3b82f6" strokeWidth={2} />
                  <Text style={styles.statItemLabel}>النشطة:</Text>
                  <Text style={styles.statItemValue}>{provider.active_sessions || 0}</Text>
                </View>
              </View>

              {(provider.completed_sessions || 0) > 0 && (
                <View style={styles.performanceBar}>
                  <View style={styles.performanceBarFill}
                    style={[styles.performanceBarFill, {
                      width: `${Math.min(100, ((provider.completed_sessions || 0) / stats.topPerformer) * 100)}%`
                    }]}
                  />
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <User size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا يوجد مقدمو خدمة'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  providerCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  providerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  providerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  avatarContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#dbeafe',
    justifyContent: 'center',
    alignItems: 'center',
  },
  providerNameSection: {
    flex: 1,
  },
  providerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  providerSpecialty: {
    fontSize: 13,
    color: '#64748b',
  },
  statusSection: {
    alignItems: 'flex-end',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  providerBio: {
    fontSize: 13,
    color: '#64748b',
    lineHeight: 20,
    marginBottom: 12,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
    marginBottom: 12,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#fef3c7',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#d97706',
  },
  statsRow: {
    gap: 8,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statItemLabel: {
    fontSize: 13,
    color: '#64748b',
  },
  statItemValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
    marginLeft: 'auto',
  },
  performanceBar: {
    height: 6,
    backgroundColor: '#f1f5f9',
    borderRadius: 3,
    marginTop: 12,
    overflow: 'hidden',
  },
  performanceBarFill: {
    height: '100%',
    backgroundColor: '#3b82f6',
    borderRadius: 3,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
