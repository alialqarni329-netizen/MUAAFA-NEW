import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Calendar, Clock, CheckCircle, Video, AlertCircle, Star, User } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SESSIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/sessions' },
  { name: 'active', label: 'النشطة', path: '/owner/sessions/active' },
  { name: 'completed', label: 'المكتملة', path: '/owner/sessions/completed' },
  { name: 'providers', label: 'المقدمين', path: '/owner/sessions/providers' },
  { name: 'complaints', label: 'الشكاوى', path: '/owner/sessions/complaints' },
  { name: 'ratings', label: 'التقييمات', path: '/owner/sessions/ratings' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/sessions/settings' },
];

interface Session {
  id: string;
  patient_name: string;
  provider_name: string;
  session_type: string;
  appointment_date: string;
  status: string;
  duration_minutes: number;
  created_at: string;
}

export default function AllSessions() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    completed: 0,
    cancelled: 0,
  });

  useEffect(() => {
    loadSessions();
  }, []);

  async function loadSessions() {
    try {
      // Get all appointments with patient and doctor names
      const { data: appointmentsData } = await supabase
        .from('appointments')
        .select(`
          *,
          patient:users!appointments_user_id_fkey(full_name),
          doctor:doctors(full_name)
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      const sessions = (appointmentsData || []).map(apt => ({
        id: apt.id,
        patient_name: apt.patient?.full_name || 'غير محدد',
        provider_name: apt.doctor?.full_name || 'غير محدد',
        session_type: apt.appointment_type || 'استشارة',
        appointment_date: apt.scheduled_date,
        status: apt.status,
        duration_minutes: apt.duration_minutes || 30,
        created_at: apt.created_at,
      }));

      setStats({
        total: sessions.length,
        active: sessions.filter(s => s.status === 'scheduled' || s.status === 'in_progress' || s.status === 'waiting').length,
        completed: sessions.filter(s => s.status === 'completed').length,
        cancelled: sessions.filter(s => s.status === 'cancelled').length,
      });

      setSessions(sessions);
    } catch (error) {
      console.error('Error loading sessions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadSessions();
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'completed': return <CheckCircle size={16} color="#10b981" strokeWidth={2} />;
      case 'in_progress': return <Video size={16} color="#3b82f6" strokeWidth={2} />;
      case 'scheduled': return <Clock size={16} color="#f59e0b" strokeWidth={2} />;
      case 'cancelled': return <AlertCircle size={16} color="#ef4444" strokeWidth={2} />;
      default: return <Clock size={16} color="#64748b" strokeWidth={2} />;
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'completed': return 'مكتملة';
      case 'in_progress': return 'جارية';
      case 'scheduled': return 'مجدولة';
      case 'cancelled': return 'ملغاة';
      default: return status;
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'completed': return '#10b981';
      case 'in_progress': return '#3b82f6';
      case 'scheduled': return '#f59e0b';
      case 'cancelled': return '#ef4444';
      default: return '#64748b';
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الجلسات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Calendar size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الجلسات</Text>
          </View>

          <View style={styles.statCard}>
            <Video size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active}</Text>
            <Text style={styles.statLabel}>نشطة</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.completed}</Text>
            <Text style={styles.statLabel}>مكتملة</Text>
          </View>

          <View style={styles.statCard}>
            <AlertCircle size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.cancelled}</Text>
            <Text style={styles.statLabel}>ملغاة</Text>
          </View>
        </View>

        {sessions.length > 0 ? (
          sessions.map((session) => (
            <View key={session.id} style={styles.sessionCard}>
              <View style={styles.sessionHeader}>
                <Video size={18} color="#3b82f6" strokeWidth={2} />
                <Text style={styles.sessionType}>{session.session_type || 'استشارة'}</Text>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(session.status) + '20' }]}>
                  {getStatusIcon(session.status)}
                  <Text style={[styles.statusText, { color: getStatusColor(session.status) }]}>
                    {getStatusText(session.status)}
                  </Text>
                </View>
              </View>

              <View style={styles.sessionDetails}>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>المريض:</Text>
                  <Text style={styles.detailValue}>{session.patient_name || '-'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>مقدم الخدمة:</Text>
                  <Text style={styles.detailValue}>{session.provider_name || '-'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>التاريخ:</Text>
                  <Text style={styles.detailValue}>
                    {new Date(session.appointment_date).toLocaleDateString('ar-SA', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>المدة:</Text>
                  <Text style={styles.detailValue}>{session.duration_minutes || 30} دقيقة</Text>
                </View>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Calendar size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا توجد جلسات</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  sessionCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#dbeafe',
  },
  sessionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  sessionType: {
    flex: 1,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  sessionDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
  },
  detailValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
});
