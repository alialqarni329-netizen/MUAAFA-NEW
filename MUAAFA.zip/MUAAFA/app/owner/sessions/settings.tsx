import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, Switch, TouchableOpacity, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Settings, Bell, Clock, Video, Shield, Users, FileText, CheckCircle, Save, AlertCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SESSIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/sessions' },
  { name: 'active', label: 'النشطة', path: '/owner/sessions/active' },
  { name: 'completed', label: 'المكتملة', path: '/owner/sessions/completed' },
  { name: 'providers', label: 'المقدمين', path: '/owner/sessions/providers' },
  { name: 'complaints', label: 'الشكاوى', path: '/owner/sessions/complaints' },
  { name: 'ratings', label: 'التقييمات', path: '/owner/sessions/ratings' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/sessions/settings' },
];

interface SessionSettings {
  auto_approve_sessions: boolean;
  require_patient_consent: boolean;
  enable_recording: boolean;
  send_reminders: boolean;
  reminder_hours_before: number;
  max_session_duration: number;
  allow_rescheduling: boolean;
  reschedule_hours_before: number;
  require_post_session_notes: boolean;
  enable_ratings: boolean;
  minimum_rating_to_display: number;
}

export default function SessionSettings() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');
  const [settings, setSettings] = useState<SessionSettings>({
    auto_approve_sessions: true,
    require_patient_consent: true,
    enable_recording: false,
    send_reminders: true,
    reminder_hours_before: 24,
    max_session_duration: 60,
    allow_rescheduling: true,
    reschedule_hours_before: 24,
    require_post_session_notes: true,
    enable_ratings: true,
    minimum_rating_to_display: 3,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      // In a real app, you would fetch settings from a settings table
      // For now, we'll use default values
      // const { data } = await supabase
      //   .from('session_settings')
      //   .select('*')
      //   .single();

      // if (data) {
      //   setSettings(data);
      // }
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadSettings();
  }

  async function handleSave() {
    setSaving(true);
    setSaveMessage('');

    try {
      // In a real app, you would save settings to database
      // await supabase
      //   .from('session_settings')
      //   .upsert(settings);

      // Simulate save delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      setSaveMessage('تم حفظ الإعدادات بنجاح');
      setTimeout(() => setSaveMessage(''), 3000);
    } catch (error) {
      console.error('Error saving settings:', error);
      setSaveMessage('حدث خطأ أثناء حفظ الإعدادات');
    } finally {
      setSaving(false);
    }
  }

  function updateSetting(key: keyof SessionSettings, value: any) {
    setSettings(prev => ({ ...prev, [key]: value }));
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الإعدادات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.header}>
          <Settings size={32} color="#3b82f6" strokeWidth={2} />
          <Text style={styles.headerTitle}>إعدادات الجلسات</Text>
          <Text style={styles.headerSubtitle}>تخصيص إعدادات الجلسات الطبية</Text>
        </View>

        {/* Session Approval */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <CheckCircle size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.sectionTitle}>الموافقة على الجلسات</Text>
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>الموافقة التلقائية على الجلسات</Text>
              <Text style={styles.settingDescription}>
                الموافقة تلقائياً على طلبات الجلسات دون مراجعة يدوية
              </Text>
            </View>
            <Switch
              value={settings.auto_approve_sessions}
              onValueChange={(value) => updateSetting('auto_approve_sessions', value)}
              trackColor={{ false: '#cbd5e1', true: '#93c5fd' }}
              thumbColor={settings.auto_approve_sessions ? '#3b82f6' : '#f1f5f9'}
            />
          </View>
        </View>

        {/* Privacy & Consent */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Shield size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.sectionTitle}>الخصوصية والموافقة</Text>
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>طلب موافقة المريض</Text>
              <Text style={styles.settingDescription}>
                طلب موافقة المريض على سياسة الخصوصية قبل الجلسة
              </Text>
            </View>
            <Switch
              value={settings.require_patient_consent}
              onValueChange={(value) => updateSetting('require_patient_consent', value)}
              trackColor={{ false: '#cbd5e1', true: '#86efac' }}
              thumbColor={settings.require_patient_consent ? '#10b981' : '#f1f5f9'}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>تفعيل تسجيل الجلسات</Text>
              <Text style={styles.settingDescription}>
                السماح بتسجيل الجلسات للرجوع إليها لاحقاً
              </Text>
            </View>
            <Switch
              value={settings.enable_recording}
              onValueChange={(value) => updateSetting('enable_recording', value)}
              trackColor={{ false: '#cbd5e1', true: '#86efac' }}
              thumbColor={settings.enable_recording ? '#10b981' : '#f1f5f9'}
            />
          </View>
        </View>

        {/* Notifications & Reminders */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Bell size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.sectionTitle}>الإشعارات والتذكيرات</Text>
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>إرسال تذكيرات للمرضى</Text>
              <Text style={styles.settingDescription}>
                إرسال تذكير تلقائي قبل موعد الجلسة
              </Text>
            </View>
            <Switch
              value={settings.send_reminders}
              onValueChange={(value) => updateSetting('send_reminders', value)}
              trackColor={{ false: '#cbd5e1', true: '#fcd34d' }}
              thumbColor={settings.send_reminders ? '#f59e0b' : '#f1f5f9'}
            />
          </View>

          {settings.send_reminders && (
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>وقت التذكير قبل الموعد (بالساعات)</Text>
              <TextInput
                style={styles.input}
                value={settings.reminder_hours_before.toString()}
                onChangeText={(text) => updateSetting('reminder_hours_before', parseInt(text) || 0)}
                keyboardType="number-pad"
                placeholder="24"
              />
            </View>
          )}
        </View>

        {/* Session Duration */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Clock size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.sectionTitle}>مدة الجلسة</Text>
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>الحد الأقصى لمدة الجلسة (بالدقائق)</Text>
            <TextInput
              style={styles.input}
              value={settings.max_session_duration.toString()}
              onChangeText={(text) => updateSetting('max_session_duration', parseInt(text) || 0)}
              keyboardType="number-pad"
              placeholder="60"
            />
          </View>
        </View>

        {/* Rescheduling */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Video size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.sectionTitle}>إعادة الجدولة</Text>
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>السماح بإعادة الجدولة</Text>
              <Text style={styles.settingDescription}>
                السماح للمرضى بإعادة جدولة مواعيدهم
              </Text>
            </View>
            <Switch
              value={settings.allow_rescheduling}
              onValueChange={(value) => updateSetting('allow_rescheduling', value)}
              trackColor={{ false: '#cbd5e1', true: '#fca5a5' }}
              thumbColor={settings.allow_rescheduling ? '#ef4444' : '#f1f5f9'}
            />
          </View>

          {settings.allow_rescheduling && (
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>الحد الأدنى للإعادة الجدولة قبل الموعد (بالساعات)</Text>
              <TextInput
                style={styles.input}
                value={settings.reschedule_hours_before.toString()}
                onChangeText={(text) => updateSetting('reschedule_hours_before', parseInt(text) || 0)}
                keyboardType="number-pad"
                placeholder="24"
              />
            </View>
          )}
        </View>

        {/* Post-Session */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <FileText size={20} color="#06b6d4" strokeWidth={2} />
            <Text style={styles.sectionTitle}>ما بعد الجلسة</Text>
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>طلب ملاحظات ما بعد الجلسة</Text>
              <Text style={styles.settingDescription}>
                إلزام الطبيب بكتابة ملاحظات بعد انتهاء الجلسة
              </Text>
            </View>
            <Switch
              value={settings.require_post_session_notes}
              onValueChange={(value) => updateSetting('require_post_session_notes', value)}
              trackColor={{ false: '#cbd5e1', true: '#67e8f9' }}
              thumbColor={settings.require_post_session_notes ? '#06b6d4' : '#f1f5f9'}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>تفعيل التقييمات</Text>
              <Text style={styles.settingDescription}>
                السماح للمرضى بتقييم الجلسات
              </Text>
            </View>
            <Switch
              value={settings.enable_ratings}
              onValueChange={(value) => updateSetting('enable_ratings', value)}
              trackColor={{ false: '#cbd5e1', true: '#67e8f9' }}
              thumbColor={settings.enable_ratings ? '#06b6d4' : '#f1f5f9'}
            />
          </View>

          {settings.enable_ratings && (
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>الحد الأدنى للتقييم لعرضه (من 5)</Text>
              <TextInput
                style={styles.input}
                value={settings.minimum_rating_to_display.toString()}
                onChangeText={(text) => updateSetting('minimum_rating_to_display', parseInt(text) || 0)}
                keyboardType="number-pad"
                placeholder="3"
              />
            </View>
          )}
        </View>

        {saveMessage ? (
          <View style={[styles.saveMessage, saveMessage.includes('خطأ') ? styles.saveMessageError : styles.saveMessageSuccess]}>
            {saveMessage.includes('خطأ') ? (
              <AlertCircle size={20} color="#ef4444" strokeWidth={2} />
            ) : (
              <CheckCircle size={20} color="#10b981" strokeWidth={2} />
            )}
            <Text style={[styles.saveMessageText, saveMessage.includes('خطأ') ? styles.saveMessageTextError : styles.saveMessageTextSuccess]}>
              {saveMessage}
            </Text>
          </View>
        ) : null}

        <TouchableOpacity
          style={[styles.saveButton, saving && styles.saveButtonDisabled]}
          onPress={handleSave}
          disabled={saving}>
          {saving ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <>
              <Save size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20, paddingBottom: 40 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
    paddingVertical: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 12,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  settingInfo: {
    flex: 1,
    marginRight: 16,
  },
  settingLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0f172a',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 13,
    color: '#64748b',
    lineHeight: 18,
  },
  inputContainer: {
    marginTop: 12,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748b',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    padding: 12,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  saveMessage: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  saveMessageSuccess: {
    backgroundColor: '#d1fae520',
    borderWidth: 1,
    borderColor: '#10b981',
  },
  saveMessageError: {
    backgroundColor: '#fee2e220',
    borderWidth: 1,
    borderColor: '#ef4444',
  },
  saveMessageText: {
    fontSize: 14,
    fontWeight: '600',
  },
  saveMessageTextSuccess: {
    color: '#10b981',
  },
  saveMessageTextError: {
    color: '#ef4444',
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#3b82f6',
    padding: 16,
    borderRadius: 12,
    marginTop: 8,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
