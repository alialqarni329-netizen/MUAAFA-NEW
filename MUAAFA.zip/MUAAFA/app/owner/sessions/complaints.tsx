import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { AlertTriangle, Search, Calendar, User, MessageSquare, AlertCircle, CheckCircle, Clock, Filter } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SESSIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/sessions' },
  { name: 'active', label: 'النشطة', path: '/owner/sessions/active' },
  { name: 'completed', label: 'المكتملة', path: '/owner/sessions/completed' },
  { name: 'providers', label: 'المقدمين', path: '/owner/sessions/providers' },
  { name: 'complaints', label: 'الشكاوى', path: '/owner/sessions/complaints' },
  { name: 'ratings', label: 'التقييمات', path: '/owner/sessions/ratings' },
  { name: 'settings', label: 'الإعدادات', path: '/owner/sessions/settings' },
];

interface Complaint {
  id: string;
  session_id: string;
  patient_id: string;
  doctor_id: string;
  complaint_type: string;
  description: string;
  status: string;
  priority: string;
  created_at: string;
  resolved_at?: string;
  patient_name?: string;
  doctor_name?: string;
  appointment_type?: string;
}

export default function SessionComplaints() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [filteredComplaints, setFilteredComplaints] = useState<Complaint[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'resolved'>('all');
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    resolved: 0,
    high_priority: 0,
  });

  useEffect(() => {
    loadComplaints();
  }, []);

  useEffect(() => {
    filterComplaints();
  }, [searchQuery, filterStatus, complaints]);

  async function loadComplaints() {
    try {
      // Since we don't have a complaints table, we'll simulate with appointments that might have issues
      // In a real app, you would have a dedicated complaints/feedback table
      const { data: appointmentsData } = await supabase
        .from('appointments')
        .select(`
          *,
          patient:users!appointments_user_id_fkey(full_name),
          doctor:doctors(full_name)
        `)
        .eq('status', 'cancelled')
        .order('created_at', { ascending: false })
        .limit(50);

      // Transform appointments to complaints format
      const complaintsData = (appointmentsData || []).map(apt => ({
        id: apt.id,
        session_id: apt.id,
        patient_id: apt.user_id,
        doctor_id: apt.doctor_id,
        complaint_type: 'جلسة ملغاة',
        description: apt.notes || 'تم إلغاء الجلسة',
        status: apt.ended_at ? 'resolved' : 'pending',
        priority: 'medium',
        created_at: apt.created_at,
        resolved_at: apt.ended_at,
        patient_name: apt.patient?.full_name || 'غير محدد',
        doctor_name: apt.doctor?.full_name || 'غير محدد',
        appointment_type: apt.appointment_type,
      }));

      const pendingCount = complaintsData.filter(c => c.status === 'pending').length;
      const resolvedCount = complaintsData.filter(c => c.status === 'resolved').length;
      const highPriorityCount = complaintsData.filter(c => c.priority === 'high').length;

      setStats({
        total: complaintsData.length,
        pending: pendingCount,
        resolved: resolvedCount,
        high_priority: highPriorityCount,
      });

      setComplaints(complaintsData);
      setFilteredComplaints(complaintsData);
    } catch (error) {
      console.error('Error loading complaints:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterComplaints() {
    let filtered = complaints;

    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(c => c.status === filterStatus);
    }

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        complaint =>
          complaint.patient_name?.toLowerCase().includes(query) ||
          complaint.doctor_name?.toLowerCase().includes(query) ||
          complaint.complaint_type?.toLowerCase().includes(query) ||
          complaint.description?.toLowerCase().includes(query)
      );
    }

    setFilteredComplaints(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadComplaints();
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'resolved': return '#10b981';
      case 'pending': return '#f59e0b';
      case 'investigating': return '#3b82f6';
      default: return '#64748b';
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'resolved': return 'محلولة';
      case 'pending': return 'قيد المعالجة';
      case 'investigating': return 'قيد التحقيق';
      default: return status;
    }
  }

  function getPriorityColor(priority: string) {
    switch (priority) {
      case 'high': return '#ef4444';
      case 'medium': return '#f59e0b';
      case 'low': return '#3b82f6';
      default: return '#64748b';
    }
  }

  function getPriorityText(priority: string) {
    switch (priority) {
      case 'high': return 'عالية';
      case 'medium': return 'متوسطة';
      case 'low': return 'منخفضة';
      default: return priority;
    }
  }

  function formatDateTime(dateTime: string) {
    return new Date(dateTime).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الشكاوى...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الجلسات" tabs={SESSIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <AlertTriangle size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الشكاوى</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending}</Text>
            <Text style={styles.statLabel}>قيد المعالجة</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.resolved}</Text>
            <Text style={styles.statLabel}>محلولة</Text>
          </View>

          <View style={styles.statCard}>
            <AlertCircle size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.high_priority}</Text>
            <Text style={styles.statLabel}>أولوية عالية</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في الشكاوى..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <View style={styles.filterContainer}>
          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'all' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('all')}>
            <Text style={[styles.filterButtonText, filterStatus === 'all' && styles.filterButtonTextActive]}>
              الكل
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'pending' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('pending')}>
            <Text style={[styles.filterButtonText, filterStatus === 'pending' && styles.filterButtonTextActive]}>
              قيد المعالجة
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.filterButton, filterStatus === 'resolved' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('resolved')}>
            <Text style={[styles.filterButtonText, filterStatus === 'resolved' && styles.filterButtonTextActive]}>
              محلولة
            </Text>
          </TouchableOpacity>
        </View>

        {filteredComplaints.length > 0 ? (
          filteredComplaints.map((complaint) => (
            <View key={complaint.id} style={styles.complaintCard}>
              <View style={styles.complaintHeader}>
                <View style={styles.badgeRow}>
                  <View style={[styles.statusBadge, { backgroundColor: getStatusColor(complaint.status) + '20' }]}>
                    <Text style={[styles.statusText, { color: getStatusColor(complaint.status) }]}>
                      {getStatusText(complaint.status)}
                    </Text>
                  </View>
                  <View style={[styles.priorityBadge, { backgroundColor: getPriorityColor(complaint.priority) + '20' }]}>
                    <AlertCircle size={12} color={getPriorityColor(complaint.priority)} strokeWidth={2} />
                    <Text style={[styles.priorityText, { color: getPriorityColor(complaint.priority) }]}>
                      {getPriorityText(complaint.priority)}
                    </Text>
                  </View>
                </View>
                <Text style={styles.complaintType}>{complaint.complaint_type}</Text>
              </View>

              <View style={styles.complaintDetails}>
                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <User size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>المريض:</Text>
                  </View>
                  <Text style={styles.detailValue}>{complaint.patient_name}</Text>
                </View>

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <User size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>الطبيب:</Text>
                  </View>
                  <Text style={styles.detailValue}>{complaint.doctor_name}</Text>
                </View>

                {complaint.appointment_type && (
                  <View style={styles.detailRow}>
                    <View style={styles.detailLeft}>
                      <MessageSquare size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailLabel}>نوع الجلسة:</Text>
                    </View>
                    <Text style={styles.detailValue}>{complaint.appointment_type}</Text>
                  </View>
                )}

                <View style={styles.detailRow}>
                  <View style={styles.detailLeft}>
                    <Calendar size={16} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailLabel}>تاريخ الإبلاغ:</Text>
                  </View>
                  <Text style={styles.detailValue}>{formatDateTime(complaint.created_at)}</Text>
                </View>

                {complaint.resolved_at && (
                  <View style={styles.detailRow}>
                    <View style={styles.detailLeft}>
                      <CheckCircle size={16} color="#64748b" strokeWidth={2} />
                      <Text style={styles.detailLabel}>تاريخ الحل:</Text>
                    </View>
                    <Text style={styles.detailValue}>{formatDateTime(complaint.resolved_at)}</Text>
                  </View>
                )}
              </View>

              {complaint.description && (
                <View style={styles.descriptionBox}>
                  <View style={styles.descriptionHeader}>
                    <MessageSquare size={14} color="#64748b" strokeWidth={2} />
                    <Text style={styles.descriptionLabel}>وصف الشكوى:</Text>
                  </View>
                  <Text style={styles.descriptionText}>{complaint.description}</Text>
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <AlertTriangle size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery || filterStatus !== 'all' ? 'لا توجد نتائج للبحث' : 'لا توجد شكاوى'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  filterContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
  },
  filterButtonActive: {
    backgroundColor: '#3b82f6',
  },
  filterButtonText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748b',
  },
  filterButtonTextActive: {
    color: '#ffffff',
  },
  complaintCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fed7aa',
  },
  complaintHeader: {
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  badgeRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  priorityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: '600',
  },
  complaintType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  complaintDetails: {
    gap: 10,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
  },
  detailValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'left',
  },
  descriptionBox: {
    backgroundColor: '#fef3c7',
    padding: 12,
    borderRadius: 8,
  },
  descriptionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  descriptionLabel: {
    fontSize: 12,
    color: '#92400e',
    fontWeight: '600',
  },
  descriptionText: {
    fontSize: 13,
    color: '#78350f',
    lineHeight: 20,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
