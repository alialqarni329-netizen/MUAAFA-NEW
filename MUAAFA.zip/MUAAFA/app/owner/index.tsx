import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import {
  Users,
  Building2,
  CreditCard,
  FileText,
  TrendingUp,
  Settings,
  Shield,
  DollarSign,
  ArrowRight,
  Crown,
  Calendar,
  ShoppingCart,
  Bell,
  Lock,
  Activity,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface OwnerStats {
  totalUsers: number;
  totalBusinesses: number;
  totalRevenue: number;
  pendingApprovals: number;
  activeSessions: number;
  totalCommission: number;
}

export default function OwnerDashboard() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [ownerName, setOwnerName] = useState('');
  const [stats, setStats] = useState<OwnerStats>({
    totalUsers: 0,
    totalBusinesses: 0,
    totalRevenue: 0,
    pendingApprovals: 0,
    activeSessions: 0,
    totalCommission: 0,
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    await Promise.all([loadOwnerInfo(), loadStats()]);
    setLoading(false);
  }

  async function loadOwnerInfo() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (user) {
      const { data: userData } = await supabase
        .from('users')
        .select('full_name')
        .eq('id', user.id)
        .maybeSingle();

      if (userData) {
        setOwnerName(userData.full_name || 'المالك');
      }
    }
  }

  async function loadStats() {
    const [
      usersCount,
      businessesCount,
      paymentsData,
      pendingCount,
      sessionsCount,
    ] = await Promise.all([
      supabase.from('users').select('*', { count: 'exact', head: true }),
      supabase
        .from('business_registrations')
        .select('*', { count: 'exact', head: true }),
      supabase.from('payments').select('total_amount, payment_type, payment_status').eq('payment_status', 'completed'),
      supabase
        .from('business_registrations')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending'),
      supabase
        .from('appointments')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'in_progress'),
    ]);

    const totalRevenue =
      paymentsData.data?.reduce((sum, payment) => sum + (Number(payment.total_amount) || 0), 0) || 0;

    const sessionRevenue = paymentsData.data?.filter(p => p.payment_type === 'appointment').reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;
    const pharmacyRevenue = paymentsData.data?.filter(p => p.payment_type === 'pharmacy_order').reduce((sum, p) => sum + (Number(p.total_amount) || 0), 0) || 0;

    const totalCommission = (sessionRevenue * 0.10) + (pharmacyRevenue * 0.07);

    setStats({
      totalUsers: usersCount.count || 0,
      totalBusinesses: businessesCount.count || 0,
      totalRevenue,
      totalCommission,
      pendingApprovals: pendingCount.count || 0,
      activeSessions: sessionsCount.count || 0,
    });
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <View style={styles.header}>
        <View>
          <View style={styles.titleRow}>
            <Crown size={32} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.title}>بوابة المالك</Text>
          </View>
          <Text style={styles.subtitle}>مرحباً {ownerName}</Text>
        </View>
        <View style={styles.badge}>
          <Shield size={16} color="#ffffff" strokeWidth={2} />
          <Text style={styles.badgeText}>Owner</Text>
        </View>
      </View>

      <View style={styles.statsGrid}>
        <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
          <View style={[styles.statIcon, { backgroundColor: '#3b82f6' }]}>
            <Users size={24} color="#ffffff" strokeWidth={2} />
          </View>
          <Text style={styles.statValue}>{stats.totalUsers}</Text>
          <Text style={styles.statLabel}>إجمالي المستخدمين</Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#f3e8ff' }]}>
          <View style={[styles.statIcon, { backgroundColor: '#a855f7' }]}>
            <Building2 size={24} color="#ffffff" strokeWidth={2} />
          </View>
          <Text style={styles.statValue}>{stats.totalBusinesses}</Text>
          <Text style={styles.statLabel}>الجهات التجارية</Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
          <View style={[styles.statIcon, { backgroundColor: '#10b981' }]}>
            <TrendingUp size={24} color="#ffffff" strokeWidth={2} />
          </View>
          <Text style={styles.statValue}>{stats.totalCommission.toFixed(0)} ر.س</Text>
          <Text style={styles.statLabel}>إجمالي العمولة</Text>
        </View>

        <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
          <View style={[styles.statIcon, { backgroundColor: '#f59e0b' }]}>
            <DollarSign size={24} color="#ffffff" strokeWidth={2} />
          </View>
          <Text style={styles.statValue}>{stats.totalRevenue.toFixed(0)} ر.س</Text>
          <Text style={styles.statLabel}>إجمالي الإيرادات</Text>
        </View>
      </View>

      {stats.pendingApprovals > 0 && (
        <TouchableOpacity
          style={styles.alertCard}
          onPress={() => router.push('/owner/business/requests')}
        >
          <View style={styles.alertIcon}>
            <Shield size={20} color="#ef4444" strokeWidth={2} />
          </View>
          <View style={styles.alertContent}>
            <Text style={styles.alertTitle}>طلبات تحتاج موافقة</Text>
            <Text style={styles.alertText}>
              {stats.pendingApprovals} طلب تسجيل جديد بانتظار الموافقة
            </Text>
          </View>
          <ArrowRight size={20} color="#ef4444" strokeWidth={2} />
        </TouchableOpacity>
      )}

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الإدارة الكاملة - Full Access</Text>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/dashboard')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#dbeafe' }]}>
              <Activity size={20} color="#3b82f6" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>لوحة التحكم الرئيسية</Text>
              <Text style={styles.menuItemSubtitle}>
                KPIs، النشاط اليومي، حالة الخدمات
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/users')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#dbeafe' }]}>
              <Users size={20} color="#3b82f6" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>إدارة المستخدمين</Text>
              <Text style={styles.menuItemSubtitle}>
                إدارة كاملة لجميع المستخدمين والصلاحيات
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/business')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#f3e8ff' }]}>
              <Building2 size={20} color="#a855f7" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>إدارة الشركات</Text>
              <Text style={styles.menuItemSubtitle}>
                صيدليات، مستشفيات، شركات تأمين
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>


        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/payments')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#fef3c7' }]}>
              <DollarSign size={20} color="#f59e0b" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>المدفوعات والفواتير</Text>
              <Text style={styles.menuItemSubtitle}>
                الفواتير، المدفوعات، بوابات الدفع
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/content')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#fce7f3' }]}>
              <FileText size={20} color="#ec4899" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>المحتوى الصحي</Text>
              <Text style={styles.menuItemSubtitle}>
                الاستبيانات، الأسئلة، البوت الصحي
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/analytics')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#e0e7ff' }]}>
              <TrendingUp size={20} color="#6366f1" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>التقارير والتحليلات</Text>
              <Text style={styles.menuItemSubtitle}>
                تقارير شاملة، تصدير PDF/Excel
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/sessions')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#dbeafe' }]}>
              <Calendar size={20} color="#3b82f6" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>الجلسات الصحية</Text>
              <Text style={styles.menuItemSubtitle}>
                إدارة الجلسات، مقدمي الخدمة، التقييمات
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/pharmacy')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#d1fae5' }]}>
              <ShoppingCart size={20} color="#10b981" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>الصيدليات والعلاجات</Text>
              <Text style={styles.menuItemSubtitle}>
                الصيدليات، الأدوية، الطلبات
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/notifications')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#fef3c7' }]}>
              <Bell size={20} color="#f59e0b" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>الإشعارات والتواصل</Text>
              <Text style={styles.menuItemSubtitle}>
                SMS، Email، الإشعارات العامة
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/settings')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#e0e7ff' }]}>
              <Settings size={20} color="#6366f1" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>الإعدادات العامة</Text>
              <Text style={styles.menuItemSubtitle}>
                OTP، الدفع، اللغات، النسخ الاحتياطي
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push('/owner/security')}
        >
          <View style={styles.menuItemLeft}>
            <View style={[styles.menuIcon, { backgroundColor: '#fee2e2' }]}>
              <Lock size={20} color="#ef4444" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.menuItemTitle}>الأمان والسجلات</Text>
              <Text style={styles.menuItemSubtitle}>
                سجل الدخول، محاولات الدخول، قيود IP
              </Text>
            </View>
          </View>
          <ArrowRight size={20} color="#94a3b8" strokeWidth={2} />
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={styles.logoutButton}
        onPress={async () => {
          await supabase.auth.signOut();
          router.replace('/auth/login');
        }}
      >
        <Text style={styles.logoutButtonText}>تسجيل الخروج</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
    paddingTop: 60,
    paddingBottom: 40,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'right',
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f59e0b',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  badgeText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    padding: 16,
    borderRadius: 16,
    alignItems: 'center',
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'center',
  },
  alertCard: {
    backgroundColor: '#fee2e2',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    gap: 12,
  },
  alertIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertContent: {
    flex: 1,
  },
  alertTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#dc2626',
    textAlign: 'right',
  },
  alertText: {
    fontSize: 12,
    color: '#991b1b',
    marginTop: 2,
    textAlign: 'right',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  menuItem: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuItemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  menuItemSubtitle: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  logoutButton: {
    backgroundColor: '#fee2e2',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
  },
  logoutButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#dc2626',
  },
});
