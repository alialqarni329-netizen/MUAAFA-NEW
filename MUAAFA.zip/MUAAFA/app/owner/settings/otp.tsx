import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, Switch, TextInput, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { ShieldCheck, Smartphone, Mail, Key } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SETTINGS_TABS = [
  { name: 'general', label: 'عام', path: '/owner/settings' },
  { name: 'google', label: 'Google OAuth', path: '/owner/settings/google' },
  { name: 'login', label: 'تسجيل الدخول', path: '/owner/settings/login' },
  { name: 'otp', label: 'OTP/2FA', path: '/owner/settings/otp' },
  { name: 'languages', label: 'اللغات', path: '/owner/settings/languages' },
  { name: 'themes', label: 'السمات', path: '/owner/settings/themes' },
  { name: 'privacy', label: 'الخصوصية', path: '/owner/settings/privacy' },
  { name: 'terms', label: 'الشروط', path: '/owner/settings/terms' },
  { name: 'backup', label: 'النسخ الاحتياطي', path: '/owner/settings/backup' },
];

interface OTPSettings {
  enabled: boolean;
  method: 'sms' | 'email' | 'authenticator';
  expiry_minutes: number;
  require_for_admin: boolean;
  require_for_sensitive: boolean;
}

export default function OTPSettingsScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [settings, setSettings] = useState<OTPSettings>({
    enabled: false,
    method: 'sms',
    expiry_minutes: 5,
    require_for_admin: true,
    require_for_sensitive: true,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: enabledData } = await supabase.from('app_settings').select('setting_value').eq('setting_key', 'otp_enabled').single();
      const { data: methodData } = await supabase.from('app_settings').select('setting_value').eq('setting_key', 'otp_method').single();
      const { data: expiryData } = await supabase.from('app_settings').select('setting_value').eq('setting_key', 'otp_expiry').single();

      setSettings({
        enabled: enabledData?.setting_value?.enabled ?? false,
        method: methodData?.setting_value?.method ?? 'sms',
        expiry_minutes: expiryData?.setting_value?.minutes ?? 5,
        require_for_admin: true,
        require_for_sensitive: true,
      });
    } catch (error: any) {
      console.error('Error loading OTP settings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadSettings();
    setRefreshing(false);
  }

  async function saveSettings() {
    setSaving(true);
    try {
      const updates = [
        { setting_key: 'otp_enabled', setting_value: { enabled: settings.enabled }, setting_type: 'otp', description: 'Enable OTP/2FA' },
        { setting_key: 'otp_method', setting_value: { method: settings.method }, setting_type: 'otp', description: 'OTP delivery method' },
        { setting_key: 'otp_expiry', setting_value: { minutes: settings.expiry_minutes }, setting_type: 'otp', description: 'OTP expiry time' },
      ];

      for (const update of updates) {
        const { error } = await supabase.from('app_settings').upsert(update, { onConflict: 'setting_key' });
        if (error) throw error;
      }

      Alert.alert('نجح', 'تم حفظ إعدادات OTP بنجاح');
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات: ' + error.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.iconContainer}>
          <ShieldCheck size={48} color="#3b82f6" strokeWidth={2} />
        </View>

        <Text style={styles.pageTitle}>المصادقة الثنائية (OTP/2FA)</Text>
        <Text style={styles.pageDescription}>إعدادات رمز التحقق لمرة واحدة والمصادقة الثنائية</Text>

        <View style={styles.card}>
          <View style={styles.settingRow}>
            <Switch value={settings.enabled} onValueChange={(value) => setSettings({ ...settings, enabled: value })} trackColor={{ false: '#cbd5e1', true: '#3b82f6' }} thumbColor="#ffffff" />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>تفعيل المصادقة الثنائية</Text>
              <Text style={styles.settingDescription}>طلب رمز تحقق إضافي عند تسجيل الدخول</Text>
            </View>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>طريقة الإرسال</Text>
          
          <TouchableOpacity style={[styles.methodCard, settings.method === 'sms' && styles.methodCardActive]} onPress={() => setSettings({ ...settings, method: 'sms' })}>
            <Smartphone size={24} color={settings.method === 'sms' ? '#3b82f6' : '#64748b'} strokeWidth={2} />
            <View style={styles.methodInfo}>
              <Text style={[styles.methodTitle, settings.method === 'sms' && styles.methodTitleActive]}>رسالة نصية (SMS)</Text>
              <Text style={styles.methodDescription}>إرسال الرمز عبر SMS</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.methodCard, settings.method === 'email' && styles.methodCardActive]} onPress={() => setSettings({ ...settings, method: 'email' })}>
            <Mail size={24} color={settings.method === 'email' ? '#3b82f6' : '#64748b'} strokeWidth={2} />
            <View style={styles.methodInfo}>
              <Text style={[styles.methodTitle, settings.method === 'email' && styles.methodTitleActive]}>البريد الإلكتروني</Text>
              <Text style={styles.methodDescription}>إرسال الرمز عبر Email</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.methodCard, settings.method === 'authenticator' && styles.methodCardActive]} onPress={() => setSettings({ ...settings, method: 'authenticator' })}>
            <Key size={24} color={settings.method === 'authenticator' ? '#3b82f6' : '#64748b'} strokeWidth={2} />
            <View style={styles.methodInfo}>
              <Text style={[styles.methodTitle, settings.method === 'authenticator' && styles.methodTitleActive]}>تطبيق المصادقة</Text>
              <Text style={styles.methodDescription}>Google Authenticator أو مشابه</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>إعدادات متقدمة</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>مدة صلاحية الرمز (بالدقائق)</Text>
            <TextInput style={styles.input} value={String(settings.expiry_minutes)} onChangeText={(text) => setSettings({ ...settings, expiry_minutes: parseInt(text) || 5 })} keyboardType="number-pad" textAlign="right" />
            <Text style={styles.helperText}>الوقت المسموح به قبل انتهاء صلاحية الرمز</Text>
          </View>

          <View style={styles.settingRow}>
            <Switch value={settings.require_for_admin} onValueChange={(value) => setSettings({ ...settings, require_for_admin: value })} trackColor={{ false: '#cbd5e1', true: '#3b82f6' }} thumbColor="#ffffff" />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>إلزامي للمديرين</Text>
              <Text style={styles.settingDescription}>طلب OTP لجميع حسابات المديرين</Text>
            </View>
          </View>

          <View style={styles.settingRow}>
            <Switch value={settings.require_for_sensitive} onValueChange={(value) => setSettings({ ...settings, require_for_sensitive: value })} trackColor={{ false: '#cbd5e1', true: '#3b82f6' }} thumbColor="#ffffff" />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>للعمليات الحساسة</Text>
              <Text style={styles.settingDescription}>طلب OTP عند تنفيذ عمليات حساسة</Text>
            </View>
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>معلومات:</Text>
          <Text style={styles.infoText}>
            • المصادقة الثنائية تزيد من أمان الحسابات{'\n'}
            • اختر الطريقة الأنسب للمستخدمين{'\n'}
            • تأكد من اختبار النظام قبل التفعيل الكامل{'\n'}
            • احتفظ بطرق استرجاع بديلة
          </Text>
        </View>

        <TouchableOpacity style={[styles.saveButton, saving && styles.saveButtonDisabled]} onPress={saveSettings} disabled={saving}>
          {saving ? <ActivityIndicator size="small" color="#ffffff" /> : <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  iconContainer: { alignItems: 'center', marginBottom: 16 },
  pageTitle: { fontSize: 24, fontWeight: 'bold', color: '#0f172a', textAlign: 'center', marginBottom: 8 },
  pageDescription: { fontSize: 14, color: '#64748b', textAlign: 'center', marginBottom: 24, lineHeight: 20 },
  card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: '#e2e8f0' },
  cardTitle: { fontSize: 18, fontWeight: 'bold', color: '#0f172a', textAlign: 'right', marginBottom: 16 },
  settingRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
  settingInfo: { flex: 1, marginRight: 12 },
  settingLabel: { fontSize: 16, fontWeight: '600', color: '#0f172a', textAlign: 'right', marginBottom: 4 },
  settingDescription: { fontSize: 13, color: '#64748b', textAlign: 'right' },
  methodCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f8fafc', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 2, borderColor: '#e2e8f0' },
  methodCardActive: { backgroundColor: '#eff6ff', borderColor: '#3b82f6' },
  methodInfo: { flex: 1, marginRight: 12 },
  methodTitle: { fontSize: 16, fontWeight: '600', color: '#64748b', textAlign: 'right', marginBottom: 4 },
  methodTitleActive: { color: '#3b82f6' },
  methodDescription: { fontSize: 13, color: '#94a3b8', textAlign: 'right' },
  inputGroup: { marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', color: '#475569', marginBottom: 8, textAlign: 'right' },
  input: { backgroundColor: '#f8fafc', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, padding: 14, fontSize: 14, color: '#0f172a' },
  helperText: { fontSize: 12, color: '#94a3b8', marginTop: 6, textAlign: 'right' },
  infoCard: { backgroundColor: '#eff6ff', borderRadius: 12, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#bfdbfe' },
  infoTitle: { fontSize: 14, fontWeight: 'bold', color: '#1e40af', marginBottom: 8, textAlign: 'right' },
  infoText: { fontSize: 13, color: '#1e40af', lineHeight: 20, textAlign: 'right' },
  saveButton: { backgroundColor: '#3b82f6', borderRadius: 12, padding: 18, alignItems: 'center', marginTop: 8 },
  saveButtonDisabled: { opacity: 0.6 },
  saveButtonText: { color: '#ffffff', fontSize: 16, fontWeight: 'bold' },
});
