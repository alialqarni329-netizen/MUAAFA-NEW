import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Switch,
  TextInput,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Lock, Shield, Clock, Key } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SETTINGS_TABS = [
  { name: 'general', label: 'عام', path: '/owner/settings' },
  { name: 'google', label: 'Google OAuth', path: '/owner/settings/google' },
  { name: 'login', label: 'تسجيل الدخول', path: '/owner/settings/login' },
  { name: 'otp', label: 'OTP/2FA', path: '/owner/settings/otp' },
  { name: 'languages', label: 'اللغات', path: '/owner/settings/languages' },
  { name: 'themes', label: 'السمات', path: '/owner/settings/themes' },
  { name: 'privacy', label: 'الخصوصية', path: '/owner/settings/privacy' },
  { name: 'terms', label: 'الشروط', path: '/owner/settings/terms' },
  { name: 'backup', label: 'النسخ الاحتياطي', path: '/owner/settings/backup' },
];

interface LoginSettings {
  max_attempts: number;
  lockout_duration: number;
  session_timeout: number;
  force_password_change: boolean;
  require_strong_password: boolean;
  enable_remember_me: boolean;
  password_min_length: number;
}

export default function LoginSettingsScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [settings, setSettings] = useState<LoginSettings>({
    max_attempts: 5,
    lockout_duration: 30,
    session_timeout: 1440,
    force_password_change: false,
    require_strong_password: true,
    enable_remember_me: true,
    password_min_length: 8,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: maxAttemptsData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'login_max_attempts')
        .single();

      const { data: lockoutData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'login_lockout_duration')
        .single();

      const { data: sessionData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'login_session_timeout')
        .single();

      const { data: forcePasswordData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'login_force_password_change')
        .single();

      setSettings({
        max_attempts: maxAttemptsData?.setting_value?.value ?? 5,
        lockout_duration: lockoutData?.setting_value?.value ?? 30,
        session_timeout: sessionData?.setting_value?.value ?? 1440,
        force_password_change: forcePasswordData?.setting_value?.enabled ?? false,
        require_strong_password: true,
        enable_remember_me: true,
        password_min_length: 8,
      });
    } catch (error: any) {
      console.error('Error loading login settings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadSettings();
    setRefreshing(false);
  }

  async function saveSettings() {
    if (settings.max_attempts < 3) {
      Alert.alert('خطأ', 'يجب أن يكون عدد المحاولات 3 على الأقل');
      return;
    }

    if (settings.password_min_length < 6) {
      Alert.alert('خطأ', 'يجب أن يكون الحد الأدنى لطول كلمة المرور 6 أحرف');
      return;
    }

    setSaving(true);

    try {
      const updates = [
        {
          setting_key: 'login_max_attempts',
          setting_value: { value: settings.max_attempts },
          setting_type: 'login',
          description: 'Maximum login attempts before lockout',
        },
        {
          setting_key: 'login_lockout_duration',
          setting_value: { value: settings.lockout_duration },
          setting_type: 'login',
          description: 'Lockout duration in minutes',
        },
        {
          setting_key: 'login_session_timeout',
          setting_value: { value: settings.session_timeout },
          setting_type: 'login',
          description: 'Session timeout in minutes',
        },
        {
          setting_key: 'login_force_password_change',
          setting_value: { enabled: settings.force_password_change },
          setting_type: 'login',
          description: 'Force password change every 90 days',
        },
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from('app_settings')
          .upsert(update, { onConflict: 'setting_key' });

        if (error) throw error;
      }

      Alert.alert('نجح', 'تم حفظ إعدادات تسجيل الدخول بنجاح');
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات: ' + error.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.iconContainer}>
          <Lock size={48} color="#3b82f6" strokeWidth={2} />
        </View>

        <Text style={styles.pageTitle}>إعدادات تسجيل الدخول والأمان</Text>
        <Text style={styles.pageDescription}>
          إدارة إعدادات الأمان وسياسات تسجيل الدخول
        </Text>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Shield size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>الحماية من الهجمات</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>عدد محاولات تسجيل الدخول الفاشلة</Text>
            <TextInput
              style={styles.input}
              value={String(settings.max_attempts)}
              onChangeText={(text) => setSettings({ ...settings, max_attempts: parseInt(text) || 5 })}
              keyboardType="number-pad"
              textAlign="right"
            />
            <Text style={styles.helperText}>الحد الأقصى قبل قفل الحساب مؤقتاً</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>مدة القفل (بالدقائق)</Text>
            <TextInput
              style={styles.input}
              value={String(settings.lockout_duration)}
              onChangeText={(text) => setSettings({ ...settings, lockout_duration: parseInt(text) || 30 })}
              keyboardType="number-pad"
              textAlign="right"
            />
            <Text style={styles.helperText}>مدة قفل الحساب بعد المحاولات الفاشلة</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Clock size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>إدارة الجلسات</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>مهلة انتهاء الجلسة (بالدقائق)</Text>
            <TextInput
              style={styles.input}
              value={String(settings.session_timeout)}
              onChangeText={(text) => setSettings({ ...settings, session_timeout: parseInt(text) || 1440 })}
              keyboardType="number-pad"
              textAlign="right"
            />
            <Text style={styles.helperText}>1440 دقيقة = 24 ساعة</Text>
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.enable_remember_me}
              onValueChange={(value) => setSettings({ ...settings, enable_remember_me: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>تفعيل خيار "تذكرني"</Text>
              <Text style={styles.settingDescription}>
                السماح للمستخدمين بالبقاء مسجلين لمدة أطول
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Key size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>سياسة كلمات المرور</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>الحد الأدنى لطول كلمة المرور</Text>
            <TextInput
              style={styles.input}
              value={String(settings.password_min_length)}
              onChangeText={(text) => setSettings({ ...settings, password_min_length: parseInt(text) || 8 })}
              keyboardType="number-pad"
              textAlign="right"
            />
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.require_strong_password}
              onValueChange={(value) => setSettings({ ...settings, require_strong_password: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>طلب كلمة مرور قوية</Text>
              <Text style={styles.settingDescription}>
                يجب أن تحتوي على أحرف كبيرة وصغيرة وأرقام ورموز
              </Text>
            </View>
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.force_password_change}
              onValueChange={(value) => setSettings({ ...settings, force_password_change: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>إجبار تغيير كلمة المرور</Text>
              <Text style={styles.settingDescription}>
                طلب تغيير كلمة المرور كل 90 يوماً
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>نصائح الأمان:</Text>
          <Text style={styles.infoText}>
            • استخدم عدد محاولات مناسب لمنع الهجمات{'\n'}
            • قم بتفعيل كلمات المرور القوية{'\n'}
            • راقب محاولات تسجيل الدخول الفاشلة{'\n'}
            • استخدم المصادقة الثنائية للحسابات الحساسة
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.saveButton, saving && styles.saveButtonDisabled]}
          onPress={saveSettings}
          disabled={saving}>
          {saving ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  iconContainer: { alignItems: 'center', marginBottom: 16 },
  pageTitle: { fontSize: 24, fontWeight: 'bold', color: '#0f172a', textAlign: 'center', marginBottom: 8 },
  pageDescription: { fontSize: 14, color: '#64748b', textAlign: 'center', marginBottom: 24, lineHeight: 20 },
  card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: '#e2e8f0' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 },
  cardTitle: { fontSize: 18, fontWeight: 'bold', color: '#0f172a', textAlign: 'right', flex: 1 },
  inputGroup: { marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', color: '#475569', marginBottom: 8, textAlign: 'right' },
  input: { backgroundColor: '#f8fafc', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, padding: 14, fontSize: 14, color: '#0f172a' },
  helperText: { fontSize: 12, color: '#94a3b8', marginTop: 6, textAlign: 'right' },
  settingRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
  settingInfo: { flex: 1, marginRight: 12 },
  settingLabel: { fontSize: 16, fontWeight: '600', color: '#0f172a', textAlign: 'right', marginBottom: 4 },
  settingDescription: { fontSize: 13, color: '#64748b', textAlign: 'right' },
  infoCard: { backgroundColor: '#eff6ff', borderRadius: 12, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#bfdbfe' },
  infoTitle: { fontSize: 14, fontWeight: 'bold', color: '#1e40af', marginBottom: 8, textAlign: 'right' },
  infoText: { fontSize: 13, color: '#1e40af', lineHeight: 20, textAlign: 'right' },
  saveButton: { backgroundColor: '#3b82f6', borderRadius: 12, padding: 18, alignItems: 'center', marginTop: 8 },
  saveButtonDisabled: { opacity: 0.6 },
  saveButtonText: { color: '#ffffff', fontSize: 16, fontWeight: 'bold' },
});
