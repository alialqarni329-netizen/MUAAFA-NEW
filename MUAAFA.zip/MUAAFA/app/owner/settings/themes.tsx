import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, Switch, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Palette, Sun, Moon, Smartphone, CheckCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SETTINGS_TABS = [
  { name: 'general', label: 'عام', path: '/owner/settings' },
  { name: 'google', label: 'Google OAuth', path: '/owner/settings/google' },
  { name: 'login', label: 'تسجيل الدخول', path: '/owner/settings/login' },
  { name: 'otp', label: 'OTP/2FA', path: '/owner/settings/otp' },
  { name: 'languages', label: 'اللغات', path: '/owner/settings/languages' },
  { name: 'themes', label: 'السمات', path: '/owner/settings/themes' },
  { name: 'privacy', label: 'الخصوصية', path: '/owner/settings/privacy' },
  { name: 'terms', label: 'الشروط', path: '/owner/settings/terms' },
  { name: 'backup', label: 'النسخ الاحتياطي', path: '/owner/settings/backup' },
];

const THEME_COLORS = [
  { name: 'أزرق', value: '#3b82f6', label: 'Blue' },
  { name: 'بنفسجي', value: '#8b5cf6', label: 'Purple' },
  { name: 'أخضر', value: '#10b981', label: 'Green' },
  { name: 'أحمر', value: '#ef4444', label: 'Red' },
  { name: 'برتقالي', value: '#f97316', label: 'Orange' },
  { name: 'وردي', value: '#ec4899', label: 'Pink' },
];

interface ThemeSettings {
  mode: 'light' | 'dark' | 'auto';
  primary_color: string;
  secondary_color: string;
  allow_user_theme: boolean;
}

export default function ThemeSettingsScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [settings, setSettings] = useState<ThemeSettings>({
    mode: 'light',
    primary_color: '#3b82f6',
    secondary_color: '#64748b',
    allow_user_theme: false,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: modeData } = await supabase.from('app_settings').select('setting_value').eq('setting_key', 'theme_mode').single();
      const { data: primaryData } = await supabase.from('app_settings').select('setting_value').eq('setting_key', 'theme_primary_color').single();
      const { data: secondaryData } = await supabase.from('app_settings').select('setting_value').eq('setting_key', 'theme_secondary_color').single();

      setSettings({
        mode: modeData?.setting_value?.mode ?? 'light',
        primary_color: primaryData?.setting_value?.color ?? '#3b82f6',
        secondary_color: secondaryData?.setting_value?.color ?? '#64748b',
        allow_user_theme: false,
      });
    } catch (error: any) {
      console.error('Error loading theme settings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadSettings();
    setRefreshing(false);
  }

  async function saveSettings() {
    setSaving(true);
    try {
      const updates = [
        { setting_key: 'theme_mode', setting_value: { mode: settings.mode }, setting_type: 'themes', description: 'Theme mode' },
        { setting_key: 'theme_primary_color', setting_value: { color: settings.primary_color }, setting_type: 'themes', description: 'Primary theme color' },
        { setting_key: 'theme_secondary_color', setting_value: { color: settings.secondary_color }, setting_type: 'themes', description: 'Secondary theme color' },
      ];

      for (const update of updates) {
        const { error } = await supabase.from('app_settings').upsert(update, { onConflict: 'setting_key' });
        if (error) throw error;
      }

      Alert.alert('نجح', 'تم حفظ إعدادات السمات بنجاح');
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات: ' + error.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.iconContainer}>
          <Palette size={48} color="#3b82f6" strokeWidth={2} />
        </View>

        <Text style={styles.pageTitle}>إعدادات السمات والمظهر</Text>
        <Text style={styles.pageDescription}>تخصيص مظهر التطبيق والألوان</Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>وضع العرض</Text>
          <View style={styles.modeOptions}>
            <TouchableOpacity style={[styles.modeCard, settings.mode === 'light' && styles.modeCardActive]} onPress={() => setSettings({ ...settings, mode: 'light' })}>
              <Sun size={32} color={settings.mode === 'light' ? '#3b82f6' : '#64748b'} strokeWidth={2} />
              <Text style={[styles.modeText, settings.mode === 'light' && styles.modeTextActive]}>فاتح</Text>
              {settings.mode === 'light' && <CheckCircle size={20} color="#3b82f6" strokeWidth={2} style={styles.checkIcon} />}
            </TouchableOpacity>

            <TouchableOpacity style={[styles.modeCard, settings.mode === 'dark' && styles.modeCardActive]} onPress={() => setSettings({ ...settings, mode: 'dark' })}>
              <Moon size={32} color={settings.mode === 'dark' ? '#3b82f6' : '#64748b'} strokeWidth={2} />
              <Text style={[styles.modeText, settings.mode === 'dark' && styles.modeTextActive]}>داكن</Text>
              {settings.mode === 'dark' && <CheckCircle size={20} color="#3b82f6" strokeWidth={2} style={styles.checkIcon} />}
            </TouchableOpacity>

            <TouchableOpacity style={[styles.modeCard, settings.mode === 'auto' && styles.modeCardActive]} onPress={() => setSettings({ ...settings, mode: 'auto' })}>
              <Smartphone size={32} color={settings.mode === 'auto' ? '#3b82f6' : '#64748b'} strokeWidth={2} />
              <Text style={[styles.modeText, settings.mode === 'auto' && styles.modeTextActive]}>تلقائي</Text>
              {settings.mode === 'auto' && <CheckCircle size={20} color="#3b82f6" strokeWidth={2} style={styles.checkIcon} />}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>اللون الأساسي</Text>
          <View style={styles.colorGrid}>
            {THEME_COLORS.map((color) => (
              <TouchableOpacity key={color.value} style={[styles.colorCard, settings.primary_color === color.value && styles.colorCardActive]} onPress={() => setSettings({ ...settings, primary_color: color.value })}>
                <View style={[styles.colorCircle, { backgroundColor: color.value }]}>
                  {settings.primary_color === color.value && <CheckCircle size={24} color="#ffffff" strokeWidth={3} />}
                </View>
                <Text style={styles.colorName}>{color.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>الإعدادات الإضافية</Text>

          <View style={styles.settingRow}>
            <Switch value={settings.allow_user_theme} onValueChange={(value) => setSettings({ ...settings, allow_user_theme: value })} trackColor={{ false: '#cbd5e1', true: '#3b82f6' }} thumbColor="#ffffff" />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>السماح للمستخدمين بتخصيص السمة</Text>
              <Text style={styles.settingDescription}>السماح للمستخدمين باختيار السمة الخاصة بهم</Text>
            </View>
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>معلومات:</Text>
          <Text style={styles.infoText}>
            • الوضع التلقائي يتبع إعدادات النظام{'\n'}
            • التغييرات تطبق فوراً على التطبيق{'\n'}
            • يمكن للمستخدمين تجاوز الإعدادات إذا سمحت لهم{'\n'}
            • تأكد من اختيار ألوان متناسقة مع العلامة التجارية
          </Text>
        </View>

        <TouchableOpacity style={[styles.saveButton, saving && styles.saveButtonDisabled]} onPress={saveSettings} disabled={saving}>
          {saving ? <ActivityIndicator size="small" color="#ffffff" /> : <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  iconContainer: { alignItems: 'center', marginBottom: 16 },
  pageTitle: { fontSize: 24, fontWeight: 'bold', color: '#0f172a', textAlign: 'center', marginBottom: 8 },
  pageDescription: { fontSize: 14, color: '#64748b', textAlign: 'center', marginBottom: 24, lineHeight: 20 },
  card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: '#e2e8f0' },
  cardTitle: { fontSize: 18, fontWeight: 'bold', color: '#0f172a', textAlign: 'right', marginBottom: 16 },
  modeOptions: { flexDirection: 'row', gap: 12 },
  modeCard: { flex: 1, backgroundColor: '#f8fafc', borderRadius: 12, padding: 16, alignItems: 'center', borderWidth: 2, borderColor: '#e2e8f0', position: 'relative' },
  modeCardActive: { backgroundColor: '#eff6ff', borderColor: '#3b82f6' },
  modeText: { fontSize: 14, fontWeight: '600', color: '#64748b', marginTop: 8 },
  modeTextActive: { color: '#3b82f6' },
  checkIcon: { position: 'absolute', top: 8, right: 8 },
  colorGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  colorCard: { width: '30%', alignItems: 'center', padding: 8 },
  colorCardActive: { },
  colorCircle: { width: 60, height: 60, borderRadius: 30, justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  colorName: { fontSize: 13, color: '#64748b', textAlign: 'center' },
  settingRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
  settingInfo: { flex: 1, marginRight: 12 },
  settingLabel: { fontSize: 16, fontWeight: '600', color: '#0f172a', textAlign: 'right', marginBottom: 4 },
  settingDescription: { fontSize: 13, color: '#64748b', textAlign: 'right' },
  infoCard: { backgroundColor: '#eff6ff', borderRadius: 12, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#bfdbfe' },
  infoTitle: { fontSize: 14, fontWeight: 'bold', color: '#1e40af', marginBottom: 8, textAlign: 'right' },
  infoText: { fontSize: 13, color: '#1e40af', lineHeight: 20, textAlign: 'right' },
  saveButton: { backgroundColor: '#3b82f6', borderRadius: 12, padding: 18, alignItems: 'center', marginTop: 8 },
  saveButtonDisabled: { opacity: 0.6 },
  saveButtonText: { color: '#ffffff', fontSize: 16, fontWeight: 'bold' },
});
