import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Switch,
  TextInput,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Chrome, Key, Shield, CheckCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SETTINGS_TABS = [
  { name: 'general', label: 'عام', path: '/owner/settings' },
  { name: 'google', label: 'Google OAuth', path: '/owner/settings/google' },
  { name: 'login', label: 'تسجيل الدخول', path: '/owner/settings/login' },
  { name: 'otp', label: 'OTP/2FA', path: '/owner/settings/otp' },
  { name: 'languages', label: 'اللغات', path: '/owner/settings/languages' },
  { name: 'themes', label: 'السمات', path: '/owner/settings/themes' },
  { name: 'privacy', label: 'الخصوصية', path: '/owner/settings/privacy' },
  { name: 'terms', label: 'الشروط', path: '/owner/settings/terms' },
  { name: 'backup', label: 'النسخ الاحتياطي', path: '/owner/settings/backup' },
];

interface GoogleOAuthSettings {
  enabled: boolean;
  client_id: string;
  client_secret: string;
  redirect_uri: string;
  allow_signup: boolean;
  auto_verify_email: boolean;
}

export default function GoogleOAuthSettingsScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [settings, setSettings] = useState<GoogleOAuthSettings>({
    enabled: false,
    client_id: '',
    client_secret: '',
    redirect_uri: '',
    allow_signup: true,
    auto_verify_email: true,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: enabledData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'google_oauth_enabled')
        .single();

      const { data: clientIdData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'google_client_id')
        .single();

      const { data: clientSecretData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'google_client_secret')
        .single();

      setSettings({
        enabled: enabledData?.setting_value?.enabled ?? false,
        client_id: clientIdData?.setting_value?.value ?? '',
        client_secret: clientSecretData?.setting_value?.value ?? '',
        redirect_uri: 'https://your-app.com/auth/callback',
        allow_signup: true,
        auto_verify_email: true,
      });
    } catch (error: any) {
      console.error('Error loading Google OAuth settings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadSettings();
    setRefreshing(false);
  }

  async function saveSettings() {
    if (settings.enabled && (!settings.client_id || !settings.client_secret)) {
      Alert.alert('خطأ', 'يجب إدخال معرف العميل والسر السري');
      return;
    }

    setSaving(true);

    try {
      const updates = [
        {
          setting_key: 'google_oauth_enabled',
          setting_value: { enabled: settings.enabled },
          setting_type: 'google_oauth',
          description: 'Enable/disable Google OAuth',
        },
        {
          setting_key: 'google_client_id',
          setting_value: { value: settings.client_id },
          setting_type: 'google_oauth',
          description: 'Google OAuth Client ID',
        },
        {
          setting_key: 'google_client_secret',
          setting_value: { value: settings.client_secret },
          setting_type: 'google_oauth',
          description: 'Google OAuth Client Secret',
        },
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from('app_settings')
          .upsert(update, { onConflict: 'setting_key' });

        if (error) throw error;
      }

      Alert.alert('نجح', 'تم حفظ إعدادات Google OAuth بنجاح');
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات: ' + error.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.iconContainer}>
          <Chrome size={48} color="#3b82f6" strokeWidth={2} />
        </View>

        <Text style={styles.pageTitle}>إعدادات Google OAuth</Text>
        <Text style={styles.pageDescription}>
          تكوين تسجيل الدخول باستخدام حساب Google للمستخدمين
        </Text>

        {/* Status Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <CheckCircle size={24} color={settings.enabled ? '#10b981' : '#94a3b8'} strokeWidth={2} />
            <Text style={styles.cardTitle}>حالة التكامل</Text>
          </View>

          <View style={styles.statusRow}>
            <Text style={styles.statusLabel}>الحالة:</Text>
            <Text
              style={[
                styles.statusValue,
                settings.enabled ? styles.statusActive : styles.statusInactive,
              ]}>
              {settings.enabled ? 'مفعل' : 'غير مفعل'}
            </Text>
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.enabled}
              onValueChange={(value) => setSettings({ ...settings, enabled: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>تفعيل Google OAuth</Text>
              <Text style={styles.settingDescription}>
                السماح للمستخدمين بتسجيل الدخول باستخدام حساب Google
              </Text>
            </View>
          </View>
        </View>

        {/* Credentials */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Key size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>بيانات الاعتماد</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>معرف العميل (Client ID)</Text>
            <TextInput
              style={styles.input}
              value={settings.client_id}
              onChangeText={(text) => setSettings({ ...settings, client_id: text })}
              placeholder="123456789-abc123.apps.googleusercontent.com"
              textAlign="right"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>السر السري (Client Secret)</Text>
            <TextInput
              style={styles.input}
              value={settings.client_secret}
              onChangeText={(text) => setSettings({ ...settings, client_secret: text })}
              placeholder="GOCSPX-xxxxxxxxxxxxx"
              textAlign="right"
              secureTextEntry
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>رابط إعادة التوجيه (Redirect URI)</Text>
            <TextInput
              style={[styles.input, styles.inputDisabled]}
              value={settings.redirect_uri}
              textAlign="right"
              editable={false}
            />
            <Text style={styles.helperText}>
              استخدم هذا الرابط في Google Cloud Console
            </Text>
          </View>
        </View>

        {/* Additional Settings */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Shield size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>الإعدادات الإضافية</Text>
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.allow_signup}
              onValueChange={(value) => setSettings({ ...settings, allow_signup: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>السماح بالتسجيل</Text>
              <Text style={styles.settingDescription}>
                إنشاء حسابات جديدة تلقائياً عند تسجيل الدخول لأول مرة
              </Text>
            </View>
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.auto_verify_email}
              onValueChange={(value) => setSettings({ ...settings, auto_verify_email: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>التحقق التلقائي من البريد</Text>
              <Text style={styles.settingDescription}>
                اعتبار البريد الإلكتروني موثقاً تلقائياً عند تسجيل الدخول بـ Google
              </Text>
            </View>
          </View>
        </View>

        {/* Instructions */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>كيفية الحصول على بيانات الاعتماد:</Text>
          <Text style={styles.infoText}>
            1. انتقل إلى Google Cloud Console{'\n'}
            2. قم بإنشاء مشروع جديد أو اختر مشروع موجود{'\n'}
            3. فعّل Google+ API{'\n'}
            4. أنشئ OAuth 2.0 Client ID{'\n'}
            5. انسخ Client ID و Client Secret{'\n'}
            6. أضف Redirect URI في Google Console
          </Text>
        </View>

        {/* Save Button */}
        <TouchableOpacity
          style={[styles.saveButton, saving && styles.saveButtonDisabled]}
          onPress={saveSettings}
          disabled={saving}>
          {saving ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  iconContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 8,
  },
  pageDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    flex: 1,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
    marginBottom: 12,
  },
  statusLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  statusValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
  },
  statusActive: {
    color: '#10b981',
  },
  statusInactive: {
    color: '#94a3b8',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  settingInfo: {
    flex: 1,
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 14,
    color: '#0f172a',
  },
  inputDisabled: {
    backgroundColor: '#f1f5f9',
    color: '#64748b',
  },
  helperText: {
    fontSize: 12,
    color: '#94a3b8',
    marginTop: 6,
    textAlign: 'right',
  },
  infoCard: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#bfdbfe',
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 8,
    textAlign: 'right',
  },
  infoText: {
    fontSize: 13,
    color: '#1e40af',
    lineHeight: 20,
    textAlign: 'right',
  },
  saveButton: {
    backgroundColor: '#3b82f6',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
