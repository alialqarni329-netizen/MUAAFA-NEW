import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Switch,
  TextInput,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Settings, DollarSign, MessageSquare, Key } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SETTINGS_TABS = [
  { name: 'general', label: 'عام', path: '/owner/settings' },
  { name: 'google', label: 'Google OAuth', path: '/owner/settings/google' },
  { name: 'login', label: 'تسجيل الدخول', path: '/owner/settings/login' },
  { name: 'otp', label: 'OTP/2FA', path: '/owner/settings/otp' },
  { name: 'languages', label: 'اللغات', path: '/owner/settings/languages' },
  { name: 'themes', label: 'السمات', path: '/owner/settings/themes' },
  { name: 'privacy', label: 'الخصوصية', path: '/owner/settings/privacy' },
  { name: 'terms', label: 'الشروط', path: '/owner/settings/terms' },
  { name: 'backup', label: 'النسخ الاحتياطي', path: '/owner/settings/backup' },
];

interface GeneralSettings {
  app_name: string;
  app_version: string;
  zidpay_api_key: string;
  zidpay_secret: string;
  chatgpt_api_key: string;
  chatgpt_model: string;
  maintenance_mode: boolean;
}

export default function GeneralSettingsScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [settings, setSettings] = useState<GeneralSettings>({
    app_name: 'HealthCare App',
    app_version: '1.0.0',
    zidpay_api_key: '',
    zidpay_secret: '',
    chatgpt_api_key: '',
    chatgpt_model: 'gpt-4',
    maintenance_mode: false,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: zidpayKeyData } = await supabase
        .from('system_config')
        .select('config_value')
        .eq('config_key', 'zidpay_api_key')
        .single();

      const { data: zidpaySecretData } = await supabase
        .from('system_config')
        .select('config_value')
        .eq('config_key', 'zidpay_secret')
        .single();

      const { data: chatgptKeyData } = await supabase
        .from('system_config')
        .select('config_value')
        .eq('config_key', 'chatgpt_api_key')
        .single();

      const { data: chatgptModelData } = await supabase
        .from('system_config')
        .select('config_value')
        .eq('config_key', 'chatgpt_model')
        .single();

      setSettings({
        app_name: 'HealthCare App',
        app_version: '1.0.0',
        zidpay_api_key: zidpayKeyData?.config_value?.key ?? '',
        zidpay_secret: zidpaySecretData?.config_value?.secret ?? '',
        chatgpt_api_key: chatgptKeyData?.config_value?.key ?? '',
        chatgpt_model: chatgptModelData?.config_value?.model ?? 'gpt-4',
        maintenance_mode: false,
      });
    } catch (error: any) {
      console.error('Error loading general settings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadSettings();
    setRefreshing(false);
  }

  async function saveSettings() {
    setSaving(true);

    try {
      const updates = [
        {
          config_key: 'zidpay_api_key',
          config_value: { key: settings.zidpay_api_key },
          category: 'api',
        },
        {
          config_key: 'zidpay_secret',
          config_value: { secret: settings.zidpay_secret },
          category: 'api',
        },
        {
          config_key: 'chatgpt_api_key',
          config_value: { key: settings.chatgpt_api_key },
          category: 'api',
        },
        {
          config_key: 'chatgpt_model',
          config_value: { model: settings.chatgpt_model },
          category: 'api',
        },
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from('system_config')
          .upsert(update, { onConflict: 'config_key' });

        if (error) throw error;
      }

      Alert.alert('نجح', 'تم حفظ الإعدادات العامة بنجاح');
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات: ' + error.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.iconContainer}>
          <Settings size={48} color="#3b82f6" strokeWidth={2} />
        </View>

        <Text style={styles.pageTitle}>الإعدادات العامة</Text>
        <Text style={styles.pageDescription}>
          إدارة الإعدادات الأساسية للتطبيق والخدمات الخارجية
        </Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>معلومات التطبيق</Text>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>اسم التطبيق</Text>
            <TextInput
              style={styles.input}
              value={settings.app_name}
              onChangeText={(text) => setSettings({ ...settings, app_name: text })}
              textAlign="right"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>رقم الإصدار</Text>
            <TextInput
              style={[styles.input, styles.inputDisabled]}
              value={settings.app_version}
              editable={false}
              textAlign="right"
            />
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.maintenance_mode}
              onValueChange={(value) => setSettings({ ...settings, maintenance_mode: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>وضع الصيانة</Text>
              <Text style={styles.settingDescription}>
                تعطيل التطبيق مؤقتاً للصيانة
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <DollarSign size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>إعدادات ZidPay</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>مفتاح API</Text>
            <TextInput
              style={styles.input}
              value={settings.zidpay_api_key}
              onChangeText={(text) => setSettings({ ...settings, zidpay_api_key: text })}
              placeholder="أدخل مفتاح API"
              textAlign="right"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>السر السري</Text>
            <TextInput
              style={styles.input}
              value={settings.zidpay_secret}
              onChangeText={(text) => setSettings({ ...settings, zidpay_secret: text })}
              placeholder="أدخل السر السري"
              secureTextEntry
              textAlign="right"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <MessageSquare size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>إعدادات ChatGPT API</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>مفتاح API</Text>
            <TextInput
              style={styles.input}
              value={settings.chatgpt_api_key}
              onChangeText={(text) => setSettings({ ...settings, chatgpt_api_key: text })}
              placeholder="sk-..."
              secureTextEntry
              textAlign="right"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>نموذج ChatGPT</Text>
            <TextInput
              style={styles.input}
              value={settings.chatgpt_model}
              onChangeText={(text) => setSettings({ ...settings, chatgpt_model: text })}
              placeholder="gpt-4"
              textAlign="right"
            />
            <Text style={styles.helperText}>مثال: gpt-4, gpt-3.5-turbo</Text>
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>معلومات مهمة:</Text>
          <Text style={styles.infoText}>
            • احتفظ بمفاتيح API آمنة ولا تشاركها{'\n'}
            • تأكد من صلاحية المفاتيح قبل الحفظ{'\n'}
            • وضع الصيانة يمنع المستخدمين من الدخول{'\n'}
            • راجع الوثائق لمزيد من المعلومات
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.saveButton, saving && styles.saveButtonDisabled]}
          onPress={saveSettings}
          disabled={saving}>
          {saving ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  iconContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 8,
  },
  pageDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    flex: 1,
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 14,
    color: '#0f172a',
  },
  inputDisabled: {
    backgroundColor: '#f1f5f9',
    color: '#64748b',
  },
  helperText: {
    fontSize: 12,
    color: '#94a3b8',
    marginTop: 6,
    textAlign: 'right',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  settingInfo: {
    flex: 1,
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  infoCard: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#bfdbfe',
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 8,
    textAlign: 'right',
  },
  infoText: {
    fontSize: 13,
    color: '#1e40af',
    lineHeight: 20,
    textAlign: 'right',
  },
  saveButton: {
    backgroundColor: '#3b82f6',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
