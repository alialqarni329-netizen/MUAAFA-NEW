import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Switch,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Languages, Globe, CheckCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SETTINGS_TABS = [
  { name: 'general', label: 'عام', path: '/owner/settings' },
  { name: 'google', label: 'Google OAuth', path: '/owner/settings/google' },
  { name: 'login', label: 'تسجيل الدخول', path: '/owner/settings/login' },
  { name: 'otp', label: 'OTP/2FA', path: '/owner/settings/otp' },
  { name: 'languages', label: 'اللغات', path: '/owner/settings/languages' },
  { name: 'themes', label: 'السمات', path: '/owner/settings/themes' },
  { name: 'privacy', label: 'الخصوصية', path: '/owner/settings/privacy' },
  { name: 'terms', label: 'الشروط', path: '/owner/settings/terms' },
  { name: 'backup', label: 'النسخ الاحتياطي', path: '/owner/settings/backup' },
];

interface LanguageOption {
  code: string;
  name: string;
  nativeName: string;
  rtl: boolean;
}

const AVAILABLE_LANGUAGES: LanguageOption[] = [
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', rtl: true },
  { code: 'en', name: 'English', nativeName: 'English', rtl: false },
  { code: 'fr', name: 'French', nativeName: 'Français', rtl: false },
  { code: 'de', name: 'German', nativeName: 'Deutsch', rtl: false },
  { code: 'es', name: 'Spanish', nativeName: 'Español', rtl: false },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', rtl: false },
];

interface LanguageSettings {
  default_language: string;
  supported_languages: string[];
  rtl_enabled: boolean;
  auto_detect: boolean;
}

export default function LanguageSettingsScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [settings, setSettings] = useState<LanguageSettings>({
    default_language: 'ar',
    supported_languages: ['ar', 'en'],
    rtl_enabled: true,
    auto_detect: false,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: defaultLangData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'default_language')
        .single();

      const { data: supportedLangsData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'supported_languages')
        .single();

      const { data: rtlData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'rtl_enabled')
        .single();

      setSettings({
        default_language: defaultLangData?.setting_value?.language ?? 'ar',
        supported_languages: supportedLangsData?.setting_value?.languages ?? ['ar', 'en'],
        rtl_enabled: rtlData?.setting_value?.enabled ?? true,
        auto_detect: false,
      });
    } catch (error: any) {
      console.error('Error loading language settings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadSettings();
    setRefreshing(false);
  }

  async function saveSettings() {
    if (settings.supported_languages.length === 0) {
      Alert.alert('خطأ', 'يجب اختيار لغة واحدة على الأقل');
      return;
    }

    if (!settings.supported_languages.includes(settings.default_language)) {
      Alert.alert('خطأ', 'يجب أن تكون اللغة الافتراضية ضمن اللغات المدعومة');
      return;
    }

    setSaving(true);

    try {
      const updates = [
        {
          setting_key: 'default_language',
          setting_value: { language: settings.default_language },
          setting_type: 'languages',
          description: 'Default application language',
        },
        {
          setting_key: 'supported_languages',
          setting_value: { languages: settings.supported_languages },
          setting_type: 'languages',
          description: 'Supported languages',
        },
        {
          setting_key: 'rtl_enabled',
          setting_value: { enabled: settings.rtl_enabled },
          setting_type: 'languages',
          description: 'Enable RTL support',
        },
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from('app_settings')
          .upsert(update, { onConflict: 'setting_key' });

        if (error) throw error;
      }

      Alert.alert('نجح', 'تم حفظ إعدادات اللغات بنجاح');
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات: ' + error.message);
    } finally {
      setSaving(false);
    }
  }

  function toggleLanguageSupport(code: string) {
    if (settings.supported_languages.includes(code)) {
      setSettings({
        ...settings,
        supported_languages: settings.supported_languages.filter((l) => l !== code),
      });
    } else {
      setSettings({
        ...settings,
        supported_languages: [...settings.supported_languages, code],
      });
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.iconContainer}>
          <Languages size={48} color="#3b82f6" strokeWidth={2} />
        </View>

        <Text style={styles.pageTitle}>إعدادات اللغة والترجمة</Text>
        <Text style={styles.pageDescription}>
          إدارة اللغات المدعومة وإعدادات الترجمة في التطبيق
        </Text>

        {/* Default Language */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Globe size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>اللغة الافتراضية</Text>
          </View>

          <View style={styles.languageGrid}>
            {AVAILABLE_LANGUAGES.map((lang) => (
              <TouchableOpacity
                key={lang.code}
                style={[
                  styles.languageCard,
                  settings.default_language === lang.code && styles.languageCardActive,
                ]}
                onPress={() => setSettings({ ...settings, default_language: lang.code })}>
                {settings.default_language === lang.code && (
                  <View style={styles.checkBadge}>
                    <CheckCircle size={16} color="#10b981" strokeWidth={2} />
                  </View>
                )}
                <Text style={styles.languageNative}>{lang.nativeName}</Text>
                <Text style={styles.languageName}>{lang.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Supported Languages */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>اللغات المدعومة</Text>
          <Text style={styles.cardDescription}>
            اختر اللغات التي سيدعمها التطبيق
          </Text>

          {AVAILABLE_LANGUAGES.map((lang) => (
            <View key={lang.code} style={styles.settingRow}>
              <Switch
                value={settings.supported_languages.includes(lang.code)}
                onValueChange={() => toggleLanguageSupport(lang.code)}
                trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
                thumbColor="#ffffff"
              />
              <View style={styles.settingInfo}>
                <Text style={styles.settingLabel}>{lang.nativeName}</Text>
                <Text style={styles.settingDescription}>
                  {lang.name} {lang.rtl && '(RTL)'}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* RTL Settings */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>إعدادات الاتجاه</Text>

          <View style={styles.settingRow}>
            <Switch
              value={settings.rtl_enabled}
              onValueChange={(value) => setSettings({ ...settings, rtl_enabled: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>تفعيل RTL</Text>
              <Text style={styles.settingDescription}>
                دعم الكتابة من اليمين إلى اليسار للغات العربية
              </Text>
            </View>
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.auto_detect}
              onValueChange={(value) => setSettings({ ...settings, auto_detect: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>الكشف التلقائي</Text>
              <Text style={styles.settingDescription}>
                اكتشاف لغة المستخدم تلقائياً من إعدادات الجهاز
              </Text>
            </View>
          </View>
        </View>

        {/* Info */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>معلومات:</Text>
          <Text style={styles.infoText}>
            • اللغة الافتراضية ستظهر لجميع المستخدمين الجدد{'\n'}
            • يمكن للمستخدمين تغيير اللغة من حساباتهم{'\n'}
            • اللغات غير المدعومة لن تظهر في قائمة الاختيار{'\n'}
            • تأكد من توفر الترجمات لجميع اللغات المدعومة
          </Text>
        </View>

        {/* Save Button */}
        <TouchableOpacity
          style={[styles.saveButton, saving && styles.saveButtonDisabled]}
          onPress={saveSettings}
          disabled={saving}>
          {saving ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  iconContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 8,
  },
  pageDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    flex: 1,
    marginBottom: 8,
  },
  cardDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
    marginBottom: 16,
  },
  languageGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  languageCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    position: 'relative',
  },
  languageCardActive: {
    backgroundColor: '#eff6ff',
    borderColor: '#3b82f6',
  },
  checkBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  languageNative: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 4,
  },
  languageName: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'center',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  settingInfo: {
    flex: 1,
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  infoCard: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#bfdbfe',
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 8,
    textAlign: 'right',
  },
  infoText: {
    fontSize: 13,
    color: '#1e40af',
    lineHeight: 20,
    textAlign: 'right',
  },
  saveButton: {
    backgroundColor: '#3b82f6',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
