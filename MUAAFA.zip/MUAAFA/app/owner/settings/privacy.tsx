import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, TextInput, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { FileText, Link, Calendar } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SETTINGS_TABS = [
  { name: 'general', label: 'عام', path: '/owner/settings' },
  { name: 'google', label: 'Google OAuth', path: '/owner/settings/google' },
  { name: 'login', label: 'تسجيل الدخول', path: '/owner/settings/login' },
  { name: 'otp', label: 'OTP/2FA', path: '/owner/settings/otp' },
  { name: 'languages', label: 'اللغات', path: '/owner/settings/languages' },
  { name: 'themes', label: 'السمات', path: '/owner/settings/themes' },
  { name: 'privacy', label: 'الخصوصية', path: '/owner/settings/privacy' },
  { name: 'terms', label: 'الشروط', path: '/owner/settings/terms' },
  { name: 'backup', label: 'النسخ الاحتياطي', path: '/owner/settings/backup' },
];

interface PrivacySettings {
  policy_url: string;
  policy_version: string;
  policy_content: string;
  last_updated: string;
}

export default function PrivacyPolicyScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [settings, setSettings] = useState<PrivacySettings>({
    policy_url: '',
    policy_version: '1.0',
    policy_content: '',
    last_updated: new Date().toISOString(),
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: urlData } = await supabase.from('app_settings').select('setting_value').eq('setting_key', 'privacy_policy_url').single();
      const { data: versionData } = await supabase.from('app_settings').select('setting_value').eq('setting_key', 'privacy_policy_version').single();

      setSettings({
        policy_url: urlData?.setting_value?.url ?? '',
        policy_version: versionData?.setting_value?.version ?? '1.0',
        policy_content: '',
        last_updated: new Date().toISOString(),
      });
    } catch (error: any) {
      console.error('Error loading privacy settings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadSettings();
    setRefreshing(false);
  }

  async function saveSettings() {
    setSaving(true);
    try {
      const updates = [
        { setting_key: 'privacy_policy_url', setting_value: { url: settings.policy_url }, setting_type: 'privacy', description: 'Privacy policy URL' },
        { setting_key: 'privacy_policy_version', setting_value: { version: settings.policy_version }, setting_type: 'privacy', description: 'Privacy policy version' },
      ];

      for (const update of updates) {
        const { error } = await supabase.from('app_settings').upsert(update, { onConflict: 'setting_key' });
        if (error) throw error;
      }

      Alert.alert('نجح', 'تم حفظ إعدادات سياسة الخصوصية بنجاح');
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات: ' + error.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.iconContainer}>
          <FileText size={48} color="#3b82f6" strokeWidth={2} />
        </View>

        <Text style={styles.pageTitle}>سياسة الخصوصية</Text>
        <Text style={styles.pageDescription}>إدارة سياسة الخصوصية وحماية البيانات</Text>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Link size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>معلومات السياسة</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>رابط سياسة الخصوصية</Text>
            <TextInput style={styles.input} value={settings.policy_url} onChangeText={(text) => setSettings({ ...settings, policy_url: text })} placeholder="https://example.com/privacy" textAlign="right" />
            <Text style={styles.helperText}>الرابط الكامل لصفحة سياسة الخصوصية</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>إصدار السياسة</Text>
            <TextInput style={styles.input} value={settings.policy_version} onChangeText={(text) => setSettings({ ...settings, policy_version: text })} placeholder="1.0" textAlign="right" />
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>آخر تحديث:</Text>
            <Text style={styles.infoValue}>{new Date(settings.last_updated).toLocaleDateString('ar-SA')}</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Calendar size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>محتوى السياسة</Text>
          </View>

          <TextInput style={[styles.input, styles.textArea]} value={settings.policy_content} onChangeText={(text) => setSettings({ ...settings, policy_content: text })} placeholder="اكتب محتوى سياسة الخصوصية هنا..." multiline numberOfLines={10} textAlign="right" />
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>ما يجب تضمينه في سياسة الخصوصية:</Text>
          <Text style={styles.infoText}>
            • نوع البيانات التي يتم جمعها{'\n'}
            • كيفية استخدام البيانات{'\n'}
            • مدة الاحتفاظ بالبيانات{'\n'}
            • حقوق المستخدمين{'\n'}
            • معلومات الاتصال{'\n'}
            • سياسة ملفات تعريف الارتباط
          </Text>
        </View>

        <TouchableOpacity style={[styles.saveButton, saving && styles.saveButtonDisabled]} onPress={saveSettings} disabled={saving}>
          {saving ? <ActivityIndicator size="small" color="#ffffff" /> : <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  iconContainer: { alignItems: 'center', marginBottom: 16 },
  pageTitle: { fontSize: 24, fontWeight: 'bold', color: '#0f172a', textAlign: 'center', marginBottom: 8 },
  pageDescription: { fontSize: 14, color: '#64748b', textAlign: 'center', marginBottom: 24, lineHeight: 20 },
  card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: '#e2e8f0' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 },
  cardTitle: { fontSize: 18, fontWeight: 'bold', color: '#0f172a', textAlign: 'right', flex: 1 },
  inputGroup: { marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', color: '#475569', marginBottom: 8, textAlign: 'right' },
  input: { backgroundColor: '#f8fafc', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, padding: 14, fontSize: 14, color: '#0f172a' },
  textArea: { minHeight: 200, textAlignVertical: 'top' },
  helperText: { fontSize: 12, color: '#94a3b8', marginTop: 6, textAlign: 'right' },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderTopWidth: 1, borderTopColor: '#f1f5f9' },
  infoLabel: { fontSize: 14, color: '#64748b' },
  infoValue: { fontSize: 14, fontWeight: '600', color: '#0f172a' },
  infoCard: { backgroundColor: '#eff6ff', borderRadius: 12, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#bfdbfe' },
  infoTitle: { fontSize: 14, fontWeight: 'bold', color: '#1e40af', marginBottom: 8, textAlign: 'right' },
  infoText: { fontSize: 13, color: '#1e40af', lineHeight: 20, textAlign: 'right' },
  saveButton: { backgroundColor: '#3b82f6', borderRadius: 12, padding: 18, alignItems: 'center', marginTop: 8 },
  saveButtonDisabled: { opacity: 0.6 },
  saveButtonText: { color: '#ffffff', fontSize: 16, fontWeight: 'bold' },
});
