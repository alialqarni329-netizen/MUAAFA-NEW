import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Switch,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Database, Download, Upload, Archive, Clock, CheckCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const SETTINGS_TABS = [
  { name: 'general', label: 'عام', path: '/owner/settings' },
  { name: 'google', label: 'Google OAuth', path: '/owner/settings/google' },
  { name: 'login', label: 'تسجيل الدخول', path: '/owner/settings/login' },
  { name: 'otp', label: 'OTP/2FA', path: '/owner/settings/otp' },
  { name: 'languages', label: 'اللغات', path: '/owner/settings/languages' },
  { name: 'themes', label: 'السمات', path: '/owner/settings/themes' },
  { name: 'privacy', label: 'الخصوصية', path: '/owner/settings/privacy' },
  { name: 'terms', label: 'الشروط', path: '/owner/settings/terms' },
  { name: 'backup', label: 'النسخ الاحتياطي', path: '/owner/settings/backup' },
];

interface BackupSettings {
  backup_enabled: boolean;
  backup_frequency: 'daily' | 'weekly' | 'monthly';
  backup_retention_days: number;
  auto_backup: boolean;
  last_backup_date: string | null;
}

export default function BackupSettingsScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [creating, setCreating] = useState(false);
  const [settings, setSettings] = useState<BackupSettings>({
    backup_enabled: true,
    backup_frequency: 'daily',
    backup_retention_days: 30,
    auto_backup: true,
    last_backup_date: null,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: backupEnabledData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'backup_enabled')
        .single();

      const { data: backupFrequencyData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'backup_frequency')
        .single();

      const { data: backupRetentionData } = await supabase
        .from('app_settings')
        .select('setting_value')
        .eq('setting_key', 'backup_retention')
        .single();

      setSettings({
        backup_enabled: backupEnabledData?.setting_value?.enabled ?? true,
        backup_frequency: backupFrequencyData?.setting_value?.frequency ?? 'daily',
        backup_retention_days: backupRetentionData?.setting_value?.days ?? 30,
        auto_backup: backupEnabledData?.setting_value?.enabled ?? true,
        last_backup_date: null,
      });
    } catch (error: any) {
      console.error('Error loading backup settings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadSettings();
    setRefreshing(false);
  }

  async function saveSettings() {
    setSaving(true);

    try {
      const updates = [
        {
          setting_key: 'backup_enabled',
          setting_value: { enabled: settings.backup_enabled },
          setting_type: 'backup',
          description: 'Enable automatic backups',
        },
        {
          setting_key: 'backup_frequency',
          setting_value: { frequency: settings.backup_frequency },
          setting_type: 'backup',
          description: 'Backup frequency',
        },
        {
          setting_key: 'backup_retention',
          setting_value: { days: settings.backup_retention_days },
          setting_type: 'backup',
          description: 'Backup retention period in days',
        },
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from('app_settings')
          .upsert(update, { onConflict: 'setting_key' });

        if (error) throw error;
      }

      Alert.alert('نجح', 'تم حفظ إعدادات النسخ الاحتياطي بنجاح');
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل حفظ الإعدادات: ' + error.message);
    } finally {
      setSaving(false);
    }
  }

  async function createBackup() {
    setCreating(true);

    try {
      // Simulate backup creation
      await new Promise((resolve) => setTimeout(resolve, 2000));

      Alert.alert('نجح', 'تم إنشاء النسخة الاحتياطية بنجاح');
      setSettings({ ...settings, last_backup_date: new Date().toISOString() });
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل إنشاء النسخة الاحتياطية');
    } finally {
      setCreating(false);
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إعدادات التطبيق" tabs={SETTINGS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.iconContainer}>
          <Database size={48} color="#3b82f6" strokeWidth={2} />
        </View>

        <Text style={styles.pageTitle}>النسخ الاحتياطي والاستعادة</Text>
        <Text style={styles.pageDescription}>
          إدارة النسخ الاحتياطي للبيانات وجدولة النسخ التلقائي
        </Text>

        {/* Backup Status */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <CheckCircle size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.cardTitle}>حالة النسخ الاحتياطي</Text>
          </View>

          {settings.last_backup_date && (
            <View style={styles.statusRow}>
              <Text style={styles.statusLabel}>آخر نسخة احتياطية:</Text>
              <Text style={styles.statusValue}>
                {new Date(settings.last_backup_date).toLocaleDateString('ar-SA')}
              </Text>
            </View>
          )}

          <View style={styles.statusRow}>
            <Text style={styles.statusLabel}>حالة النظام:</Text>
            <Text style={[styles.statusValue, styles.statusActive]}>نشط</Text>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>الإجراءات السريعة</Text>

          <TouchableOpacity
            style={[styles.actionButton, creating && styles.actionButtonDisabled]}
            onPress={createBackup}
            disabled={creating}>
            {creating ? (
              <ActivityIndicator size="small" color="#ffffff" />
            ) : (
              <>
                <Download size={20} color="#ffffff" strokeWidth={2} />
                <Text style={styles.actionButtonText}>إنشاء نسخة احتياطية الآن</Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButtonSecondary}>
            <Upload size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.actionButtonSecondaryText}>استعادة من نسخة احتياطية</Text>
          </TouchableOpacity>
        </View>

        {/* Backup Settings */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>إعدادات النسخ الاحتياطي</Text>

          <View style={styles.settingRow}>
            <Switch
              value={settings.backup_enabled}
              onValueChange={(value) => setSettings({ ...settings, backup_enabled: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>تفعيل النسخ الاحتياطي التلقائي</Text>
              <Text style={styles.settingDescription}>
                يتم إنشاء نسخ احتياطية تلقائياً حسب الجدول المحدد
              </Text>
            </View>
          </View>

          <View style={styles.settingRow}>
            <Switch
              value={settings.auto_backup}
              onValueChange={(value) => setSettings({ ...settings, auto_backup: value })}
              trackColor={{ false: '#cbd5e1', true: '#3b82f6' }}
              thumbColor="#ffffff"
            />
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>النسخ التلقائي</Text>
              <Text style={styles.settingDescription}>تشغيل النسخ الاحتياطي التلقائي</Text>
            </View>
          </View>
        </View>

        {/* Frequency Settings */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Clock size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>تكرار النسخ الاحتياطي</Text>
          </View>

          <View style={styles.frequencyOptions}>
            <TouchableOpacity
              style={[
                styles.frequencyOption,
                settings.backup_frequency === 'daily' && styles.frequencyOptionActive,
              ]}
              onPress={() => setSettings({ ...settings, backup_frequency: 'daily' })}>
              <Text
                style={[
                  styles.frequencyText,
                  settings.backup_frequency === 'daily' && styles.frequencyTextActive,
                ]}>
                يومياً
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.frequencyOption,
                settings.backup_frequency === 'weekly' && styles.frequencyOptionActive,
              ]}
              onPress={() => setSettings({ ...settings, backup_frequency: 'weekly' })}>
              <Text
                style={[
                  styles.frequencyText,
                  settings.backup_frequency === 'weekly' && styles.frequencyTextActive,
                ]}>
                أسبوعياً
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.frequencyOption,
                settings.backup_frequency === 'monthly' && styles.frequencyOptionActive,
              ]}
              onPress={() => setSettings({ ...settings, backup_frequency: 'monthly' })}>
              <Text
                style={[
                  styles.frequencyText,
                  settings.backup_frequency === 'monthly' && styles.frequencyTextActive,
                ]}>
                شهرياً
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Retention Settings */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Archive size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardTitle}>مدة الاحتفاظ بالنسخ</Text>
          </View>

          <View style={styles.retentionOptions}>
            {[7, 14, 30, 60, 90].map((days) => (
              <TouchableOpacity
                key={days}
                style={[
                  styles.retentionOption,
                  settings.backup_retention_days === days && styles.retentionOptionActive,
                ]}
                onPress={() => setSettings({ ...settings, backup_retention_days: days })}>
                <Text
                  style={[
                    styles.retentionText,
                    settings.backup_retention_days === days && styles.retentionTextActive,
                  ]}>
                  {days} يوم
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Save Button */}
        <TouchableOpacity
          style={[styles.saveButton, saving && styles.saveButtonDisabled]}
          onPress={saveSettings}
          disabled={saving}>
          {saving ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.saveButtonText}>حفظ الإعدادات</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  iconContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'center',
    marginBottom: 8,
  },
  pageDescription: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
    flex: 1,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  statusLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  statusValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
  },
  statusActive: {
    color: '#10b981',
  },
  actionButton: {
    backgroundColor: '#3b82f6',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 12,
  },
  actionButtonDisabled: {
    opacity: 0.6,
  },
  actionButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  actionButtonSecondary: {
    backgroundColor: '#eff6ff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  actionButtonSecondaryText: {
    color: '#3b82f6',
    fontSize: 16,
    fontWeight: 'bold',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  settingInfo: {
    flex: 1,
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  frequencyOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  frequencyOption: {
    flex: 1,
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  frequencyOptionActive: {
    backgroundColor: '#eff6ff',
    borderColor: '#3b82f6',
  },
  frequencyText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  frequencyTextActive: {
    color: '#3b82f6',
  },
  retentionOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  retentionOption: {
    backgroundColor: '#f1f5f9',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  retentionOptionActive: {
    backgroundColor: '#eff6ff',
    borderColor: '#3b82f6',
  },
  retentionText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748b',
  },
  retentionTextActive: {
    color: '#3b82f6',
  },
  saveButton: {
    backgroundColor: '#3b82f6',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
