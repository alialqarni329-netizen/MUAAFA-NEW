import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, TextInput, Modal } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Mail, Send, CheckCircle, XCircle, Clock, Search, Plus } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const NOTIFICATIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/notifications' },
  { name: 'users', label: 'المستخدمين', path: '/owner/notifications/users' },
  { name: 'business', label: 'الشركات', path: '/owner/notifications/business' },
  { name: 'email', label: 'البريد', path: '/owner/notifications/email' },
  { name: 'sms', label: 'الرسائل', path: '/owner/notifications/sms' },
  { name: 'logs', label: 'السجل', path: '/owner/notifications/logs' },
];

interface EmailNotification {
  id: string;
  recipient_email: string;
  subject: string;
  body: string;
  status: string;
  sent_at: string | null;
  created_at: string;
  error_message: string | null;
}

export default function EmailNotifications() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [emails, setEmails] = useState<EmailNotification[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    sent: 0,
    failed: 0,
    pending: 0,
  });

  useEffect(() => {
    loadEmails();
  }, []);

  async function loadEmails() {
    try {
      const { data: emailsData } = await supabase
        .from('notifications')
        .select('*')
        .eq('type', 'email')
        .order('created_at', { ascending: false })
        .limit(50);

      const { count: totalCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('type', 'email');

      const { count: sentCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('type', 'email')
        .eq('status', 'delivered');

      const { count: failedCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('type', 'email')
        .eq('status', 'failed');

      const { count: pendingCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('type', 'email')
        .eq('status', 'pending');

      setEmails(emailsData || []);
      setStats({
        total: totalCount || 0,
        sent: sentCount || 0,
        failed: failedCount || 0,
        pending: pendingCount || 0,
      });
    } catch (error) {
      console.error('Error loading emails:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadEmails();
  }

  async function sendEmailNotification() {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert([
          {
            recipient_type: 'users',
            type: 'email',
            title: 'بريد إلكتروني جديد',
            message: 'تم إرسال بريد إلكتروني تجريبي',
            status: 'pending',
            created_at: new Date().toISOString(),
          },
        ]);

      if (error) throw error;

      await loadEmails();
    } catch (error) {
      console.error('Error sending email:', error);
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'delivered':
        return <CheckCircle size={18} color="#10b981" strokeWidth={2} />;
      case 'failed':
        return <XCircle size={18} color="#ef4444" strokeWidth={2} />;
      default:
        return <Clock size={18} color="#f59e0b" strokeWidth={2} />;
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'delivered':
        return '#10b981';
      case 'failed':
        return '#ef4444';
      default:
        return '#f59e0b';
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'delivered':
        return 'تم الإرسال';
      case 'failed':
        return 'فشل';
      default:
        return 'قيد الإرسال';
    }
  }

  const filteredEmails = emails.filter(email =>
    email.subject?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    email.recipient_email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل رسائل البريد...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
      >
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Mail size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الرسائل</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <CheckCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.sent.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>تم الإرسال</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Clock size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>قيد الإرسال</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <XCircle size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.failed.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>فشل</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في رسائل البريد..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
            textAlign="right"
          />
        </View>

        <View style={styles.header}>
          <Text style={styles.sectionTitle}>رسائل البريد الإلكتروني</Text>
          <TouchableOpacity style={styles.newButton} onPress={sendEmailNotification}>
            <Plus size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.newButtonText}>إرسال جديد</Text>
          </TouchableOpacity>
        </View>

        {filteredEmails.length > 0 ? (
          filteredEmails.map((email) => (
            <View key={email.id} style={styles.emailCard}>
              <View style={styles.emailHeader}>
                <View style={styles.emailInfo}>
                  <Mail size={20} color="#3b82f6" strokeWidth={2} />
                  <View style={styles.emailDetails}>
                    <Text style={styles.emailSubject}>{email.subject}</Text>
                    <Text style={styles.emailRecipient}>{email.recipient_email}</Text>
                  </View>
                </View>
                <View style={styles.statusContainer}>
                  {getStatusIcon(email.status)}
                  <Text style={[styles.statusText, { color: getStatusColor(email.status) }]}>
                    {getStatusText(email.status)}
                  </Text>
                </View>
              </View>
              <Text style={styles.emailBody} numberOfLines={2}>
                {email.body}
              </Text>
              {email.error_message && (
                <View style={styles.errorContainer}>
                  <XCircle size={14} color="#ef4444" strokeWidth={2} />
                  <Text style={styles.errorText}>{email.error_message}</Text>
                </View>
              )}
              <Text style={styles.emailDate}>
                {new Date(email.created_at).toLocaleDateString('ar-SA', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </Text>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Mail size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد رسائل بريد إلكتروني</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    gap: 6,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 20,
    gap: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#0f172a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  newButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#3b82f6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
  },
  newButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  emailCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  emailHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  emailInfo: {
    flexDirection: 'row',
    flex: 1,
    gap: 10,
  },
  emailDetails: {
    flex: 1,
  },
  emailSubject: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  emailRecipient: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  emailBody: {
    fontSize: 13,
    color: '#64748b',
    marginBottom: 12,
    textAlign: 'right',
    lineHeight: 20,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#fee2e2',
    padding: 8,
    borderRadius: 8,
    marginBottom: 8,
  },
  errorText: {
    flex: 1,
    fontSize: 12,
    color: '#ef4444',
    textAlign: 'right',
  },
  emailDate: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    marginTop: 12,
    fontSize: 16,
    color: '#94a3b8',
  },
});
