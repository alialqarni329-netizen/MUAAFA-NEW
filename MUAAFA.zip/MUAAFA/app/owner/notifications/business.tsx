import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Building2, Bell, Send, Search, CheckCircle, XCircle, Clock } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const NOTIFICATIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/notifications' },
  { name: 'users', label: 'المستخدمين', path: '/owner/notifications/users' },
  { name: 'business', label: 'الشركات', path: '/owner/notifications/business' },
  { name: 'email', label: 'البريد', path: '/owner/notifications/email' },
  { name: 'sms', label: 'الرسائل', path: '/owner/notifications/sms' },
  { name: 'logs', label: 'السجل', path: '/owner/notifications/logs' },
];

interface BusinessNotification {
  id: string;
  title: string;
  message: string;
  status: string;
  created_at: string;
  user?: {
    full_name: string;
  };
}

interface NotificationStats {
  total: number;
  delivered: number;
  failed: number;
  pending: number;
}

export default function BusinessNotifications() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications, setNotifications] = useState<BusinessNotification[]>([]);
  const [stats, setStats] = useState<NotificationStats>({
    total: 0,
    delivered: 0,
    failed: 0,
    pending: 0,
  });

  useEffect(() => {
    loadNotifications();
  }, []);

  async function loadNotifications() {
    try {
      const { data: businessNotifs } = await supabase
        .from('notifications')
        .select(`
          id,
          title,
          message,
          status,
          created_at,
          user:users(full_name)
        `)
        .eq('recipient_type', 'business')
        .order('created_at', { ascending: false })
        .limit(50);

      const { count: totalCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('recipient_type', 'business');

      const { count: deliveredCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('recipient_type', 'business')
        .eq('status', 'delivered');

      const { count: failedCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('recipient_type', 'business')
        .eq('status', 'failed');

      const { count: pendingCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('recipient_type', 'business')
        .eq('status', 'pending');

      setNotifications(businessNotifs || []);
      setStats({
        total: totalCount || 0,
        delivered: deliveredCount || 0,
        failed: failedCount || 0,
        pending: pendingCount || 0,
      });
    } catch (error) {
      console.error('Error loading business notifications:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadNotifications();
  }

  async function sendNotification() {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert([
          {
            recipient_type: 'business',
            type: 'push',
            title: 'إشعار جديد للشركات',
            message: 'تم إرسال إشعار تجريبي',
            status: 'pending',
            created_at: new Date().toISOString(),
          },
        ]);

      if (error) throw error;

      await loadNotifications();
    } catch (error) {
      console.error('Error sending notification:', error);
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'delivered':
        return <CheckCircle size={16} color="#10b981" strokeWidth={2} />;
      case 'failed':
        return <XCircle size={16} color="#ef4444" strokeWidth={2} />;
      default:
        return <Clock size={16} color="#f59e0b" strokeWidth={2} />;
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'delivered':
        return '#10b981';
      case 'failed':
        return '#ef4444';
      default:
        return '#f59e0b';
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'delivered':
        return 'تم التسليم';
      case 'failed':
        return 'فشل';
      default:
        return 'قيد الإرسال';
    }
  }

  const filteredNotifications = notifications.filter(notif =>
    notif.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    notif.message?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل إشعارات الشركات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
      >
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Building2 size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <CheckCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.delivered.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>مسلم</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Clock size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>معلق</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <XCircle size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.failed.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>فاشل</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في إشعارات الشركات..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
            textAlign="right"
          />
        </View>

        <View style={styles.header}>
          <Text style={styles.sectionTitle}>إشعارات الشركات</Text>
          <TouchableOpacity style={styles.sendButton} onPress={sendNotification}>
            <Send size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.sendButtonText}>إرسال</Text>
          </TouchableOpacity>
        </View>

        {filteredNotifications.length > 0 ? (
          filteredNotifications.map((notif) => (
            <View key={notif.id} style={styles.notificationCard}>
              <View style={styles.notificationHeader}>
                <View style={styles.notificationInfo}>
                  <Text style={styles.notificationTitle}>{notif.title}</Text>
                  {notif.user?.full_name && (
                    <Text style={styles.senderName}>{notif.user.full_name}</Text>
                  )}
                </View>
                <View style={styles.statusContainer}>
                  {getStatusIcon(notif.status)}
                  <Text style={[styles.statusText, { color: getStatusColor(notif.status) }]}>
                    {getStatusText(notif.status)}
                  </Text>
                </View>
              </View>
              <Text style={styles.notificationMessage} numberOfLines={2}>
                {notif.message}
              </Text>
              <Text style={styles.notificationDate}>
                {new Date(notif.created_at).toLocaleDateString('ar-SA', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </Text>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Building2 size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد إشعارات للشركات</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    gap: 6,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 20,
    gap: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#0f172a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  sendButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#3b82f6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
  },
  sendButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  notificationCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  notificationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  notificationInfo: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  senderName: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  notificationMessage: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 12,
    textAlign: 'right',
    lineHeight: 20,
  },
  notificationDate: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'right',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    marginTop: 12,
    fontSize: 16,
    color: '#94a3b8',
  },
});
