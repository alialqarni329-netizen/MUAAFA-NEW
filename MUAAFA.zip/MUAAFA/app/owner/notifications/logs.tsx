import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { FileText, CheckCircle, XCircle, Clock, Search } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const NOTIFICATIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/notifications' },
  { name: 'users', label: 'المستخدمين', path: '/owner/notifications/users' },
  { name: 'business', label: 'الشركات', path: '/owner/notifications/business' },
  { name: 'email', label: 'البريد', path: '/owner/notifications/email' },
  { name: 'sms', label: 'الرسائل', path: '/owner/notifications/sms' },
  { name: 'logs', label: 'السجل', path: '/owner/notifications/logs' },
];

export default function NotificationLogs() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [logs, setLogs] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, success: 0, failed: 0, pending: 0 });

  useEffect(() => {
    loadLogs();
  }, []);

  async function loadLogs() {
    try {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      const { count: totalCount } = await supabase.from('notifications').select('*', { count: 'exact', head: true });
      const { count: successCount } = await supabase.from('notifications').select('*', { count: 'exact', head: true }).eq('status', 'delivered');
      const { count: failedCount } = await supabase.from('notifications').select('*', { count: 'exact', head: true }).eq('status', 'failed');
      const { count: pendingCount } = await supabase.from('notifications').select('*', { count: 'exact', head: true }).eq('status', 'pending');

      setLogs(data || []);
      setStats({ total: totalCount || 0, success: successCount || 0, failed: failedCount || 0, pending: pendingCount || 0 });
    } catch (error) {
      console.error('Error loading logs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadLogs();
  }

  const filteredLogs = logs.filter(log =>
    log.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.message?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.type?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  function getStatusIcon(status: string) {
    switch (status) {
      case 'delivered': return <CheckCircle size={16} color="#10b981" strokeWidth={2} />;
      case 'failed': return <XCircle size={16} color="#ef4444" strokeWidth={2} />;
      default: return <Clock size={16} color="#f59e0b" strokeWidth={2} />;
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل سجل الإرسال...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <FileText size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي السجلات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <CheckCircle size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.success.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>ناجحة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Clock size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pending.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>معلقة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#fee2e2' }]}>
            <XCircle size={20} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.failed.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>فاشلة</Text>
          </View>
        </View>
        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput style={styles.searchInput} placeholder="البحث في السجل..." placeholderTextColor="#94a3b8" value={searchQuery} onChangeText={setSearchQuery} textAlign="right" />
        </View>
        <Text style={styles.sectionTitle}>سجل الإرسال</Text>
        {filteredLogs.length > 0 ? (
          filteredLogs.map((log) => (
            <View key={log.id} style={styles.logCard}>
              <View style={styles.logHeader}>
                <View style={styles.logInfo}>
                  <Text style={styles.logTitle}>{log.title || 'إشعار'}</Text>
                  <Text style={styles.logType}>{log.type === 'email' ? 'بريد' : log.type === 'sms' ? 'رسالة' : 'إشعار'}</Text>
                </View>
                {getStatusIcon(log.status)}
              </View>
              <Text style={styles.logDate}>
                {new Date(log.created_at).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </Text>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <FileText size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد سجلات</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 16, fontSize: 16, color: '#64748b' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: { flex: 1, minWidth: '47%', padding: 14, borderRadius: 12, alignItems: 'center', gap: 6 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  statLabel: { fontSize: 11, color: '#64748b', textAlign: 'center' },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 20, gap: 8, borderWidth: 1, borderColor: '#e2e8f0' },
  searchInput: { flex: 1, fontSize: 14, color: '#0f172a' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', marginBottom: 12, textAlign: 'right' },
  logCard: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  logHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  logInfo: { flex: 1 },
  logTitle: { fontSize: 15, fontWeight: 'bold', color: '#0f172a', marginBottom: 4, textAlign: 'right' },
  logType: { fontSize: 13, color: '#64748b', textAlign: 'right' },
  logDate: { fontSize: 12, color: '#94a3b8', textAlign: 'right' },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#94a3b8' },
});
