import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Users, Bell, Send, Search, Filter } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const NOTIFICATIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/notifications' },
  { name: 'users', label: 'المستخدمين', path: '/owner/notifications/users' },
  { name: 'business', label: 'الشركات', path: '/owner/notifications/business' },
  { name: 'email', label: 'البريد', path: '/owner/notifications/email' },
  { name: 'sms', label: 'الرسائل', path: '/owner/notifications/sms' },
  { name: 'logs', label: 'السجل', path: '/owner/notifications/logs' },
];

interface UserNotification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  created_at: string;
  user?: {
    full_name: string;
    email: string;
  };
}

export default function UserNotifications() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications, setNotifications] = useState<UserNotification[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    read: 0,
    unread: 0,
    today: 0,
  });

  useEffect(() => {
    loadNotifications();
  }, []);

  async function loadNotifications() {
    try {
      const { data: notificationsData } = await supabase
        .from('notifications')
        .select(`
          *,
          user:users(full_name, email)
        `)
        .eq('recipient_type', 'users')
        .order('created_at', { ascending: false })
        .limit(50);

      const { count: totalCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('recipient_type', 'users');

      const { count: readCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('recipient_type', 'users')
        .eq('read', true);

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const { count: todayCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('recipient_type', 'users')
        .gte('created_at', today.toISOString());

      setNotifications(notificationsData || []);
      setStats({
        total: totalCount || 0,
        read: readCount || 0,
        unread: (totalCount || 0) - (readCount || 0),
        today: todayCount || 0,
      });
    } catch (error) {
      console.error('Error loading user notifications:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadNotifications();
  }

  async function sendUserNotification() {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert([
          {
            recipient_type: 'users',
            type: 'push',
            title: 'إشعار جديد للمستخدمين',
            message: 'تم إرسال إشعار تجريبي إلى جميع المستخدمين',
            status: 'pending',
            created_at: new Date().toISOString(),
          },
        ]);

      if (error) throw error;

      await loadNotifications();
    } catch (error) {
      console.error('Error sending notification:', error);
    }
  }

  const filteredNotifications = notifications.filter(notif =>
    notif.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    notif.message?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل إشعارات المستخدمين...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
      >
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe' }]}>
            <Users size={20} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الإشعارات</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#d1fae5' }]}>
            <Bell size={20} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.today.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>اليوم</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fef3c7' }]}>
            <Bell size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.unread.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>غير مقروءة</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#f3e8ff' }]}>
            <Bell size={20} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.read.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>مقروءة</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في إشعارات المستخدمين..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
            textAlign="right"
          />
        </View>

        <View style={styles.header}>
          <Text style={styles.sectionTitle}>إشعارات المستخدمين</Text>
          <TouchableOpacity style={styles.sendButton} onPress={sendUserNotification}>
            <Send size={18} color="#ffffff" strokeWidth={2} />
            <Text style={styles.sendButtonText}>إرسال إشعار</Text>
          </TouchableOpacity>
        </View>

        {filteredNotifications.length > 0 ? (
          filteredNotifications.map((notification) => (
            <View key={notification.id} style={styles.notificationCard}>
              <View style={styles.notificationHeader}>
                <View style={styles.notificationInfo}>
                  <Text style={styles.notificationTitle}>{notification.title}</Text>
                  <Text style={styles.notificationUser}>
                    {notification.user?.full_name || 'مستخدم'}
                  </Text>
                </View>
                <View style={[
                  styles.readBadge,
                  { backgroundColor: notification.read ? '#d1fae5' : '#fef3c7' }
                ]}>
                  <Text style={[
                    styles.readBadgeText,
                    { color: notification.read ? '#10b981' : '#f59e0b' }
                  ]}>
                    {notification.read ? 'مقروءة' : 'غير مقروءة'}
                  </Text>
                </View>
              </View>
              <Text style={styles.notificationMessage} numberOfLines={2}>
                {notification.message}
              </Text>
              <View style={styles.notificationFooter}>
                <Text style={styles.notificationDate}>
                  {new Date(notification.created_at).toLocaleDateString('ar-SA', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </Text>
                <Text style={styles.notificationType}>
                  {notification.type === 'email' ? 'بريد' : notification.type === 'sms' ? 'رسالة' : 'إشعار'}
                </Text>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Users size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد إشعارات للمستخدمين</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    gap: 6,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 20,
    gap: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#0f172a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  sendButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#3b82f6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
  },
  sendButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  notificationCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  notificationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  notificationInfo: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  notificationUser: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  readBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  readBadgeText: {
    fontSize: 11,
    fontWeight: '600',
  },
  notificationMessage: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 12,
    textAlign: 'right',
    lineHeight: 20,
  },
  notificationFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  notificationDate: {
    fontSize: 12,
    color: '#94a3b8',
  },
  notificationType: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    marginTop: 12,
    fontSize: 16,
    color: '#94a3b8',
  },
});
