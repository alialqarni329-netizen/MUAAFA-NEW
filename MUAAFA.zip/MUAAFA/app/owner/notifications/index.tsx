import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Bell, Users, Building2, Mail, MessageSquare, Search, Send } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const NOTIFICATIONS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/notifications' },
  { name: 'users', label: 'المستخدمين', path: '/owner/notifications/users' },
  { name: 'business', label: 'الشركات', path: '/owner/notifications/business' },
  { name: 'email', label: 'البريد', path: '/owner/notifications/email' },
  { name: 'sms', label: 'الرسائل', path: '/owner/notifications/sms' },
  { name: 'logs', label: 'السجل', path: '/owner/notifications/logs' },
];

interface NotificationStats {
  totalSent: number;
  pendingCount: number;
  failedCount: number;
  deliveredCount: number;
}

interface Notification {
  id: string;
  type: string;
  recipient_type: string;
  title: string;
  message: string;
  status: string;
  created_at: string;
  sent_at: string | null;
}

export default function NotificationsOverview() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState<NotificationStats>({
    totalSent: 0,
    pendingCount: 0,
    failedCount: 0,
    deliveredCount: 0,
  });
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    loadNotifications();
  }, []);

  async function loadNotifications() {
    try {
      const { count: totalCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true });

      const { count: pendingCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      const { count: failedCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'failed');

      const { count: deliveredCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'delivered');

      const { data: notificationsData } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      setStats({
        totalSent: totalCount || 0,
        pendingCount: pendingCount || 0,
        failedCount: failedCount || 0,
        deliveredCount: deliveredCount || 0,
      });

      setNotifications(notificationsData || []);
    } catch (error) {
      console.error('Error loading notifications:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadNotifications();
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'delivered':
        return '#10b981';
      case 'failed':
        return '#ef4444';
      case 'pending':
        return '#f59e0b';
      default:
        return '#64748b';
    }
  }

  function getStatusText(status: string) {
    switch (status) {
      case 'delivered':
        return 'تم التسليم';
      case 'failed':
        return 'فشل';
      case 'pending':
        return 'قيد الإرسال';
      default:
        return status;
    }
  }

  function getTypeIcon(type: string) {
    switch (type) {
      case 'email':
        return <Mail size={16} color="#3b82f6" strokeWidth={2} />;
      case 'sms':
        return <MessageSquare size={16} color="#8b5cf6" strokeWidth={2} />;
      case 'push':
        return <Bell size={16} color="#10b981" strokeWidth={2} />;
      default:
        return <Bell size={16} color="#64748b" strokeWidth={2} />;
    }
  }

  const filteredNotifications = notifications.filter(notif =>
    notif.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    notif.message?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الإشعارات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إدارة الإشعارات" tabs={NOTIFICATIONS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
      >
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#dbeafe', borderColor: '#3b82f6' }]}>
            <Bell size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.totalSent.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>إجمالي الإشعارات</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#d1fae5', borderColor: '#10b981' }]}>
            <Send size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.deliveredCount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>تم التسليم</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fef3c7', borderColor: '#f59e0b' }]}>
            <Bell size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pendingCount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>قيد الإرسال</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: '#fee2e2', borderColor: '#ef4444' }]}>
            <Bell size={24} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.failedCount.toLocaleString('ar-SA')}</Text>
            <Text style={styles.statLabel}>فشل الإرسال</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث في الإشعارات..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
            textAlign="right"
          />
        </View>

        <Text style={styles.sectionTitle}>آخر الإشعارات المرسلة</Text>

        {filteredNotifications.length > 0 ? (
          filteredNotifications.map((notification) => (
            <View key={notification.id} style={styles.notificationCard}>
              <View style={styles.notificationHeader}>
                <View style={styles.notificationTypeRow}>
                  {getTypeIcon(notification.type)}
                  <Text style={styles.notificationType}>
                    {notification.type === 'email' ? 'بريد إلكتروني' :
                     notification.type === 'sms' ? 'رسالة نصية' : 'إشعار'}
                  </Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(notification.status) + '20' }]}>
                  <Text style={[styles.statusText, { color: getStatusColor(notification.status) }]}>
                    {getStatusText(notification.status)}
                  </Text>
                </View>
              </View>
              <Text style={styles.notificationTitle}>{notification.title}</Text>
              <Text style={styles.notificationMessage} numberOfLines={2}>
                {notification.message}
              </Text>
              <View style={styles.notificationFooter}>
                <Text style={styles.notificationDate}>
                  {new Date(notification.created_at).toLocaleDateString('ar-SA', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </Text>
                <Text style={styles.notificationRecipient}>
                  {notification.recipient_type === 'users' ? 'المستخدمين' : 'الشركات'}
                </Text>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Bell size={48} color="#cbd5e1" strokeWidth={1.5} />
            <Text style={styles.emptyText}>لا توجد إشعارات</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 20,
    gap: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#0f172a',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  notificationCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  notificationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  notificationTypeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  notificationType: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 6,
    textAlign: 'right',
  },
  notificationMessage: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 12,
    textAlign: 'right',
    lineHeight: 20,
  },
  notificationFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  notificationDate: {
    fontSize: 12,
    color: '#94a3b8',
  },
  notificationRecipient: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    marginTop: 12,
    fontSize: 16,
    color: '#94a3b8',
  },
});
