import { Stack } from 'expo-router';
import { useEffect, useState } from 'react';
import { useRouter } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { View, ActivityIndicator, StyleSheet } from 'react-native';

export default function OwnerLayout() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkOwnerAccess();
  }, []);

  async function checkOwnerAccess() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.replace('/auth/login');
        return;
      }

      const { data: userData } = await supabase
        .from('users')
        .select('user_role')
        .eq('id', user.id)
        .maybeSingle();

      if (!userData || userData.user_role !== 'owner') {
        router.replace('/');
        return;
      }

      setLoading(false);
    } catch (error) {
      console.error('Error checking owner access:', error);
      router.replace('/');
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
      </View>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />

      <Stack.Screen name="dashboard" />
      <Stack.Screen name="users" />
      <Stack.Screen name="business" />
      <Stack.Screen name="payments" />
      <Stack.Screen name="content" />
      <Stack.Screen name="analytics" />
      <Stack.Screen name="sessions" />
      <Stack.Screen name="pharmacy" />
      <Stack.Screen name="notifications" />
      <Stack.Screen name="settings" />
      <Stack.Screen name="security" />
    </Stack>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
});
