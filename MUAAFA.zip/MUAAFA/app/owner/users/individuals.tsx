import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { User, Search, Calendar, Shield, Building2, CreditCard, Ban, CheckCircle, Trash2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'جميع المستخدمين', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'الملاك', path: '/owner/users/owners' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/users/activity' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'reset', label: 'سجل الدخول', path: '/owner/users/reset' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
];

interface IndividualUser {
  id: string;
  full_name: string;
  phone: string;
  email: string;
  national_id: string;
  created_at: string;
  banned_until: string | null;
  user_subscriptions?: Array<{
    subscription_plans?: {
      name_ar: string;
    };
  }>;
}

export default function IndividualUsers() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [users, setUsers] = useState<IndividualUser[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<IndividualUser[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedInsurance, setSelectedInsurance] = useState<string>('all');
  const [stats, setStats] = useState({
    total: 0,
    todayCount: 0,
    activeSubscriptions: 0,
  });

  useEffect(() => {
    loadIndividualUsers();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [searchQuery, selectedInsurance, users]);

  async function loadIndividualUsers() {
    try {
      const { data } = await supabase
        .from('users')
        .select(`
          *,
          user_subscriptions(
            subscription_plans(name_ar)
          )
        `)
        .eq('user_role', 'individual_user')
        .order('created_at', { ascending: false });

      const usersData = data || [];
      const today = new Date().toISOString().split('T')[0];

      setUsers(usersData);
      setFilteredUsers(usersData);

      const todayUsers = usersData.filter(u => u.created_at.startsWith(today));

      setStats({
        total: usersData.length,
        todayCount: todayUsers.length,
        activeSubscriptions: usersData.filter(u => u.user_subscriptions && u.user_subscriptions.length > 0).length,
      });
    } catch (error) {
      console.error('Error loading individual users:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterUsers() {
    let filtered = users;

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        u =>
          u.phone?.includes(query) ||
          u.full_name?.toLowerCase().includes(query) ||
          u.national_id?.includes(query) ||
          u.email?.toLowerCase().includes(query)
      );
    }

    setFilteredUsers(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadIndividualUsers();
  }

  async function handleSuspendUser(userId: string, userName: string) {
    Alert.alert(
      'تعليق المستخدم',
      `هل أنت متأكد من تعليق حساب ${userName}؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'تعليق',
          style: 'destructive',
          onPress: async () => {
            try {
              const bannedUntil = new Date();
              bannedUntil.setFullYear(bannedUntil.getFullYear() + 10);

              const { error } = await supabase
                .from('users')
                .update({ banned_until: bannedUntil.toISOString() })
                .eq('id', userId);

              if (error) throw error;

              Alert.alert('نجح', 'تم تعليق المستخدم بنجاح');
              await loadIndividualUsers();
            } catch (error: any) {
              Alert.alert('خطأ', `فشل تعليق المستخدم: ${error.message}`);
            }
          },
        },
      ]
    );
  }

  async function handleActivateUser(userId: string, userName: string) {
    Alert.alert(
      'تفعيل المستخدم',
      `هل أنت متأكد من تفعيل حساب ${userName}؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'تفعيل',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('users')
                .update({ banned_until: null })
                .eq('id', userId);

              if (error) throw error;

              Alert.alert('نجح', 'تم تفعيل المستخدم بنجاح');
              await loadIndividualUsers();
            } catch (error: any) {
              Alert.alert('خطأ', `فشل تفعيل المستخدم: ${error.message}`);
            }
          },
        },
      ]
    );
  }

  async function handleDeleteUser(userId: string, userName: string) {
    Alert.alert(
      'حذف المستخدم',
      `⚠️ تحذير: سيتم حذف جميع بيانات ${userName} بشكل نهائي. هل أنت متأكد؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف نهائياً',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase.auth.admin.deleteUser(userId);

              if (error) throw error;

              Alert.alert('نجح', 'تم حذف المستخدم بنجاح');
              await loadIndividualUsers();
            } catch (error: any) {
              Alert.alert('خطأ', `فشل حذف المستخدم: ${error.message}`);
            }
          },
        },
      ]
    );
  }

  if (loading) {
    return (
      <OwnerTabLayout title="المستخدمون الأفراد" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل المستخدمين...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="المستخدمون الأفراد" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <User size={24} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الأفراد</Text>
          </View>

          <View style={styles.statCard}>
            <Calendar size={24} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayCount}</Text>
            <Text style={styles.statLabel}>تسجيلات اليوم</Text>
          </View>

          <View style={styles.statCard}>
            <CreditCard size={24} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.activeSubscriptions}</Text>
            <Text style={styles.statLabel}>اشتراكات نشطة</Text>
          </View>
        </View>

        <View style={styles.searchContainer}>
          <View style={styles.searchBox}>
            <Search size={20} color="#64748b" strokeWidth={2} />
            <TextInput
              style={styles.searchInput}
              placeholder="البحث برقم الجوال أو الاسم أو رقم الهوية..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholderTextColor="#94a3b8"
            />
          </View>
        </View>

        {filteredUsers.length > 0 ? (
          filteredUsers.map((user) => {
            const isSuspended = user.banned_until && new Date(user.banned_until) > new Date();

            return (
              <View key={user.id} style={[styles.userCard, isSuspended && styles.suspendedCard]}>
                <View style={styles.userHeader}>
                  <User size={20} color={isSuspended ? '#ef4444' : '#3b82f6'} strokeWidth={2} />
                  <Text style={styles.userName}>{user.full_name || 'بدون اسم'}</Text>
                  {isSuspended && (
                    <View style={styles.suspendedBadge}>
                      <Text style={styles.suspendedBadgeText}>معلق</Text>
                    </View>
                  )}
                </View>

                <View style={styles.userDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>رقم الهوية/الإقامة:</Text>
                    <Text style={styles.detailValue}>{user.national_id || '-'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>رقم الجوال:</Text>
                    <Text style={styles.detailValue}>{user.phone || '-'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>البريد الإلكتروني:</Text>
                    <Text style={styles.detailValue}>{user.email || '-'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>نوع الاشتراك:</Text>
                    <Text style={styles.subscriptionText}>
                      {user.user_subscriptions?.[0]?.subscription_plans?.name_ar || 'مجاني'}
                    </Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>تاريخ التسجيل:</Text>
                    <Text style={styles.detailValue}>
                      {new Date(user.created_at).toLocaleDateString('ar-SA', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </Text>
                  </View>
                </View>

                <View style={styles.actionsRow}>
                  {isSuspended ? (
                    <TouchableOpacity
                      style={[styles.actionButton, styles.activateButton]}
                      onPress={() => handleActivateUser(user.id, user.full_name)}>
                      <CheckCircle size={18} color="#10b981" strokeWidth={2} />
                      <Text style={[styles.actionButtonText, styles.activateButtonText]}>
                        تفعيل
                      </Text>
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity
                      style={[styles.actionButton, styles.suspendButton]}
                      onPress={() => handleSuspendUser(user.id, user.full_name)}>
                      <Ban size={18} color="#f59e0b" strokeWidth={2} />
                      <Text style={[styles.actionButtonText, styles.suspendButtonText]}>
                        تعليق
                      </Text>
                    </TouchableOpacity>
                  )}

                  <TouchableOpacity
                    style={[styles.actionButton, styles.deleteButton]}
                    onPress={() => handleDeleteUser(user.id, user.full_name)}>
                    <Trash2 size={18} color="#ef4444" strokeWidth={2} />
                    <Text style={[styles.actionButtonText, styles.deleteButtonText]}>
                      حذف
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <User size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا يوجد مستخدمون أفراد'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  searchContainer: {
    marginBottom: 20,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  userCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#dbeafe',
  },
  suspendedCard: {
    borderColor: '#fecaca',
    backgroundColor: '#fef2f2',
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
  },
  suspendedBadge: {
    backgroundColor: '#ef4444',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  suspendedBadgeText: {
    color: '#ffffff',
    fontSize: 11,
    fontWeight: 'bold',
  },
  userDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  subscriptionText: {
    fontSize: 13,
    color: '#10b981',
    fontWeight: 'bold',
    textAlign: 'left',
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
  },
  suspendButton: {
    backgroundColor: '#fffbeb',
    borderColor: '#fbbf24',
  },
  activateButton: {
    backgroundColor: '#f0fdf4',
    borderColor: '#10b981',
  },
  deleteButton: {
    backgroundColor: '#fef2f2',
    borderColor: '#ef4444',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  suspendButtonText: {
    color: '#f59e0b',
  },
  activateButtonText: {
    color: '#10b981',
  },
  deleteButtonText: {
    color: '#ef4444',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
