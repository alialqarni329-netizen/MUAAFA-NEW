import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity, Alert, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { User, Ban, CheckCircle, RotateCcw, FileText, Search } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'جميع المستخدمين', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'الملاك', path: '/owner/users/owners' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/users/activity' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'reset', label: 'سجل الدخول', path: '/owner/users/reset' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
];

interface UserAccount {
  id: string;
  full_name: string;
  email: string;
  phone_number: string;
  role: string;
  is_suspended: boolean;
  created_at: string;
}

export default function UserActions() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<UserAccount[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [noteModalUser, setNoteModalUser] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [searchQuery, users]);

  async function loadUsers() {
    try {
      const { data } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      const usersData = data || [];
      setUsers(usersData);
      setFilteredUsers(usersData);
    } catch (error) {
      console.error('Error loading users:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterUsers() {
    if (!searchQuery.trim()) {
      setFilteredUsers(users);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = users.filter(
      u =>
        u.full_name?.toLowerCase().includes(query) ||
        u.email?.toLowerCase().includes(query) ||
        u.phone_number?.includes(query)
    );
    setFilteredUsers(filtered);
  }

  async function handleSuspendUser(userId: string, userName: string) {
    Alert.alert(
      'تأكيد الإيقاف',
      `هل أنت متأكد من إيقاف حساب ${userName}؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'إيقاف',
          style: 'destructive',
          onPress: async () => {
            try {
              await supabase.from('users').update({ is_suspended: true }).eq('id', userId);
              Alert.alert('نجح', 'تم إيقاف الحساب بنجاح');
              await loadUsers();
            } catch (error) {
              Alert.alert('خطأ', 'فشل إيقاف الحساب');
            }
          },
        },
      ]
    );
  }

  async function handleActivateUser(userId: string, userName: string) {
    try {
      await supabase.from('users').update({ is_suspended: false }).eq('id', userId);
      Alert.alert('نجح', `تم تفعيل حساب ${userName} بنجاح`);
      await loadUsers();
    } catch (error) {
      Alert.alert('خطأ', 'فشل تفعيل الحساب');
    }
  }

  async function handleResetOTP(userId: string, userName: string) {
    Alert.alert(
      'تصفير OTP',
      `هل تريد تصفير رمز التحقق لـ ${userName}؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'تصفير',
          onPress: async () => {
            Alert.alert('نجح', 'تم تصفير رمز التحقق. يمكن للمستخدم طلب رمز جديد.');
          },
        },
      ]
    );
  }

  async function handleSaveNote(userId: string) {
    if (!noteText.trim()) {
      Alert.alert('تنبيه', 'الرجاء كتابة ملاحظة');
      return;
    }

    try {
      await supabase.from('user_notes').insert({
        user_id: userId,
        note: noteText,
        created_by: 'owner',
      });

      Alert.alert('نجح', 'تم حفظ الملاحظة');
      setNoteModalUser(null);
      setNoteText('');
    } catch (error) {
      Alert.alert('خطأ', 'فشل حفظ الملاحظة');
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadUsers();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="إجراءات على الحسابات" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل المستخدمين...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="إجراءات على الحسابات" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث بالاسم أو البريد أو الجوال..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredUsers.length > 0 ? (
          filteredUsers.map((user) => (
            <View key={user.id} style={styles.userCard}>
              <View style={styles.userHeader}>
                <User size={18} color="#3b82f6" strokeWidth={2} />
                <View style={styles.userInfo}>
                  <Text style={styles.userName}>{user.full_name || 'بدون اسم'}</Text>
                  <Text style={styles.userEmail}>{user.email || user.phone_number}</Text>
                </View>
                {user.is_suspended && (
                  <View style={styles.suspendedBadge}>
                    <Text style={styles.suspendedText}>موقوف</Text>
                  </View>
                )}
              </View>

              <View style={styles.actionsGrid}>
                {user.is_suspended ? (
                  <TouchableOpacity
                    style={[styles.actionButton, { backgroundColor: '#d1fae5' }]}
                    onPress={() => handleActivateUser(user.id, user.full_name)}>
                    <CheckCircle size={18} color="#065f46" strokeWidth={2} />
                    <Text style={[styles.actionText, { color: '#065f46' }]}>تفعيل</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    style={[styles.actionButton, { backgroundColor: '#fee2e2' }]}
                    onPress={() => handleSuspendUser(user.id, user.full_name)}>
                    <Ban size={18} color="#991b1b" strokeWidth={2} />
                    <Text style={[styles.actionText, { color: '#991b1b' }]}>إيقاف</Text>
                  </TouchableOpacity>
                )}

                <TouchableOpacity
                  style={[styles.actionButton, { backgroundColor: '#fef3c7' }]}
                  onPress={() => handleResetOTP(user.id, user.full_name)}>
                  <RotateCcw size={18} color="#92400e" strokeWidth={2} />
                  <Text style={[styles.actionText, { color: '#92400e' }]}>تصفير OTP</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.actionButton, { backgroundColor: '#dbeafe' }]}
                  onPress={() => setNoteModalUser(user.id)}>
                  <FileText size={18} color="#1e40af" strokeWidth={2} />
                  <Text style={[styles.actionText, { color: '#1e40af' }]}>ملاحظات</Text>
                </TouchableOpacity>
              </View>

              {noteModalUser === user.id && (
                <View style={styles.noteBox}>
                  <TextInput
                    style={styles.noteInput}
                    placeholder="اكتب ملاحظة إدارية..."
                    value={noteText}
                    onChangeText={setNoteText}
                    multiline
                    numberOfLines={3}
                    textAlign="right"
                    placeholderTextColor="#94a3b8"
                  />
                  <View style={styles.noteActions}>
                    <TouchableOpacity
                      style={styles.saveNoteButton}
                      onPress={() => handleSaveNote(user.id)}>
                      <Text style={styles.saveNoteText}>حفظ</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.cancelNoteButton}
                      onPress={() => {
                        setNoteModalUser(null);
                        setNoteText('');
                      }}>
                      <Text style={styles.cancelNoteText}>إلغاء</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <User size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>لا توجد نتائج</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 20,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  userCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  userEmail: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  suspendedBadge: {
    backgroundColor: '#fee2e2',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  suspendedText: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#991b1b',
  },
  actionsGrid: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    flex: 1,
    minWidth: '30%',
    justifyContent: 'center',
  },
  actionText: {
    fontSize: 13,
    fontWeight: '600',
  },
  noteBox: {
    marginTop: 12,
    padding: 12,
    backgroundColor: '#f8fafc',
    borderRadius: 8,
  },
  noteInput: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    fontSize: 14,
    color: '#0f172a',
    minHeight: 80,
  },
  noteActions: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 8,
  },
  saveNoteButton: {
    flex: 1,
    backgroundColor: '#3b82f6',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveNoteText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  cancelNoteButton: {
    flex: 1,
    backgroundColor: '#e2e8f0',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelNoteText: {
    color: '#475569',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
  },
});
