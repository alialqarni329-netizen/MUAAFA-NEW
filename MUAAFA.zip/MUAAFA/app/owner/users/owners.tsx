import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Crown, Search, Building2, Calendar, Phone, Mail, CheckCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'المالكين', path: '/owner/users/owners' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'activity', label: 'النشاط', path: '/owner/users/activity' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
  { name: 'reset', label: 'إعادة التعيين', path: '/owner/users/reset' },
  { name: 'surveys', label: 'الاستبيانات', path: '/owner/users/health-surveys' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
];

interface OwnerUser {
  id: string;
  full_name: string;
  phone: string;
  email?: string;
  national_id?: string;
  created_at: string;
  business_registrations?: Array<{
    id: string;
    business_name_ar: string;
    business_type: string;
    commercial_registration_number: string;
    status: string;
  }>;
}

export default function BusinessOwners() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [owners, setOwners] = useState<OwnerUser[]>([]);
  const [filteredOwners, setFilteredOwners] = useState<OwnerUser[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    todayCount: 0,
    activeBusinesses: 0,
    pendingApprovals: 0,
  });

  useEffect(() => {
    loadOwners();
  }, []);

  useEffect(() => {
    filterOwners();
  }, [searchQuery, owners]);

  async function loadOwners() {
    try {
      const { data: usersData } = await supabase
        .from('users')
        .select(`
          *,
          business_registrations(
            id,
            business_name_ar,
            business_type,
            commercial_registration_number,
            status
          )
        `)
        .eq('user_role', 'business_owner')
        .order('created_at', { ascending: false });

      const ownersData = usersData || [];
      const today = new Date().toISOString().split('T')[0];

      setOwners(ownersData);
      setFilteredOwners(ownersData);

      const todayOwners = ownersData.filter(o => o.created_at.startsWith(today));
      const activeBusinessCount = ownersData.reduce((count, owner) => {
        const activeBusiness = owner.business_registrations?.filter(b => b.status === 'approved').length || 0;
        return count + activeBusiness;
      }, 0);
      const pendingBusinessCount = ownersData.reduce((count, owner) => {
        const pendingBusiness = owner.business_registrations?.filter(b => b.status === 'pending').length || 0;
        return count + pendingBusiness;
      }, 0);

      setStats({
        total: ownersData.length,
        todayCount: todayOwners.length,
        activeBusinesses: activeBusinessCount,
        pendingApprovals: pendingBusinessCount,
      });
    } catch (error) {
      console.error('Error loading business owners:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterOwners() {
    if (!searchQuery.trim()) {
      setFilteredOwners(owners);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = owners.filter(
      o =>
        o.full_name?.toLowerCase().includes(query) ||
        o.phone?.includes(query) ||
        o.email?.toLowerCase().includes(query) ||
        o.business_registrations?.some(b =>
          b.business_name_ar?.toLowerCase().includes(query) ||
          b.commercial_registration_number?.includes(query)
        )
    );
    setFilteredOwners(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadOwners();
  }

  function getBusinessTypeLabel(type: string) {
    const types: Record<string, string> = {
      hospital: 'مستشفى',
      clinic: 'عيادة',
      pharmacy: 'صيدلية',
      lab: 'مختبر',
      insurance: 'تأمين',
    };
    return types[type] || type;
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'approved':
        return { bg: '#d1fae5', text: '#065f46' };
      case 'pending':
        return { bg: '#fef3c7', text: '#92400e' };
      case 'rejected':
        return { bg: '#fee2e2', text: '#991b1b' };
      default:
        return { bg: '#f1f5f9', text: '#475569' };
    }
  }

  function getStatusLabel(status: string) {
    const labels: Record<string, string> = {
      approved: 'موثق',
      pending: 'قيد المراجعة',
      rejected: 'مرفوض',
      suspended: 'موقوف',
    };
    return labels[status] || status;
  }

  if (loading) {
    return (
      <OwnerTabLayout title="ملاك الشركات" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#f59e0b" />
          <Text style={styles.loadingText}>جاري تحميل المالكين...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="ملاك الشركات" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Crown size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المالكين</Text>
          </View>

          <View style={styles.statCard}>
            <Calendar size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayCount}</Text>
            <Text style={styles.statLabel}>تسجيلات اليوم</Text>
          </View>

          <View style={styles.statCard}>
            <Building2 size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.activeBusinesses}</Text>
            <Text style={styles.statLabel}>أعمال موثقة</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.pendingApprovals}</Text>
            <Text style={styles.statLabel}>طلبات معلقة</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث بالاسم أو الجوال أو اسم الشركة..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredOwners.length > 0 ? (
          filteredOwners.map((owner) => (
            <View key={owner.id} style={styles.ownerCard}>
              <View style={styles.ownerHeader}>
                <View style={styles.iconContainer}>
                  <Crown size={20} color="#f59e0b" strokeWidth={2} />
                </View>
                <View style={styles.ownerInfo}>
                  <Text style={styles.ownerName}>{owner.full_name || 'بدون اسم'}</Text>
                  <View style={styles.contactRow}>
                    <Phone size={12} color="#64748b" strokeWidth={2} />
                    <Text style={styles.contactText}>{owner.phone || '-'}</Text>
                  </View>
                  {owner.email && (
                    <View style={styles.contactRow}>
                      <Mail size={12} color="#64748b" strokeWidth={2} />
                      <Text style={styles.contactText}>{owner.email}</Text>
                    </View>
                  )}
                </View>
              </View>

              {owner.business_registrations && owner.business_registrations.length > 0 && (
                <View style={styles.businessSection}>
                  <Text style={styles.businessSectionTitle}>الأعمال المسجلة:</Text>
                  {owner.business_registrations.map((business) => {
                    const statusColors = getStatusColor(business.status);
                    return (
                      <View key={business.id} style={styles.businessCard}>
                        <View style={styles.businessHeader}>
                          <Building2 size={16} color="#3b82f6" strokeWidth={2} />
                          <Text style={styles.businessName}>{business.business_name_ar}</Text>
                          <View style={[styles.statusBadge, { backgroundColor: statusColors.bg }]}>
                            <Text style={[styles.statusText, { color: statusColors.text }]}>
                              {getStatusLabel(business.status)}
                            </Text>
                          </View>
                        </View>
                        <View style={styles.businessDetails}>
                          <Text style={styles.businessType}>
                            {getBusinessTypeLabel(business.business_type)}
                          </Text>
                          {business.commercial_registration_number && (
                            <Text style={styles.crNumber}>
                              س.ت: {business.commercial_registration_number}
                            </Text>
                          )}
                        </View>
                      </View>
                    );
                  })}
                </View>
              )}

              <View style={styles.ownerFooter}>
                <Text style={styles.joinDate}>
                  انضم في: {new Date(owner.created_at).toLocaleDateString('ar-SA', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </Text>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Crown size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا يوجد ملاك شركات'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '22%',
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  ownerCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fef3c7',
  },
  ownerHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#fef3c7',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ownerInfo: {
    flex: 1,
  },
  ownerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 6,
    textAlign: 'right',
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  contactText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  businessSection: {
    gap: 8,
    marginBottom: 12,
  },
  businessSectionTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  businessCard: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  businessHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  businessName: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
  businessDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  businessType: {
    fontSize: 12,
    color: '#3b82f6',
    fontWeight: '600',
  },
  crNumber: {
    fontSize: 11,
    color: '#64748b',
  },
  ownerFooter: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  joinDate: {
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'right',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
