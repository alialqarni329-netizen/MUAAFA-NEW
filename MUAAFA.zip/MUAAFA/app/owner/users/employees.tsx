import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Briefcase, Search, Building2, Calendar, Phone, Mail, Shield } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'المالكين', path: '/owner/users/owners' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'activity', label: 'النشاط', path: '/owner/users/activity' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
  { name: 'reset', label: 'إعادة التعيين', path: '/owner/users/reset' },
  { name: 'surveys', label: 'الاستبيانات', path: '/owner/users/health-surveys' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
];

interface EmployeeUser {
  id: string;
  full_name: string;
  phone: string;
  email?: string;
  national_id?: string;
  created_at: string;
  business_id?: string;
  position?: string;
  business_registrations?: {
    id: string;
    business_name_ar: string;
    business_type: string;
    status: string;
  };
}

export default function Employees() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [employees, setEmployees] = useState<EmployeeUser[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<EmployeeUser[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    todayCount: 0,
    activeCount: 0,
    byBusinessType: {} as Record<string, number>,
  });

  useEffect(() => {
    loadEmployees();
  }, []);

  useEffect(() => {
    filterEmployees();
  }, [searchQuery, employees]);

  async function loadEmployees() {
    try {
      const { data: usersData } = await supabase
        .from('users')
        .select(`
          *,
          business_registrations(
            id,
            business_name_ar,
            business_type,
            status
          )
        `)
        .eq('user_role', 'employee')
        .order('created_at', { ascending: false });

      const employeesData = usersData || [];
      const today = new Date().toISOString().split('T')[0];

      setEmployees(employeesData);
      setFilteredEmployees(employeesData);

      const todayEmployees = employeesData.filter(e => e.created_at.startsWith(today));
      const activeEmployees = employeesData.filter(e =>
        e.business_registrations?.status === 'approved'
      );

      const businessTypeCounts: Record<string, number> = {};
      employeesData.forEach(employee => {
        const type = employee.business_registrations?.business_type || 'other';
        businessTypeCounts[type] = (businessTypeCounts[type] || 0) + 1;
      });

      setStats({
        total: employeesData.length,
        todayCount: todayEmployees.length,
        activeCount: activeEmployees.length,
        byBusinessType: businessTypeCounts,
      });
    } catch (error) {
      console.error('Error loading employees:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterEmployees() {
    if (!searchQuery.trim()) {
      setFilteredEmployees(employees);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = employees.filter(
      e =>
        e.full_name?.toLowerCase().includes(query) ||
        e.phone?.includes(query) ||
        e.email?.toLowerCase().includes(query) ||
        e.national_id?.includes(query) ||
        e.business_registrations?.business_name_ar?.toLowerCase().includes(query)
    );
    setFilteredEmployees(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadEmployees();
  }

  function getBusinessTypeLabel(type: string) {
    const types: Record<string, string> = {
      hospital: 'مستشفى',
      clinic: 'عيادة',
      pharmacy: 'صيدلية',
      lab: 'مختبر',
      insurance: 'تأمين',
    };
    return types[type] || type;
  }

  function getBusinessTypeIcon(type: string) {
    return <Building2 size={14} color="#3b82f6" strokeWidth={2} />;
  }

  if (loading) {
    return (
      <OwnerTabLayout title="موظفو الشركات" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل الموظفين...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="موظفو الشركات" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Briefcase size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الموظفين</Text>
          </View>

          <View style={styles.statCard}>
            <Calendar size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayCount}</Text>
            <Text style={styles.statLabel}>تسجيلات اليوم</Text>
          </View>

          <View style={styles.statCard}>
            <Shield size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.activeCount}</Text>
            <Text style={styles.statLabel}>موظفون نشطون</Text>
          </View>

          <View style={styles.statCard}>
            <Building2 size={22} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{Object.keys(stats.byBusinessType).length}</Text>
            <Text style={styles.statLabel}>أنواع الأعمال</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث بالاسم أو الجوال أو الهوية أو اسم الشركة..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredEmployees.length > 0 ? (
          filteredEmployees.map((employee) => (
            <View key={employee.id} style={styles.employeeCard}>
              <View style={styles.employeeHeader}>
                <View style={styles.iconContainer}>
                  <Briefcase size={20} color="#3b82f6" strokeWidth={2} />
                </View>
                <View style={styles.employeeInfo}>
                  <Text style={styles.employeeName}>{employee.full_name || 'بدون اسم'}</Text>
                  <View style={styles.contactRow}>
                    <Phone size={12} color="#64748b" strokeWidth={2} />
                    <Text style={styles.contactText}>{employee.phone || '-'}</Text>
                  </View>
                  {employee.email && (
                    <View style={styles.contactRow}>
                      <Mail size={12} color="#64748b" strokeWidth={2} />
                      <Text style={styles.contactText}>{employee.email}</Text>
                    </View>
                  )}
                </View>
              </View>

              {employee.business_registrations && (
                <View style={styles.businessSection}>
                  <View style={styles.businessCard}>
                    <View style={styles.businessHeader}>
                      {getBusinessTypeIcon(employee.business_registrations.business_type)}
                      <Text style={styles.businessName}>
                        {employee.business_registrations.business_name_ar}
                      </Text>
                    </View>
                    <View style={styles.businessFooter}>
                      <Text style={styles.businessType}>
                        {getBusinessTypeLabel(employee.business_registrations.business_type)}
                      </Text>
                      {employee.business_registrations.status === 'approved' && (
                        <View style={styles.activeBadge}>
                          <Text style={styles.activeBadgeText}>نشط</Text>
                        </View>
                      )}
                    </View>
                  </View>
                </View>
              )}

              <View style={styles.employeeFooter}>
                {employee.national_id && (
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>رقم الهوية:</Text>
                    <Text style={styles.detailValue}>{employee.national_id}</Text>
                  </View>
                )}
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>تاريخ الانضمام:</Text>
                  <Text style={styles.detailValue}>
                    {new Date(employee.created_at).toLocaleDateString('ar-SA', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </Text>
                </View>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Briefcase size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا يوجد موظفون'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '22%',
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  employeeCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#dbeafe',
  },
  employeeHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#dbeafe',
    justifyContent: 'center',
    alignItems: 'center',
  },
  employeeInfo: {
    flex: 1,
  },
  employeeName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 6,
    textAlign: 'right',
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  contactText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  businessSection: {
    marginBottom: 12,
  },
  businessCard: {
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  businessHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  businessName: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  businessFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  businessType: {
    fontSize: 12,
    color: '#3b82f6',
    fontWeight: '600',
  },
  activeBadge: {
    backgroundColor: '#d1fae5',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  activeBadgeText: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#065f46',
  },
  employeeFooter: {
    gap: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 12,
    color: '#0f172a',
    fontWeight: '600',
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
