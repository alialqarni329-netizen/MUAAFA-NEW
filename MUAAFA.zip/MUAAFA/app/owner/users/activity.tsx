import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Activity, CheckCircle, XCircle, Clock, Search, ShoppingCart, Calendar as CalendarIcon, CreditCard } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'جميع المستخدمين', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'الملاك', path: '/owner/users/owners' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/users/activity' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'reset', label: 'سجل الدخول', path: '/owner/users/reset' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
];

interface ActivityLog {
  id: string;
  user_id: string;
  action_type: string;
  action_details: string;
  status: string;
  created_at: string;
  users?: {
    full_name: string;
    phone_number: string;
  };
}

export default function UserActivity() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [filteredActivities, setFilteredActivities] = useState<ActivityLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    successful: 0,
    failed: 0,
    todayCount: 0,
  });

  useEffect(() => {
    loadActivities();
  }, []);

  useEffect(() => {
    filterActivities();
  }, [searchQuery, activities]);

  async function loadActivities() {
    try {
      const { data } = await supabase
        .from('user_activity_logs')
        .select('*, users(full_name, phone_number)')
        .order('created_at', { ascending: false })
        .limit(100);

      const activitiesData = data || [];
      const today = new Date().toISOString().split('T')[0];

      setActivities(activitiesData);
      setFilteredActivities(activitiesData);

      const todayActivities = activitiesData.filter(a => a.created_at.startsWith(today));

      setStats({
        total: activitiesData.length,
        successful: activitiesData.filter(a => a.status === 'success').length,
        failed: activitiesData.filter(a => a.status === 'failed').length,
        todayCount: todayActivities.length,
      });
    } catch (error) {
      console.error('Error loading activities:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterActivities() {
    if (!searchQuery.trim()) {
      setFilteredActivities(activities);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = activities.filter(
      a =>
        a.users?.full_name?.toLowerCase().includes(query) ||
        a.users?.phone_number?.includes(query) ||
        a.action_type?.toLowerCase().includes(query)
    );
    setFilteredActivities(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadActivities();
  }

  function getActionIcon(actionType: string) {
    switch (actionType) {
      case 'pharmacy_order':
      case 'medication_purchase':
        return <ShoppingCart size={16} color="#8b5cf6" strokeWidth={2} />;
      case 'appointment_booking':
      case 'session_booked':
        return <CalendarIcon size={16} color="#3b82f6" strokeWidth={2} />;
      case 'payment':
      case 'subscription':
        return <CreditCard size={16} color="#10b981" strokeWidth={2} />;
      default:
        return <Activity size={16} color="#64748b" strokeWidth={2} />;
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'success':
        return <CheckCircle size={14} color="#10b981" strokeWidth={2} />;
      case 'failed':
        return <XCircle size={14} color="#ef4444" strokeWidth={2} />;
      case 'pending':
        return <Clock size={14} color="#f59e0b" strokeWidth={2} />;
      default:
        return null;
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'success':
        return { bg: '#d1fae5', text: '#065f46' };
      case 'failed':
        return { bg: '#fee2e2', text: '#991b1b' };
      case 'pending':
        return { bg: '#fef3c7', text: '#92400e' };
      default:
        return { bg: '#f1f5f9', text: '#475569' };
    }
  }

  function getActionTypeText(actionType: string) {
    const types: Record<string, string> = {
      pharmacy_order: 'طلب دواء',
      medication_purchase: 'شراء دواء',
      appointment_booking: 'حجز موعد',
      session_booked: 'حجز جلسة',
      payment: 'دفع',
      subscription: 'اشتراك',
      login: 'تسجيل دخول',
      logout: 'تسجيل خروج',
    };
    return types[actionType] || actionType;
  }

  if (loading) {
    return (
      <OwnerTabLayout title="سجل نشاط المستخدم" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل السجلات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="سجل نشاط المستخدم" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Activity size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي العمليات</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.successful}</Text>
            <Text style={styles.statLabel}>ناجحة</Text>
          </View>

          <View style={styles.statCard}>
            <XCircle size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.failed}</Text>
            <Text style={styles.statLabel}>فاشلة</Text>
          </View>

          <View style={styles.statCard}>
            <Clock size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.todayCount}</Text>
            <Text style={styles.statLabel}>عمليات اليوم</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث بالاسم أو الجوال أو نوع العملية..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredActivities.length > 0 ? (
          filteredActivities.map((activity) => {
            const colors = getStatusColor(activity.status);
            return (
              <View key={activity.id} style={styles.activityCard}>
                <View style={styles.activityHeader}>
                  {getActionIcon(activity.action_type)}
                  <View style={styles.activityInfo}>
                    <Text style={styles.userName}>{activity.users?.full_name || 'مستخدم'}</Text>
                    <Text style={styles.actionType}>{getActionTypeText(activity.action_type)}</Text>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
                    {getStatusIcon(activity.status)}
                    <Text style={[styles.statusText, { color: colors.text }]}>
                      {activity.status === 'success' ? 'ناجح' : activity.status === 'failed' ? 'فاشل' : 'معلق'}
                    </Text>
                  </View>
                </View>

                {activity.action_details && (
                  <View style={styles.detailsBox}>
                    <Text style={styles.detailsText}>{activity.action_details}</Text>
                  </View>
                )}

                <Text style={styles.timestamp}>
                  {new Date(activity.created_at).toLocaleString('ar-SA', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </Text>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Activity size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد سجلات نشاط'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '22%',
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 20,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  activityCard: {
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  activityHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  activityInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  actionType: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
  detailsBox: {
    backgroundColor: '#f8fafc',
    padding: 10,
    borderRadius: 8,
    marginBottom: 8,
  },
  detailsText: {
    fontSize: 13,
    color: '#475569',
    textAlign: 'right',
    lineHeight: 20,
  },
  timestamp: {
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'left',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
