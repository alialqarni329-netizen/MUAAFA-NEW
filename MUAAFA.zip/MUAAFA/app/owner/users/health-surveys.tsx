import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { FileText, Search, User, Calendar, Pill, AlertCircle, Download } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'جميع المستخدمين', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'الملاك', path: '/owner/users/owners' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/users/activity' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'reset', label: 'سجل الدخول', path: '/owner/users/reset' },
  { name: 'health-surveys', label: 'الاستبيانات', path: '/owner/users/health-surveys' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
];

interface HealthSurvey {
  id: string;
  user_id: string;
  chronic_diseases: string[];
  allergies: string[];
  current_medications: string[];
  additional_notes: string;
  created_at: string;
  users?: {
    full_name: string;
    phone_number: string;
  };
}

export default function HealthSurveys() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [surveys, setSurveys] = useState<HealthSurvey[]>([]);
  const [filteredSurveys, setFilteredSurveys] = useState<HealthSurvey[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    withChronicDiseases: 0,
    withAllergies: 0,
    withMedications: 0,
  });

  useEffect(() => {
    loadHealthSurveys();
  }, []);

  useEffect(() => {
    filterSurveys();
  }, [searchQuery, surveys]);

  async function loadHealthSurveys() {
    try {
      const { data } = await supabase
        .from('health_questionnaires')
        .select('*, users(full_name, phone_number)')
        .order('created_at', { ascending: false });

      const surveysData = data || [];

      setSurveys(surveysData);
      setFilteredSurveys(surveysData);

      setStats({
        total: surveysData.length,
        withChronicDiseases: surveysData.filter(s => s.chronic_diseases && s.chronic_diseases.length > 0).length,
        withAllergies: surveysData.filter(s => s.allergies && s.allergies.length > 0).length,
        withMedications: surveysData.filter(s => s.current_medications && s.current_medications.length > 0).length,
      });
    } catch (error) {
      console.error('Error loading health surveys:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterSurveys() {
    if (!searchQuery.trim()) {
      setFilteredSurveys(surveys);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = surveys.filter(
      s =>
        s.users?.full_name?.toLowerCase().includes(query) ||
        s.users?.phone_number?.includes(query)
    );
    setFilteredSurveys(filtered);
  }

  async function handleExportToClinic(surveyId: string, patientName: string) {
    Alert.alert(
      'تصدير للعيادة',
      `هل تريد إرسال استبيان ${patientName} للطبيب؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'إرسال',
          onPress: async () => {
            Alert.alert('نجح', 'تم إرسال الاستبيان للطبيب بنجاح');
          },
        },
      ]
    );
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadHealthSurveys();
  }

  if (loading) {
    return (
      <OwnerTabLayout title="الاستبيانات الصحية" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#10b981" />
          <Text style={styles.loadingText}>جاري تحميل الاستبيانات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="الاستبيانات الصحية" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <FileText size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي الاستبيانات</Text>
          </View>

          <View style={styles.statCard}>
            <AlertCircle size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.withChronicDiseases}</Text>
            <Text style={styles.statLabel}>أمراض مزمنة</Text>
          </View>

          <View style={styles.statCard}>
            <AlertCircle size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.withAllergies}</Text>
            <Text style={styles.statLabel}>حساسية</Text>
          </View>

          <View style={styles.statCard}>
            <Pill size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.withMedications}</Text>
            <Text style={styles.statLabel}>أدوية حالية</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث بالاسم أو رقم الجوال..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredSurveys.length > 0 ? (
          filteredSurveys.map((survey) => (
            <View key={survey.id} style={styles.surveyCard}>
              <View style={styles.surveyHeader}>
                <User size={18} color="#10b981" strokeWidth={2} />
                <View style={styles.patientInfo}>
                  <Text style={styles.patientName}>{survey.users?.full_name || 'مريض'}</Text>
                  <Text style={styles.patientPhone}>{survey.users?.phone_number || '-'}</Text>
                </View>
                <TouchableOpacity
                  style={styles.exportButton}
                  onPress={() => handleExportToClinic(survey.id, survey.users?.full_name || 'المريض')}>
                  <Download size={16} color="#ffffff" strokeWidth={2} />
                  <Text style={styles.exportText}>إرسال للطبيب</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.surveyContent}>
                {survey.chronic_diseases && survey.chronic_diseases.length > 0 && (
                  <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                      <AlertCircle size={16} color="#ef4444" strokeWidth={2} />
                      <Text style={styles.sectionTitle}>الأمراض المزمنة:</Text>
                    </View>
                    <View style={styles.tagsContainer}>
                      {survey.chronic_diseases.map((disease, index) => (
                        <View key={index} style={[styles.tag, { backgroundColor: '#fee2e2', borderColor: '#ef4444' }]}>
                          <Text style={[styles.tagText, { color: '#991b1b' }]}>{disease}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                )}

                {survey.allergies && survey.allergies.length > 0 && (
                  <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                      <AlertCircle size={16} color="#f59e0b" strokeWidth={2} />
                      <Text style={styles.sectionTitle}>الحساسية:</Text>
                    </View>
                    <View style={styles.tagsContainer}>
                      {survey.allergies.map((allergy, index) => (
                        <View key={index} style={[styles.tag, { backgroundColor: '#fef3c7', borderColor: '#f59e0b' }]}>
                          <Text style={[styles.tagText, { color: '#92400e' }]}>{allergy}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                )}

                {survey.current_medications && survey.current_medications.length > 0 && (
                  <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                      <Pill size={16} color="#3b82f6" strokeWidth={2} />
                      <Text style={styles.sectionTitle}>الأدوية الحالية:</Text>
                    </View>
                    <View style={styles.tagsContainer}>
                      {survey.current_medications.map((medication, index) => (
                        <View key={index} style={[styles.tag, { backgroundColor: '#dbeafe', borderColor: '#3b82f6' }]}>
                          <Text style={[styles.tagText, { color: '#1e40af' }]}>{medication}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                )}

                {survey.additional_notes && (
                  <View style={styles.notesBox}>
                    <Text style={styles.notesLabel}>ملاحظات إضافية:</Text>
                    <Text style={styles.notesText}>{survey.additional_notes}</Text>
                  </View>
                )}

                <View style={styles.dateRow}>
                  <Calendar size={12} color="#94a3b8" strokeWidth={2} />
                  <Text style={styles.dateText}>
                    {new Date(survey.created_at).toLocaleDateString('ar-SA', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </Text>
                </View>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <FileText size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد استبيانات صحية'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '22%',
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  surveyCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#d1fae5',
  },
  surveyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  patientInfo: {
    flex: 1,
  },
  patientName: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  patientPhone: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  exportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#10b981',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  exportText: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '600',
  },
  surveyContent: {
    gap: 12,
  },
  section: {
    gap: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#475569',
    textAlign: 'right',
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  tag: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 6,
    borderWidth: 1,
  },
  tagText: {
    fontSize: 12,
    fontWeight: '600',
  },
  notesBox: {
    backgroundColor: '#f8fafc',
    padding: 10,
    borderRadius: 8,
  },
  notesLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 4,
    textAlign: 'right',
  },
  notesText: {
    fontSize: 13,
    color: '#64748b',
    lineHeight: 20,
    textAlign: 'right',
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  dateText: {
    fontSize: 11,
    color: '#94a3b8',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
