import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Shield, Search, Camera, MapPin, Bell, Image, CheckCircle, XCircle, Clock } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'الكل', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'المالكين', path: '/owner/users/owners' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'activity', label: 'النشاط', path: '/owner/users/activity' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
  { name: 'reset', label: 'إعادة التعيين', path: '/owner/users/reset' },
  { name: 'surveys', label: 'الاستبيانات', path: '/owner/users/health-surveys' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
];

interface UserPermission {
  id: string;
  user_id: string;
  camera_permission: boolean;
  location_permission: boolean;
  notifications_permission: boolean;
  photos_permission: boolean;
  camera_granted_at?: string;
  location_granted_at?: string;
  notifications_granted_at?: string;
  photos_granted_at?: string;
  updated_at: string;
  users?: {
    full_name: string;
    phone: string;
  };
}

export default function UserPermissions() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [permissions, setPermissions] = useState<UserPermission[]>([]);
  const [filteredPermissions, setFilteredPermissions] = useState<UserPermission[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'granted' | 'denied'>('all');
  const [stats, setStats] = useState({
    total: 0,
    cameraGranted: 0,
    locationGranted: 0,
    notificationsGranted: 0,
    photosGranted: 0,
  });

  useEffect(() => {
    loadPermissions();
  }, []);

  useEffect(() => {
    filterPermissions();
  }, [searchQuery, filterType, permissions]);

  async function loadPermissions() {
    try {
      const { data } = await supabase
        .from('user_permissions')
        .select('*, users(full_name, phone)')
        .order('updated_at', { ascending: false });

      const permissionsData = data || [];

      setPermissions(permissionsData);
      setFilteredPermissions(permissionsData);

      setStats({
        total: permissionsData.length,
        cameraGranted: permissionsData.filter(p => p.camera_permission).length,
        locationGranted: permissionsData.filter(p => p.location_permission).length,
        notificationsGranted: permissionsData.filter(p => p.notifications_permission).length,
        photosGranted: permissionsData.filter(p => p.photos_permission).length,
      });
    } catch (error) {
      console.error('Error loading permissions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterPermissions() {
    let filtered = permissions;

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        p =>
          p.users?.full_name?.toLowerCase().includes(query) ||
          p.users?.phone?.includes(query)
      );
    }

    if (filterType === 'granted') {
      filtered = filtered.filter(
        p => p.camera_permission || p.location_permission || p.notifications_permission || p.photos_permission
      );
    } else if (filterType === 'denied') {
      filtered = filtered.filter(
        p => !p.camera_permission && !p.location_permission && !p.notifications_permission && !p.photos_permission
      );
    }

    setFilteredPermissions(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadPermissions();
  }

  function getPermissionIcon(type: 'camera' | 'location' | 'notifications' | 'photos', granted: boolean) {
    const color = granted ? '#10b981' : '#94a3b8';
    const size = 16;

    switch (type) {
      case 'camera':
        return <Camera size={size} color={color} strokeWidth={2} />;
      case 'location':
        return <MapPin size={size} color={color} strokeWidth={2} />;
      case 'notifications':
        return <Bell size={size} color={color} strokeWidth={2} />;
      case 'photos':
        return <Image size={size} color={color} strokeWidth={2} />;
    }
  }

  function getPermissionLabel(type: string) {
    const labels: Record<string, string> = {
      camera: 'الكاميرا',
      location: 'الموقع',
      notifications: 'الإشعارات',
      photos: 'الصور',
    };
    return labels[type] || type;
  }

  if (loading) {
    return (
      <OwnerTabLayout title="صلاحيات المستخدمين" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8b5cf6" />
          <Text style={styles.loadingText}>جاري تحميل الصلاحيات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="صلاحيات المستخدمين" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Shield size={22} color="#8b5cf6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المستخدمين</Text>
          </View>

          <View style={styles.statCard}>
            <Camera size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.cameraGranted}</Text>
            <Text style={styles.statLabel}>كاميرا</Text>
          </View>

          <View style={styles.statCard}>
            <MapPin size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.locationGranted}</Text>
            <Text style={styles.statLabel}>موقع</Text>
          </View>

          <View style={styles.statCard}>
            <Bell size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.notificationsGranted}</Text>
            <Text style={styles.statLabel}>إشعارات</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث بالاسم أو رقم الجوال..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        <View style={styles.filterButtons}>
          <TouchableOpacity
            style={[styles.filterBtn, filterType === 'all' && styles.filterBtnActive]}
            onPress={() => setFilterType('all')}>
            <Text style={[styles.filterBtnText, filterType === 'all' && styles.filterBtnTextActive]}>
              الكل
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.filterBtn, filterType === 'granted' && styles.filterBtnActive]}
            onPress={() => setFilterType('granted')}>
            <CheckCircle size={14} color={filterType === 'granted' ? '#ffffff' : '#10b981'} strokeWidth={2} />
            <Text style={[styles.filterBtnText, filterType === 'granted' && styles.filterBtnTextActive]}>
              ممنوحة
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.filterBtn, filterType === 'denied' && styles.filterBtnActive]}
            onPress={() => setFilterType('denied')}>
            <XCircle size={14} color={filterType === 'denied' ? '#ffffff' : '#ef4444'} strokeWidth={2} />
            <Text style={[styles.filterBtnText, filterType === 'denied' && styles.filterBtnTextActive]}>
              مرفوضة
            </Text>
          </TouchableOpacity>
        </View>

        {filteredPermissions.length > 0 ? (
          filteredPermissions.map((perm) => {
            const allPermissions = [
              { type: 'camera' as const, granted: perm.camera_permission, grantedAt: perm.camera_granted_at },
              { type: 'location' as const, granted: perm.location_permission, grantedAt: perm.location_granted_at },
              { type: 'notifications' as const, granted: perm.notifications_permission, grantedAt: perm.notifications_granted_at },
              { type: 'photos' as const, granted: perm.photos_permission, grantedAt: perm.photos_granted_at },
            ];

            const grantedCount = allPermissions.filter(p => p.granted).length;

            return (
              <View key={perm.id} style={styles.permissionCard}>
                <View style={styles.permissionHeader}>
                  <Shield size={18} color="#8b5cf6" strokeWidth={2} />
                  <View style={styles.userInfo}>
                    <Text style={styles.userName}>{perm.users?.full_name || 'مستخدم'}</Text>
                    <Text style={styles.userPhone}>{perm.users?.phone || '-'}</Text>
                  </View>
                  <View style={styles.countBadge}>
                    <Text style={styles.countText}>{grantedCount}/4</Text>
                  </View>
                </View>

                <View style={styles.permissionsGrid}>
                  {allPermissions.map((permission) => (
                    <View
                      key={permission.type}
                      style={[
                        styles.permissionItem,
                        { backgroundColor: permission.granted ? '#d1fae5' : '#f1f5f9' }
                      ]}>
                      {getPermissionIcon(permission.type, permission.granted)}
                      <Text
                        style={[
                          styles.permissionLabel,
                          { color: permission.granted ? '#065f46' : '#64748b' }
                        ]}>
                        {getPermissionLabel(permission.type)}
                      </Text>
                      {permission.granted ? (
                        <CheckCircle size={14} color="#10b981" strokeWidth={2} />
                      ) : (
                        <XCircle size={14} color="#94a3b8" strokeWidth={2} />
                      )}
                    </View>
                  ))}
                </View>

                <View style={styles.permissionFooter}>
                  <Clock size={12} color="#94a3b8" strokeWidth={2} />
                  <Text style={styles.updateTime}>
                    آخر تحديث: {new Date(perm.updated_at).toLocaleDateString('ar-SA', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <Shield size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد صلاحيات مسجلة'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '22%',
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  filterButtons: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  filterBtnActive: {
    backgroundColor: '#8b5cf6',
    borderColor: '#8b5cf6',
  },
  filterBtnText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748b',
  },
  filterBtnTextActive: {
    color: '#ffffff',
  },
  permissionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e9d5ff',
  },
  permissionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  userPhone: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  countBadge: {
    backgroundColor: '#8b5cf6',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  countText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  permissionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  permissionItem: {
    flex: 1,
    minWidth: '47%',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    padding: 10,
    borderRadius: 8,
  },
  permissionLabel: {
    flex: 1,
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'right',
  },
  permissionFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  updateTime: {
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'right',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
