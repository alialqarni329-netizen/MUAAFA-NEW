import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { UserX, Search, Unlock, AlertCircle, Calendar, Shield } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'جميع المستخدمين', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'الملاك', path: '/owner/users/owners' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/users/activity' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'reset', label: 'سجل الدخول', path: '/owner/users/reset' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
];

interface SuspendedUser {
  id: string;
  full_name: string;
  phone: string;
  email: string;
  user_role: 'owner' | 'business_admin' | 'individual_user' | null;
  banned_until: string;
  created_at: string;
  updated_at: string;
}

export default function SuspendedUsers() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [users, setUsers] = useState<SuspendedUser[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<SuspendedUser[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [unsuspending, setUnsuspending] = useState<string | null>(null);

  useEffect(() => {
    loadSuspendedUsers();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [searchQuery, users]);

  async function loadSuspendedUsers() {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .not('banned_until', 'is', null)
        .gte('banned_until', new Date().toISOString())
        .order('updated_at', { ascending: false });

      if (error) {
        console.error('Error loading suspended users:', error);
        setUsers([]);
        setFilteredUsers([]);
      } else {
        const usersData = data || [];
        setUsers(usersData);
        setFilteredUsers(usersData);
      }
    } catch (error) {
      console.error('Error loading suspended users:', error);
      setUsers([]);
      setFilteredUsers([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterUsers() {
    if (!searchQuery.trim()) {
      setFilteredUsers(users);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = users.filter(
      user =>
        user.full_name?.toLowerCase().includes(query) ||
        user.phone?.includes(query) ||
        user.email?.toLowerCase().includes(query)
    );
    setFilteredUsers(filtered);
  }

  async function handleUnsuspend(userId: string, userName: string) {
    Alert.alert(
      'إلغاء الحظر',
      `هل أنت متأكد من إلغاء حظر ${userName || 'هذا المستخدم'}؟`,
      [
        {
          text: 'إلغاء',
          style: 'cancel',
        },
        {
          text: 'تأكيد',
          onPress: async () => {
            try {
              setUnsuspending(userId);

              const { error } = await supabase
                .from('users')
                .update({
                  banned_until: null,
                  updated_at: new Date().toISOString()
                })
                .eq('id', userId);

              if (error) throw error;

              Alert.alert('نجح', 'تم إلغاء حظر المستخدم بنجاح');
              await loadSuspendedUsers();
            } catch (error: any) {
              console.error('Error unsuspending user:', error);
              Alert.alert('خطأ', `فشل إلغاء حظر المستخدم: ${error.message}`);
            } finally {
              setUnsuspending(null);
            }
          },
        },
      ]
    );
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadSuspendedUsers();
  }

  function getRoleLabel(role: string | null) {
    switch (role) {
      case 'individual_user':
        return 'فرد';
      case 'business_admin':
        return 'مدير أعمال';
      case 'owner':
        return 'مالك';
      default:
        return 'غير محدد';
    }
  }

  function getDaysSince(dateString: string) {
    const diff = Date.now() - new Date(dateString).getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days === 0) return 'اليوم';
    if (days === 1) return 'أمس';
    return `منذ ${days} أيام`;
  }

  if (loading) {
    return (
      <OwnerTabLayout title="المستخدمون الموقوفون" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل المستخدمين...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="المستخدمون الموقوفون" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsBox}>
          <UserX size={24} color="#ef4444" strokeWidth={2} />
          <View style={styles.statsInfo}>
            <Text style={styles.statsValue}>{users.length}</Text>
            <Text style={styles.statsLabel}>مستخدم موقوف</Text>
          </View>
        </View>

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث بالاسم أو رقم الجوال..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredUsers.length > 0 ? (
          filteredUsers.map((user) => (
            <View key={user.id} style={styles.userCard}>
              <View style={styles.userHeader}>
                <View style={styles.avatarContainer}>
                  <UserX size={20} color="#ef4444" strokeWidth={2} />
                </View>
                <View style={styles.userInfo}>
                  <Text style={styles.userName}>{user.full_name || 'بدون اسم'}</Text>
                  <Text style={styles.userPhone}>{user.phone || '-'}</Text>
                  <View style={styles.roleBadge}>
                    <Text style={styles.roleText}>{getRoleLabel(user.user_role)}</Text>
                  </View>
                </View>
              </View>

              <View style={styles.reasonBox}>
                <View style={styles.reasonHeader}>
                  <AlertCircle size={16} color="#ef4444" strokeWidth={2} />
                  <Text style={styles.reasonTitle}>معلومات الحظر:</Text>
                </View>
                <Text style={styles.reasonText}>
                  محظور حتى: {new Date(user.banned_until).toLocaleDateString('ar-SA', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </Text>
              </View>

              <View style={styles.metaInfo}>
                <View style={styles.metaRow}>
                  <Calendar size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.metaText}>
                    تاريخ التسجيل: {new Date(user.created_at).toLocaleDateString('ar-SA', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </Text>
                </View>
                <View style={styles.metaRow}>
                  <Shield size={14} color="#64748b" strokeWidth={2} />
                  <Text style={styles.metaText}>
                    آخر تحديث: {getDaysSince(user.updated_at)}
                  </Text>
                </View>
              </View>

              <TouchableOpacity
                style={[styles.unsuspendBtn, unsuspending === user.id && styles.unsuspendBtnDisabled]}
                onPress={() => handleUnsuspend(user.id, user.full_name)}
                disabled={unsuspending === user.id}>
                {unsuspending === user.id ? (
                  <ActivityIndicator size="small" color="#ffffff" />
                ) : (
                  <>
                    <Unlock size={18} color="#ffffff" strokeWidth={2} />
                    <Text style={styles.unsuspendText}>إلغاء الحظر</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <UserX size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا يوجد مستخدمون موقوفون'}
            </Text>
            <Text style={styles.emptySubtext}>
              هذا شيء جيد! جميع المستخدمين نشطون
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#fee2e2',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  statsInfo: {
    flex: 1,
  },
  statsValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#991b1b',
    textAlign: 'right',
  },
  statsLabel: {
    fontSize: 13,
    color: '#991b1b',
    marginTop: 2,
    textAlign: 'right',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  userCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  avatarContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#fee2e2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  userPhone: {
    fontSize: 13,
    color: '#64748b',
    marginBottom: 6,
    textAlign: 'right',
  },
  roleBadge: {
    alignSelf: 'flex-end',
    backgroundColor: '#f1f5f9',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  roleText: {
    fontSize: 11,
    color: '#64748b',
    fontWeight: '600',
  },
  reasonBox: {
    backgroundColor: '#fef2f2',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  reasonHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  reasonTitle: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#991b1b',
  },
  reasonText: {
    fontSize: 13,
    color: '#7f1d1d',
    lineHeight: 20,
    textAlign: 'right',
  },
  metaInfo: {
    gap: 8,
    marginBottom: 12,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  unsuspendBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#10b981',
    paddingVertical: 12,
    borderRadius: 10,
  },
  unsuspendBtnDisabled: {
    opacity: 0.6,
  },
  unsuspendText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
    fontWeight: '600',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#cbd5e1',
    marginTop: 8,
    textAlign: 'center',
  },
});
