import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TextInput, TouchableOpacity, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { LogIn, CheckCircle, XCircle, AlertTriangle, Search, Smartphone, Globe } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const USERS_TABS = [
  { name: 'all', label: 'جميع المستخدمين', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'employees', label: 'الموظفين', path: '/owner/users/employees' },
  { name: 'owners', label: 'الملاك', path: '/owner/users/owners' },
  { name: 'actions', label: 'الإجراءات', path: '/owner/users/actions' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/users/activity' },
  { name: 'suspended', label: 'الموقوفين', path: '/owner/users/suspended' },
  { name: 'reset', label: 'سجل الدخول', path: '/owner/users/reset' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
];

interface LoginLog {
  id: string;
  user_id: string;
  phone_number: string;
  device_type: string;
  ip_address: string;
  login_status: string;
  failed_reason?: string;
  created_at: string;
  users?: {
    full_name: string;
  };
}

export default function LoginLogs() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [logs, setLogs] = useState<LoginLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<LoginLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({
    total: 0,
    successful: 0,
    failed: 0,
    todayCount: 0,
    suspiciousAttempts: 0,
  });

  useEffect(() => {
    loadLoginLogs();
  }, []);

  useEffect(() => {
    filterLogs();
  }, [searchQuery, logs]);

  async function loadLoginLogs() {
    try {
      const { data } = await supabase
        .from('login_logs')
        .select('*, users(full_name)')
        .order('created_at', { ascending: false })
        .limit(200);

      const logsData = data || [];
      const today = new Date().toISOString().split('T')[0];

      setLogs(logsData);
      setFilteredLogs(logsData);

      const todayLogs = logsData.filter(log => log.created_at.startsWith(today));

      const failedAttempts = new Map<string, number>();
      logsData
        .filter(log => log.login_status === 'failed')
        .forEach(log => {
          const key = `${log.phone_number}_${log.ip_address}`;
          failedAttempts.set(key, (failedAttempts.get(key) || 0) + 1);
        });

      const suspiciousCount = Array.from(failedAttempts.values()).filter(count => count >= 3).length;

      setStats({
        total: logsData.length,
        successful: logsData.filter(log => log.login_status === 'success').length,
        failed: logsData.filter(log => log.login_status === 'failed').length,
        todayCount: todayLogs.length,
        suspiciousAttempts: suspiciousCount,
      });
    } catch (error) {
      console.error('Error loading login logs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function filterLogs() {
    if (!searchQuery.trim()) {
      setFilteredLogs(logs);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = logs.filter(
      log =>
        log.phone_number?.includes(query) ||
        log.users?.full_name?.toLowerCase().includes(query) ||
        log.ip_address?.includes(query)
    );
    setFilteredLogs(filtered);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadLoginLogs();
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'success':
        return <CheckCircle size={16} color="#10b981" strokeWidth={2} />;
      case 'failed':
        return <XCircle size={16} color="#ef4444" strokeWidth={2} />;
      default:
        return <AlertTriangle size={16} color="#f59e0b" strokeWidth={2} />;
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'success':
        return { bg: '#d1fae5', text: '#065f46' };
      case 'failed':
        return { bg: '#fee2e2', text: '#991b1b' };
      default:
        return { bg: '#fef3c7', text: '#92400e' };
    }
  }

  function getDeviceIcon(deviceType: string) {
    if (deviceType?.toLowerCase().includes('ios') || deviceType?.toLowerCase().includes('iphone')) {
      return <Smartphone size={14} color="#64748b" strokeWidth={2} />;
    } else if (deviceType?.toLowerCase().includes('android')) {
      return <Smartphone size={14} color="#64748b" strokeWidth={2} />;
    }
    return <Globe size={14} color="#64748b" strokeWidth={2} />;
  }

  if (loading) {
    return (
      <OwnerTabLayout title="سجل الدخول" tabs={USERS_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل السجلات...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="سجل الدخول" tabs={USERS_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <LogIn size={22} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي المحاولات</Text>
          </View>

          <View style={styles.statCard}>
            <CheckCircle size={22} color="#10b981" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.successful}</Text>
            <Text style={styles.statLabel}>ناجح</Text>
          </View>

          <View style={styles.statCard}>
            <XCircle size={22} color="#ef4444" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.failed}</Text>
            <Text style={styles.statLabel}>فاشل</Text>
          </View>

          <View style={styles.statCard}>
            <AlertTriangle size={22} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.statValue}>{stats.suspiciousAttempts}</Text>
            <Text style={styles.statLabel}>مشبوه</Text>
          </View>
        </View>

        {stats.suspiciousAttempts > 0 && (
          <View style={styles.alertBox}>
            <AlertTriangle size={20} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.alertText}>
              تم رصد {stats.suspiciousAttempts} محاولة دخول مشبوهة (3+ محاولات فاشلة)
            </Text>
          </View>
        )}

        <View style={styles.searchBox}>
          <Search size={20} color="#64748b" strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="البحث برقم الجوال أو IP..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
        </View>

        {filteredLogs.length > 0 ? (
          filteredLogs.map((log) => {
            const colors = getStatusColor(log.login_status);
            return (
              <View key={log.id} style={styles.logCard}>
                <View style={styles.logHeader}>
                  <LogIn size={18} color="#3b82f6" strokeWidth={2} />
                  <View style={styles.logInfo}>
                    <Text style={styles.userName}>{log.users?.full_name || 'مستخدم'}</Text>
                    <Text style={styles.phoneNumber}>{log.phone_number}</Text>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
                    {getStatusIcon(log.login_status)}
                    <Text style={[styles.statusText, { color: colors.text }]}>
                      {log.login_status === 'success' ? 'نجح' : 'فشل'}
                    </Text>
                  </View>
                </View>

                <View style={styles.logDetails}>
                  <View style={styles.detailRow}>
                    {getDeviceIcon(log.device_type)}
                    <Text style={styles.detailText}>{log.device_type || 'غير محدد'}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Globe size={14} color="#64748b" strokeWidth={2} />
                    <Text style={styles.detailText}>{log.ip_address || '-'}</Text>
                  </View>
                  {log.login_status === 'failed' && log.failed_reason && (
                    <View style={styles.errorBox}>
                      <Text style={styles.errorText}>{log.failed_reason}</Text>
                    </View>
                  )}
                  <Text style={styles.timestamp}>
                    {new Date(log.created_at).toLocaleString('ar-SA', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
              </View>
            );
          })
        ) : (
          <View style={styles.emptyState}>
            <LogIn size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyText}>
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد سجلات دخول'}
            </Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '22%',
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 6,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'center',
  },
  alertBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#fef3c7',
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#f59e0b',
    marginBottom: 16,
  },
  alertText: {
    flex: 1,
    fontSize: 13,
    color: '#92400e',
    fontWeight: '600',
    textAlign: 'right',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#0f172a',
    textAlign: 'right',
  },
  logCard: {
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  logHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  logInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  phoneNumber: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
    textAlign: 'right',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
  logDetails: {
    gap: 6,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  errorBox: {
    backgroundColor: '#fee2e2',
    padding: 8,
    borderRadius: 6,
    marginTop: 4,
  },
  errorText: {
    fontSize: 12,
    color: '#991b1b',
    textAlign: 'right',
  },
  timestamp: {
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'left',
    marginTop: 4,
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 16,
    textAlign: 'center',
  },
});
