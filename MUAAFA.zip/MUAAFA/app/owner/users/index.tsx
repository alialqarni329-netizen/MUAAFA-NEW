import { Read } from '@/lib/supabase';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Users as UsersIcon, Search, Shield } from 'lucide-react-native';

const USERS_TABS = [
  { name: 'all', label: 'جميع المستخدمين', path: '/owner/users' },
  { name: 'individuals', label: 'الأفراد', path: '/owner/users/individuals' },
  { name: 'owners', label: 'ملاك الشركات', path: '/owner/users/owners' },
  { name: 'employees', label: 'الموظفون', path: '/owner/users/employees' },
  { name: 'suspended', label: 'الموقوفون', path: '/owner/users/suspended' },
  { name: 'permissions', label: 'الصلاحيات', path: '/owner/users/permissions' },
  { name: 'activity', label: 'سجل النشاط', path: '/owner/users/activity' },
  { name: 'reset', label: 'إعادة تعيين', path: '/owner/users/reset' },
  { name: 'actions', label: 'إجراءات', path: '/owner/users/actions' },
];

export default function AllUsers() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    const { data } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(20);
    setUsers(data || []);
    setLoading(false);
  }

  return (
    <OwnerTabLayout title="إدارة المستخدمين" tabs={USERS_TABS}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        {loading ? (
          <ActivityIndicator size="large" color="#3b82f6" />
        ) : (
          <>
            <View style={styles.statsRow}>
              <View style={styles.statCard}>
                <UsersIcon size={24} color="#3b82f6" strokeWidth={2} />
                <Text style={styles.statValue}>{users.length}</Text>
                <Text style={styles.statLabel}>إجمالي المستخدمين</Text>
              </View>
            </View>

            {users.map((user) => (
              <View key={user.id} style={styles.userCard}>
                <View style={styles.userInfo}>
                  <Text style={styles.userName}>{user.full_name || 'مستخدم'}</Text>
                  <Text style={styles.userRole}>{user.user_role || 'individual_user'}</Text>
                </View>
                <Shield size={16} color="#64748b" strokeWidth={2} />
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  statsRow: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#dbeafe',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  userCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  userRole: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'right',
  },
});
