import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { AlertTriangle, Info, CheckCircle, XCircle } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const DASHBOARD_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/dashboard' },
  { name: 'activity', label: 'النشاط اليومي', path: '/owner/dashboard/activity' },
  { name: 'operations', label: 'آخر العمليات', path: '/owner/dashboard/operations' },
  { name: 'alerts', label: 'تنبيهات النظام', path: '/owner/dashboard/alerts' },
  { name: 'services', label: 'حالة الخدمات', path: '/owner/dashboard/services' },
];

interface SystemAlert {
  id: string;
  type: 'warning' | 'info' | 'success' | 'error';
  title: string;
  message: string;
  count?: number;
}

export default function SystemAlerts() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [alerts, setAlerts] = useState<SystemAlert[]>([]);

  useEffect(() => {
    loadAlerts();
  }, []);

  async function loadAlerts() {
    try {
      const systemAlerts: SystemAlert[] = [];

      const [pendingBusinesses, inProgressAppts, failedPayments, newUsers, lowStockItems] = await Promise.all([
        supabase.from('business_registrations').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('appointments').select('*', { count: 'exact', head: true }).eq('status', 'in_progress'),
        supabase.from('payments').select('*', { count: 'exact', head: true }).eq('status', 'failed'),
        supabase.from('users').select('*', { count: 'exact', head: true }).gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
        supabase.from('business_registrations').select('*', { count: 'exact', head: true }).eq('status', 'inactive'),
      ]);

      // Pending business registrations
      if ((pendingBusinesses.count || 0) > 0) {
        systemAlerts.push({
          id: '1',
          type: 'warning',
          title: 'طلبات تسجيل قيد الانتظار',
          message: `يوجد ${pendingBusinesses.count} طلب تسجيل شركة بحاجة للموافقة`,
          count: pendingBusinesses.count || 0,
        });
      }

      // Ongoing appointments
      if ((inProgressAppts.count || 0) > 0) {
        systemAlerts.push({
          id: '2',
          type: 'info',
          title: 'جلسات عمل قيد التنفيذ',
          message: `هناك ${inProgressAppts.count} جلسة عمل قيد المتابعة`,
          count: inProgressAppts.count || 0,
        });
      }

      // Failed payments
      if ((failedPayments.count || 0) > 0) {
        systemAlerts.push({
          id: '3',
          type: 'error',
          title: 'عمليات دفع فاشلة',
          message: `فشلت ${failedPayments.count} عملية دفع - يحتاج إلى تدخل`,
          count: failedPayments.count || 0,
        });
      }

      // New user registrations (success alert)
      if ((newUsers.count || 0) > 0) {
        systemAlerts.push({
          id: '4',
          type: 'success',
          title: 'مستخدمين جدد',
          message: `تم تسجيل ${newUsers.count} مستخدم جديد في آخر 24 ساعة`,
          count: newUsers.count || 0,
        });
      }

      // Inactive businesses
      if ((lowStockItems.count || 0) > 0) {
        systemAlerts.push({
          id: '5',
          type: 'warning',
          title: 'شركات غير نشطة',
          message: `هناك ${lowStockItems.count} شركة معطلة تحتاج للتفعيل`,
          count: lowStockItems.count || 0,
        });
      }

      if (systemAlerts.length === 0) {
        systemAlerts.push({
          id: '6',
          type: 'success',
          title: 'النظام سليم',
          message: 'جميع الأنظمة تعمل بشكل طبيعي - لا توجد مشاكل',
        });
      }

      setAlerts(systemAlerts);
    } catch (error) {
      console.error('Error loading alerts:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadAlerts();
    setRefreshing(false);
  }

  function getAlertIcon(type: string) {
    switch (type) {
      case 'warning': return <AlertTriangle size={24} color="#f59e0b" strokeWidth={2} />;
      case 'info': return <Info size={24} color="#3b82f6" strokeWidth={2} />;
      case 'success': return <CheckCircle size={24} color="#10b981" strokeWidth={2} />;
      case 'error': return <XCircle size={24} color="#ef4444" strokeWidth={2} />;
      default: return <Info size={24} color="#64748b" strokeWidth={2} />;
    }
  }

  function getAlertColor(type: string) {
    switch (type) {
      case 'warning': return '#fef3c7';
      case 'info': return '#dbeafe';
      case 'success': return '#d1fae5';
      case 'error': return '#fee2e2';
      default: return '#f1f5f9';
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="لوحة التحكم الرئيسية" tabs={DASHBOARD_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  const criticalAlerts = alerts.filter(a => a.type === 'error').length;
  const warningAlerts = alerts.filter(a => a.type === 'warning').length;
  const infoAlerts = alerts.filter(a => a.type === 'info').length;
  const successAlerts = alerts.filter(a => a.type === 'success').length;

  return (
    <OwnerTabLayout title="لوحة التحكم الرئيسية" tabs={DASHBOARD_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <Text style={styles.title}>تنبيهات النظام</Text>
        <Text style={styles.subtitle}>التنبيهات والإشعارات الهامة (محدثة)</Text>

        <View style={styles.summaryGrid}>
          <View style={styles.summaryCard}>
            <Text style={[styles.summaryValue, { color: '#ef4444' }]}>{criticalAlerts}</Text>
            <Text style={styles.summaryLabel}>حرجة</Text>
          </View>
          <View style={styles.summaryCard}>
            <Text style={[styles.summaryValue, { color: '#f59e0b' }]}>{warningAlerts}</Text>
            <Text style={styles.summaryLabel}>تحذيرات</Text>
          </View>
          <View style={styles.summaryCard}>
            <Text style={[styles.summaryValue, { color: '#3b82f6' }]}>{infoAlerts}</Text>
            <Text style={styles.summaryLabel}>معلومات</Text>
          </View>
          <View style={styles.summaryCard}>
            <Text style={[styles.summaryValue, { color: '#10b981' }]}>{successAlerts}</Text>
            <Text style={styles.summaryLabel}>إيجابية</Text>
          </View>
        </View>

        {alerts.map((alert) => (
          <View key={alert.id} style={[styles.alertCard, { backgroundColor: getAlertColor(alert.type) }]}>
            <View style={styles.alertIcon}>{getAlertIcon(alert.type)}</View>
            <View style={styles.alertContent}>
              <Text style={styles.alertTitle}>{alert.title}</Text>
              <Text style={styles.alertMessage}>{alert.message}</Text>
            </View>
            {alert.count !== undefined && (
              <View style={styles.alertBadge}>
                <Text style={styles.alertBadgeText}>{alert.count}</Text>
              </View>
            )}
          </View>
        ))}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#64748b',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 24,
    textAlign: 'right',
  },
  summaryGrid: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    alignItems: 'center',
  },
  summaryValue: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  summaryLabel: {
    fontSize: 11,
    color: '#64748b',
  },
  alertCard: {
    flexDirection: 'row',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    gap: 12,
    alignItems: 'center',
  },
  alertIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertContent: {
    flex: 1,
    gap: 4,
  },
  alertTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  alertMessage: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  alertBadge: {
    backgroundColor: '#ef4444',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  alertBadgeText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
});
