import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Activity, Users, LogIn, UserPlus, CreditCard, ShoppingCart, TrendingUp, Clock, Building2, MessageSquare } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const DASHBOARD_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/dashboard' },
  { name: 'activity', label: 'النشاط اليومي', path: '/owner/dashboard/activity' },
  { name: 'operations', label: 'آخر العمليات', path: '/owner/dashboard/operations' },
  { name: 'alerts', label: 'تنبيهات النظام', path: '/owner/dashboard/alerts' },
  { name: 'services', label: 'حالة الخدمات', path: '/owner/dashboard/services' },
];

interface DailyActivity {
  newUsers: number;
  activeUsers: number;
  newSubscriptions: number;
  newOrders: number;
  totalRevenue: number;
  loginCount: number;
  newBusinesses: number;
  appointmentsSessions: number;
  chatConversations: number;
}

interface HourlyData {
  hour: string;
  count: number;
}

export default function DailyActivity() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activity, setActivity] = useState<DailyActivity>({
    newUsers: 0,
    activeUsers: 0,
    newSubscriptions: 0,
    newOrders: 0,
    totalRevenue: 0,
    loginCount: 0,
    newBusinesses: 0,
    appointmentsSessions: 0,
    chatConversations: 0,
  });
  const [hourlyActivity, setHourlyActivity] = useState<HourlyData[]>([]);

  useEffect(() => {
    loadActivity();
  }, []);

  async function loadActivity() {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayISO = today.toISOString();

      const [newUsersRes, activeUsersRes, subscriptionsRes, paymentsRes, businessesRes, appointmentsRes, chatRes] = await Promise.all([
        supabase.from('users').select('*', { count: 'exact', head: true }).gte('created_at', todayISO),
        supabase.from('users').select('*', { count: 'exact', head: true }).gte('last_sign_in_at', todayISO),
        supabase.from('subscriptions').select('*', { count: 'exact', head: true }).gte('created_at', todayISO),
        supabase.from('payments').select('amount').gte('created_at', todayISO).eq('status', 'completed'),
        supabase.from('business_registrations').select('*', { count: 'exact', head: true }).gte('created_at', todayISO),
        supabase.from('appointments').select('*', { count: 'exact', head: true }).gte('created_at', todayISO),
        supabase.from('chat_conversations').select('*', { count: 'exact', head: true }).gte('created_at', todayISO),
      ]);

      const revenue = paymentsRes.data?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0;

      setActivity({
        newUsers: newUsersRes.count || 0,
        activeUsers: activeUsersRes.count || 0,
        newSubscriptions: subscriptionsRes.count || 0,
        newOrders: 0,
        totalRevenue: revenue,
        loginCount: activeUsersRes.count || 0,
        newBusinesses: businessesRes.count || 0,
        appointmentsSessions: appointmentsRes.count || 0,
        chatConversations: chatRes.count || 0,
      });

      // Load hourly activity data
      const hourlyData: HourlyData[] = [];
      for (let i = 0; i < 24; i++) {
        const hourStart = new Date(today);
        hourStart.setHours(i, 0, 0, 0);
        const hourEnd = new Date(today);
        hourEnd.setHours(i + 1, 0, 0, 0);

        const { count } = await supabase
          .from('users')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', hourStart.toISOString())
          .lt('created_at', hourEnd.toISOString());

        hourlyData.push({
          hour: `${i}:00`,
          count: count || 0,
        });
      }
      setHourlyActivity(hourlyData);
    } catch (error) {
      console.error('Error loading daily activity:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadActivity();
    setRefreshing(false);
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  if (loading) {
    return (
      <OwnerTabLayout title="لوحة التحكم الرئيسية" tabs={DASHBOARD_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  const maxHourlyCount = Math.max(...hourlyActivity.map(h => h.count), 1);

  return (
    <OwnerTabLayout title="لوحة التحكم الرئيسية" tabs={DASHBOARD_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <Text style={styles.title}>النشاط اليومي</Text>
        <Text style={styles.subtitle}>إحصائيات اليوم الحالي (بيانات حية من قاعدة البيانات)</Text>

        <View style={styles.grid}>
          <View style={[styles.card, { backgroundColor: '#dbeafe' }]}>
            <UserPlus size={28} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardValue}>{activity.newUsers}</Text>
            <Text style={styles.cardLabel}>مستخدمين جدد</Text>
          </View>

          <View style={[styles.card, { backgroundColor: '#d1fae5' }]}>
            <LogIn size={28} color="#10b981" strokeWidth={2} />
            <Text style={styles.cardValue}>{activity.activeUsers}</Text>
            <Text style={styles.cardLabel}>تسجيلات دخول</Text>
          </View>

          <View style={[styles.card, { backgroundColor: '#fef3c7' }]}>
            <CreditCard size={28} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.cardValue}>{activity.newSubscriptions}</Text>
            <Text style={styles.cardLabel}>اشتراكات جديدة</Text>
          </View>

          <View style={[styles.card, { backgroundColor: '#f3e8ff' }]}>
            <ShoppingCart size={28} color="#a855f7" strokeWidth={2} />
            <Text style={styles.cardValue}>{formatCurrency(activity.totalRevenue)}</Text>
            <Text style={styles.cardLabel}>إيرادات اليوم</Text>
          </View>

          <View style={[styles.card, { backgroundColor: '#dbeafe' }]}>
            <Activity size={28} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.cardValue}>{activity.appointmentsSessions}</Text>
            <Text style={styles.cardLabel}>جلسات العمل</Text>
          </View>

          <View style={[styles.card, { backgroundColor: '#d1fae5' }]}>
            <Building2 size={28} color="#10b981" strokeWidth={2} />
            <Text style={styles.cardValue}>{activity.newBusinesses}</Text>
            <Text style={styles.cardLabel}>شركات جديدة</Text>
          </View>

          <View style={[styles.card, { backgroundColor: '#fef3c7' }]}>
            <MessageSquare size={28} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.cardValue}>{activity.chatConversations}</Text>
            <Text style={styles.cardLabel}>محادثات</Text>
          </View>

          <View style={[styles.card, { backgroundColor: '#f3e8ff' }]}>
            <TrendingUp size={28} color="#a855f7" strokeWidth={2} />
            <Text style={styles.cardValue}>{activity.loginCount}</Text>
            <Text style={styles.cardLabel}>إجمالي الدخول</Text>
          </View>
        </View>

        {hourlyActivity.length > 0 && (
          <View style={styles.chartCard}>
            <View style={styles.chartHeader}>
              <Clock size={18} color="#3b82f6" strokeWidth={2} />
              <Text style={styles.chartTitle}>النشاط بالساعات</Text>
            </View>
            <View style={styles.barChart}>
              {hourlyActivity.map((item, index) => {
                if (index % 2 === 0) {
                  const barHeight = (item.count / maxHourlyCount) * 100;
                  return (
                    <View key={index} style={styles.barContainer}>
                      <View style={styles.barWrapper}>
                        <View style={[styles.bar, { height: `${barHeight}%` }]} />
                      </View>
                      <Text style={styles.barLabel}>{item.hour}</Text>
                    </View>
                  );
                }
              })}
            </View>
          </View>
        )}

        {activity.newUsers === 0 && activity.activeUsers === 0 && activity.appointmentsSessions === 0 && (
          <View style={styles.emptyState}>
            <Activity size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyTitle}>لا يوجد نشاط اليوم</Text>
            <Text style={styles.emptyText}>لم يتم تسجيل أي نشاط في النظام اليوم</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#64748b',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 8,
    textAlign: 'right',
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 24,
    textAlign: 'right',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  card: {
    flex: 1,
    minWidth: '47%',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
  },
  cardValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 12,
  },
  cardLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
    gap: 12,
    marginTop: 24,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  emptyText: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  chartCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  chartHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  barChart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 120,
    gap: 2,
  },
  barContainer: {
    flex: 1,
    alignItems: 'center',
    gap: 2,
  },
  barWrapper: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-end',
  },
  bar: {
    width: '100%',
    backgroundColor: '#3b82f6',
    borderRadius: 2,
    minHeight: 2,
  },
  barLabel: {
    fontSize: 8,
    color: '#64748b',
    textAlign: 'center',
  },
});
