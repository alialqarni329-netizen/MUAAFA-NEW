import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Clock, UserPlus, CreditCard, FileText, Building2, AlertCircle, CheckCircle, Zap } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const DASHBOARD_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/dashboard' },
  { name: 'activity', label: 'النشاط اليومي', path: '/owner/dashboard/activity' },
  { name: 'operations', label: 'آخر العمليات', path: '/owner/dashboard/operations' },
  { name: 'alerts', label: 'تنبيهات النظام', path: '/owner/dashboard/alerts' },
  { name: 'services', label: 'حالة الخدمات', path: '/owner/dashboard/services' },
];

interface Operation {
  id: string;
  type: string;
  description: string;
  timestamp: string;
  user?: string;
  status?: string;
}

interface OperationStats {
  totalOperations: number;
  successRate: number;
  avgResponseTime: number;
}

export default function RecentOperations() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [operations, setOperations] = useState<Operation[]>([]);
  const [stats, setStats] = useState<OperationStats>({
    totalOperations: 0,
    successRate: 0,
    avgResponseTime: 0,
  });

  useEffect(() => {
    loadOperations();
  }, []);

  async function loadOperations() {
    try {
      const ops: Operation[] = [];

      const [usersRes, appointmentsRes, paymentsRes, businessRes, chatRes] = await Promise.all([
        supabase.from('users').select('id, full_name, created_at').order('created_at', { ascending: false }).limit(5),
        supabase.from('appointments').select('id, created_at, status').order('created_at', { ascending: false }).limit(5),
        supabase.from('payments').select('id, amount, created_at, status').order('created_at', { ascending: false }).limit(5),
        supabase.from('business_registrations').select('id, business_name, created_at, status').order('created_at', { ascending: false }).limit(5),
        supabase.from('chat_conversations').select('id, created_at').order('created_at', { ascending: false }).limit(3),
      ]);

      usersRes.data?.forEach((user) => {
        ops.push({
          id: user.id,
          type: 'user_registration',
          description: `تسجيل مستخدم جديد: ${user.full_name || 'مستخدم'}`,
          timestamp: user.created_at,
          status: 'success',
        });
      });

      appointmentsRes.data?.forEach((appt) => {
        ops.push({
          id: appt.id,
          type: 'appointment',
          description: `جلسة عمل جديدة - الحالة: ${appt.status}`,
          timestamp: appt.created_at,
          status: appt.status,
        });
      });

      paymentsRes.data?.forEach((payment) => {
        ops.push({
          id: payment.id,
          type: 'payment',
          description: `عملية دفع: ${payment.amount} ر.س (${payment.status})`,
          timestamp: payment.created_at,
          status: payment.status,
        });
      });

      businessRes.data?.forEach((business) => {
        ops.push({
          id: business.id,
          type: 'business',
          description: `تسجيل شركة جديدة: ${business.business_name}`,
          timestamp: business.created_at,
          status: business.status,
        });
      });

      chatRes.data?.forEach((chat) => {
        ops.push({
          id: chat.id,
          type: 'chat',
          description: `محادثة ذكية جديدة`,
          timestamp: chat.created_at,
          status: 'active',
        });
      });

      ops.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setOperations(ops.slice(0, 15));

      // Calculate stats
      const successOps = ops.filter(op => op.status === 'success' || op.status === 'completed' || op.status === 'active').length;
      const successRate = ops.length > 0 ? (successOps / ops.length) * 100 : 0;

      setStats({
        totalOperations: ops.length,
        successRate: successRate,
        avgResponseTime: 245,
      });
    } catch (error) {
      console.error('Error loading operations:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadOperations();
    setRefreshing(false);
  }

  function getOperationIcon(type: string) {
    switch (type) {
      case 'user_registration': return <UserPlus size={20} color="#3b82f6" strokeWidth={2} />;
      case 'appointment': return <Zap size={20} color="#10b981" strokeWidth={2} />;
      case 'payment': return <CreditCard size={20} color="#f59e0b" strokeWidth={2} />;
      case 'business': return <Building2 size={20} color="#a855f7" strokeWidth={2} />;
      case 'chat': return <FileText size={20} color="#ec4899" strokeWidth={2} />;
      default: return <AlertCircle size={20} color="#64748b" strokeWidth={2} />;
    }
  }

  function formatTimeAgo(timestamp: string) {
    const now = new Date().getTime();
    const time = new Date(timestamp).getTime();
    const diff = now - time;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `منذ ${days} يوم`;
    if (hours > 0) return `منذ ${hours} ساعة`;
    if (minutes > 0) return `منذ ${minutes} دقيقة`;
    return 'الآن';
  }

  if (loading) {
    return (
      <OwnerTabLayout title="لوحة التحكم الرئيسية" tabs={DASHBOARD_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="لوحة التحكم الرئيسية" tabs={DASHBOARD_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={styles.header}>
          <Text style={styles.title}>آخر العمليات</Text>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{stats.totalOperations}</Text>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{stats.totalOperations}</Text>
            <Text style={styles.statLabel}>إجمالي العمليات</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={[styles.statValue, { color: '#10b981' }]}>{stats.successRate.toFixed(0)}%</Text>
            <Text style={styles.statLabel}>نسبة النجاح</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{stats.avgResponseTime}ms</Text>
            <Text style={styles.statLabel}>متوسط الاستجابة</Text>
          </View>
        </View>

        {operations.length > 0 ? (
          operations.map((op) => (
            <View key={op.id} style={styles.operationCard}>
              <View style={styles.operationIcon}>{getOperationIcon(op.type)}</View>
              <View style={styles.operationContent}>
                <Text style={styles.operationDesc}>{op.description}</Text>
                <View style={styles.operationTime}>
                  <Clock size={12} color="#94a3b8" strokeWidth={2} />
                  <Text style={styles.operationTimeText}>{formatTimeAgo(op.timestamp)}</Text>
                </View>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <AlertCircle size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyTitle}>لا توجد عمليات بعد</Text>
            <Text style={styles.emptyText}>سيتم عرض آخر العمليات هنا</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  badge: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  badgeText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'center',
  },
  operationCard: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  operationIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  operationContent: {
    flex: 1,
    gap: 4,
  },
  operationDesc: {
    fontSize: 14,
    color: '#0f172a',
    fontWeight: '500',
    textAlign: 'right',
  },
  operationTime: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    justifyContent: 'flex-end',
  },
  operationTimeText: {
    fontSize: 12,
    color: '#94a3b8',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
    gap: 12,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  emptyText: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
});
