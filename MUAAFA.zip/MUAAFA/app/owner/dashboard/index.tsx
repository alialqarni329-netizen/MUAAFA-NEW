import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Users, ArrowUpRight, DollarSign, ShoppingBag, TrendingUp, Building2, Pill, AlertCircle, CheckCircle, XCircle, Clock, MessageSquare, UserCheck } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const DASHBOARD_TABS = [
  { name: 'overview', label: 'نظرة عامة', path: '/owner/dashboard' },
  { name: 'activity', label: 'النشاط اليومي', path: '/owner/dashboard/activity' },
  { name: 'operations', label: 'آخر العمليات', path: '/owner/dashboard/operations' },
  { name: 'alerts', label: 'تنبيهات النظام', path: '/owner/dashboard/alerts' },
  { name: 'services', label: 'حالة الخدمات', path: '/owner/dashboard/services' },
];

interface DashboardStats {
  totalUsers: number;
  todayReferrals: number;
  totalCommission: number;
  activeOrders: number;
}

interface WeeklyGrowth {
  week: string;
  count: number;
}

interface RevenueDistribution {
  hospitals: number;
  pharmacies: number;
}

interface BotPerformance {
  totalChats: number;
  successfulReferrals: number;
  conversionRate: number;
}

interface RecentAlert {
  id: string;
  type: 'pharmacy' | 'payment' | 'api';
  message: string;
  time: string;
}

interface RecentReferral {
  id: string;
  patient_name: string;
  hospital_name: string;
  insurance_status: 'approved' | 'rejected' | 'pending';
  created_at: string;
}

export default function DashboardOverview() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    todayReferrals: 0,
    totalCommission: 0,
    activeOrders: 0,
  });
  const [weeklyGrowth, setWeeklyGrowth] = useState<WeeklyGrowth[]>([]);
  const [revenueDistribution, setRevenueDistribution] = useState<RevenueDistribution>({
    hospitals: 0,
    pharmacies: 0,
  });
  const [botPerformance, setBotPerformance] = useState<BotPerformance>({
    totalChats: 0,
    successfulReferrals: 0,
    conversionRate: 0,
  });
  const [recentAlerts, setRecentAlerts] = useState<RecentAlert[]>([]);
  const [recentReferrals, setRecentReferrals] = useState<RecentReferral[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayISO = today.toISOString();

      // Load comprehensive data from all relevant tables
      const [usersRes, appointmentsRes, paymentsRes, businessRes, chatRes, subscriptionsRes] = await Promise.all([
        supabase.from('users').select('*', { count: 'exact', head: true }),
        supabase.from('appointments').select('*', { count: 'exact', head: true }).gte('created_at', todayISO),
        supabase.from('payments').select('amount, status').eq('status', 'completed'),
        supabase.from('business_registrations').select('*', { count: 'exact', head: true }),
        supabase.from('chat_conversations').select('*', { count: 'exact', head: true }),
        supabase.from('subscriptions').select('*', { count: 'exact', head: true }).eq('status', 'active'),
      ]);

      const totalUsersCount = usersRes.count || 0;
      const todayReferralsCount = appointmentsRes.count || 0;
      const paymentsData = paymentsRes.data || [];
      const businessCount = businessRes.count || 0;
      const chatCount = chatRes.count || 0;
      const activeSubscriptionsCount = subscriptionsRes.count || 0;

      // Calculate revenue metrics
      const totalRevenue = paymentsData.reduce((sum, p) => sum + (p.amount || 0), 0);
      const totalCommission = totalRevenue * 0.10;

      // Get all completed appointments for conversion rate
      const { count: completedAppointmentsCount } = await supabase
        .from('appointments')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'completed');

      const conversionRate = chatCount > 0 ? (completedAppointmentsCount / chatCount) * 100 : 0;

      // Get recent appointments
      const { data: recentAppointments } = await supabase
        .from('appointments')
        .select('id, patient_name, provider_name, status, created_at')
        .order('created_at', { ascending: false })
        .limit(5);

      setStats({
        totalUsers: totalUsersCount || 0,
        todayReferrals: todayReferralsCount || 0,
        totalCommission,
        activeOrders: businessCount || 0,
      });

      setRevenueDistribution({
        hospitals: totalRevenue * 0.6,
        pharmacies: totalRevenue * 0.4,
      });

      setBotPerformance({
        totalChats: chatCount || 0,
        successfulReferrals: completedAppointmentsCount || 0,
        conversionRate,
      });

      const weeklyData: WeeklyGrowth[] = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        date.setHours(0, 0, 0, 0);
        const nextDate = new Date(date);
        nextDate.setDate(nextDate.getDate() + 1);

        const { count } = await supabase
          .from('users')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', date.toISOString())
          .lt('created_at', nextDate.toISOString());

        const weekLabel = i === 0 ? 'اليوم' : i === 1 ? 'أمس' : `${i} أيام`;
        weeklyData.push({ week: weekLabel, count: count || 0 });
      }
      setWeeklyGrowth(weeklyData);

      const alerts: RecentAlert[] = [
        { id: '1', type: 'pharmacy', message: 'تم تسجيل صيدلية جديدة في الرياض', time: 'منذ ساعة' },
        { id: '2', type: 'api', message: 'استهلاك ChatGPT API: 85% من الميزانية', time: 'منذ 3 ساعات' },
        { id: '3', type: 'payment', message: 'فشل عملية دفع من المستخدم #4521', time: 'منذ 5 ساعات' },
      ];
      setRecentAlerts(alerts);

      setRecentReferrals(
        (recentAppointments || []).map(app => ({
          id: app.id,
          patient_name: app.patient_name || 'مريض',
          hospital_name: app.provider_name || 'مستشفى',
          insurance_status: (app.status === 'completed' ? 'approved' : app.status === 'cancelled' ? 'rejected' : 'pending') as any,
          created_at: app.created_at,
        }))
      );
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadDashboardData();
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
    }).format(amount);
  }

  function getInsuranceIcon(status: string) {
    switch (status) {
      case 'approved':
        return <CheckCircle size={16} color="#10b981" strokeWidth={2} />;
      case 'rejected':
        return <XCircle size={16} color="#ef4444" strokeWidth={2} />;
      default:
        return <Clock size={16} color="#f59e0b" strokeWidth={2} />;
    }
  }

  function getInsuranceText(status: string) {
    switch (status) {
      case 'approved':
        return 'مقبول';
      case 'rejected':
        return 'مرفوض';
      default:
        return 'قيد المراجعة';
    }
  }

  function getInsuranceColor(status: string) {
    switch (status) {
      case 'approved':
        return '#10b981';
      case 'rejected':
        return '#ef4444';
      default:
        return '#f59e0b';
    }
  }

  if (loading) {
    return (
      <OwnerTabLayout title="لوحة التحكم الرئيسية" tabs={DASHBOARD_TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري تحميل لوحة التحكم...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  const totalRevenue = revenueDistribution.hospitals + revenueDistribution.pharmacies;
  const hospitalsPercentage = totalRevenue > 0 ? (revenueDistribution.hospitals / totalRevenue) * 100 : 0;
  const pharmaciesPercentage = totalRevenue > 0 ? (revenueDistribution.pharmacies / totalRevenue) * 100 : 0;

  const maxWeeklyCount = Math.max(...weeklyGrowth.map(w => w.count), 1);

  return (
    <OwnerTabLayout title="لوحة التحكم الرئيسية" tabs={DASHBOARD_TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}>

        <Text style={styles.pageTitle}>الأرقام السريعة (Live)</Text>

        <View style={styles.liveStatsGrid}>
          <View style={[styles.liveCard, { backgroundColor: '#dbeafe', borderColor: '#3b82f6' }]}>
            <View style={styles.liveHeader}>
              <Users size={20} color="#3b82f6" strokeWidth={2} />
              <View style={styles.liveDot} />
            </View>
            <Text style={styles.liveValue}>{stats.totalUsers.toLocaleString('ar-SA')}</Text>
            <Text style={styles.liveLabel}>إجمالي المستخدمين</Text>
          </View>

          <View style={[styles.liveCard, { backgroundColor: '#d1fae5', borderColor: '#10b981' }]}>
            <View style={styles.liveHeader}>
              <ArrowUpRight size={20} color="#10b981" strokeWidth={2} />
              <View style={styles.liveDot} />
            </View>
            <Text style={styles.liveValue}>{stats.todayReferrals.toLocaleString('ar-SA')}</Text>
            <Text style={styles.liveLabel}>عمليات اليوم</Text>
          </View>

          <View style={[styles.liveCard, { backgroundColor: '#fef3c7', borderColor: '#f59e0b' }]}>
            <View style={styles.liveHeader}>
              <DollarSign size={20} color="#f59e0b" strokeWidth={2} />
              <View style={styles.liveDot} />
            </View>
            <Text style={styles.liveValue}>{formatCurrency(stats.totalCommission)}</Text>
            <Text style={styles.liveLabel}>إجمالي العمولات (10%)</Text>
          </View>

          <View style={[styles.liveCard, { backgroundColor: '#f3e8ff', borderColor: '#8b5cf6' }]}>
            <View style={styles.liveHeader}>
              <ShoppingBag size={20} color="#8b5cf6" strokeWidth={2} />
              <View style={styles.liveDot} />
            </View>
            <Text style={styles.liveValue}>{stats.activeOrders.toLocaleString('ar-SA')}</Text>
            <Text style={styles.liveLabel}>الطلبات النشطة</Text>
          </View>
        </View>

        <View style={styles.chartsRow}>
          <View style={styles.chartCard}>
            <View style={styles.chartHeader}>
              <TrendingUp size={18} color="#3b82f6" strokeWidth={2} />
              <Text style={styles.chartTitle}>نمو المستخدمين الجدد</Text>
            </View>
            <View style={styles.barChart}>
              {weeklyGrowth.map((item, index) => {
                const barHeight = (item.count / maxWeeklyCount) * 100;
                return (
                  <View key={index} style={styles.barContainer}>
                    <View style={styles.barWrapper}>
                      <View style={[styles.bar, { height: `${barHeight}%` }]} />
                    </View>
                    <Text style={styles.barValue}>{item.count}</Text>
                    <Text style={styles.barLabel}>{item.week}</Text>
                  </View>
                );
              })}
            </View>
          </View>

          <View style={styles.chartCard}>
            <View style={styles.chartHeader}>
              <DollarSign size={18} color="#10b981" strokeWidth={2} />
              <Text style={styles.chartTitle}>توزيع الإيرادات</Text>
            </View>
            <View style={styles.pieChart}>
              <View style={styles.pieRow}>
                <View style={styles.pieItem}>
                  <Building2 size={16} color="#3b82f6" strokeWidth={2} />
                  <Text style={styles.pieLabelText}>المستشفيات</Text>
                </View>
                <Text style={styles.piePercent}>{hospitalsPercentage.toFixed(0)}%</Text>
              </View>
              <View style={[styles.pieBar, { backgroundColor: '#dbeafe' }]}>
                <View style={[styles.pieFill, { width: `${hospitalsPercentage}%`, backgroundColor: '#3b82f6' }]} />
              </View>

              <View style={styles.pieRow}>
                <View style={styles.pieItem}>
                  <Pill size={16} color="#8b5cf6" strokeWidth={2} />
                  <Text style={styles.pieLabelText}>الصيدليات</Text>
                </View>
                <Text style={styles.piePercent}>{pharmaciesPercentage.toFixed(0)}%</Text>
              </View>
              <View style={[styles.pieBar, { backgroundColor: '#f3e8ff' }]}>
                <View style={[styles.pieFill, { width: `${pharmaciesPercentage}%`, backgroundColor: '#8b5cf6' }]} />
              </View>
            </View>
          </View>
        </View>

        <View style={styles.chartCard}>
          <View style={styles.chartHeader}>
            <MessageSquare size={18} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.chartTitle}>أداء البوت الذكي</Text>
          </View>
          <View style={styles.botStats}>
            <View style={styles.botStatItem}>
              <Text style={styles.botStatValue}>{botPerformance.totalChats.toLocaleString('ar-SA')}</Text>
              <Text style={styles.botStatLabel}>إجمالي المحادثات</Text>
            </View>
            <View style={styles.botStatDivider} />
            <View style={styles.botStatItem}>
              <Text style={styles.botStatValue}>{botPerformance.successfulReferrals.toLocaleString('ar-SA')}</Text>
              <Text style={styles.botStatLabel}>تحويلات ناجحة</Text>
            </View>
            <View style={styles.botStatDivider} />
            <View style={styles.botStatItem}>
              <Text style={[styles.botStatValue, { color: '#10b981' }]}>
                {botPerformance.conversionRate.toFixed(1)}%
              </Text>
              <Text style={styles.botStatLabel}>معدل التحويل</Text>
            </View>
          </View>
        </View>

        <View style={styles.alertsSection}>
          <View style={styles.sectionHeader}>
            <AlertCircle size={18} color="#f59e0b" strokeWidth={2} />
            <Text style={styles.sectionTitle}>التنبيهات العاجلة</Text>
          </View>
          {recentAlerts.map((alert) => (
            <View key={alert.id} style={styles.alertItem}>
              <View style={styles.alertIcon}>
                {alert.type === 'pharmacy' && <Building2 size={16} color="#10b981" strokeWidth={2} />}
                {alert.type === 'payment' && <XCircle size={16} color="#ef4444" strokeWidth={2} />}
                {alert.type === 'api' && <AlertCircle size={16} color="#f59e0b" strokeWidth={2} />}
              </View>
              <View style={styles.alertContent}>
                <Text style={styles.alertMessage}>{alert.message}</Text>
                <Text style={styles.alertTime}>{alert.time}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.referralsSection}>
          <View style={styles.sectionHeader}>
            <UserCheck size={18} color="#3b82f6" strokeWidth={2} />
            <Text style={styles.sectionTitle}>آخر التحويلات للمستشفيات</Text>
          </View>
          <View style={styles.referralsTable}>
            <View style={styles.tableHeader}>
              <Text style={[styles.tableHeaderText, { flex: 2 }]}>اسم المريض</Text>
              <Text style={[styles.tableHeaderText, { flex: 2 }]}>المستشفى</Text>
              <Text style={[styles.tableHeaderText, { flex: 1 }]}>حالة التأمين</Text>
            </View>
            {recentReferrals.length > 0 ? (
              recentReferrals.map((referral) => (
                <View key={referral.id} style={styles.tableRow}>
                  <Text style={[styles.tableCellText, { flex: 2 }]}>{referral.patient_name}</Text>
                  <Text style={[styles.tableCellText, { flex: 2 }]}>{referral.hospital_name}</Text>
                  <View style={[styles.tableCell, { flex: 1 }]}>
                    <View style={styles.insuranceStatus}>
                      {getInsuranceIcon(referral.insurance_status)}
                      <Text style={[styles.insuranceText, { color: getInsuranceColor(referral.insurance_status) }]}>
                        {getInsuranceText(referral.insurance_status)}
                      </Text>
                    </View>
                  </View>
                </View>
              ))
            ) : (
              <View style={styles.emptyTable}>
                <Text style={styles.emptyText}>لا توجد تحويلات حديثة</Text>
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </OwnerTabLayout>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  pageTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  liveStatsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  liveCard: {
    flex: 1,
    minWidth: '47%',
    padding: 14,
    borderRadius: 12,
    borderWidth: 2,
  },
  liveHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  liveDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10b981',
  },
  liveValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  liveLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'right',
  },
  chartsRow: {
    gap: 12,
    marginBottom: 12,
  },
  chartCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  chartHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  barChart: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 140,
    gap: 4,
  },
  barContainer: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  barWrapper: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-end',
  },
  bar: {
    width: '100%',
    backgroundColor: '#3b82f6',
    borderRadius: 4,
    minHeight: 4,
  },
  barValue: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  barLabel: {
    fontSize: 9,
    color: '#64748b',
    textAlign: 'center',
  },
  pieChart: {
    gap: 12,
  },
  pieRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  pieItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  pieLabelText: {
    fontSize: 13,
    color: '#0f172a',
    textAlign: 'right',
  },
  piePercent: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  pieBar: {
    height: 24,
    borderRadius: 6,
    overflow: 'hidden',
    marginBottom: 12,
  },
  pieFill: {
    height: '100%',
  },
  botStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  botStatItem: {
    flex: 1,
    alignItems: 'center',
  },
  botStatValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  botStatLabel: {
    fontSize: 11,
    color: '#64748b',
    textAlign: 'center',
  },
  botStatDivider: {
    width: 1,
    height: 40,
    backgroundColor: '#e2e8f0',
  },
  alertsSection: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginBottom: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  alertItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  alertIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertContent: {
    flex: 1,
  },
  alertMessage: {
    fontSize: 13,
    color: '#0f172a',
    marginBottom: 2,
    textAlign: 'right',
  },
  alertTime: {
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'right',
  },
  referralsSection: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  referralsTable: {
    gap: 8,
  },
  tableHeader: {
    flexDirection: 'row',
    paddingVertical: 8,
    borderBottomWidth: 2,
    borderBottomColor: '#e2e8f0',
  },
  tableHeaderText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#64748b',
    textAlign: 'right',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  tableCell: {
    justifyContent: 'center',
  },
  tableCellText: {
    fontSize: 12,
    color: '#0f172a',
    textAlign: 'right',
  },
  insuranceStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    justifyContent: 'flex-end',
  },
  insuranceText: {
    fontSize: 11,
    fontWeight: '600',
  },
  emptyTable: {
    padding: 24,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 13,
    color: '#94a3b8',
  },
});
