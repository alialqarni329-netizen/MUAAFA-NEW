import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  Platform,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import {
  MessageCircle,
  HelpCircle,
  Book,
  Shield,
  Bot,
  Mail,
  Phone,
  FileText,
  ChevronRight,
  Clock,
  CheckCircle,
  AlertCircle,
  Zap,
  Heart,
} from 'lucide-react-native';

export default function HelpCenterScreen() {
  const router = useRouter();

  const handleAIAssistant = () => {
    router.push('/(tabs)');
  };

  const handleWhatsApp = () => {
    Linking.openURL('https://wa.me/966556236305');
  };

  const handleEmail = () => {
    Linking.openURL('mailto:muaafa@outlook.sa');
  };

  const handlePrivacy = () => {
    router.push('/privacy');
  };

  const handleSupport = () => {
    router.push('/support');
  };

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'مركز المساعدة',
          headerStyle: {
            backgroundColor: '#0ea5e9',
          },
          headerTintColor: '#ffffff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      />
      <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
        <View style={styles.heroSection}>
          <View style={styles.heroIconContainer}>
            <HelpCircle size={64} color="#0ea5e9" strokeWidth={2} />
          </View>
          <Text style={styles.heroTitle}>مركز المساعدة</Text>
          <Text style={styles.heroSubtitle}>
            نحن هنا لمساعدتك في الاستفادة القصوى من مُعافى
          </Text>
        </View>

        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>بحاجة لمساعدة فورية؟</Text>

          <TouchableOpacity style={styles.quickActionCard} onPress={handleAIAssistant}>
            <View style={styles.quickActionLeft}>
              <View style={[styles.quickActionIcon, { backgroundColor: '#dcfce7' }]}>
                <Bot size={28} color="#16a34a" strokeWidth={2} />
              </View>
              <View style={styles.quickActionContent}>
                <Text style={styles.quickActionTitle}>الطبيب الذكي</Text>
                <Text style={styles.quickActionDescription}>متاح 24/7</Text>
              </View>
            </View>
            <ChevronRight size={20} color="#94a3b8" strokeWidth={2} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickActionCard} onPress={handleSupport}>
            <View style={styles.quickActionLeft}>
              <View style={[styles.quickActionIcon, { backgroundColor: '#dbeafe' }]}>
                <MessageCircle size={28} color="#0ea5e9" strokeWidth={2} />
              </View>
              <View style={styles.quickActionContent}>
                <Text style={styles.quickActionTitle}>تواصل مع الدعم</Text>
                <Text style={styles.quickActionDescription}>خيارات متعددة</Text>
              </View>
            </View>
            <ChevronRight size={20} color="#94a3b8" strokeWidth={2} />
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <HelpCircle size={24} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.sectionTitle}>الأسئلة الشائعة</Text>
          </View>

          <View style={styles.faqCategory}>
            <Text style={styles.faqCategoryTitle}>حول الطبيب الذكي</Text>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <CheckCircle size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>ما هو الطبيب الذكي؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                الطبيب الذكي هو مساعد صحي افتراضي يعمل بالذكاء الاصطناعي، يقدم لك استشارات
                صحية فورية، ويساعدك في فهم حالتك الصحية، ويجيب على أسئلتك الطبية على مدار
                الساعة.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <CheckCircle size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>هل يمكن الاعتماد على نصائح الطبيب الذكي؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                الطبيب الذكي يقدم معلومات طبية موثوقة ومبنية على أحدث الأبحاث العلمية، لكنه لا
                يغني عن استشارة طبيب حقيقي في الحالات الطارئة أو التشخيصات المعقدة. دائماً
                استشر طبيباً مختصاً للحصول على تشخيص دقيق.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <CheckCircle size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>كم مرة يمكنني استخدام الطبيب الذكي؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                في الخطة المجانية، يمكنك استخدام الطبيب الذكي لمدة 10 دقائق يومياً. مع
                الاشتراكات المدفوعة، تحصل على وقت غير محدود للمحادثات مع ميزات إضافية مثل
                تحليل التقارير الطبية وإنشاء ملخصات صحية.
              </Text>
            </View>
          </View>

          <View style={styles.faqCategory}>
            <Text style={styles.faqCategoryTitle}>الخصوصية والأمان</Text>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <Shield size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>هل معلوماتي الصحية آمنة؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                نعم، نحن نأخذ خصوصيتك على محمل الجد. جميع بياناتك الصحية محمية بأعلى معايير
                التشفير والأمان. نستخدم تقنية التشفير من طرف إلى طرف، ولا نشارك معلوماتك مع
                أي جهة خارجية دون إذنك الصريح.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <Shield size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>من يمكنه رؤية معلوماتي الطبية؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                أنت فقط من يمتلك السيطرة الكاملة على معلوماتك الطبية. يمكنك مشاركة تقاريرك مع
                الأطباء الذين تختارهم فقط. الفريق الطبي في مُعافى يلتزم بأعلى معايير السرية
                الطبية ولا يطّلع على بياناتك إلا بإذنك.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <Shield size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>ماذا يحدث لبياناتي عند حذف الحساب؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                عند حذف حسابك، يتم حذف جميع بياناتك الشخصية والصحية بشكل دائم من خوادمنا خلال
                30 يوماً. لن نحتفظ بأي معلومات شخصية بعد ذلك، باستثناء ما يتطلبه القانون.
              </Text>
            </View>
          </View>

          <View style={styles.faqCategory}>
            <Text style={styles.faqCategoryTitle}>الاشتراكات والحساب</Text>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <CheckCircle size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>كيف أقوم بترقية اشتراكي؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                يمكنك ترقية اشتراكك في أي وقت من خلال الذهاب إلى الإعدادات {'>'} إدارة الاشتراك
                {'>'} اختيار الخطة المناسبة لك. ستحصل على إمكانية الوصول الفوري لجميع ميزات
                الخطة الجديدة.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <CheckCircle size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>كيف ألغي اشتراكي؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                يمكنك إلغاء اشتراكك في أي وقت من خلال الإعدادات {'>'} إدارة الاشتراك {'>'} إلغاء
                الاشتراك. لن يتم تحصيل أي رسوم إضافية، وستستمر في الاستفادة من مزايا الاشتراك
                حتى نهاية فترة الدفع الحالية.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <CheckCircle size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>كيف أحدث معلوماتي الشخصية؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                اذهب إلى الإعدادات {'>'} المعلومات الشخصية، ثم اضغط على أيقونة التعديل بجانب
                اسمك. يمكنك تحديث الاسم، البريد الإلكتروني، رقم الهاتف، وتاريخ الميلاد.
              </Text>
            </View>
          </View>

          <View style={styles.faqCategory}>
            <Text style={styles.faqCategoryTitle}>استخدام التطبيق</Text>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <Book size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>كيف أبحث عن دواء معين؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                اذهب إلى تبويب "الصيدليات" ثم اضغط على "البحث عن دواء". يمكنك البحث بالاسم
                التجاري أو العلمي، ومقارنة الأسعار بين الصيدليات المختلفة، وطلب توصيل الدواء
                لمنزلك.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <Book size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>كيف أحجز جلسة استشارة عن بعد؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                اذهب إلى تبويب "الجلسات" واختر "حجز جلسة جديدة". اختر التخصص المطلوب، ثم الطبيب،
                ثم الوقت المناسب لك. ستتلقى رابط الجلسة قبل موعدها بـ 15 دقيقة.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <Book size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>كيف أرفع تقرير طبي؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                اذهب إلى تبويب "التقارير" ثم اضغط على "رفع تقرير جديد". اختر الصورة من معرض
                الصور أو التقطها بالكاميرا. يمكن للذكاء الاصطناعي تحليل التقرير وتبسيط محتواه
                بلغة سهلة الفهم.
              </Text>
            </View>

            <View style={styles.faqItem}>
              <View style={styles.faqQuestionRow}>
                <Book size={18} color="#10b981" strokeWidth={2} />
                <Text style={styles.faqQuestion}>كيف أتابع أهدافي الصحية؟</Text>
              </View>
              <Text style={styles.faqAnswer}>
                اذهب إلى تبويب "اللياقة" لتسجيل وتتبع نشاطك البدني، الوزن، والتغذية. يمكنك
                إنشاء أهداف شخصية ومتابعة تقدمك من خلال الرسوم البيانية والإحصائيات التفصيلية.
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <MessageCircle size={24} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.sectionTitle}>طرق التواصل مع الدعم</Text>
          </View>

          <TouchableOpacity style={styles.contactCard} onPress={handleWhatsApp}>
            <View style={styles.contactLeft}>
              <View style={[styles.contactIcon, { backgroundColor: '#dcfce7' }]}>
                <Phone size={24} color="#16a34a" strokeWidth={2} />
              </View>
              <View style={styles.contactContent}>
                <Text style={styles.contactTitle}>واتساب</Text>
                <Text style={styles.contactDescription}>رد سريع خلال دقائق</Text>
                <Text style={styles.contactValue}>0556236305</Text>
              </View>
            </View>
            <Clock size={16} color="#10b981" strokeWidth={2} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.contactCard} onPress={handleEmail}>
            <View style={styles.contactLeft}>
              <View style={[styles.contactIcon, { backgroundColor: '#dbeafe' }]}>
                <Mail size={24} color="#0ea5e9" strokeWidth={2} />
              </View>
              <View style={styles.contactContent}>
                <Text style={styles.contactTitle}>البريد الإلكتروني</Text>
                <Text style={styles.contactDescription}>رد خلال 24 ساعة</Text>
                <Text style={styles.contactValue}>muaafa@outlook.sa</Text>
              </View>
            </View>
            <Clock size={16} color="#0ea5e9" strokeWidth={2} />
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Book size={24} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.sectionTitle}>تعليمات الاستخدام</Text>
          </View>

          <View style={styles.guideCard}>
            <Zap size={20} color="#f59e0b" strokeWidth={2} />
            <View style={styles.guideContent}>
              <Text style={styles.guideTitle}>البدء السريع</Text>
              <Text style={styles.guideText}>
                1. أكمل ملفك الشخصي في الإعدادات{'\n'}
                2. جرب الطبيب الذكي للحصول على استشارة فورية{'\n'}
                3. احجز جلسة استشارة مع طبيب مختص{'\n'}
                4. ارفع تقاريرك الطبية لحفظها وتحليلها
              </Text>
            </View>
          </View>

          <View style={styles.guideCard}>
            <Heart size={20} color="#ec4899" strokeWidth={2} />
            <View style={styles.guideContent}>
              <Text style={styles.guideTitle}>نصائح للاستفادة القصوى</Text>
              <Text style={styles.guideText}>
                • استخدم الطبيب الذكي للأسئلة السريعة{'\n'}
                • احجز جلسات الفيديو للحالات المعقدة{'\n'}
                • احتفظ بجميع تقاريرك الطبية في مكان واحد{'\n'}
                • تابع أهدافك الصحية بانتظام{'\n'}
                • قارن أسعار الأدوية قبل الشراء
              </Text>
            </View>
          </View>
        </View>

        <TouchableOpacity style={styles.privacyButton} onPress={handlePrivacy}>
          <Shield size={20} color="#0ea5e9" strokeWidth={2} />
          <Text style={styles.privacyButtonText}>اقرأ سياسة الخصوصية</Text>
          <ChevronRight size={20} color="#0ea5e9" strokeWidth={2} />
        </TouchableOpacity>

        <View style={styles.footerNote}>
          <AlertCircle size={18} color="#64748b" strokeWidth={2} />
          <Text style={styles.footerNoteText}>
            لم تجد إجابة لسؤالك؟ تواصل مع فريق الدعم وسنكون سعداء بمساعدتك!
          </Text>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  scrollContent: {
    paddingBottom: 40,
  },
  heroSection: {
    backgroundColor: '#ffffff',
    padding: 32,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  heroIconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#dbeafe',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  heroTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
  },
  heroSubtitle: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
  },
  quickActionsSection: {
    backgroundColor: '#ffffff',
    padding: 20,
    marginTop: 16,
    marginHorizontal: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  section: {
    backgroundColor: '#ffffff',
    padding: 20,
    marginTop: 16,
    marginHorizontal: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  quickActionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  quickActionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  quickActionIcon: {
    width: 56,
    height: 56,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quickActionContent: {
    flex: 1,
  },
  quickActionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  quickActionDescription: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  faqCategory: {
    marginBottom: 24,
  },
  faqCategoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0ea5e9',
    marginBottom: 16,
    textAlign: 'right',
  },
  faqItem: {
    marginBottom: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  faqQuestionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    justifyContent: 'flex-end',
  },
  faqQuestion: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
    flex: 1,
  },
  faqAnswer: {
    fontSize: 14,
    color: '#64748b',
    lineHeight: 22,
    textAlign: 'right',
    paddingRight: 26,
  },
  contactCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  contactLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  contactIcon: {
    width: 56,
    height: 56,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  contactContent: {
    flex: 1,
  },
  contactTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  contactDescription: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 4,
    textAlign: 'right',
  },
  contactValue: {
    fontSize: 13,
    color: '#0ea5e9',
    fontWeight: '600',
    textAlign: 'right',
  },
  guideCard: {
    flexDirection: 'row',
    gap: 12,
    padding: 16,
    backgroundColor: '#fffbeb',
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fef3c7',
  },
  guideContent: {
    flex: 1,
  },
  guideTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'right',
  },
  guideText: {
    fontSize: 14,
    color: '#78716c',
    lineHeight: 22,
    textAlign: 'right',
  },
  privacyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 16,
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  privacyButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0ea5e9',
  },
  footerNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 16,
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
  },
  footerNoteText: {
    flex: 1,
    fontSize: 13,
    color: '#64748b',
    lineHeight: 20,
    textAlign: 'right',
  },
});
