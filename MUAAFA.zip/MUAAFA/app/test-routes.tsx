import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';

export default function TestRoutesScreen() {
  const router = useRouter();

  const routes = [
    { title: 'الرئيسية', path: '/' },
    { title: 'التبويبات', path: '/(tabs)' },
    { title: 'تسجيل الدخول', path: '/auth/login' },
    { title: 'إنشاء حساب', path: '/auth/register' },
    { title: 'دخول المنشآت', path: '/business/login' },
    { title: 'لوحة الإدارة', path: '/admin/index' },
    { title: 'السلة', path: '/cart' },
    { title: 'الدفع', path: '/checkout' },
    { title: 'الصيدلية', path: '/pharmacy/index' },
    { title: 'بحث العلاجات', path: '/pharmacy/search' },
    { title: 'الأهداف', path: '/fitness/goals' },
    { title: 'التقارير', path: '/reports/submit' },
    { title: 'الملف الشخصي', path: '/profile' },
    { title: 'عن التطبيق', path: '/about' },
    { title: 'اتصل بنا', path: '/contact' },
    { title: 'الدعم', path: '/support' },
    { title: 'صفحة غير موجودة', path: '/test-404-page' },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>اختبار المسارات</Text>
        <Text style={styles.subtitle}>اضغط على أي رابط للاختبار</Text>
      </View>

      <ScrollView style={styles.content}>
        {routes.map((route, index) => (
          <TouchableOpacity
            key={index}
            style={styles.routeButton}
            onPress={() => {
              try {
                router.push(route.path as any);
              } catch (error) {
                console.error('Navigation error:', error);
              }
            }}>
            <Text style={styles.routeTitle}>{route.title}</Text>
            <Text style={styles.routePath}>{route.path}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#0ea5e9',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#ffffff',
    textAlign: 'center',
    opacity: 0.9,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  routeButton: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  routeTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 4,
    textAlign: 'right',
  },
  routePath: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
    fontFamily: 'monospace',
  },
});
