import { useEffect } from 'react';
import { Stack, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { LanguageProvider } from '@/lib/i18n/LanguageContext';
import { ChatProvider } from '@/lib/ChatContext';

export default function RootLayout() {
  useFrameworkReady();

  useEffect(() => {
    console.log('[ROOT] MOUNT');
    return () => console.log('[ROOT] UNMOUNT');
  }, []);

  const router = useRouter();

  if (__DEV__) {
    const origReplace = router.replace;
    const origPush = router.push;
    // @ts-ignore
    router.replace = (...args) => {
      console.log('[NAV] replace', args);
      console.trace('[NAV] replace trace');
      return origReplace(...args);
    };
    // @ts-ignore
    router.push = (...args) => {
      console.log('[NAV] push', args);
      console.trace('[NAV] push trace');
      return origPush(...args);
    };
  }

  return (
    <LanguageProvider>
      <ChatProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="(tabs)" options={{ animation: 'none' }} />
        <Stack.Screen name="owner" />
        <Stack.Screen name="auth/login" />
        <Stack.Screen name="auth/register" />
        <Stack.Screen name="auth/phone-login" />
        <Stack.Screen name="auth/verify-phone" />
        <Stack.Screen name="auth/forgot-password" />
        <Stack.Screen name="business/login" />
        <Stack.Screen name="business/register" />
        <Stack.Screen name="business/pending-approval" />
        <Stack.Screen name="business/complete-profile" />
        <Stack.Screen name="business/dashboard" />
        <Stack.Screen name="admin/index" />
        <Stack.Screen name="admin/users" />
        <Stack.Screen name="admin/sessions" />
        <Stack.Screen name="admin/settings" />
        <Stack.Screen name="questionnaire" />
        <Stack.Screen name="subscription" />
        <Stack.Screen name="subscription-plans" />
        <Stack.Screen name="profile" />
        <Stack.Screen name="about" />
        <Stack.Screen name="privacy" />
        <Stack.Screen name="contact" />
        <Stack.Screen name="support" />
        <Stack.Screen name="cart" />
        <Stack.Screen name="checkout" />
        <Stack.Screen name="order-success" />
        <Stack.Screen name="book-session" />
        <Stack.Screen name="pharmacy/index" />
        <Stack.Screen name="pharmacy/search" />
        <Stack.Screen name="pharmacies/category/[id]" />
        <Stack.Screen name="pharmacies/treatment/[id]" />
        <Stack.Screen name="fitness/goals" />
        <Stack.Screen name="fitness/create-goal" />
        <Stack.Screen name="fitness/add-workout" />
        <Stack.Screen name="reports/submit" />
        <Stack.Screen name="reports/insurance" />
        <Stack.Screen name="reports/health-approvals" />
        <Stack.Screen name="reports/details/[id]" />
        <Stack.Screen name="test-routes" />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="auto" />
      </ChatProvider>
    </LanguageProvider>
  );
}
