import { Link, Stack, useRouter } from 'expo-router';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import { Home, Search, HelpCircle, ArrowRight } from 'lucide-react-native';

export default function NotFoundScreen() {
  const router = useRouter();

  return (
    <>
      <Stack.Screen
        options={{
          title: 'الصفحة غير موجودة',
          headerShown: false,
        }}
      />
      <View style={styles.container}>
        <View style={styles.errorContainer}>
          <Search size={80} color="#cbd5e1" strokeWidth={1.5} />
          <Text style={styles.title}>404</Text>
          <Text style={styles.subtitle}>عذراً، الصفحة غير موجودة</Text>
          <Text style={styles.description}>
            الصفحة التي تبحث عنها غير موجودة أو تم نقلها إلى موقع آخر
          </Text>
        </View>

        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => router.replace('/(tabs)')}
          >
            <Home size={20} color="#ffffff" strokeWidth={2} />
            <Text style={styles.primaryButtonText}>العودة للرئيسية</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={() => router.push('/help')}
          >
            <HelpCircle size={20} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.secondaryButtonText}>مركز المساعدة</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.quickLinksContainer}>
          <Text style={styles.quickLinksTitle}>صفحات مفيدة</Text>

          <TouchableOpacity
            style={styles.quickLink}
            onPress={() => router.push('/support')}
          >
            <Text style={styles.quickLinkText}>خدمة العملاء</Text>
            <ArrowRight size={16} color="#64748b" strokeWidth={2} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.quickLink}
            onPress={() => router.push('/privacy')}
          >
            <Text style={styles.quickLinkText}>سياسة الخصوصية</Text>
            <ArrowRight size={16} color="#64748b" strokeWidth={2} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.quickLink}
            onPress={() => router.push('/about')}
          >
            <Text style={styles.quickLinkText}>عن مُعافى</Text>
            <ArrowRight size={16} color="#64748b" strokeWidth={2} />
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 24,
    justifyContent: 'center',
  },
  errorContainer: {
    alignItems: 'center',
    marginBottom: 48,
  },
  title: {
    fontSize: 96,
    fontWeight: 'bold',
    color: '#0ea5e9',
    marginTop: 24,
    marginBottom: 16,
  },
  subtitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    maxWidth: 400,
  },
  actionsContainer: {
    gap: 12,
    marginBottom: 32,
  },
  primaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#0ea5e9',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  primaryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  secondaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#ffffff',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#0ea5e9',
  },
  secondaryButtonText: {
    color: '#0ea5e9',
    fontSize: 16,
    fontWeight: 'bold',
  },
  quickLinksContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  quickLinksTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  quickLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  quickLinkText: {
    fontSize: 15,
    color: '#64748b',
    textAlign: 'right',
  },
});
