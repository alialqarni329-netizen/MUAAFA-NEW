import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { Mail, MessageCircle } from 'lucide-react-native';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function ContactScreen() {
  const router = useRouter();
  const { language } = useLanguage();

  const handleEmailPress = () => {
    Linking.openURL('mailto:muaafa@outlook.sa');
  };

  const handleXPress = () => {
    Linking.openURL('https://x.com/MuaafaHealth');
  };

  const handleWhatsAppPress = () => {
    Linking.openURL('https://wa.me/966556236305');
  };

  const handleLiveChatPress = () => {
    router.push('/(tabs)');
  };

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'تواصل معنا',
          headerStyle: {
            backgroundColor: '#0ea5e9',
          },
          headerTintColor: '#ffffff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      />
      <View style={styles.container}>
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <Mail size={48} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.headerTitle}>
              {language === 'ar' ? 'نحن هنا لمساعدتك' : 'We are here to help you'}
            </Text>
            <Text style={styles.headerSubtitle}>
              {language === 'ar'
                ? 'تواصل معنا للاستفسارات والاقتراحات والملاحظات'
                : 'Contact us for inquiries, suggestions and feedback'}
            </Text>
          </View>

          <View style={styles.contactCard}>
            <View style={styles.contactHeader}>
              <MessageCircle size={24} color="#10b981" strokeWidth={2} />
              <Text style={styles.contactTitle}>
                {language === 'ar' ? 'المحادثة المباشرة' : 'Live Chat'}
              </Text>
            </View>
            <Text style={styles.contactDescription}>
              {language === 'ar'
                ? 'تحدث مع مساعد مُعافى الذكي للحصول على إجابات فورية'
                : 'Chat with MUAAFA AI assistant for instant answers'}
            </Text>
            <TouchableOpacity
              style={[styles.contactButton, styles.chatButton]}
              onPress={handleLiveChatPress}>
              <Text style={styles.contactButtonText}>
                {language === 'ar' ? 'ابدأ المحادثة' : 'Start Chat'}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.contactCard}>
            <View style={styles.contactHeader}>
              <MessageCircle size={24} color="#25D366" strokeWidth={2} />
              <Text style={styles.contactTitle}>
                {language === 'ar' ? 'واتساب' : 'WhatsApp'}
              </Text>
            </View>
            <Text style={styles.contactDescription}>
              {language === 'ar'
                ? 'تواصل معنا مباشرة عبر واتساب'
                : 'Contact us directly via WhatsApp'}
            </Text>
            <TouchableOpacity
              style={[styles.contactButton, styles.whatsappButton]}
              onPress={handleWhatsAppPress}>
              <Text style={styles.contactButtonText}>0556236305</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.contactCard}>
            <View style={styles.contactHeader}>
              <Mail size={24} color="#0ea5e9" strokeWidth={2} />
              <Text style={styles.contactTitle}>
                {language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
              </Text>
            </View>
            <Text style={styles.contactDescription}>
              {language === 'ar'
                ? 'للاستفسارات العامة والدعم الفني والملاحظات'
                : 'For general inquiries, technical support and feedback'}
            </Text>
            <TouchableOpacity style={styles.contactButton} onPress={handleEmailPress}>
              <Text style={styles.contactButtonText}>muaafa@outlook.sa</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.contactCard}>
            <View style={styles.contactHeader}>
              <Text style={styles.xIcon}>𝕏</Text>
              <Text style={styles.contactTitle}>X</Text>
            </View>
            <Text style={styles.contactDescription}>
              {language === 'ar'
                ? 'تابعنا على X لآخر الأخبار والتحديثات'
                : 'Follow us on X for latest news and updates'}
            </Text>
            <TouchableOpacity
              style={[styles.contactButton, styles.xButton]}
              onPress={handleXPress}>
              <Text style={styles.contactButtonText}>@MuaafaHealth</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>أوقات الرد</Text>
            <Text style={styles.infoText}>
              نحن نعمل على الرد على جميع الاستفسارات في أسرع وقت ممكن، عادةً خلال 24-48 ساعة
              عمل.
            </Text>
          </View>

          <View style={styles.categoriesCard}>
            <Text style={styles.categoriesTitle}>كيف يمكننا مساعدتك؟</Text>
            <View style={styles.categoryItem}>
              <Text style={styles.categoryDot}>•</Text>
              <Text style={styles.categoryText}>استفسارات حول الاشتراكات والدفع</Text>
            </View>
            <View style={styles.categoryItem}>
              <Text style={styles.categoryDot}>•</Text>
              <Text style={styles.categoryText}>مشاكل تقنية في التطبيق</Text>
            </View>
            <View style={styles.categoryItem}>
              <Text style={styles.categoryDot}>•</Text>
              <Text style={styles.categoryText}>الاقتراحات والملاحظات</Text>
            </View>
            <View style={styles.categoryItem}>
              <Text style={styles.categoryDot}>•</Text>
              <Text style={styles.categoryText}>الشراكات والتعاون</Text>
            </View>
            <View style={styles.categoryItem}>
              <Text style={styles.categoryDot}>•</Text>
              <Text style={styles.categoryText}>الاستفسارات الطبية (سيتم توجيهك لطبيب متخصص)</Text>
            </View>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 16,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
  },
  contactCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  contactHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  contactTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  contactDescription: {
    fontSize: 15,
    color: '#64748b',
    marginBottom: 16,
    textAlign: 'right',
    lineHeight: 22,
  },
  contactButton: {
    backgroundColor: '#0ea5e9',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  chatButton: {
    backgroundColor: '#10b981',
  },
  whatsappButton: {
    backgroundColor: '#25D366',
  },
  xButton: {
    backgroundColor: '#000000',
  },
  xIcon: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000',
  },
  contactButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  infoCard: {
    backgroundColor: '#e0f2fe',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#075985',
    marginBottom: 12,
    textAlign: 'right',
  },
  infoText: {
    fontSize: 15,
    color: '#0c4a6e',
    textAlign: 'right',
    lineHeight: 24,
  },
  categoriesCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  categoriesTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  categoryItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
    gap: 8,
  },
  categoryDot: {
    fontSize: 16,
    color: '#0ea5e9',
    fontWeight: 'bold',
  },
  categoryText: {
    flex: 1,
    fontSize: 15,
    color: '#475569',
    textAlign: 'right',
    lineHeight: 22,
  },
});
