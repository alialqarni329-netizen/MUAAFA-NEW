import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { ChevronRight, Dumbbell, Clock, Flame } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

export default function AddWorkoutScreen() {
  const router = useRouter();
  const [workoutName, setWorkoutName] = useState('');
  const [duration, setDuration] = useState('');
  const [calories, setCalories] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSubmit() {
    if (!workoutName || !duration) {
      Alert.alert('خطأ', 'يرجى إدخال اسم التمرين والمدة');
      return;
    }

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not found');

      const { error } = await supabase.from('fitness_workouts').insert({
        user_id: user.id,
        workout_name: workoutName,
        duration_minutes: parseInt(duration),
        calories_burned: calories ? parseInt(calories) : 0,
        notes: notes || null,
      });

      if (error) throw error;

      Alert.alert('تم الحفظ', 'تم إضافة التمرين بنجاح', [
        { text: 'حسناً', onPress: () => router.push('/fitness/my-data') },
      ]);
    } catch (error: any) {
      console.error('Error saving workout:', error);
      Alert.alert('خطأ', 'تعذر حفظ التمرين');
    } finally {
      setSaving(false);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>إضافة تمرين</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>اسم التمرين *</Text>
            <View style={styles.inputContainer}>
              <Dumbbell size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.input}
                placeholder="مثال: جري، سباحة، رفع أثقال"
                value={workoutName}
                onChangeText={setWorkoutName}
                textAlign="right"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>المدة (دقيقة) *</Text>
            <View style={styles.inputContainer}>
              <Clock size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.input}
                placeholder="30"
                value={duration}
                onChangeText={setDuration}
                keyboardType="number-pad"
                textAlign="right"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>السعرات المحروقة (اختياري)</Text>
            <View style={styles.inputContainer}>
              <Flame size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.input}
                placeholder="200"
                value={calories}
                onChangeText={setCalories}
                keyboardType="number-pad"
                textAlign="right"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>ملاحظات (اختياري)</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="أضف أي ملاحظات عن التمرين..."
              value={notes}
              onChangeText={setNotes}
              multiline
              numberOfLines={4}
              textAlign="right"
              textAlignVertical="top"
            />
          </View>
        </View>

        <TouchableOpacity
          style={[styles.submitButton, saving && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={saving}>
          <Text style={styles.submitButtonText}>
            {saving ? 'جاري الحفظ...' : 'حفظ التمرين'}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  form: {
    gap: 20,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    paddingHorizontal: 16,
    gap: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
    paddingVertical: 14,
  },
  textArea: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    padding: 16,
    minHeight: 100,
  },
  submitButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 24,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
