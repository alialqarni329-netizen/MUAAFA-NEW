import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import {
  ChevronRight,
  Target,
  Dumbbell,
  Flame,
  Clock,
  Calendar,
  Trash2,
  TrendingUp,
  Plus,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface Workout {
  id: string;
  workout_name: string;
  duration_minutes: number;
  calories_burned: number;
  notes: string | null;
  created_at: string;
}

interface Goal {
  id: string;
  goal_type: string;
  target_value: number;
  current_value: number;
  start_date: string;
  end_date: string;
  is_completed: boolean;
  created_at: string;
}

export default function MyFitnessDataScreen() {
  const router = useRouter();
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<'workouts' | 'goals'>('workouts');

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    await Promise.all([loadWorkouts(), loadGoals()]);
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }

  async function loadWorkouts() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('fitness_workouts')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setWorkouts(data || []);
    } catch (error: any) {
      console.error('Error loading workouts:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadGoals() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('fitness_goals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setGoals(data || []);
    } catch (error: any) {
      console.error('Error loading goals:', error);
    } finally {
      setLoading(false);
    }
  }

  async function deleteWorkout(id: string) {
    Alert.alert(
      'حذف التمرين',
      'هل أنت متأكد من حذف هذا التمرين؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('fitness_workouts')
                .delete()
                .eq('id', id);

              if (error) throw error;
              setWorkouts((prev) => prev.filter((w) => w.id !== id));
              Alert.alert('تم الحذف', 'تم حذف التمرين بنجاح');
            } catch (error) {
              console.error('Error deleting workout:', error);
              Alert.alert('خطأ', 'تعذر حذف التمرين');
            }
          },
        },
      ]
    );
  }

  async function deleteGoal(id: string) {
    Alert.alert(
      'حذف الهدف',
      'هل أنت متأكد من حذف هذا الهدف؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('fitness_goals')
                .delete()
                .eq('id', id);

              if (error) throw error;
              setGoals((prev) => prev.filter((g) => g.id !== id));
              Alert.alert('تم الحذف', 'تم حذف الهدف بنجاح');
            } catch (error) {
              console.error('Error deleting goal:', error);
              Alert.alert('خطأ', 'تعذر حذف الهدف');
            }
          },
        },
      ]
    );
  }

  function getGoalLabel(type: string) {
    const labels: Record<string, string> = {
      steps: 'خطوات',
      calories: 'سعرة حرارية',
      sleep: 'ساعات نوم',
      weight: 'كيلوغرام',
    };
    return labels[type] || type;
  }

  function getProgress(goal: Goal) {
    return Math.min((goal.current_value / goal.target_value) * 100, 100);
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>تماريني وأهدافي</Text>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'workouts' && styles.activeTab]}
          onPress={() => setActiveTab('workouts')}>
          <Dumbbell
            size={20}
            color={activeTab === 'workouts' ? '#0ea5e9' : '#64748b'}
            strokeWidth={2}
          />
          <Text
            style={[styles.tabText, activeTab === 'workouts' && styles.activeTabText]}>
            التمارين ({workouts.length})
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'goals' && styles.activeTab]}
          onPress={() => setActiveTab('goals')}>
          <Target
            size={20}
            color={activeTab === 'goals' ? '#0ea5e9' : '#64748b'}
            strokeWidth={2}
          />
          <Text style={[styles.tabText, activeTab === 'goals' && styles.activeTabText]}>
            الأهداف ({goals.length})
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        {activeTab === 'workouts' && (
          <>
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => router.push('/fitness/add-workout')}>
              <Plus size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.addButtonText}>إضافة تمرين جديد</Text>
            </TouchableOpacity>

            {workouts.length === 0 ? (
              <View style={styles.emptyState}>
                <Dumbbell size={64} color="#cbd5e1" strokeWidth={2} />
                <Text style={styles.emptyStateTitle}>لا توجد تمارين محفوظة</Text>
                <Text style={styles.emptyStateText}>
                  ابدأ بإضافة تمرين جديد لتتبع نشاطك الرياضي
                </Text>
              </View>
            ) : (
              <View style={styles.list}>
                {workouts.map((workout) => (
                  <View key={workout.id} style={styles.workoutCard}>
                    <View style={styles.workoutHeader}>
                      <View style={styles.workoutIconContainer}>
                        <Dumbbell size={24} color="#10b981" strokeWidth={2} />
                      </View>
                      <View style={styles.workoutInfo}>
                        <Text style={styles.workoutName}>{workout.workout_name}</Text>
                        <View style={styles.workoutMeta}>
                          <View style={styles.metaItem}>
                            <Clock size={14} color="#64748b" strokeWidth={2} />
                            <Text style={styles.metaText}>
                              {workout.duration_minutes} دقيقة
                            </Text>
                          </View>
                          <View style={styles.metaItem}>
                            <Flame size={14} color="#f59e0b" strokeWidth={2} />
                            <Text style={styles.metaText}>
                              {workout.calories_burned} سعرة
                            </Text>
                          </View>
                        </View>
                        {workout.notes && (
                          <Text style={styles.workoutNotes}>{workout.notes}</Text>
                        )}
                        <View style={styles.workoutFooter}>
                          <Calendar size={12} color="#94a3b8" strokeWidth={2} />
                          <Text style={styles.workoutDate}>
                            {new Date(workout.created_at).toLocaleDateString('ar-SA', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric',
                            })}
                          </Text>
                        </View>
                      </View>
                      <TouchableOpacity
                        style={styles.deleteButton}
                        onPress={() => deleteWorkout(workout.id)}>
                        <Trash2 size={18} color="#ef4444" strokeWidth={2} />
                      </TouchableOpacity>
                    </View>
                  </View>
                ))}
              </View>
            )}
          </>
        )}

        {activeTab === 'goals' && (
          <>
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => router.push('/fitness/create-goal')}>
              <Plus size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.addButtonText}>إضافة هدف جديد</Text>
            </TouchableOpacity>

            {goals.length === 0 ? (
              <View style={styles.emptyState}>
                <Target size={64} color="#cbd5e1" strokeWidth={2} />
                <Text style={styles.emptyStateTitle}>لا توجد أهداف محفوظة</Text>
                <Text style={styles.emptyStateText}>
                  ابدأ بإضافة هدف جديد وتتبع تقدمك نحو تحقيقه
                </Text>
              </View>
            ) : (
              <View style={styles.list}>
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>الأهداف النشطة</Text>
                  {goals.filter((g) => !g.is_completed).length === 0 ? (
                    <Text style={styles.noItemsText}>لا توجد أهداف نشطة</Text>
                  ) : (
                    goals
                      .filter((g) => !g.is_completed)
                      .map((goal) => (
                        <View key={goal.id} style={styles.goalCard}>
                          <View style={styles.goalHeader}>
                            <View style={styles.goalIconContainer}>
                              <Target size={24} color="#0ea5e9" strokeWidth={2} />
                            </View>
                            <View style={styles.goalInfo}>
                              <Text style={styles.goalType}>
                                {getGoalLabel(goal.goal_type)}
                              </Text>
                              <Text style={styles.goalTarget}>
                                الهدف: {goal.target_value}
                              </Text>
                              <View style={styles.progressContainer}>
                                <View style={styles.progressBar}>
                                  <View
                                    style={[
                                      styles.progressFill,
                                      { width: `${getProgress(goal)}%` },
                                    ]}
                                  />
                                </View>
                                <Text style={styles.progressText}>
                                  {goal.current_value} / {goal.target_value} (
                                  {getProgress(goal).toFixed(0)}%)
                                </Text>
                              </View>
                              <View style={styles.goalDates}>
                                <Text style={styles.goalDate}>
                                  ينتهي: {new Date(goal.end_date).toLocaleDateString('ar-SA')}
                                </Text>
                              </View>
                            </View>
                            <TouchableOpacity
                              style={styles.deleteButton}
                              onPress={() => deleteGoal(goal.id)}>
                              <Trash2 size={18} color="#ef4444" strokeWidth={2} />
                            </TouchableOpacity>
                          </View>
                        </View>
                      ))
                  )}
                </View>

                {goals.filter((g) => g.is_completed).length > 0 && (
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>الأهداف المكتملة</Text>
                    {goals
                      .filter((g) => g.is_completed)
                      .map((goal) => (
                        <View key={goal.id} style={[styles.goalCard, styles.completedGoal]}>
                          <View style={styles.goalHeader}>
                            <View
                              style={[
                                styles.goalIconContainer,
                                styles.completedGoalIcon,
                              ]}>
                              <Target size={24} color="#10b981" strokeWidth={2} />
                            </View>
                            <View style={styles.goalInfo}>
                              <Text style={styles.goalType}>
                                {getGoalLabel(goal.goal_type)}
                              </Text>
                              <Text style={styles.completedBadge}>✓ مكتمل</Text>
                            </View>
                            <TouchableOpacity
                              style={styles.deleteButton}
                              onPress={() => deleteGoal(goal.id)}>
                              <Trash2 size={18} color="#ef4444" strokeWidth={2} />
                            </TouchableOpacity>
                          </View>
                        </View>
                      ))}
                  </View>
                )}
              </View>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: '#0ea5e9',
  },
  tabText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#64748b',
  },
  activeTabText: {
    color: '#0ea5e9',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  addButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  list: {
    gap: 16,
  },
  section: {
    gap: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  noItemsText: {
    fontSize: 14,
    color: '#94a3b8',
    textAlign: 'center',
    padding: 24,
  },
  workoutCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  workoutHeader: {
    flexDirection: 'row',
    gap: 12,
  },
  workoutIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#d1fae5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  workoutInfo: {
    flex: 1,
    gap: 8,
  },
  workoutName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  workoutMeta: {
    flexDirection: 'row',
    gap: 16,
    justifyContent: 'flex-end',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 13,
    color: '#64748b',
  },
  workoutNotes: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
    fontStyle: 'italic',
  },
  workoutFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    justifyContent: 'flex-end',
  },
  workoutDate: {
    fontSize: 12,
    color: '#94a3b8',
  },
  deleteButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#fee2e2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  goalCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  completedGoal: {
    backgroundColor: '#f8fafc',
  },
  goalHeader: {
    flexDirection: 'row',
    gap: 12,
  },
  goalIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#dbeafe',
    justifyContent: 'center',
    alignItems: 'center',
  },
  completedGoalIcon: {
    backgroundColor: '#d1fae5',
  },
  goalInfo: {
    flex: 1,
    gap: 8,
  },
  goalType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  goalTarget: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  progressContainer: {
    gap: 6,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#f1f5f9',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#0ea5e9',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  goalDates: {
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  goalDate: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  completedBadge: {
    fontSize: 13,
    color: '#10b981',
    fontWeight: '600',
    textAlign: 'right',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
    gap: 16,
  },
  emptyStateTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#64748b',
  },
  emptyStateText: {
    fontSize: 14,
    color: '#94a3b8',
    textAlign: 'center',
    lineHeight: 22,
  },
});
