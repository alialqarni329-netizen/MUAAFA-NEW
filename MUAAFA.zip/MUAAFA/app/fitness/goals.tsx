import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { ChevronRight, Target, TrendingUp, Plus, Footprints, Flame, Moon, Scale } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface Goal {
  id: string;
  goal_type: string;
  target_value: number;
  current_value: number;
  start_date: string;
  end_date: string;
  is_completed: boolean;
}

export default function FitnessGoalsScreen() {
  const router = useRouter();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadGoals();
  }, []);

  async function loadGoals() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('fitness_goals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setGoals(data || []);
    } catch (error: any) {
      console.error('Error loading goals:', error);
    } finally {
      setLoading(false);
    }
  }

  function getGoalIcon(type: string) {
    switch (type) {
      case 'steps':
        return <Footprints size={24} color="#0ea5e9" strokeWidth={2} />;
      case 'calories':
        return <Flame size={24} color="#f59e0b" strokeWidth={2} />;
      case 'sleep':
        return <Moon size={24} color="#8b5cf6" strokeWidth={2} />;
      case 'weight':
        return <Scale size={24} color="#10b981" strokeWidth={2} />;
      default:
        return <Target size={24} color="#64748b" strokeWidth={2} />;
    }
  }

  function getGoalLabel(type: string) {
    const labels: Record<string, string> = {
      steps: 'خطوات',
      calories: 'سعرة حرارية',
      sleep: 'ساعات نوم',
      weight: 'كيلوغرام',
    };
    return labels[type] || type;
  }

  function getProgress(goal: Goal) {
    return Math.min((goal.current_value / goal.target_value) * 100, 100);
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>الأهداف والتحديات</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <TouchableOpacity
          style={styles.newGoalButton}
          onPress={() => router.push('/fitness/create-goal')}>
          <Plus size={24} color="#ffffff" strokeWidth={2} />
          <Text style={styles.newGoalButtonText}>إضافة هدف جديد</Text>
        </TouchableOpacity>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <TrendingUp size={20} color="#0ea5e9" strokeWidth={2} />
            <Text style={styles.sectionTitle}>الأهداف النشطة</Text>
          </View>

          {goals.filter(g => !g.is_completed).map((goal) => (
            <View key={goal.id} style={styles.goalCard}>
              <View style={styles.goalHeader}>
                <View style={styles.goalIcon}>
                  {getGoalIcon(goal.goal_type)}
                </View>
                <View style={styles.goalInfo}>
                  <Text style={styles.goalType}>{getGoalLabel(goal.goal_type)}</Text>
                  <Text style={styles.goalTarget}>
                    الهدف: {goal.target_value} {getGoalLabel(goal.goal_type)}
                  </Text>
                </View>
              </View>

              <View style={styles.progressContainer}>
                <View style={styles.progressBar}>
                  <View
                    style={[
                      styles.progressFill,
                      { width: `${getProgress(goal)}%` },
                    ]}
                  />
                </View>
                <Text style={styles.progressText}>
                  {goal.current_value} / {goal.target_value} ({getProgress(goal).toFixed(0)}%)
                </Text>
              </View>

              <View style={styles.goalDates}>
                <Text style={styles.goalDate}>
                  ينتهي: {new Date(goal.end_date).toLocaleDateString('ar-SA')}
                </Text>
              </View>
            </View>
          ))}

          {goals.filter(g => !g.is_completed).length === 0 && (
            <View style={styles.emptyState}>
              <Target size={48} color="#cbd5e1" strokeWidth={2} />
              <Text style={styles.emptyStateText}>لا توجد أهداف نشطة</Text>
              <Text style={styles.emptyStateSubtext}>ابدأ بإضافة هدف جديد</Text>
            </View>
          )}
        </View>

        {goals.filter(g => g.is_completed).length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>الأهداف المكتملة</Text>
            </View>

            {goals.filter(g => g.is_completed).map((goal) => (
              <View key={goal.id} style={[styles.goalCard, styles.completedGoalCard]}>
                <View style={styles.goalHeader}>
                  <View style={[styles.goalIcon, styles.completedGoalIcon]}>
                    {getGoalIcon(goal.goal_type)}
                  </View>
                  <View style={styles.goalInfo}>
                    <Text style={styles.goalType}>{getGoalLabel(goal.goal_type)}</Text>
                    <Text style={styles.completedBadge}>✓ مكتمل</Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 24,
  },
  newGoalButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  newGoalButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  section: {
    gap: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  goalCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  completedGoalCard: {
    backgroundColor: '#f8fafc',
  },
  goalHeader: {
    flexDirection: 'row',
    gap: 12,
  },
  goalIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#eff6ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  completedGoalIcon: {
    backgroundColor: '#d1fae5',
  },
  goalInfo: {
    flex: 1,
  },
  goalType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  goalTarget: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'right',
  },
  progressContainer: {
    gap: 8,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#f1f5f9',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#0ea5e9',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'right',
  },
  goalDates: {
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  goalDate: {
    fontSize: 12,
    color: '#64748b',
    textAlign: 'right',
  },
  completedBadge: {
    fontSize: 13,
    color: '#10b981',
    fontWeight: '600',
    textAlign: 'right',
  },
  emptyState: {
    padding: 48,
    alignItems: 'center',
    gap: 12,
  },
  emptyStateText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748b',
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#94a3b8',
  },
});
