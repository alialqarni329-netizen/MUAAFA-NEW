import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { ChevronRight, Target } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

export default function CreateGoalScreen() {
  const router = useRouter();
  const [goalType, setGoalType] = useState('steps');
  const [targetValue, setTargetValue] = useState('');
  const [days, setDays] = useState('7');
  const [saving, setSaving] = useState(false);

  const goalTypes = [
    { value: 'steps', label: 'خطوات', unit: 'خطوة' },
    { value: 'calories', label: 'سعرات حرارية', unit: 'سعرة' },
    { value: 'sleep', label: 'ساعات نوم', unit: 'ساعة' },
    { value: 'weight', label: 'الوزن', unit: 'كجم' },
  ];

  async function handleSubmit() {
    if (!targetValue || !days) {
      Alert.alert('خطأ', 'يرجى إدخال جميع الحقول');
      return;
    }

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not found');

      const today = new Date();
      const endDate = new Date();
      endDate.setDate(today.getDate() + parseInt(days));

      const { error } = await supabase.from('fitness_goals').insert({
        user_id: user.id,
        goal_type: goalType,
        target_value: parseFloat(targetValue),
        start_date: today.toISOString().split('T')[0],
        end_date: endDate.toISOString().split('T')[0],
      });

      if (error) throw error;

      Alert.alert('تم الحفظ', 'تم إنشاء الهدف بنجاح', [
        { text: 'حسناً', onPress: () => router.push('/fitness/my-data') },
      ]);
    } catch (error: any) {
      console.error('Error creating goal:', error);
      Alert.alert('خطأ', 'تعذر إنشاء الهدف');
    } finally {
      setSaving(false);
    }
  }

  const selectedGoalType = goalTypes.find(g => g.value === goalType);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronRight size={24} color="#0f172a" strokeWidth={2} />
        </TouchableOpacity>
        <Text style={styles.title}>إنشاء هدف جديد</Text>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>نوع الهدف</Text>
            <View style={styles.goalTypesGrid}>
              {goalTypes.map((type) => (
                <TouchableOpacity
                  key={type.value}
                  style={[
                    styles.goalTypeButton,
                    goalType === type.value && styles.goalTypeButtonActive,
                  ]}
                  onPress={() => setGoalType(type.value)}>
                  <Text
                    style={[
                      styles.goalTypeText,
                      goalType === type.value && styles.goalTypeTextActive,
                    ]}>
                    {type.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              الهدف ({selectedGoalType?.unit})
            </Text>
            <View style={styles.inputContainer}>
              <Target size={20} color="#64748b" strokeWidth={2} />
              <TextInput
                style={styles.input}
                placeholder={goalType === 'steps' ? '10000' : '500'}
                value={targetValue}
                onChangeText={setTargetValue}
                keyboardType="number-pad"
                textAlign="right"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>المدة (أيام)</Text>
            <TextInput
              style={styles.input}
              placeholder="7"
              value={days}
              onChangeText={setDays}
              keyboardType="number-pad"
              textAlign="right"
            />
          </View>
        </View>

        <TouchableOpacity
          style={[styles.submitButton, saving && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={saving}>
          <Text style={styles.submitButtonText}>
            {saving ? 'جاري الحفظ...' : 'إنشاء الهدف'}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  form: {
    gap: 20,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
    textAlign: 'right',
  },
  goalTypesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  goalTypeButton: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    alignItems: 'center',
  },
  goalTypeButtonActive: {
    backgroundColor: '#eff6ff',
    borderColor: '#0ea5e9',
  },
  goalTypeText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#64748b',
  },
  goalTypeTextActive: {
    color: '#0ea5e9',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    paddingHorizontal: 16,
    gap: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
    paddingVertical: 14,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    padding: 16,
  },
  submitButton: {
    backgroundColor: '#0ea5e9',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 24,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
