import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useState, useEffect } from 'react';
import { Stack, useRouter } from 'expo-router';
import { User, Trash2, Save } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

export default function ProfileScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: 'male' as 'male' | 'female',
    location: '',
  });

  useEffect(() => {
    loadProfile();
  }, []);

  async function loadProfile() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (data) {
        setFormData({
          fullName: data.full_name || '',
          email: user.email || '',
          phone: data.phone || '',
          dateOfBirth: data.date_of_birth || '',
          gender: (data.gender as 'male' | 'female') || 'male',
          location: data.location || '',
        });
      }
    }
  }

  async function handleUpdate() {
    setLoading(true);
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setLoading(false);
      return;
    }

    const { error } = await supabase
      .from('users')
      .update({
        full_name: formData.fullName,
        phone: formData.phone,
        date_of_birth: formData.dateOfBirth,
        gender: formData.gender,
        location: formData.location,
        updated_at: new Date().toISOString(),
      })
      .eq('id', user.id);

    setLoading(false);

    if (error) {
      Alert.alert('خطأ', 'حدث خطأ أثناء تحديث البيانات');
    } else {
      Alert.alert('نجح', 'تم تحديث معلوماتك بنجاح');
    }
  }

  async function handleDeleteAccount() {
    Alert.alert(
      'حذف الحساب',
      'هل أنت متأكد من حذف حسابك وجميع بياناتك؟ هذا الإجراء لا يمكن التراجع عنه.',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            const {
              data: { user },
            } = await supabase.auth.getUser();
            if (!user) return;

            await supabase.from('users').delete().eq('id', user.id);

            await supabase.auth.signOut();
            Alert.alert('تم الحذف', 'تم حذف حسابك وجميع بياناتك بنجاح', [
              { text: 'حسناً', onPress: () => router.replace('/auth/login') },
            ]);
          },
        },
      ]
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'المعلومات الشخصية',
          headerStyle: { backgroundColor: '#0ea5e9' },
          headerTintColor: '#ffffff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      />
      <View style={styles.container}>
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatar}>
              <User size={48} color="#0ea5e9" strokeWidth={2} />
            </View>
            <Text style={styles.avatarTitle}>إدارة حسابك</Text>
          </View>

          <View style={styles.form}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>الاسم الكامل</Text>
              <TextInput
                style={styles.input}
                value={formData.fullName}
                onChangeText={(text) => setFormData({ ...formData, fullName: text })}
                textAlign="right"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>البريد الإلكتروني</Text>
              <TextInput
                style={[styles.input, styles.inputDisabled]}
                value={formData.email}
                editable={false}
                textAlign="right"
              />
              <Text style={styles.hint}>البريد الإلكتروني لا يمكن تعديله</Text>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>رقم الجوال</Text>
              <TextInput
                style={styles.input}
                value={formData.phone}
                onChangeText={(text) => setFormData({ ...formData, phone: text })}
                keyboardType="phone-pad"
                textAlign="right"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>تاريخ الميلاد</Text>
              <TextInput
                style={styles.input}
                value={formData.dateOfBirth}
                onChangeText={(text) => setFormData({ ...formData, dateOfBirth: text })}
                placeholder="YYYY-MM-DD"
                textAlign="right"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>الجنس</Text>
              <View style={styles.genderContainer}>
                <TouchableOpacity
                  style={[
                    styles.genderButton,
                    formData.gender === 'female' && styles.genderButtonActive,
                  ]}
                  onPress={() => setFormData({ ...formData, gender: 'female' })}>
                  <Text
                    style={[
                      styles.genderButtonText,
                      formData.gender === 'female' && styles.genderButtonTextActive,
                    ]}>
                    أنثى
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.genderButton,
                    formData.gender === 'male' && styles.genderButtonActive,
                  ]}
                  onPress={() => setFormData({ ...formData, gender: 'male' })}>
                  <Text
                    style={[
                      styles.genderButtonText,
                      formData.gender === 'male' && styles.genderButtonTextActive,
                    ]}>
                    ذكر
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>الموقع</Text>
              <TextInput
                style={styles.input}
                value={formData.location}
                onChangeText={(text) => setFormData({ ...formData, location: text })}
                textAlign="right"
              />
            </View>

            <TouchableOpacity
              style={[styles.saveButton, loading && styles.saveButtonDisabled]}
              onPress={handleUpdate}
              disabled={loading}>
              <Save size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.saveButtonText}>
                {loading ? 'جاري الحفظ...' : 'حفظ التغييرات'}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.dangerZone}>
            <Text style={styles.dangerTitle}>منطقة الخطر</Text>
            <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteAccount}>
              <Trash2 size={20} color="#ef4444" strokeWidth={2} />
              <Text style={styles.deleteButtonText}>حذف الحساب والبيانات</Text>
            </TouchableOpacity>
            <Text style={styles.dangerHint}>
              سيتم حذف جميع بياناتك بما في ذلك المحادثات، الجلسات، والاستبيان الطبي
            </Text>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  avatarContainer: { alignItems: 'center', marginBottom: 32 },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#e0f2fe',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  avatarTitle: { fontSize: 20, fontWeight: 'bold', color: '#0f172a' },
  form: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  inputGroup: { marginBottom: 20 },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#0f172a',
  },
  inputDisabled: { backgroundColor: '#f1f5f9', color: '#94a3b8' },
  hint: { fontSize: 12, color: '#94a3b8', marginTop: 4, textAlign: 'right' },
  genderContainer: { flexDirection: 'row', gap: 12, justifyContent: 'flex-end' },
  genderButton: {
    flex: 1,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
  },
  genderButtonActive: { backgroundColor: '#e0f2fe', borderColor: '#0ea5e9' },
  genderButtonText: { fontSize: 16, color: '#64748b', fontWeight: '600' },
  genderButtonTextActive: { color: '#0ea5e9' },
  saveButton: {
    backgroundColor: '#0ea5e9',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
    marginTop: 8,
  },
  saveButtonDisabled: { opacity: 0.6 },
  saveButtonText: { color: '#ffffff', fontSize: 16, fontWeight: 'bold' },
  dangerZone: {
    backgroundColor: '#fef2f2',
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  dangerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#991b1b',
    marginBottom: 12,
    textAlign: 'right',
  },
  deleteButton: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#fecaca',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 12,
  },
  deleteButtonText: { fontSize: 16, color: '#ef4444', fontWeight: '600' },
  dangerHint: {
    fontSize: 13,
    color: '#991b1b',
    textAlign: 'right',
    lineHeight: 20,
  },
});
