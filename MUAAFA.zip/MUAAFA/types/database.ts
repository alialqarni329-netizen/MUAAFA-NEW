export interface User {
  id: string;
  full_name: string;
  phone: string;
  date_of_birth: string | null;
  gender: 'male' | 'female' | null;
  location: string;
  language: string;
  created_at: string;
  updated_at: string;
}

export interface ChatConversation {
  id: string;
  user_id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface ChatMessage {
  id: string;
  conversation_id: string;
  sender_type: 'user' | 'ai';
  content: string;
  image_url: string | null;
  created_at: string;
}

export interface Doctor {
  id: string;
  full_name: string;
  specialty: string;
  bio: string;
  rating: number;
  is_available: boolean;
  created_at: string;
}

export interface Session {
  id: string;
  user_id: string;
  doctor_id: string;
  session_type: 'video' | 'chat';
  status: 'upcoming' | 'completed' | 'cancelled';
  scheduled_date: string;
  scheduled_time: string;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  plan_type: 'trial' | 'weekly' | 'monthly' | 'yearly';
  status: 'active' | 'expired' | 'cancelled';
  start_date: string;
  end_date: string | null;
  trial_minutes_used: number;
  trial_day: number;
  created_at: string;
  updated_at: string;
}

export interface UsageLog {
  id: string;
  user_id: string;
  session_type: 'chat' | 'doctor' | 'image_analysis';
  duration_seconds: number;
  created_at: string;
}

export interface ImageAnalysis {
  id: string;
  user_id: string;
  image_url: string;
  analysis_result: string | null;
  body_part: string;
  created_at: string;
}

export interface HealthArticle {
  id: string;
  title: string;
  content: string;
  category: string;
  image_url: string | null;
  created_at: string;
  updated_at: string;
}
