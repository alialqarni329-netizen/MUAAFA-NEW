import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Construction, ArrowLeft, Info } from 'lucide-react-native';

interface UnderDevelopmentProps {
  feature: string;
  description?: string;
  expectedDate?: string;
}

export function UnderDevelopment({ feature, description, expectedDate }: UnderDevelopmentProps) {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Construction size={64} color="#f59e0b" strokeWidth={2} />
        </View>

        <View style={styles.badge}>
          <Text style={styles.badgeText}>قيد التطوير</Text>
        </View>

        <Text style={styles.title}>{feature}</Text>

        {description && (
          <Text style={styles.description}>{description}</Text>
        )}

        <View style={styles.infoCard}>
          <Info size={20} color="#0ea5e9" strokeWidth={2} />
          <View style={styles.infoContent}>
            <Text style={styles.infoTitle}>هذه الميزة قيد التطوير حالياً</Text>
            <Text style={styles.infoText}>
              نعمل بجد لإضافة هذه الميزة وتوفيرها{'\n'}
              في أقرب وقت ممكن
            </Text>
            {expectedDate && (
              <Text style={styles.dateText}>
                متوقع: {expectedDate}
              </Text>
            )}
          </View>
        </View>

        <TouchableOpacity
          style={styles.button}
          onPress={() => router.back()}>
          <ArrowLeft size={20} color="#ffffff" strokeWidth={2} />
          <Text style={styles.buttonText}>العودة</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  content: {
    alignItems: 'center',
    maxWidth: 500,
    width: '100%',
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#fef3c7',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  badge: {
    backgroundColor: '#fbbf24',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginBottom: 16,
  },
  badgeText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  infoCard: {
    flexDirection: 'row',
    backgroundColor: '#e0f2fe',
    padding: 16,
    borderRadius: 12,
    gap: 12,
    width: '100%',
    marginBottom: 32,
    borderWidth: 1,
    borderColor: '#bae6fd',
  },
  infoContent: {
    flex: 1,
    gap: 4,
  },
  infoTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0c4a6e',
    textAlign: 'right',
  },
  infoText: {
    fontSize: 14,
    color: '#075985',
    textAlign: 'right',
    lineHeight: 20,
  },
  dateText: {
    fontSize: 13,
    color: '#0284c7',
    fontWeight: '600',
    marginTop: 4,
    textAlign: 'right',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#6366f1',
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
