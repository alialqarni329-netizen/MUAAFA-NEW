import { View, TouchableOpacity, StyleSheet, Animated, Modal, Pressable, Text, Platform } from 'react-native';
import { useState, useRef, useEffect } from 'react';
import { useRouter, usePathname } from 'expo-router';
import { ShoppingCart, FileText } from 'lucide-react-native';
import { BlurView } from 'expo-blur';
import * as Haptics from 'expo-haptics';
import { supabase } from '@/lib/supabase';

export function GlobalFAB() {
  const router = useRouter();
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const authRoutes = ['/auth/login', '/auth/register', '/auth/phone-login', '/auth/verify-phone', '/auth/forgot-password', '/business/login', '/business/register'];
  const businessRoutes = ['/business/dashboard', '/business/employees', '/business/claims', '/business/sessions', '/business/billing', '/business/analytics', '/business/settings', '/business/delivery-dashboard', '/business/insurance-dashboard', '/business/pending-approval'];
  const allowedRoutes = ['/(tabs)', '/(tabs)/index', '/(tabs)/fitness', '/(tabs)/history', '/(tabs)/pharmacies', '/(tabs)/reports', '/(tabs)/sessions', '/(tabs)/settings', '/cart', '/subscription-plans'];

  const isInTabsRoute = pathname.startsWith('/(tabs)') || pathname === '/' || allowedRoutes.some(route => pathname.startsWith(route.replace('/(tabs)', '')));
  const shouldHideFAB = authRoutes.includes(pathname) || businessRoutes.includes(pathname) || pathname.startsWith('/business/') || !isAuthenticated || !isInTabsRoute;

  const scaleAnim = useRef(new Animated.Value(0)).current;
  const rotationAnim = useRef(new Animated.Value(0)).current;

  const actionButtons = [
    {
      icon: FileText,
      label: 'السجل',
      color: '#06b6d4',
      route: '/(tabs)/history',
    },
    {
      icon: ShoppingCart,
      label: 'السلة',
      color: '#10b981',
      route: '/cart',
      badge: cartCount > 0 ? cartCount : null,
    },
  ];

  useEffect(() => {
    checkAuthentication();
    loadCartCount();

    const subscription = supabase
      .channel('cart_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'cart_items',
        },
        () => {
          loadCartCount();
        }
      )
      .subscribe();

    const authListener = supabase.auth.onAuthStateChange((event, session) => {
      setIsAuthenticated(!!session);
    });

    return () => {
      subscription.unsubscribe();
      authListener.data.subscription.unsubscribe();
    };
  }, []);

  async function checkAuthentication() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      setIsAuthenticated(!!user);
    } catch (error) {
      setIsAuthenticated(false);
    }
  }

  async function loadCartCount() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { count } = await supabase
        .from('cart_items')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id);

      setCartCount(count || 0);
    } catch (error) {
      console.error('Error loading cart count:', error);
    }
  }

  useEffect(() => {
    if (isOpen) {
      Animated.parallel([
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 8,
          tension: 40,
          useNativeDriver: true,
        }),
        Animated.timing(rotationAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(scaleAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(rotationAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [isOpen]);

  const rotation = rotationAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '45deg'],
  });

  function toggleMenu() {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    setIsOpen(!isOpen);
  }

  function handleActionPress(route: string) {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setIsOpen(false);
    router.push(route as any);
  }

  if (shouldHideFAB) return null;

  return (
    <>
      {isOpen && (
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setIsOpen(false)}
        >
          <BlurView intensity={20} style={StyleSheet.absoluteFill} tint="dark" />
        </Pressable>
      )}

      <View style={styles.container} pointerEvents="box-none">
        {actionButtons.map((button, index) => {
          const IconComponent = button.icon;
          const translateY = scaleAnim.interpolate({
            inputRange: [0, 1],
            outputRange: [0, -(index + 1) * 70],
          });

          return (
            <Animated.View
              key={button.label}
              style={[
                styles.actionButton,
                {
                  transform: [{ translateY }, { scale: scaleAnim }],
                  opacity: scaleAnim,
                },
              ]}
            >
              <TouchableOpacity
                style={[styles.actionButtonInner, { backgroundColor: button.color }]}
                onPress={() => handleActionPress(button.route)}
                activeOpacity={0.8}
              >
                <IconComponent size={24} color="#ffffff" strokeWidth={2} />
                {button.badge && (
                  <View style={styles.badge}>
                    <Text style={styles.badgeText}>
                      {button.badge}
                    </Text>
                  </View>
                )}
              </TouchableOpacity>
            </Animated.View>
          );
        })}

        <TouchableOpacity
          style={[
            styles.fab,
            isOpen ? styles.fabActive : styles.fabInactive,
          ]}
          onPress={toggleMenu}
          activeOpacity={0.9}
        >
          <Animated.View style={{ transform: [{ rotate: rotation }] }}>
            <View style={styles.fabIconContainer}>
              <View style={styles.fabIcon}>
                <View style={styles.fabIconLine} />
                <View style={[styles.fabIconLine, styles.fabIconLineVertical]} />
              </View>
            </View>
          </Animated.View>
        </TouchableOpacity>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    right: 20,
    top: '50%',
    marginTop: -32,
    alignItems: 'center',
    zIndex: 999,
  },
  modalOverlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 998,
  },
  fab: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#0ea5e9',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    zIndex: 1000,
  },
  fabInactive: {
    opacity: 0.5,
  },
  fabActive: {
    opacity: 1,
    backgroundColor: '#0284c7',
  },
  fabIconContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  fabIcon: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  fabIconLine: {
    width: 20,
    height: 3,
    backgroundColor: '#ffffff',
    borderRadius: 2,
  },
  fabIconLineVertical: {
    position: 'absolute',
    transform: [{ rotate: '90deg' }],
  },
  actionButton: {
    position: 'absolute',
    bottom: 0,
    alignItems: 'center',
    zIndex: 1001,
  },
  actionButtonInner: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#ef4444',
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#ffffff',
  },
  badgeInner: {
    paddingHorizontal: 6,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
