import { View, Text, StyleSheet } from 'react-native';
import { Construction } from 'lucide-react-native';

interface Props {
  title: string;
  description?: string;
}

export default function UnderDevelopmentOwner({ title, description }: Props) {
  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        <Construction size={64} color="#f59e0b" strokeWidth={2} />
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>قيد التطوير</Text>
      {description && <Text style={styles.description}>{description}</Text>}
      <View style={styles.badge}>
        <Text style={styles.badgeText}>قريباً</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    padding: 20,
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#fef3c7',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'center',
  },
  message: {
    fontSize: 18,
    color: '#64748b',
    marginBottom: 8,
    textAlign: 'center',
  },
  description: {
    fontSize: 14,
    color: '#94a3b8',
    marginBottom: 20,
    textAlign: 'center',
    lineHeight: 20,
  },
  badge: {
    backgroundColor: '#f59e0b',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  badgeText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
});
