import React, { useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, ViewStyle } from 'react-native';
import { getBrandSettings, getDefaultBrandSettings, BrandSettings } from '@/lib/brand-utils';
import { Shield } from 'lucide-react-native';

interface BrandLogoProps {
  size?: 'small' | 'medium' | 'large';
  showText?: boolean;
  showTagline?: boolean;
  language?: 'ar' | 'en';
  style?: ViewStyle;
  color?: string;
}

export default function BrandLogo({
  size = 'medium',
  showText = true,
  showTagline = false,
  language = 'ar',
  style,
  color = '#0ea5e9',
}: BrandLogoProps) {
  const [brandSettings, setBrandSettings] = useState<BrandSettings>(getDefaultBrandSettings());

  useEffect(() => {
    loadBrandSettings();
  }, []);

  async function loadBrandSettings() {
    const settings = await getBrandSettings();
    if (settings) {
      setBrandSettings(settings);
    }
  }

  const sizes = {
    small: { icon: 40, text: 16, tagline: 12 },
    medium: { icon: 60, text: 24, tagline: 14 },
    large: { icon: 100, text: 32, tagline: 16 },
  };

  const currentSize = sizes[size];

  return (
    <View style={[styles.container, style]}>
      <View style={[styles.iconContainer, { width: currentSize.icon, height: currentSize.icon }]}>
        <Shield size={currentSize.icon * 0.8} color={color} strokeWidth={2} />
        <View style={styles.heartbeat}>
          <Text style={[styles.heartbeatLine, { color }]}>━━━━</Text>
        </View>
      </View>

      {showText && (
        <View style={styles.textContainer}>
          <Text style={[styles.appName, { fontSize: currentSize.text, color: '#1e293b' }]}>
            {language === 'ar' ? brandSettings.name_ar : brandSettings.name_en}
          </Text>
          {showTagline && (
            <Text style={[styles.tagline, { fontSize: currentSize.tagline, color: '#64748b' }]}>
              {language === 'ar' ? brandSettings.tagline_ar : brandSettings.tagline_en}
            </Text>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  heartbeat: {
    position: 'absolute',
    bottom: '20%',
  },
  heartbeatLine: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  textContainer: {
    marginTop: 12,
    alignItems: 'center',
  },
  appName: {
    fontWeight: 'bold',
    textAlign: 'center',
  },
  tagline: {
    marginTop: 4,
    textAlign: 'center',
  },
});
