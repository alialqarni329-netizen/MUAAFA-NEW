import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { ShieldOff, ArrowLeft } from 'lucide-react-native';
import { usePermissions, hasPermission } from '@/lib/rbac/usePermissions';
import { Permission } from '@/lib/rbac/permissions';
import { ReactNode } from 'react';

interface ProtectedRouteProps {
  children: ReactNode;
  requiredPermission?: Permission | Permission[];
  businessId?: string;
  fallback?: ReactNode;
}

export function ProtectedRoute({
  children,
  requiredPermission,
  businessId,
  fallback
}: ProtectedRouteProps) {
  const router = useRouter();
  const { permissions, isOwner, loading } = usePermissions(businessId);

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#6366f1" />
        <Text style={styles.loadingText}>جارٍ التحقق من الصلاحيات...</Text>
      </View>
    );
  }

  if (requiredPermission) {
    const hasAccess = hasPermission(permissions, isOwner, requiredPermission);

    if (!hasAccess) {
      if (fallback) {
        return <>{fallback}</>;
      }

      return (
        <View style={styles.container}>
          <View style={styles.content}>
            <View style={styles.iconContainer}>
              <ShieldOff size={64} color="#ef4444" strokeWidth={2} />
            </View>
            <Text style={styles.title}>غير مصرح لك</Text>
            <Text style={styles.message}>
              ليس لديك الصلاحيات الكافية{'\n'}للوصول إلى هذه الصفحة
            </Text>
            <Text style={styles.hint}>
              يرجى الاتصال بمدير المنشأة{'\n'}لطلب الصلاحيات المطلوبة
            </Text>
            <TouchableOpacity
              style={styles.button}
              onPress={() => router.back()}>
              <ArrowLeft size={20} color="#ffffff" strokeWidth={2} />
              <Text style={styles.buttonText}>العودة</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }
  }

  return <>{children}</>;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
    marginTop: 16,
  },
  content: {
    alignItems: 'center',
    maxWidth: 400,
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#fee2e2',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 12,
    textAlign: 'center',
  },
  message: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 16,
  },
  hint: {
    fontSize: 14,
    color: '#94a3b8',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 32,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#6366f1',
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
