import { View, Text, StyleSheet, TouchableOpacity, Modal } from 'react-native';
import { useState } from 'react';
import { Check, X } from 'lucide-react-native';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export function LanguageSelector() {
  const { language, setLanguage, t } = useLanguage();
  const [modalVisible, setModalVisible] = useState(false);

  const languages = [
    { code: 'ar' as const, name: 'العربية', nativeName: 'العربية' },
    { code: 'en' as const, name: 'English', nativeName: 'English' },
  ];

  function handleSelectLanguage(lang: 'ar' | 'en') {
    setLanguage(lang);
    setModalVisible(false);
  }

  return (
    <>
      <TouchableOpacity style={styles.button} onPress={() => setModalVisible(true)}>
        <Text style={styles.buttonText}>
          {language === 'ar' ? 'العربية' : 'English'}
        </Text>
      </TouchableOpacity>

      <Modal
        visible={modalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <X size={24} color="#64748b" strokeWidth={2} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>{t('settings.language')}</Text>
              <View style={{ width: 24 }} />
            </View>

            <View style={styles.languagesList}>
              {languages.map((lang) => (
                <TouchableOpacity
                  key={lang.code}
                  style={[
                    styles.languageItem,
                    language === lang.code && styles.languageItemActive,
                  ]}
                  onPress={() => handleSelectLanguage(lang.code)}>
                  <Text style={styles.languageName}>{lang.nativeName}</Text>
                  {language === lang.code && (
                    <Check size={24} color="#0ea5e9" strokeWidth={2} />
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    color: '#0f172a',
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    width: '100%',
    maxWidth: 400,
    padding: 24,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  languagesList: {
    gap: 12,
  },
  languageItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  languageItemActive: {
    backgroundColor: '#e0f2fe',
    borderColor: '#0ea5e9',
  },
  languageName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#0f172a',
  },
});
