import { View, Text, StyleSheet, TouchableOpacity, Animated } from 'react-native';
import { useState, useEffect, useRef } from 'react';
import { useRouter, usePathname } from 'expo-router';
import { ShoppingCart } from 'lucide-react-native';
import { getCartCount } from '@/lib/cart-utils';

export function FloatingCartButton() {
  const router = useRouter();
  const pathname = usePathname();
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const [isVisible, setIsVisible] = useState(true);
  const [itemCount, setItemCount] = useState(0);

  useEffect(() => {
    const hiddenPaths = ['/auth/', '/admin/', '/business/'];
    const shouldHide = hiddenPaths.some(path => pathname?.includes(path));
    setIsVisible(!shouldHide);
  }, [pathname]);

  useEffect(() => {
    loadCartCount();
    const interval = setInterval(loadCartCount, 2000);
    return () => clearInterval(interval);
  }, []);

  async function loadCartCount() {
    const count = await getCartCount();
    setItemCount(count);
  }

  useEffect(() => {
    if (itemCount > 0) {
      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 1.2,
          duration: 150,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 150,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [itemCount]);

  if (!isVisible) {
    return null;
  }

  return (
    <Animated.View
      style={[
        styles.container,
        {
          transform: [{ scale: scaleAnim }],
        },
      ]}>
      <TouchableOpacity
        style={styles.button}
        onPress={() => router.push('/cart')}
        activeOpacity={0.8}>
        <ShoppingCart size={24} color="#ffffff" strokeWidth={2} />
        {itemCount > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{itemCount > 99 ? '99+' : itemCount}</Text>
          </View>
        )}
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 85,
    right: 20,
    zIndex: 1000,
    elevation: 8,
  },
  button: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#10b981',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#10b981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#ef4444',
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 6,
    borderWidth: 2,
    borderColor: '#ffffff',
  },
  badgeText: {
    color: '#ffffff',
    fontSize: 11,
    fontWeight: 'bold',
  },
});
