import { supabase } from './supabase';

export interface AdminUser {
  id: string;
  role: 'owner' | 'admin' | 'moderator';
  permissions?: string[];
  created_at: string;
}

export async function checkIsAdmin(userId: string): Promise<AdminUser | null> {
  try {
    const { data, error } = await supabase
      .from('admin_users')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) {
      console.error('Error checking admin status:', error);
      return null;
    }

    return data;
  } catch (error) {
    console.error('Error in checkIsAdmin:', error);
    return null;
  }
}

export async function getCurrentAdminUser(): Promise<AdminUser | null> {
  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return null;
    }

    return await checkIsAdmin(user.id);
  } catch (error) {
    console.error('Error getting current admin user:', error);
    return null;
  }
}

export function hasPermission(adminUser: AdminUser | null, permission: string): boolean {
  if (!adminUser) return false;

  if (adminUser.role === 'owner') return true;

  if (!adminUser.permissions || adminUser.permissions.length === 0) return false;

  if (adminUser.permissions.includes('all')) return true;

  return adminUser.permissions.includes(permission);
}

export function isOwner(adminUser: AdminUser | null): boolean {
  return adminUser?.role === 'owner';
}

export async function getUsersStats() {
  try {
    const { count: totalUsers } = await supabase
      .from('users')
      .select('*', { count: 'exact', head: true });

    const { count: activeSubscriptions } = await supabase
      .from('subscriptions')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'active');

    const { count: completedSessions } = await supabase
      .from('sessions')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'completed');

    const { count: totalRecordings } = await supabase
      .from('session_recordings')
      .select('*', { count: 'exact', head: true });

    return {
      totalUsers: totalUsers || 0,
      activeSubscriptions: activeSubscriptions || 0,
      completedSessions: completedSessions || 0,
      totalRecordings: totalRecordings || 0,
    };
  } catch (error) {
    console.error('Error fetching stats:', error);
    return {
      totalUsers: 0,
      activeSubscriptions: 0,
      completedSessions: 0,
      totalRecordings: 0,
    };
  }
}

export async function getAllUsers(page = 0, limit = 20) {
  try {
    const from = page * limit;
    const to = from + limit - 1;

    const { data, error, count } = await supabase
      .from('users')
      .select('*, subscriptions(*)', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) throw error;

    return { users: data || [], total: count || 0 };
  } catch (error) {
    console.error('Error fetching users:', error);
    return { users: [], total: 0 };
  }
}

export async function getAllSessions(page = 0, limit = 20) {
  try {
    const from = page * limit;
    const to = from + limit - 1;

    const { data, error, count } = await supabase
      .from('sessions')
      .select('*, users(*)', { count: 'exact' })
      .order('scheduled_date', { ascending: false })
      .range(from, to);

    if (error) throw error;

    return { sessions: data || [], total: count || 0 };
  } catch (error) {
    console.error('Error fetching sessions:', error);
    return { sessions: [], total: 0 };
  }
}

export async function getRecentActivity(limit = 10) {
  try {
    const { data: recentUsers } = await supabase
      .from('users')
      .select('full_name, created_at')
      .order('created_at', { ascending: false })
      .limit(limit);

    const { data: recentSessions } = await supabase
      .from('sessions')
      .select('*, users(full_name)')
      .order('created_at', { ascending: false })
      .limit(limit);

    return {
      recentUsers: recentUsers || [],
      recentSessions: recentSessions || [],
    };
  } catch (error) {
    console.error('Error fetching recent activity:', error);
    return {
      recentUsers: [],
      recentSessions: [],
    };
  }
}
