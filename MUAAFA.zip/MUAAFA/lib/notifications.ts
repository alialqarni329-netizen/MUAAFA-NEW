import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { supabase } from './supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export interface NotificationPermissions {
  granted: boolean;
  canAskAgain: boolean;
}

export async function requestNotificationPermissions(): Promise<NotificationPermissions> {
  try {
    if (Platform.OS === 'web') {
      return { granted: false, canAskAgain: false };
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      return { granted: false, canAskAgain: existingStatus === 'denied' };
    }

    const token = await Notifications.getExpoPushTokenAsync({
      projectId: 'your-project-id',
    });

    await saveNotificationToken(token.data);

    return { granted: true, canAskAgain: false };
  } catch (error) {
    console.error('Error requesting notification permissions:', error);
    return { granted: false, canAskAgain: true };
  }
}

async function saveNotificationToken(token: string) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('user_preferences')
      .upsert({
        user_id: user.id,
        notification_token: token,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id' });
  } catch (error) {
    console.error('Error saving notification token:', error);
  }
}

export async function scheduleMedicationReminder(
  medicationName: string,
  time: Date,
  reminderId: string
): Promise<string | null> {
  try {
    if (Platform.OS === 'web') {
      return null;
    }

    const trigger: Notifications.CalendarTriggerInput = {
      type: Notifications.SchedulableTriggerInputTypes.CALENDAR,
      hour: time.getHours(),
      minute: time.getMinutes(),
      repeats: true,
    };

    const notificationId = await Notifications.scheduleNotificationAsync({
      content: {
        title: 'تذكير بالدواء 💊',
        body: `حان موعد تناول دواء ${medicationName}`,
        sound: true,
        priority: Notifications.AndroidNotificationPriority.HIGH,
        data: { reminderId, type: 'medication' },
      },
      trigger,
    });

    return notificationId;
  } catch (error) {
    console.error('Error scheduling medication reminder:', error);
    return null;
  }
}

export async function scheduleAppointmentReminder(
  doctorName: string,
  appointmentDate: Date,
  appointmentId: string
): Promise<string | null> {
  try {
    if (Platform.OS === 'web') {
      return null;
    }

    const reminderTime = new Date(appointmentDate);
    reminderTime.setHours(reminderTime.getHours() - 1);

    if (reminderTime.getTime() <= Date.now()) {
      console.log('Reminder time is in the past, skipping notification');
      return null;
    }

    const { status } = await Notifications.getPermissionsAsync();
    if (status !== 'granted') {
      console.log('Notification permissions not granted, skipping');
      return null;
    }

    const trigger: Notifications.DateTriggerInput = {
      type: Notifications.SchedulableTriggerInputTypes.DATE,
      date: reminderTime,
    };

    const notificationId = await Notifications.scheduleNotificationAsync({
      content: {
        title: 'تذكير بموعد طبي 👨‍⚕️',
        body: `موعدك مع ${doctorName} بعد ساعة واحدة`,
        sound: true,
        priority: Notifications.AndroidNotificationPriority.HIGH,
        data: { appointmentId, type: 'appointment' },
      },
      trigger,
    });

    return notificationId;
  } catch (error) {
    return null;
  }
}

export async function cancelNotification(notificationId: string): Promise<boolean> {
  try {
    if (Platform.OS === 'web') {
      return false;
    }

    await Notifications.cancelScheduledNotificationAsync(notificationId);
    return true;
  } catch (error) {
    console.error('Error canceling notification:', error);
    return false;
  }
}

export async function cancelAllNotifications(): Promise<boolean> {
  try {
    if (Platform.OS === 'web') {
      return false;
    }

    await Notifications.cancelAllScheduledNotificationsAsync();
    return true;
  } catch (error) {
    console.error('Error canceling all notifications:', error);
    return false;
  }
}

export async function getAllScheduledNotifications() {
  try {
    if (Platform.OS === 'web') {
      return [];
    }

    const notifications = await Notifications.getAllScheduledNotificationsAsync();
    return notifications;
  } catch (error) {
    console.error('Error getting scheduled notifications:', error);
    return [];
  }
}

export async function logNotification(
  userId: string,
  type: string,
  title: string,
  body: string,
  metadata?: any
) {
  try {
    await supabase.from('notification_logs').insert({
      user_id: userId,
      notification_type: type,
      title,
      body,
      metadata: metadata || {},
      is_read: false,
    });
  } catch (error) {
    console.error('Error logging notification:', error);
  }
}

export async function sendLocalNotification(
  title: string,
  body: string,
  data?: any
): Promise<void> {
  try {
    if (Platform.OS === 'web') {
      return;
    }

    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: true,
        data: data || {},
      },
      trigger: null,
    });
  } catch (error) {
    console.error('Error sending local notification:', error);
  }
}

export function setupNotificationListener(
  onNotificationReceived: (notification: Notifications.Notification) => void,
  onNotificationResponse: (response: Notifications.NotificationResponse) => void
) {
  if (Platform.OS === 'web') {
    return { remove: () => {} };
  }

  const subscription = Notifications.addNotificationReceivedListener(onNotificationReceived);
  const responseSubscription = Notifications.addNotificationResponseReceivedListener(onNotificationResponse);

  return {
    remove: () => {
      subscription.remove();
      responseSubscription.remove();
    },
  };
}
