import React, { createContext, useContext, useState, useEffect } from 'react';
import { I18nManager } from 'react-native';
import { translations, Language } from './translations';
import { supabase } from '../supabase';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>('ar');
  const isRTL = language === 'ar';

  useEffect(() => {
    loadLanguage();
  }, []);

  async function loadLanguage() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from('users')
        .select('language')
        .eq('id', user.id)
        .maybeSingle();

      if (data?.language) {
        setLanguageState(data.language as Language);
      }
    }
  }

  async function setLanguage(lang: Language) {
    setLanguageState(lang);

    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      await supabase.from('users').update({ language: lang }).eq('id', user.id);
    }

    if (lang === 'ar') {
      I18nManager.forceRTL(true);
    } else {
      I18nManager.forceRTL(false);
    }
  }

  function t(key: string): string {
    const keys = key.split('.');
    let value: any = translations[language];

    for (const k of keys) {
      value = value?.[k];
      if (value === undefined) {
        return key;
      }
    }

    return typeof value === 'string' ? value : key;
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
