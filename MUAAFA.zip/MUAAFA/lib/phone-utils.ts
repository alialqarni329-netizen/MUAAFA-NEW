export function formatPhoneToE164(phone: string): string {
  let cleaned = phone.replace(/\D/g, '');

  if (cleaned.startsWith('966')) {
    return `+${cleaned}`;
  }

  if (cleaned.startsWith('0')) {
    cleaned = cleaned.substring(1);
  }

  if (cleaned.startsWith('5') && cleaned.length === 9) {
    return `+966${cleaned}`;
  }

  throw new Error('رقم الهاتف غير صحيح. يجب أن يبدأ بـ 05 ويتكون من 10 أرقام');
}

export function validateSaudiPhone(phone: string): boolean {
  const cleaned = phone.replace(/\D/g, '');

  if (cleaned.startsWith('966')) {
    return cleaned.length === 12 && cleaned[3] === '5';
  }

  if (cleaned.startsWith('05')) {
    return cleaned.length === 10;
  }

  if (cleaned.startsWith('5')) {
    return cleaned.length === 9;
  }

  return false;
}

interface RateLimitEntry {
  count: number;
  firstAttempt: number;
  lastAttempt: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

export function checkOTPRateLimit(phone: string): { allowed: boolean; waitTime?: number } {
  const MAX_ATTEMPTS = 3;
  const WINDOW_MS = 15 * 60 * 1000;
  const now = Date.now();

  const entry = rateLimitStore.get(phone);

  if (!entry) {
    rateLimitStore.set(phone, {
      count: 1,
      firstAttempt: now,
      lastAttempt: now,
    });
    return { allowed: true };
  }

  const timeElapsed = now - entry.firstAttempt;

  if (timeElapsed > WINDOW_MS) {
    rateLimitStore.set(phone, {
      count: 1,
      firstAttempt: now,
      lastAttempt: now,
    });
    return { allowed: true };
  }

  if (entry.count >= MAX_ATTEMPTS) {
    const waitTime = Math.ceil((WINDOW_MS - timeElapsed) / 1000 / 60);
    return { allowed: false, waitTime };
  }

  entry.count++;
  entry.lastAttempt = now;
  rateLimitStore.set(phone, entry);

  return { allowed: true };
}

export function formatPhoneDisplay(phone: string): string {
  if (phone.startsWith('+966')) {
    const number = phone.substring(4);
    return `+966 ${number.substring(0, 2)} ${number.substring(2, 5)} ${number.substring(5)}`;
  }
  return phone;
}
