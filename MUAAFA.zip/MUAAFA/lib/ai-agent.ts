import { supabase } from './supabase';

const AI_WEBHOOK_URL = 'https://moodi-app.app.n8n.cloud/webhook/8b384f8b-fd82-415c-8566-3e7270f2a1ab/chat';
const IMAGE_ANALYSIS_URL = 'https://moodi-app.app.n8n.cloud/webhook/analyze-image';

export interface AIResponse {
  text: string;
  action?: 'book_session' | 'analyze_image' | 'view_plans' | 'start_trial' | 'cancel_subscription' | 'pharmacy_search' | 'pharmacy_list' | 'upload_prescription' | 'track_order' | 'none';
  sessionData?: {
    doctorId?: string;
    sessionType: 'video' | 'chat';
    date?: string;
    time?: string;
  };
  imageAnalysis?: {
    findings: string;
    recommendations: string;
    urgency: 'low' | 'medium' | 'high';
  };
  subscriptionData?: {
    planId?: string;
    planName?: string;
  };
  pharmacyData?: {
    medicationName?: string;
    pharmacyId?: string;
    orderId?: string;
  };
}

export async function sendMessageToAI(
  message: string,
  userId: string,
  conversationHistory?: any[]
): Promise<AIResponse> {
  try {
    const intent = detectIntent(message);

    if (intent.type !== 'general') {
      return await handleIntent(intent, userId, message);
    }

    const response = await fetch(AI_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chatInput: message,
        sessionId: userId,
        history: conversationHistory || [],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Failed to get AI response');
    }

    let aiText = '';
    if (data.output) aiText = data.output;
    else if (data.text) aiText = data.text;
    else if (data.message) aiText = data.message;
    else if (typeof data === 'string') aiText = data;

    return {
      text: aiText,
      action: data.action || 'none',
      sessionData: data.sessionData,
      imageAnalysis: data.imageAnalysis,
    };
  } catch (error: any) {
    console.error('Error sending message to AI:', error);
    throw error;
  }
}

function detectIntent(message: string): { type: string; data?: any } {
  const msg = message.toLowerCase();

  if (msg.includes('باقات') || msg.includes('اشتراك') || msg.includes('الخطط') || msg.includes('وش الخطط')) {
    return { type: 'view_plans' };
  }

  if (msg.includes('تجربة مجانية') || msg.includes('جرب البريميوم') || msg.includes('ابدأ تجربة')) {
    return { type: 'start_trial' };
  }

  if (msg.includes('الغِ التجربة') || msg.includes('أوقف التجديد') || msg.includes('الغاء الاشتراك')) {
    return { type: 'cancel_subscription' };
  }

  if (msg.includes('صيدليات') || msg.includes('صيدلية') || msg.includes('أقرب صيدلية')) {
    return { type: 'pharmacy_list' };
  }

  if (msg.includes('متوفر') || msg.includes('ابحث عن') || msg.includes('دواء')) {
    const medicationMatch = msg.match(/(?:متوفر|ابحث عن)\s+(\w+)/);
    return {
      type: 'pharmacy_search',
      data: { medication: medicationMatch ? medicationMatch[1] : '' }
    };
  }

  if (msg.includes('ارفع وصفت') || msg.includes('ابعت صورة الوصفة')) {
    return { type: 'upload_prescription' };
  }

  if (msg.includes('تتبع طلبي') || msg.includes('فين طلبي')) {
    const orderMatch = msg.match(/(?:طلبي|طلب)\s+(\w+)/);
    return {
      type: 'track_order',
      data: { orderId: orderMatch ? orderMatch[1] : '' }
    };
  }

  return { type: 'general' };
}

async function handleIntent(intent: { type: string; data?: any }, userId: string, originalMessage: string): Promise<AIResponse> {
  switch (intent.type) {
    case 'view_plans':
      return await handleViewPlans();

    case 'start_trial':
      return await handleStartTrial(userId);

    case 'cancel_subscription':
      return await handleCancelSubscription(userId);

    case 'pharmacy_list':
      return await handlePharmacyList();

    case 'pharmacy_search':
      return await handlePharmacySearch(intent.data?.medication);

    case 'upload_prescription':
      return handleUploadPrescription();

    case 'track_order':
      return await handleTrackOrder(userId, intent.data?.orderId);

    default:
      return {
        text: 'عذراً، لم أفهم طلبك. هل يمكنك إعادة صياغته؟',
        action: 'none',
      };
  }
}

async function handleViewPlans(): Promise<AIResponse> {
  try {
    const { data: plans, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('is_active', true)
      .order('price_monthly', { ascending: true });

    if (error) throw error;

    let response = 'هذي الباقات المتاحة:\n\n';

    plans?.forEach(plan => {
      response += `📦 ${plan.name}\n`;
      response += `   السعر: ${plan.price_monthly} ريال/شهر\n`;
      response += `   ${plan.description}\n\n`;
    });

    response += 'تقدر تبدأ تجربة مجانية 7 أيام أو تشترك مباشرة!';

    return {
      text: response,
      action: 'view_plans',
    };
  } catch (error) {
    console.error('Error fetching plans:', error);
    return {
      text: 'تعذر جلب الباقات الآن. حاول مرة ثانية.',
      action: 'none',
    };
  }
}

async function handleStartTrial(userId: string): Promise<AIResponse> {
  try {
    const { data: existingSub } = await supabase
      .from('user_subscriptions')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (existingSub) {
      return {
        text: 'عندك اشتراك فعّال! ما تقدر تبدأ تجربة مجانية ثانية.',
        action: 'none',
      };
    }

    const { data: plans } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('name', 'Premium')
      .single();

    if (!plans) {
      return {
        text: 'ما لقينا باقة Premium. تواصل مع الدعم.',
        action: 'none',
      };
    }

    const trialExpiresAt = new Date();
    trialExpiresAt.setDate(trialExpiresAt.getDate() + 7);

    const { error } = await supabase.from('user_subscriptions').insert({
      user_id: userId,
      plan_id: plans.id,
      status: 'trial',
      billing_period: 'monthly',
      trial_expires_at: trialExpiresAt.toISOString(),
      current_period_end: trialExpiresAt.toISOString(),
    });

    if (error) throw error;

    return {
      text: `تم تفعيل تجربة مجانية لباقة ${plans.name}. ما راح نسحب شي إلا بعد انتهاء الفترة (7 أيام).`,
      action: 'start_trial',
      subscriptionData: {
        planId: plans.id,
        planName: plans.name,
      },
    };
  } catch (error) {
    console.error('Error starting trial:', error);
    return {
      text: 'فشل تفعيل التجربة. تأكد من بيانات البطاقة أو حاول لاحقاً.',
      action: 'none',
    };
  }
}

async function handleCancelSubscription(userId: string): Promise<AIResponse> {
  try {
    const { data: sub, error: fetchError } = await supabase
      .from('user_subscriptions')
      .select('*, subscription_plans(*)')
      .eq('user_id', userId)
      .eq('status', 'active')
      .single();

    if (fetchError || !sub) {
      return {
        text: 'ما عندك اشتراك فعّال.',
        action: 'none',
      };
    }

    const { error: updateError } = await supabase
      .from('user_subscriptions')
      .update({
        cancel_at_period_end: true,
        updated_at: new Date().toISOString(),
      })
      .eq('id', sub.id);

    if (updateError) throw updateError;

    const expiryDate = new Date(sub.current_period_end).toLocaleDateString('ar-SA');

    return {
      text: `تم إلغاء التجديد. اشتراكك ينتهي بتاريخ ${expiryDate}.`,
      action: 'cancel_subscription',
    };
  } catch (error) {
    console.error('Error canceling subscription:', error);
    return {
      text: 'ما قدرنا نلغي الاشتراك الآن. جرّب لاحقاً.',
      action: 'none',
    };
  }
}

async function handlePharmacyList(): Promise<AIResponse> {
  try {
    const { data: pharmacies, error } = await supabase
      .from('pharmacies')
      .select('*')
      .eq('is_active', true)
      .order('rating', { ascending: false })
      .limit(10);

    if (error) throw error;

    let response = 'هذي أقرب الصيدليات:\n\n';

    pharmacies?.forEach((pharmacy, index) => {
      response += `${index + 1}. ${pharmacy.name}\n`;
      response += `   📍 ${pharmacy.address}\n`;
      response += `   ⭐ ${pharmacy.rating}/5\n`;
      if (pharmacy.is_24_hours) response += `   ⏰ 24 ساعة\n`;
      if (pharmacy.has_instant_delivery) response += `   🚚 توصيل فوري\n`;
      response += '\n';
    });

    response += 'تبي أرتبها حسب السعر أو التوصيل؟';

    return {
      text: response,
      action: 'pharmacy_list',
    };
  } catch (error) {
    console.error('Error fetching pharmacies:', error);
    return {
      text: 'مشكلة بالوصول للموقع. عطنا مدينتك أو اسم الحي.',
      action: 'none',
    };
  }
}

async function handlePharmacySearch(medicationName?: string): Promise<AIResponse> {
  if (!medicationName) {
    return {
      text: 'أي دواء تبحث عنه؟',
      action: 'pharmacy_search',
    };
  }

  try {
    const { data: medications, error } = await supabase
      .from('medications')
      .select(`
        *,
        pharmacy_inventory (
          pharmacy_id,
          price,
          stock_quantity,
          pharmacies (name, address)
        )
      `)
      .ilike('name', `%${medicationName}%`)
      .limit(5);

    if (error) throw error;

    if (!medications || medications.length === 0) {
      return {
        text: `الدواء "${medicationName}" غير متوفر حاليا — ابغى اشعار لو توفر؟`,
        action: 'pharmacy_search',
      };
    }

    let response = `نتائج البحث عن "${medicationName}":\n\n`;

    medications.forEach((med: any) => {
      response += `💊 ${med.name}\n`;
      if (med.pharmacy_inventory && med.pharmacy_inventory.length > 0) {
        const inventory = med.pharmacy_inventory[0];
        response += `   متوفر في: ${inventory.pharmacies?.name}\n`;
        response += `   السعر: ${inventory.price} ريال\n`;
      }
      response += '\n';
    });

    return {
      text: response,
      action: 'pharmacy_search',
      pharmacyData: { medicationName },
    };
  } catch (error) {
    console.error('Error searching medication:', error);
    return {
      text: 'حصل خطأ في البحث. حاول مرة ثانية.',
      action: 'none',
    };
  }
}

function handleUploadPrescription(): AIResponse {
  return {
    text: 'تقدر ترفع وصفتك من قسم "الصيدلية" → "رفع وصفة". ارفع صورة واضحة للوصفة وبنراجعها خلال دقائق.',
    action: 'upload_prescription',
  };
}

async function handleTrackOrder(userId: string, orderId?: string): Promise<AIResponse> {
  try {
    if (!orderId) {
      const { data: orders, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1);

      if (error || !orders || orders.length === 0) {
        return {
          text: 'ما لقيت طلبات حديثة.',
          action: 'none',
        };
      }

      orderId = orders[0].id;
    }

    const { data: order, error } = await supabase
      .from('orders')
      .select('*, pharmacies(*)')
      .eq('id', orderId)
      .eq('user_id', userId)
      .single();

    if (error || !order) {
      return {
        text: 'ما لقيت الطلب ذا.',
        action: 'none',
      };
    }

    const statusMap: Record<string, string> = {
      pending: 'قيد الانتظار',
      confirmed: 'تم التأكيد',
      preparing: 'جاري التجهيز',
      out_for_delivery: 'في الطريق',
      delivered: 'تم التوصيل',
      cancelled: 'ملغي',
    };
    const statusText = statusMap[order.status] || order.status;

    let response = `حالة الطلب #${order.id.substring(0, 8)}:\n\n`;
    response += `📦 الحالة: ${statusText}\n`;
    response += `🏪 الصيدلية: ${order.pharmacies?.name}\n`;
    response += `💰 المبلغ: ${order.total_amount} ريال\n`;

    if (order.estimated_delivery_time) {
      const eta = new Date(order.estimated_delivery_time).toLocaleString('ar-SA');
      response += `⏰ الوصول المتوقع: ${eta}\n`;
    }

    return {
      text: response,
      action: 'track_order',
      pharmacyData: { orderId: order.id },
    };
  } catch (error) {
    console.error('Error tracking order:', error);
    return {
      text: 'حصل خطأ في تتبع الطلب.',
      action: 'none',
    };
  }
}

export async function analyzeImage(
  imageUri: string,
  userId: string,
  additionalContext?: string
): Promise<AIResponse> {
  try {
    const contextMessage = additionalContext
      ? `المستخدم أرفق صورة وقال: "${additionalContext}". يرجى تحليل الصورة وتقديم استشارة طبية مناسبة.`
      : 'المستخدم أرفق صورة. يرجى تحليلها وتقديم استشارة طبية.';

    const { data: imageRecord, error: insertError } = await supabase
      .from('image_analysis')
      .insert({
        user_id: userId,
        image_url: imageUri.substring(0, 100),
        body_part: additionalContext || 'صورة طبية',
      })
      .select()
      .single();

    if (insertError) {
      console.error('Error saving image record:', insertError);
    }

    const response = await fetch(AI_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chatInput: contextMessage,
        sessionId: userId,
        imageUri: imageUri,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Failed to analyze image');
    }

    let aiText = '';
    if (data.output) aiText = data.output;
    else if (data.text) aiText = data.text;
    else if (data.message) aiText = data.message;
    else if (typeof data === 'string') aiText = data;
    else aiText = 'تم استلام الصورة. من فضلك صف الأعراض أو المشكلة التي تعاني منها لأتمكن من مساعدتك بشكل أفضل.';

    if (imageRecord && aiText) {
      await supabase
        .from('image_analysis')
        .update({
          analysis_result: aiText,
        })
        .eq('id', imageRecord.id);
    }

    return {
      text: aiText,
      action: 'analyze_image',
      imageAnalysis: {
        findings: aiText,
        recommendations: aiText,
        urgency: 'low',
      },
    };
  } catch (error: any) {
    console.error('Error analyzing image:', error);
    throw error;
  }
}

export async function bookSessionViaAI(
  userId: string,
  sessionData: {
    sessionType: 'video' | 'chat';
    preferredDate?: string;
    preferredTime?: string;
    notes?: string;
  }
): Promise<any> {
  try {
    const { data: doctors } = await supabase
      .from('doctors')
      .select('*')
      .eq('is_available', true)
      .limit(1);

    if (!doctors || doctors.length === 0) {
      throw new Error('لا يوجد أطباء متاحون حالياً');
    }

    const doctor = doctors[0];

    const scheduledDate = sessionData.preferredDate || new Date().toISOString().split('T')[0];
    const scheduledTime = sessionData.preferredTime || '10:00:00';

    const { data: session, error } = await supabase
      .from('sessions')
      .insert({
        user_id: userId,
        doctor_id: doctor.id,
        session_type: sessionData.sessionType,
        status: 'upcoming',
        scheduled_date: scheduledDate,
        scheduled_time: scheduledTime,
        notes: sessionData.notes || 'جلسة محجوزة عبر المساعد الذكي',
        session_mode: 'scheduled',
      })
      .select()
      .single();

    if (error) {
      console.error('Error booking session:', error);
      throw error;
    }

    return {
      success: true,
      session: session,
      doctor: doctor,
      message: `تم حجز جلسة ${sessionData.sessionType === 'video' ? 'فيديو' : 'نصية'} مع الدكتور ${doctor.full_name} بتاريخ ${scheduledDate} الساعة ${scheduledTime}`,
    };
  } catch (error: any) {
    console.error('Error booking session via AI:', error);
    throw error;
  }
}

export async function getAvailableDoctors() {
  try {
    const { data, error } = await supabase
      .from('doctors')
      .select('*')
      .eq('is_available', true)
      .order('rating', { ascending: false });

    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Error fetching doctors:', error);
    return [];
  }
}

export async function getUserSessions(userId: string, limit = 10) {
  try {
    const { data, error } = await supabase
      .from('sessions')
      .select('*, doctors(*)')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Error fetching user sessions:', error);
    return [];
  }
}
