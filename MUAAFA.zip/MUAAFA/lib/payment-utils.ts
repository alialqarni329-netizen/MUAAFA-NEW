import { supabase } from './supabase';

export interface InsurancePolicy {
  id: string;
  user_id: string;
  policy_number: string;
  provider_name: string;
  coverage_percentage: number;
  coverage_limit?: number;
  start_date: string;
  end_date: string;
  status: 'active' | 'expired' | 'cancelled';
}

export interface PaymentCalculation {
  insuranceCovered: number;
  userPayable: number;
}

export function calculatePayment(
  price: number,
  insuranceCoverage?: number
): PaymentCalculation {
  if (!insuranceCoverage || insuranceCoverage <= 0) {
    return {
      insuranceCovered: 0,
      userPayable: price,
    };
  }

  const coveredAmount = price * (insuranceCoverage / 100);
  return {
    insuranceCovered: Math.round(coveredAmount * 100) / 100,
    userPayable: Math.round((price - coveredAmount) * 100) / 100,
  };
}

export async function getUserActiveInsurance(userId: string): Promise<InsurancePolicy | null> {
  const { data, error } = await supabase
    .from('insurance_policies')
    .select('*')
    .eq('user_id', userId)
    .eq('status', 'active')
    .gte('end_date', new Date().toISOString().split('T')[0])
    .lte('start_date', new Date().toISOString().split('T')[0])
    .maybeSingle();

  if (error) {
    console.error('Error fetching insurance:', error);
    return null;
  }

  return data;
}

export async function createMedicalSession(
  userId: string,
  doctorName: string,
  specialty: string,
  sessionDate: Date,
  price: number,
  insurancePolicyId?: string
) {
  let insuranceCovered = 0;
  let userPayable = price;

  if (insurancePolicyId) {
    const { data: calcResult } = await supabase.rpc('calculate_user_payable', {
      total_price: price,
      insurance_policy_id: insurancePolicyId,
    });

    if (calcResult && calcResult.length > 0) {
      insuranceCovered = calcResult[0].insurance_covered || 0;
      userPayable = calcResult[0].user_payable || price;
    }
  }

  const { data, error } = await supabase
    .from('medical_sessions')
    .insert({
      user_id: userId,
      doctor_name: doctorName,
      specialty: specialty,
      session_date: sessionDate.toISOString(),
      price: price,
      insurance_policy_id: insurancePolicyId || null,
      insurance_covered: insuranceCovered,
      user_payable: userPayable,
      payment_status: 'pending',
      session_status: 'pending',
    })
    .select()
    .single();

  if (error) {
    throw error;
  }

  return data;
}

export async function createPharmacyOrder(
  userId: string,
  pharmacyId: string | null,
  pharmacyName: string,
  items: any[],
  totalPrice: number,
  insurancePolicyId?: string,
  deliveryAddress?: string,
  deliveryNotes?: string
) {
  let insuranceCovered = 0;
  let userPayable = totalPrice;

  if (insurancePolicyId) {
    const { data: calcResult } = await supabase.rpc('calculate_user_payable', {
      total_price: totalPrice,
      insurance_policy_id: insurancePolicyId,
    });

    if (calcResult && calcResult.length > 0) {
      insuranceCovered = calcResult[0].insurance_covered || 0;
      userPayable = calcResult[0].user_payable || totalPrice;
    }
  }

  const { data, error } = await supabase
    .from('pharmacy_orders')
    .insert({
      user_id: userId,
      pharmacy_id: pharmacyId,
      pharmacy_name: pharmacyName,
      items: items,
      total_price: totalPrice,
      insurance_policy_id: insurancePolicyId || null,
      insurance_covered: insuranceCovered,
      user_payable: userPayable,
      payment_status: 'pending',
      order_status: 'pending',
      delivery_address: deliveryAddress || null,
      delivery_notes: deliveryNotes || null,
    })
    .select()
    .single();

  if (error) {
    throw error;
  }

  return data;
}

export async function verifyZedPayPayment(
  transactionId: string,
  amount: number
): Promise<{ verified: boolean; status: string; error?: string }> {
  try {
    const response = await fetch('https://api.zedpay.sa/v1/transactions/verify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.EXPO_PUBLIC_ZEDPAY_API_KEY}`,
      },
      body: JSON.stringify({
        transaction_id: transactionId,
        expected_amount: amount,
      }),
    });

    if (!response.ok) {
      return { verified: false, status: 'error', error: 'فشل التحقق من الدفع' };
    }

    const result = await response.json();

    return {
      verified: result.status === 'paid' && result.amount === amount,
      status: result.status,
    };
  } catch (error) {
    console.error('ZedPay verification error:', error);
    return { verified: false, status: 'error', error: 'خطأ في الاتصال بنظام الدفع' };
  }
}

export async function updatePaymentStatus(
  type: 'medical_session' | 'pharmacy_order',
  id: string,
  status: 'paid' | 'failed' | 'refunded',
  paymentMethod?: string,
  gatewayTransactionId?: string
) {
  const tableName = type === 'medical_session' ? 'medical_sessions' : 'pharmacy_orders';

  if (status === 'paid' && !gatewayTransactionId) {
    throw new Error('CRITICAL: Cannot mark payment as paid without ZedPay transaction ID');
  }

  const { data: record, error: fetchError } = await supabase
    .from(tableName)
    .select('*')
    .eq('id', id)
    .single();

  if (fetchError) {
    throw fetchError;
  }

  if (status === 'paid' && gatewayTransactionId) {
    const verification = await verifyZedPayPayment(
      gatewayTransactionId,
      record.user_payable
    );

    if (!verification.verified) {
      throw new Error(
        verification.error || 'فشل التحقق من الدفع. الرجاء التواصل مع الدعم الفني'
      );
    }
  }

  const updateData: any = {
    payment_status: status,
    updated_at: new Date().toISOString(),
  };

  if (paymentMethod) {
    updateData.payment_method = paymentMethod;
  }

  if (gatewayTransactionId) {
    updateData.gateway_transaction_id = gatewayTransactionId;
  }

  const { data, error } = await supabase
    .from(tableName)
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    throw error;
  }

  if (status === 'paid') {
    await supabase.from('payment_transactions').insert({
      user_id: data.user_id,
      reference_type: type,
      reference_id: id,
      amount: data.user_payable,
      payment_method: paymentMethod || 'zedpay',
      payment_gateway: 'zedpay',
      gateway_transaction_id: gatewayTransactionId || null,
      status: 'completed',
      completed_at: new Date().toISOString(),
    });
  }

  return data;
}

export function formatCurrency(amount: number): string {
  return `${amount.toFixed(2)} ر.س`;
}

export async function createZedPayPaymentIntent(
  orderId: string,
  amount: number,
  type: 'medical_session' | 'pharmacy_order',
  userId: string
): Promise<{ paymentUrl: string; paymentId: string; error?: string }> {
  try {
    const callbackUrl = `myapp://payment/success?type=${type}&id=${orderId}`;

    const response = await fetch('https://api.zedpay.sa/v1/payments/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.EXPO_PUBLIC_ZEDPAY_API_KEY}`,
      },
      body: JSON.stringify({
        amount: amount,
        currency: 'SAR',
        reference_id: orderId,
        reference_type: type,
        customer_id: userId,
        callback_url: callbackUrl,
        description: type === 'medical_session' ? 'جلسة طبية' : 'طلب صيدلية',
      }),
    });

    if (!response.ok) {
      return {
        paymentUrl: '',
        paymentId: '',
        error: 'فشل إنشاء عملية الدفع. الرجاء المحاولة مرة أخرى',
      };
    }

    const result = await response.json();

    return {
      paymentUrl: result.payment_url || result.checkout_url,
      paymentId: result.payment_id || result.id,
    };
  } catch (error) {
    console.error('ZedPay payment creation error:', error);
    return {
      paymentUrl: '',
      paymentId: '',
      error: 'خطأ في الاتصال بنظام الدفع. الرجاء المحاولة مرة أخرى',
    };
  }
}

export function generatePaymentUrl(
  orderId: string,
  amount: number,
  type: 'medical_session' | 'pharmacy_order'
): string {
  console.warn('DEPRECATED: Use createZedPayPaymentIntent instead. This function returns mock URL.');
  const callbackUrl = `myapp://payment/success?type=${type}&id=${orderId}`;
  return `https://api.zedpay.sa/checkout?amount=${amount}&reference=${orderId}&callback=${encodeURIComponent(callbackUrl)}`;
}
