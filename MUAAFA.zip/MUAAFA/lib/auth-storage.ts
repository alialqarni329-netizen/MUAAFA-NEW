import AsyncStorage from '@react-native-async-storage/async-storage';

const TOKEN_KEY = 'supabase_auth_token';
const USER_ROLE_KEY = 'user_role';
const USER_DATA_KEY = 'user_data';

export const AuthStorage = {
  async saveAuthToken(token: string): Promise<void> {
    try {
      await AsyncStorage.setItem(TOKEN_KEY, token);
    } catch (error) {
      console.error('Error saving auth token:', error);
      throw new Error('فشل حفظ بيانات التوثيق');
    }
  },

  async getAuthToken(): Promise<string | null> {
    try {
      return await AsyncStorage.getItem(TOKEN_KEY);
    } catch (error) {
      console.error('Error getting auth token:', error);
      return null;
    }
  },

  async saveUserRole(role: string): Promise<void> {
    try {
      await AsyncStorage.setItem(USER_ROLE_KEY, role);
    } catch (error) {
      console.error('Error saving user role:', error);
    }
  },

  async getUserRole(): Promise<string | null> {
    try {
      return await AsyncStorage.getItem(USER_ROLE_KEY);
    } catch (error) {
      console.error('Error getting user role:', error);
      return null;
    }
  },

  async saveUserData(data: any): Promise<void> {
    try {
      await AsyncStorage.setItem(USER_DATA_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving user data:', error);
    }
  },

  async getUserData(): Promise<any | null> {
    try {
      const data = await AsyncStorage.getItem(USER_DATA_KEY);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Error getting user data:', error);
      return null;
    }
  },

  async clearAuth(): Promise<void> {
    try {
      await AsyncStorage.multiRemove([TOKEN_KEY, USER_ROLE_KEY, USER_DATA_KEY]);
    } catch (error) {
      console.error('Error clearing auth:', error);
    }
  },

  async isAuthenticated(): Promise<boolean> {
    const token = await this.getAuthToken();
    return token !== null;
  }
};
