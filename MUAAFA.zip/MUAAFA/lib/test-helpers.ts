import { supabase } from './supabase';

export interface TestResult {
  testId: string;
  testName: string;
  passed: boolean;
  error?: string;
  details?: any;
}

export class TestRunner {
  results: TestResult[] = [];

  async runTest(
    testId: string,
    testName: string,
    testFn: () => Promise<void>
  ): Promise<TestResult> {
    console.log(`Running test ${testId}: ${testName}...`);

    try {
      await testFn();
      const result: TestResult = {
        testId,
        testName,
        passed: true,
      };
      this.results.push(result);
      console.log(`✅ PASSED: ${testName}`);
      return result;
    } catch (error: any) {
      const result: TestResult = {
        testId,
        testName,
        passed: false,
        error: error.message,
      };
      this.results.push(result);
      console.error(`❌ FAILED: ${testName}`, error);
      return result;
    }
  }

  printSummary() {
    const passed = this.results.filter(r => r.passed).length;
    const failed = this.results.filter(r => !r.passed).length;

    console.log('\n=== TEST SUMMARY ===');
    console.log(`Total: ${this.results.length}`);
    console.log(`Passed: ${passed}`);
    console.log(`Failed: ${failed}`);

    if (failed > 0) {
      console.log('\nFailed Tests:');
      this.results
        .filter(r => !r.passed)
        .forEach(r => {
          console.log(`- ${r.testId}: ${r.testName}`);
          console.log(`  Error: ${r.error}`);
        });
    }

    return { passed, failed, total: this.results.length };
  }
}

export async function createTestUser(
  phone: string = '+966501234567',
  hasInsurance: boolean = false
): Promise<{ userId: string; insuranceId?: string }> {
  const { data: authData, error: authError } = await supabase.auth.signUp({
    phone,
    password: 'TestPassword123!',
  });

  if (authError) throw authError;
  if (!authData.user) throw new Error('User creation failed');

  const userId = authData.user.id;

  const { error: profileError } = await supabase
    .from('users')
    .upsert({
      id: userId,
      phone,
      role: 'individual',
    });

  if (profileError) throw profileError;

  let insuranceId: string | undefined;

  if (hasInsurance) {
    const { data: insurance, error: insuranceError } = await supabase
      .from('insurance_policies')
      .insert({
        user_id: userId,
        policy_number: `TEST-${Date.now()}`,
        provider_name: 'شركة اختبار للتأمين',
        coverage_percentage: 80,
        start_date: '2025-01-01',
        end_date: '2025-12-31',
        status: 'active',
      })
      .select()
      .single();

    if (insuranceError) throw insuranceError;
    insuranceId = insurance.id;
  }

  return { userId, insuranceId };
}

export async function cleanupTestUser(userId: string) {
  await supabase.from('medical_sessions').delete().eq('user_id', userId);
  await supabase.from('pharmacy_orders').delete().eq('user_id', userId);
  await supabase.from('insurance_policies').delete().eq('user_id', userId);
  await supabase.from('users').delete().eq('id', userId);
  await supabase.auth.admin.deleteUser(userId);
}

export async function testInsuranceCalculation(): Promise<void> {
  const price = 200;
  const coverage = 80;

  const { data, error } = await supabase.rpc('calculate_user_payable', {
    total_price: price,
    insurance_policy_id: null,
  });

  if (error) throw error;

  const result = data[0];
  if (result.insurance_covered !== 0) {
    throw new Error('Insurance covered should be 0 without policy');
  }
  if (result.user_payable !== price) {
    throw new Error(`User payable should be ${price}`);
  }
}

export async function testMedicalSessionCreation(
  userId: string,
  insuranceId?: string
): Promise<string> {
  const sessionDate = new Date();
  sessionDate.setDate(sessionDate.getDate() + 7);

  const { data, error } = await supabase
    .from('medical_sessions')
    .insert({
      user_id: userId,
      doctor_name: 'د. اختبار',
      specialty: 'عام',
      session_date: sessionDate.toISOString(),
      price: 200,
      insurance_policy_id: insuranceId || null,
      insurance_covered: insuranceId ? 160 : 0,
      user_payable: insuranceId ? 40 : 200,
      payment_status: 'pending',
      session_status: 'pending',
    })
    .select()
    .single();

  if (error) throw error;

  if (data.payment_status !== 'pending') {
    throw new Error('Payment status should be pending');
  }
  if (data.session_status !== 'pending') {
    throw new Error('Session status should be pending');
  }

  return data.id;
}

export async function testPaymentEnforcement(sessionId: string): Promise<void> {
  const { error } = await supabase
    .from('medical_sessions')
    .update({ session_status: 'confirmed' })
    .eq('id', sessionId)
    .eq('payment_status', 'pending');

  if (!error) {
    throw new Error('Should not be able to confirm without payment');
  }
}

export async function testPaymentSuccess(sessionId: string): Promise<void> {
  const { data, error } = await supabase
    .from('medical_sessions')
    .update({
      payment_status: 'paid',
      updated_at: new Date().toISOString(),
    })
    .eq('id', sessionId)
    .select()
    .single();

  if (error) throw error;

  await new Promise(resolve => setTimeout(resolve, 1000));

  const { data: updated, error: fetchError } = await supabase
    .from('medical_sessions')
    .select('*')
    .eq('id', sessionId)
    .single();

  if (fetchError) throw fetchError;

  if (updated.session_status !== 'confirmed') {
    throw new Error('Session should be auto-confirmed after payment');
  }

  if (!updated.paid_at) {
    throw new Error('paid_at should be set');
  }

  if (!updated.confirmed_at) {
    throw new Error('confirmed_at should be set');
  }
}

export async function testPharmacyOrderCreation(
  userId: string,
  insuranceId?: string
): Promise<string> {
  const { data, error } = await supabase
    .from('pharmacy_orders')
    .insert({
      user_id: userId,
      pharmacy_name: 'صيدلية اختبار',
      items: [
        {
          medication_id: 'test-med-1',
          name: 'دواء اختبار',
          quantity: 2,
          unit_price: 50,
        },
      ],
      total_price: 100,
      insurance_policy_id: insuranceId || null,
      insurance_covered: insuranceId ? 80 : 0,
      user_payable: insuranceId ? 20 : 100,
      payment_status: 'pending',
      order_status: 'pending',
    })
    .select()
    .single();

  if (error) throw error;

  if (data.payment_status !== 'pending') {
    throw new Error('Payment status should be pending');
  }

  return data.id;
}

export async function testRLSSecurity(
  userId: string,
  otherUserId: string
): Promise<void> {
  const sessionDate = new Date();
  sessionDate.setDate(sessionDate.getDate() + 7);

  const { data: session } = await supabase
    .from('medical_sessions')
    .insert({
      user_id: otherUserId,
      doctor_name: 'د. آخر',
      specialty: 'عام',
      session_date: sessionDate.toISOString(),
      price: 150,
      insurance_covered: 0,
      user_payable: 150,
      payment_status: 'pending',
      session_status: 'pending',
    })
    .select()
    .single();

  if (!session) throw new Error('Could not create test session');

  await supabase.auth.signInWithPassword({
    phone: '+966501234567',
    password: 'TestPassword123!',
  });

  const { data: otherSessions } = await supabase
    .from('medical_sessions')
    .select('*')
    .eq('user_id', otherUserId);

  if (otherSessions && otherSessions.length > 0) {
    throw new Error('RLS VIOLATION: User can access other users data');
  }
}

export async function runAllCriticalTests(): Promise<void> {
  const runner = new TestRunner();

  await runner.runTest('CALC-1', 'Insurance Calculation', async () => {
    await testInsuranceCalculation();
  });

  let testUserId: string;
  let testInsuranceId: string | undefined;

  await runner.runTest('USER-1', 'Create Test User Without Insurance', async () => {
    const result = await createTestUser('+966501111111', false);
    testUserId = result.userId;
  });

  await runner.runTest('USER-2', 'Create Test User With Insurance', async () => {
    const result = await createTestUser('+966502222222', true);
    testInsuranceId = result.insuranceId;
  });

  let sessionId: string;

  await runner.runTest('SESSION-1', 'Create Medical Session', async () => {
    sessionId = await testMedicalSessionCreation(testUserId, testInsuranceId);
  });

  await runner.runTest('PAYMENT-1', 'Payment Enforcement', async () => {
    await testPaymentEnforcement(sessionId);
  });

  await runner.runTest('PAYMENT-2', 'Payment Success Flow', async () => {
    await testPaymentSuccess(sessionId);
  });

  let orderId: string;

  await runner.runTest('PHARMACY-1', 'Create Pharmacy Order', async () => {
    orderId = await testPharmacyOrderCreation(testUserId, testInsuranceId);
  });

  const summary = runner.printSummary();

  if (summary.failed > 0) {
    throw new Error(`${summary.failed} test(s) failed`);
  }

  console.log('\n✅ All critical tests passed!');
}
