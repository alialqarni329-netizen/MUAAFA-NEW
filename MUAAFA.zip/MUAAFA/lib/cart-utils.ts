import { supabase } from './supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface CartProduct {
  id: string;
  name: string;
  price: number;
  type: 'treatment' | 'report' | 'subscription' | 'test' | 'insurance' | 'session' | 'product';
  metadata?: any;
}

const CART_STORAGE_KEY = 'muaafa_cart_items';

export async function addToCart(product: CartProduct, quantity: number = 1) {
  try {
    const { data: { user } } = await supabase.auth.getUser();

    if (user) {
      const { data: existing } = await supabase
        .from('cart_items')
        .select('*')
        .eq('user_id', user.id)
        .eq('product_id', product.id)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('cart_items')
          .update({ quantity: existing.quantity + quantity })
          .eq('id', existing.id);
      } else {
        await supabase.from('cart_items').insert({
          user_id: user.id,
          product_id: product.id,
          quantity,
        });
      }

      await supabase.from('products').upsert({
        id: product.id,
        name: product.name,
        price: product.price,
        product_type: product.type,
        metadata: product.metadata || {},
      }, { onConflict: 'id' });
    }

    const localCart = await getLocalCart();
    const existingIndex = localCart.findIndex((item: any) => item.id === product.id);

    if (existingIndex >= 0) {
      localCart[existingIndex].quantity += quantity;
    } else {
      localCart.push({ ...product, quantity });
    }

    await AsyncStorage.setItem(CART_STORAGE_KEY, JSON.stringify(localCart));

    return true;
  } catch (error) {
    console.error('Error adding to cart:', error);
    return false;
  }
}

export async function getLocalCart() {
  try {
    const cart = await AsyncStorage.getItem(CART_STORAGE_KEY);
    return cart ? JSON.parse(cart) : [];
  } catch (error) {
    console.error('Error getting local cart:', error);
    return [];
  }
}

export async function syncCart() {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const localCart = await getLocalCart();

    for (const item of localCart) {
      await addToCart(item, item.quantity);
    }
  } catch (error) {
    console.error('Error syncing cart:', error);
  }
}

export async function clearLocalCart() {
  try {
    await AsyncStorage.removeItem(CART_STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing local cart:', error);
  }
}

export async function getCartCount(): Promise<number> {
  try {
    const { data: { user } } = await supabase.auth.getUser();

    if (user) {
      const { data } = await supabase
        .from('cart_items')
        .select('quantity')
        .eq('user_id', user.id);

      return data?.reduce((sum, item) => sum + item.quantity, 0) || 0;
    }

    const localCart = await getLocalCart();
    return localCart.reduce((sum: number, item: any) => sum + item.quantity, 0);
  } catch (error) {
    console.error('Error getting cart count:', error);
    return 0;
  }
}
