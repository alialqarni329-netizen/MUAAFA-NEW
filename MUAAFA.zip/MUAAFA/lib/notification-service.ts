import { supabase } from './supabase';

export interface NotificationData {
  recipient_type: 'users' | 'business';
  type: 'email' | 'sms' | 'push';
  title: string;
  message: string;
  status?: 'pending' | 'delivered' | 'failed';
  user_id?: string;
  recipient_email?: string;
  phone_number?: string;
  error_message?: string | null;
}

export interface NotificationStats {
  total: number;
  delivered: number;
  failed: number;
  pending: number;
}

// Fetch all notifications for a recipient type
export async function getNotificationsByRecipientType(
  recipientType: 'users' | 'business',
  limit = 50
) {
  const { data, error } = await supabase
    .from('notifications')
    .select(`
      id,
      title,
      message,
      status,
      type,
      created_at,
      user:users(full_name, email, phone)
    `)
    .eq('recipient_type', recipientType)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data;
}

// Fetch notifications by type (email, sms, push)
export async function getNotificationsByType(
  type: 'email' | 'sms' | 'push',
  limit = 50
) {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('type', type)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data;
}

// Get notification stats for a recipient type
export async function getNotificationStats(
  recipientType?: 'users' | 'business'
): Promise<NotificationStats> {
  let totalQuery = supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true });

  let deliveredQuery = supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'delivered');

  let failedQuery = supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'failed');

  let pendingQuery = supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'pending');

  if (recipientType) {
    totalQuery = totalQuery.eq('recipient_type', recipientType);
    deliveredQuery = deliveredQuery.eq('recipient_type', recipientType);
    failedQuery = failedQuery.eq('recipient_type', recipientType);
    pendingQuery = pendingQuery.eq('recipient_type', recipientType);
  }

  const [{ count: total }, { count: delivered }, { count: failed }, { count: pending }] =
    await Promise.all([
      totalQuery,
      deliveredQuery,
      failedQuery,
      pendingQuery,
    ]);

  return {
    total: total || 0,
    delivered: delivered || 0,
    failed: failed || 0,
    pending: pending || 0,
  };
}

// Send a notification
export async function sendNotification(data: NotificationData) {
  const notification = {
    recipient_type: data.recipient_type,
    type: data.type,
    title: data.title,
    message: data.message,
    status: data.status || 'pending',
    created_at: new Date().toISOString(),
    user_id: data.user_id || null,
    recipient_email: data.recipient_email || null,
    phone_number: data.phone_number || null,
  };

  const { data: result, error } = await supabase
    .from('notifications')
    .insert([notification])
    .select();

  if (error) throw error;
  return result?.[0];
}

// Update notification status
export async function updateNotificationStatus(
  notificationId: string,
  status: 'pending' | 'delivered' | 'failed',
  errorMessage?: string
) {
  const update: any = { status };
  if (errorMessage) {
    update.error_message = errorMessage;
  }

  const { data, error } = await supabase
    .from('notifications')
    .update(update)
    .eq('id', notificationId)
    .select();

  if (error) throw error;
  return data?.[0];
}

// Bulk send notifications to multiple recipients
export async function bulkSendNotifications(
  recipientType: 'users' | 'business',
  notificationType: 'email' | 'sms' | 'push',
  title: string,
  message: string,
  recipients?: string[] // user_ids or emails
) {
  const notifications = [];

  if (recipients && recipients.length > 0) {
    // Send to specific recipients
    for (const recipient of recipients) {
      notifications.push({
        recipient_type: recipientType,
        type: notificationType,
        title,
        message,
        status: 'pending',
        created_at: new Date().toISOString(),
        user_id: notificationType === 'push' ? recipient : null,
        recipient_email: notificationType === 'email' ? recipient : null,
        phone_number: notificationType === 'sms' ? recipient : null,
      });
    }
  } else {
    // Send to all recipients of that type
    notifications.push({
      recipient_type: recipientType,
      type: notificationType,
      title,
      message,
      status: 'pending',
      created_at: new Date().toISOString(),
    });
  }

  const { data, error } = await supabase
    .from('notifications')
    .insert(notifications)
    .select();

  if (error) throw error;
  return data;
}

// Get notification history with filters
export async function getNotificationHistory(
  filters?: {
    recipientType?: 'users' | 'business';
    type?: 'email' | 'sms' | 'push';
    status?: 'pending' | 'delivered' | 'failed';
    startDate?: Date;
    endDate?: Date;
    limit?: number;
  }
) {
  let query = supabase
    .from('notifications')
    .select('*')
    .order('created_at', { ascending: false });

  if (filters?.recipientType) {
    query = query.eq('recipient_type', filters.recipientType);
  }

  if (filters?.type) {
    query = query.eq('type', filters.type);
  }

  if (filters?.status) {
    query = query.eq('status', filters.status);
  }

  if (filters?.startDate) {
    query = query.gte('created_at', filters.startDate.toISOString());
  }

  if (filters?.endDate) {
    query = query.lte('created_at', filters.endDate.toISOString());
  }

  const limit = filters?.limit || 100;
  query = query.limit(limit);

  const { data, error } = await query;

  if (error) throw error;
  return data;
}

// Get email statistics
export async function getEmailStats() {
  return getNotificationStats();
}

// Get SMS statistics
export async function getSMSStats() {
  return getNotificationStats();
}

// Delete notification
export async function deleteNotification(notificationId: string) {
  const { error } = await supabase
    .from('notifications')
    .delete()
    .eq('id', notificationId);

  if (error) throw error;
  return true;
}

// Mark notification as read
export async function markAsRead(notificationId: string) {
  const { data, error } = await supabase
    .from('notifications')
    .update({ read: true })
    .eq('id', notificationId)
    .select();

  if (error) throw error;
  return data?.[0];
}

// Resend failed notification
export async function resendNotification(notificationId: string) {
  const { data: notification, error: fetchError } = await supabase
    .from('notifications')
    .select('*')
    .eq('id', notificationId)
    .single();

  if (fetchError) throw fetchError;

  if (!notification) {
    throw new Error('Notification not found');
  }

  const { data, error } = await supabase
    .from('notifications')
    .update({ status: 'pending', error_message: null })
    .eq('id', notificationId)
    .select();

  if (error) throw error;
  return data?.[0];
}
