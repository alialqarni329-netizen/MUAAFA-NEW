export interface ValidationResult {
  isValid: boolean;
  errorMessage: string;
  normalizedValue?: string;
}

const ALLOWED_EMAIL_DOMAINS = [
  'gmail.com',
  'googlemail.com',
  'outlook.com',
  'outlook.sa',
  'hotmail.com',
  'hotmail.sa',
  'yahoo.com',
  'yahoo.sa',
  'icloud.com',
  'me.com',
  'live.com',
  'live.sa',
  'msn.com',
  'stc.com.sa',
  'mobily.com.sa',
  'zain.com.sa',
  'saudi.gov.sa',
  'moe.gov.sa',
  'moh.gov.sa',
  'mof.gov.sa',
  'mol.gov.sa',
  'spa.gov.sa',
  'edu.sa',
  'com.sa',
  'org.sa',
  'net.sa',
  'muaafa.com',
];

export function validateEmail(email: string): ValidationResult {
  const trimmedEmail = email.trim();

  if (!trimmedEmail) {
    return {
      isValid: false,
      errorMessage: 'البريد الإلكتروني مطلوب',
    };
  }

  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;

  if (!emailRegex.test(trimmedEmail)) {
    return {
      isValid: false,
      errorMessage: 'يرجى إدخال عنوان بريد إلكتروني صحيح، تأكد من وجود @ والنطاق بشكل سليم',
    };
  }

  const emailParts = trimmedEmail.toLowerCase().split('@');
  if (emailParts.length !== 2) {
    return {
      isValid: false,
      errorMessage: 'صيغة البريد الإلكتروني غير صحيحة، يجب أن يحتوي على @ واحد فقط',
    };
  }

  const [localPart, domain] = emailParts;

  if (localPart.length < 2) {
    return {
      isValid: false,
      errorMessage: 'اسم المستخدم في البريد الإلكتروني قصير جداً (حرفين على الأقل)',
    };
  }

  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return {
      isValid: false,
      errorMessage: 'البريد الإلكتروني لا يجب أن يبدأ أو ينتهي بنقطة',
    };
  }

  if (localPart.includes('..')) {
    return {
      isValid: false,
      errorMessage: 'البريد الإلكتروني لا يجب أن يحتوي على نقطتين متتاليتين',
    };
  }

  const isDomainAllowed = ALLOWED_EMAIL_DOMAINS.some(
    (allowedDomain) => domain === allowedDomain || domain.endsWith(`.${allowedDomain}`)
  );

  if (!isDomainAllowed) {
    return {
      isValid: false,
      errorMessage: `النطاق "${domain}" غير مدعوم. يرجى استخدام بريد إلكتروني من نطاق معروف (مثل: gmail.com، outlook.com، hotmail.com)`,
    };
  }

  const suspiciousPatterns = [
    /temp/i,
    /fake/i,
    /test/i,
    /spam/i,
    /trash/i,
    /dispose/i,
    /throwaway/i,
    /guerrilla/i,
    /mailinator/i,
    /10minute/i,
  ];

  for (const pattern of suspiciousPatterns) {
    if (pattern.test(trimmedEmail)) {
      return {
        isValid: false,
        errorMessage: 'لا يمكن استخدام بريد إلكتروني مؤقت أو وهمي، يرجى استخدام بريد حقيقي',
      };
    }
  }

  return {
    isValid: true,
    errorMessage: '',
  };
}

export function validatePhone(phone: string): ValidationResult {
  const trimmedPhone = phone.trim();

  if (!trimmedPhone) {
    return {
      isValid: false,
      errorMessage: 'رقم الجوال مطلوب',
    };
  }

  const cleanPhone = trimmedPhone.replace(/[\s\-\(\)]/g, '');

  const saudiPhoneRegex = /^(\+?966|00966|0)?5[0-9]{8}$/;

  if (!saudiPhoneRegex.test(cleanPhone)) {
    return {
      isValid: false,
      errorMessage: 'رقم الجوال غير صحيح، يجب أن يكون رقم سعودي يبدأ بـ 05 (مثال: 0501234567 أو +966501234567)',
    };
  }

  let normalizedPhone = cleanPhone;
  if (normalizedPhone.startsWith('00966')) {
    normalizedPhone = '+966' + normalizedPhone.substring(5);
  } else if (normalizedPhone.startsWith('966')) {
    normalizedPhone = '+966' + normalizedPhone.substring(3);
  } else if (normalizedPhone.startsWith('0')) {
    normalizedPhone = '+966' + normalizedPhone.substring(1);
  } else if (!normalizedPhone.startsWith('+966')) {
    normalizedPhone = '+966' + normalizedPhone;
  }

  return {
    isValid: true,
    errorMessage: '',
    normalizedValue: normalizedPhone,
  };
}

export function validateNationalId(nationalId: string): ValidationResult {
  const trimmedId = nationalId.trim();

  if (!trimmedId) {
    return {
      isValid: false,
      errorMessage: 'رقم الهوية مطلوب',
    };
  }

  if (!/^\d+$/.test(trimmedId)) {
    return {
      isValid: false,
      errorMessage: 'رقم الهوية يجب أن يحتوي على أرقام فقط',
    };
  }

  if (trimmedId.length !== 10) {
    return {
      isValid: false,
      errorMessage: `رقم الهوية يجب أن يكون 10 أرقام بالضبط (أدخلت ${trimmedId.length} رقم)`,
    };
  }

  const firstDigit = parseInt(trimmedId[0]);
  if (firstDigit !== 1 && firstDigit !== 2) {
    return {
      isValid: false,
      errorMessage: 'رقم الهوية يجب أن يبدأ بـ 1 (سعودي) أو 2 (مقيم)',
    };
  }

  return {
    isValid: true,
    errorMessage: '',
  };
}

export function validateCommercialRegistration(crNumber: string): ValidationResult {
  const trimmedCr = crNumber.trim();

  if (!trimmedCr) {
    return {
      isValid: false,
      errorMessage: 'رقم السجل التجاري مطلوب',
    };
  }

  if (!/^\d+$/.test(trimmedCr)) {
    return {
      isValid: false,
      errorMessage: 'رقم السجل التجاري يجب أن يحتوي على أرقام فقط',
    };
  }

  if (trimmedCr.length !== 10) {
    return {
      isValid: false,
      errorMessage: `رقم السجل التجاري يجب أن يكون 10 أرقام بالضبط (أدخلت ${trimmedCr.length} رقم)`,
    };
  }

  return {
    isValid: true,
    errorMessage: '',
  };
}

export function validatePassword(password: string): ValidationResult {
  if (!password) {
    return {
      isValid: false,
      errorMessage: 'كلمة المرور مطلوبة',
    };
  }

  if (password.length < 8) {
    return {
      isValid: false,
      errorMessage: `كلمة المرور قصيرة جداً، يجب أن تكون 8 أحرف على الأقل (أدخلت ${password.length} حرف)`,
    };
  }

  if (password.length > 72) {
    return {
      isValid: false,
      errorMessage: 'كلمة المرور طويلة جداً، يجب ألا تتجاوز 72 حرف',
    };
  }

  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);

  const missingRequirements = [];
  if (!hasUpperCase) missingRequirements.push('حرف كبير (A-Z)');
  if (!hasLowerCase) missingRequirements.push('حرف صغير (a-z)');
  if (!hasNumber) missingRequirements.push('رقم (0-9)');

  if (missingRequirements.length > 0) {
    return {
      isValid: false,
      errorMessage: `كلمة المرور يجب أن تحتوي على: ${missingRequirements.join('، ')}`,
    };
  }

  const commonPasswords = ['password', '12345678', 'qwerty123', 'abc12345', 'password1'];
  if (commonPasswords.includes(password.toLowerCase())) {
    return {
      isValid: false,
      errorMessage: 'كلمة المرور شائعة جداً، يرجى اختيار كلمة مرور أقوى',
    };
  }

  return {
    isValid: true,
    errorMessage: '',
  };
}

export function validateBusinessEmail(email: string): ValidationResult {
  const trimmedEmail = email.trim();

  if (!trimmedEmail) {
    return {
      isValid: false,
      errorMessage: 'البريد الإلكتروني مطلوب',
    };
  }

  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;

  if (!emailRegex.test(trimmedEmail)) {
    return {
      isValid: false,
      errorMessage: 'يرجى إدخال عنوان بريد إلكتروني صحيح',
    };
  }

  const emailParts = trimmedEmail.toLowerCase().split('@');
  if (emailParts.length !== 2) {
    return {
      isValid: false,
      errorMessage: 'صيغة البريد الإلكتروني غير صحيحة',
    };
  }

  const [localPart, domain] = emailParts;

  if (localPart.length < 2) {
    return {
      isValid: false,
      errorMessage: 'اسم المستخدم في البريد الإلكتروني قصير جداً',
    };
  }

  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return {
      isValid: false,
      errorMessage: 'البريد الإلكتروني لا يجب أن يبدأ أو ينتهي بنقطة',
    };
  }

  if (localPart.includes('..')) {
    return {
      isValid: false,
      errorMessage: 'البريد الإلكتروني لا يجب أن يحتوي على نقطتين متتاليتين',
    };
  }

  return {
    isValid: true,
    errorMessage: '',
  };
}

export function validateBusinessName(name: string): ValidationResult {
  const trimmedName = name.trim();

  if (!trimmedName) {
    return {
      isValid: false,
      errorMessage: 'اسم المنشأة مطلوب',
    };
  }

  if (trimmedName.length < 3) {
    return {
      isValid: false,
      errorMessage: 'اسم المنشأة قصير جداً، يجب أن يكون 3 أحرف على الأقل',
    };
  }

  if (trimmedName.length > 100) {
    return {
      isValid: false,
      errorMessage: 'اسم المنشأة طويل جداً، يجب ألا يتجاوز 100 حرف',
    };
  }

  const validNameRegex = /^[\u0600-\u06FFa-zA-Z0-9\s\-\.\&]+$/;
  if (!validNameRegex.test(trimmedName)) {
    return {
      isValid: false,
      errorMessage: 'اسم المنشأة يحتوي على أحرف غير مسموحة، يرجى استخدام الأحرف العربية أو الإنجليزية والأرقام فقط',
    };
  }

  return {
    isValid: true,
    errorMessage: '',
  };
}

export function parseSupabaseError(error: any): string {
  if (!error) {
    return 'حدث خطأ غير متوقع';
  }

  const errorMessage = error.message || error.toString();

  if (errorMessage.includes('duplicate key') || errorMessage.includes('unique constraint')) {
    if (errorMessage.includes('email')) {
      return 'البريد الإلكتروني مسجل مسبقاً، يرجى استخدام بريد آخر أو تسجيل الدخول';
    }
    if (errorMessage.includes('phone')) {
      return 'رقم الجوال مسجل مسبقاً، يرجى استخدام رقم آخر أو تسجيل الدخول';
    }
    if (errorMessage.includes('commercial_registration')) {
      return 'رقم السجل التجاري مسجل مسبقاً في النظام';
    }
    return 'البيانات المدخلة موجودة مسبقاً في النظام';
  }

  if (errorMessage.includes('violates foreign key constraint')) {
    return 'خطأ في الربط مع البيانات، يرجى المحاولة مرة أخرى';
  }

  if (errorMessage.includes('violates check constraint')) {
    return 'البيانات المدخلة لا تتطابق مع المتطلبات المحددة';
  }

  if (errorMessage.includes('violates not-null constraint')) {
    const fieldMatch = errorMessage.match(/column "(\w+)"/);
    if (fieldMatch) {
      const fieldName = fieldMatch[1];
      const arabicFieldNames: Record<string, string> = {
        business_name: 'اسم المنشأة',
        commercial_registration: 'رقم السجل التجاري',
        phone: 'رقم الجوال',
        email: 'البريد الإلكتروني',
        owner_national_id: 'رقم الهوية',
      };
      const arabicName = arabicFieldNames[fieldName] || fieldName;
      return `${arabicName} مطلوب ولا يمكن تركه فارغاً`;
    }
    return 'أحد الحقول المطلوبة فارغ';
  }

  if (errorMessage.includes('Network request failed') || errorMessage.includes('Failed to fetch')) {
    return 'خطأ في الاتصال بالإنترنت، يرجى التحقق من اتصالك والمحاولة مرة أخرى';
  }

  if (errorMessage.includes('timeout')) {
    return 'انتهت مهلة الاتصال، يرجى المحاولة مرة أخرى';
  }

  if (errorMessage.includes('row-level security') || errorMessage.includes('violates row level security')) {
    if (errorMessage.includes('business_verification') || errorMessage.includes('business_registrations')) {
      return 'عذراً، تعذر إتمام تسجيل المنشأة حالياً\n\nيرجى التأكد من:\n• أنك مسجل دخول بشكل صحيح\n• إدخال جميع البيانات المطلوبة\n\nإذا استمرت المشكلة، يرجى التواصل مع الدعم الفني';
    }
    return 'عذراً، لا يمكن إتمام هذه العملية حالياً، يرجى المحاولة لاحقاً أو التواصل مع الدعم الفني';
  }

  if (errorMessage.includes('Permission denied') || errorMessage.includes('RLS')) {
    return 'ليس لديك الصلاحيات اللازمة لإتمام هذه العملية، يرجى التأكد من تسجيل الدخول';
  }

  if (error.status === 401) {
    return 'انتهت صلاحية الجلسة، يرجى تسجيل الدخول مرة أخرى';
  }

  if (error.status === 403) {
    return 'غير مصرح لك بإجراء هذه العملية';
  }

  if (error.status === 404) {
    return 'البيانات المطلوبة غير موجودة';
  }

  if (error.status === 500) {
    return 'خطأ في الخادم، يرجى المحاولة لاحقاً';
  }

  if (errorMessage.length < 100) {
    return errorMessage;
  }

  return 'حدث خطأ غير متوقع، يرجى التواصل مع الدعم الفني';
}
