import { supabase } from './supabase';

export interface BrandSettings {
  logo_url: string;
  name_ar: string;
  name_en: string;
  full_name: string;
  primary_color: string;
  background_color: string;
  logo_description: string;
  notification_icon: string;
  splash_logo: string;
  favicon: string;
  tagline_ar: string;
  tagline_en: string;
}

let cachedBrandSettings: BrandSettings | null = null;

export async function getBrandSettings(): Promise<BrandSettings | null> {
  if (cachedBrandSettings) {
    return cachedBrandSettings;
  }

  try {
    const { data, error } = await supabase
      .from('brand_settings')
      .select('*')
      .maybeSingle();

    if (error) {
      console.error('Error fetching brand settings:', error);
      return getDefaultBrandSettings();
    }

    cachedBrandSettings = data;
    return data;
  } catch (error) {
    console.error('Error in getBrandSettings:', error);
    return getDefaultBrandSettings();
  }
}

export function getDefaultBrandSettings(): BrandSettings {
  return {
    logo_url: '/assets/images/icon.png',
    name_ar: 'مُعافى',
    name_en: 'MUAAFA',
    full_name: 'مُعافى | MUAAFA',
    primary_color: '#0ea5e9',
    background_color: '#0ea5e9',
    logo_description: 'شعار مُعافى يتكون من درع واقي مع حرف M وخط نبض القلب، يرمز إلى الحماية والصحة',
    notification_icon: '/assets/images/adaptive-icon.png',
    splash_logo: '/assets/images/splash.png',
    favicon: '/assets/images/favicon.png',
    tagline_ar: 'صحتك بين يديك',
    tagline_en: 'Your Health in Your Hands',
  };
}

export function clearBrandCache() {
  cachedBrandSettings = null;
}

export const BRAND_COLORS = {
  primary: '#0ea5e9',
  primaryDark: '#0284c7',
  primaryLight: '#38bdf8',
  background: '#0ea5e9',
  white: '#ffffff',
  black: '#000000',
  gray: '#6b7280',
  lightGray: '#f3f4f6',
  success: '#10b981',
  error: '#ef4444',
  warning: '#f59e0b',
};
