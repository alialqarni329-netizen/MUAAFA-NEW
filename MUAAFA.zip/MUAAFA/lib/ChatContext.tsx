import React, { createContext, useContext, useState, useCallback, useRef, ReactNode } from 'react';
import { supabase } from './supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  status?: 'sending' | 'sent' | 'failed';
  analysis?: any;
}

interface ChatContextType {
  messages: Message[];
  conversationId: string | null;
  userId: string | null;
  loading: boolean;
  isSending: boolean;
  initializeChat: (language: string) => Promise<void>;
  sendMessage: (text: string, language: string) => Promise<void>;
  clearMessages: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function ChatProvider({ children }: { children: ReactNode }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [initialized, setInitialized] = useState(false);
  const messagesRef = useRef<Message[]>([]);

  messagesRef.current = messages;

  React.useEffect(() => {
    console.log('[CHAT_PROVIDER] MOUNT');
    return () => console.log('[CHAT_PROVIDER] UNMOUNT');
  }, []);

  const initializeChat = useCallback(async (language: string) => {
    if (initialized) {
      return;
    }

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Not authenticated');
      }
      setUserId(user.id);

      let currentConversationId = await AsyncStorage.getItem(`chat_conversation_${user.id}`);

      if (currentConversationId) {
        const { data: existingConv } = await supabase
          .from('chat_conversations')
          .select('id')
          .eq('id', currentConversationId)
          .eq('user_id', user.id)
          .maybeSingle();

        if (existingConv) {
          setConversationId(existingConv.id);

          const { data: historyMessages } = await supabase
            .from('chat_messages')
            .select('*')
            .eq('conversation_id', existingConv.id)
            .order('created_at', { ascending: true })
            .limit(50);

          if (historyMessages && historyMessages.length > 0) {
            const loadedMessages: Message[] = historyMessages.map((msg) => ({
              id: msg.id,
              role: msg.sender_type === 'ai' ? 'assistant' : 'user',
              content: msg.content,
              timestamp: new Date(msg.created_at),
              status: 'sent',
              analysis: msg.severity_level ? {
                severity_level: msg.severity_level,
                suggested_action: msg.suggested_action,
                app_features_mentioned: msg.app_features_mentioned || [],
              } : undefined,
            }));
            setMessages(loadedMessages);
            setInitialized(true);
            return;
          }
        }
      }

      if (!currentConversationId) {
        const { data: conv, error } = await supabase
          .from('chat_conversations')
          .insert({ user_id: user.id })
          .select()
          .single();

        if (error || !conv?.id) {
          console.error('[CHAT ERROR] failed to create conversation', error);
          return;
        }

        currentConversationId = conv.id;
        await AsyncStorage.setItem(`chat_conversation_${user.id}`, conv.id);
        setConversationId(conv.id);
      }

      const welcomeMsg = language === 'ar'
        ? 'يا هلا! 👋 أنا الطبيب الذكي في مُعافى 🩺\n\nأنا هنا لمساعدتك في:\n📚 معلومات صحية عامة وتثقيفية\n🌿 معلومات من الموروث الصحي الشعبي\n💊 تعريف عام بالأدوية (بدون جرعات)\n🏃 نصائح نمط حياة عامة\n💡 توعية صحية عامة\n\n⚠️ تنبيه مهم: لا أقدم تشخيصات أو وصفات طبية أو جرعات. للاستشارة الطبية الحقيقية، احجز جلسة مع طبيب متخصص.\n\nكيف أساعدك اليوم؟'
        : 'Welcome! 👋 I\'m the Smart Doctor in Muaafa 🩺\n\nI\'m here to help you with:\n📚 General health information and education\n🌿 Traditional health wisdom information\n💊 General medication information (no dosages)\n🏃 General lifestyle advice\n💡 Health awareness\n\n⚠️ Important Note: I don\'t provide diagnoses, prescriptions, or dosages. For real medical consultation, book a session with a specialist doctor.\n\nHow can I help you today?';

      setMessages([
        {
          id: 'welcome',
          role: 'assistant',
          content: welcomeMsg,
          timestamp: new Date(),
          status: 'sent',
        },
      ]);
      setInitialized(true);
    } catch (error) {
      console.error('Initialize error:', error);
      setMessages([{
        id: 'error-init',
        role: 'assistant',
        content: language === 'ar'
          ? '❌ حدث خطأ في بدء المحادثة. يرجى تحديث الصفحة.'
          : '❌ Error starting conversation. Please refresh.',
        timestamp: new Date(),
        status: 'sent',
      }]);
    } finally {
      setLoading(false);
    }
  }, [initialized]);

  const sendMessage = useCallback(async (text: string, language: string) => {
    console.log('[CHAT DEBUG] before insert', { conversationId, userId, text });

    if (!conversationId) {
      console.error('[CHAT ERROR] conversationId missing');
      return;
    }
    if (!userId) {
      console.error('[CHAT ERROR] userId missing');
      return;
    }
    if (!text || !text.trim()) {
      console.error('[CHAT ERROR] empty content');
      return;
    }

    if (isSending) {
      return;
    }

    const userMessageId = `user-${Date.now()}`;
    const userMessage: Message = {
      id: userMessageId,
      role: 'user',
      content: text,
      timestamp: new Date(),
      status: 'sending',
    };

    setMessages((prev) => {
      const next = [...prev, userMessage];
      messagesRef.current = next;
      return next;
    });
    setIsSending(true);

    try {
      const conversationHistory = messagesRef.current
        .filter((m) => m.id !== 'welcome' && m.status !== 'failed')
        .map((m) => ({ role: m.role, content: m.content }));

      conversationHistory.push({ role: 'user', content: text });

      const { data, error } = await supabase.functions.invoke('health-chatbot-fast', {
        body: {
          messages: conversationHistory,
          conversationId,
          userId,
        },
      });

      if (error) {
        throw error;
      }

      const responseContent = data?.message || data?.reply;
      if (!responseContent) {
        throw new Error('Invalid response');
      }

      setMessages((prev) => {
        const next = prev.map((msg) =>
          msg.id === userMessageId ? { ...msg, status: 'sent' as const } : msg
        );
        messagesRef.current = next;
        return next;
      });

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: responseContent,
        timestamp: new Date(),
        status: 'sent',
        analysis: data.analysis,
      };

      setMessages((prev) => {
        const next = [...prev, assistantMessage];
        messagesRef.current = next;
        return next;
      });

      const userPayload = {
        conversation_id: conversationId,
        sender_type: 'user',
        content: text.trim(),
      };

      const { error: userInsertError } = await supabase
        .from('chat_messages')
        .insert(userPayload);

      if (userInsertError) {
        console.error('[DB USER INSERT ERROR]', userInsertError);
      } else {
        console.log('[DB USER INSERT OK]');
      }

      const aiPayload = {
        conversation_id: conversationId,
        sender_type: 'ai',
        content: responseContent,
        severity_level: data?.analysis?.severity_level ?? null,
        suggested_action: data?.analysis?.suggested_action ?? null,
        app_features_mentioned: data?.analysis?.app_features_mentioned ?? [],
      };

      const { error: aiInsertError } = await supabase
        .from('chat_messages')
        .insert(aiPayload);

      if (aiInsertError) {
        console.error('[DB AI INSERT ERROR]', aiInsertError);
      } else {
        console.log('[DB AI INSERT OK]');
      }

      await supabase
        .from('chat_conversations')
        .update({ last_message_at: new Date().toISOString() })
        .eq('id', conversationId);

    } catch (error: any) {
      console.error('Send error:', error);

      setMessages((prev) => {
        const next = prev.map((msg) =>
          msg.id === userMessageId ? { ...msg, status: 'failed' as const } : msg
        );
        messagesRef.current = next;
        return next;
      });

      const errorMsg = language === 'ar'
        ? '❌ فشل إرسال الرسالة. يرجى المحاولة مرة أخرى.'
        : '❌ Failed to send. Please try again.';

      setMessages((prev) => {
        const next = [...prev, {
          id: `error-${Date.now()}`,
          role: 'assistant',
          content: errorMsg,
          timestamp: new Date(),
          status: 'sent',
        }];
        messagesRef.current = next;
        return next;
      });
    } finally {
      setIsSending(false);
    }
  }, [isSending, conversationId, userId]);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setConversationId(null);
    setInitialized(false);
  }, []);

  return (
    <ChatContext.Provider
      value={{
        messages,
        conversationId,
        userId,
        loading,
        isSending,
        initializeChat,
        sendMessage,
        clearMessages,
      }}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within ChatProvider');
  }
  return context;
}
