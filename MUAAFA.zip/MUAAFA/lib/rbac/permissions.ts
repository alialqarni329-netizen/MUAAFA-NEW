export const PERMISSIONS = {
  GENERAL: {
    VIEW_DASHBOARD: 'view_dashboard',
    MANAGE_SETTINGS: 'manage_settings',
    MANAGE_STAFF: 'manage_staff',
    VIEW_REPORTS: 'view_reports',
    VIEW_STATISTICS: 'view_statistics',
    VIEW_AUDIT_LOG: 'view_audit_log',
  },
  MEDICAL: {
    MANAGE_SESSIONS: 'manage_sessions',
    VIEW_MEDICAL_RECORDS: 'view_medical_records',
    UPLOAD_MEDICAL_REPORTS: 'upload_medical_reports',
    MANAGE_APPOINTMENTS: 'manage_appointments',
    VIEW_PATIENTS: 'view_patients',
  },
  FINANCIAL: {
    VIEW_INVOICES: 'view_invoices',
    MANAGE_PAYMENTS: 'manage_payments',
    VIEW_FINANCIAL_REPORTS: 'view_financial_reports',
  },
  PHARMACY: {
    MANAGE_MEDICINES: 'manage_medicines',
    VIEW_ORDERS: 'view_orders',
    FULFILL_ORDERS: 'fulfill_orders',
    MANAGE_INVENTORY: 'manage_inventory',
  },
  INSURANCE: {
    MANAGE_CLAIMS: 'manage_claims',
    APPROVE_CLAIMS: 'approve_claims',
    VIEW_CLAIMS: 'view_claims',
    REQUEST_DOCUMENTS: 'request_documents',
  },
} as const;

export type Permission = typeof PERMISSIONS[keyof typeof PERMISSIONS][keyof typeof PERMISSIONS[keyof typeof PERMISSIONS]];

export const ROUTE_PERMISSIONS: Record<string, Permission[]> = {
  '/business/dashboard': [PERMISSIONS.GENERAL.VIEW_DASHBOARD],
  '/business/employees': [PERMISSIONS.GENERAL.MANAGE_STAFF],
  '/business/claims': [PERMISSIONS.INSURANCE.VIEW_CLAIMS],
  '/business/sessions': [PERMISSIONS.MEDICAL.MANAGE_SESSIONS],
  '/business/billing': [PERMISSIONS.FINANCIAL.VIEW_INVOICES],
  '/business/analytics': [PERMISSIONS.GENERAL.VIEW_STATISTICS],
  '/business/settings': [PERMISSIONS.GENERAL.MANAGE_SETTINGS],
  '/pharmacy/index': [PERMISSIONS.PHARMACY.MANAGE_MEDICINES],
};

export function getRequiredPermissions(route: string): Permission[] {
  return ROUTE_PERMISSIONS[route] || [];
}
