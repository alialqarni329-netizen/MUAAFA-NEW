import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Permission } from './permissions';

interface UserPermissions {
  permissions: Permission[];
  isOwner: boolean;
  loading: boolean;
}

export function usePermissions(businessId?: string): UserPermissions {
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPermissions();
  }, [businessId]);

  async function loadPermissions() {
    try {
      setLoading(true);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      let actualBusinessId = businessId;

      if (!actualBusinessId) {
        const { data: businessData } = await supabase
          .from('business_registrations')
          .select('id')
          .eq('user_id', user.id)
          .maybeSingle();

        if (businessData) {
          actualBusinessId = businessData.id;
        }
      }

      if (!actualBusinessId) {
        setLoading(false);
        return;
      }

      const { data: ownerCheck } = await supabase
        .from('business_registrations')
        .select('id')
        .eq('id', actualBusinessId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (ownerCheck) {
        setIsOwner(true);
        setPermissions(['*'] as any);
        setLoading(false);
        return;
      }

      const { data: permissionsData } = await supabase
        .rpc('get_user_permissions', {
          p_user_id: user.id,
          p_business_id: actualBusinessId
        });

      if (permissionsData) {
        setPermissions(permissionsData.map((p: any) => p.permission_name));
      }

      setLoading(false);
    } catch (error) {
      console.error('Error loading permissions:', error);
      setLoading(false);
    }
  }

  return { permissions, isOwner, loading };
}

export function hasPermission(
  userPermissions: Permission[],
  isOwner: boolean,
  requiredPermission: Permission | Permission[]
): boolean {
  if (isOwner) return true;

  if (userPermissions.includes('*' as any)) return true;

  if (Array.isArray(requiredPermission)) {
    return requiredPermission.some(perm => userPermissions.includes(perm));
  }

  return userPermissions.includes(requiredPermission);
}

export async function checkPermissionAsync(
  businessId: string,
  permission: Permission
): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { data, error } = await supabase
      .rpc('has_permission', {
        p_user_id: user.id,
        p_business_id: businessId,
        p_permission_name: permission
      });

    if (error) throw error;

    return data === true;
  } catch (error) {
    console.error('Error checking permission:', error);
    return false;
  }
}

export async function logActivity(
  businessId: string,
  action: string,
  resourceType?: string,
  resourceId?: string,
  details?: Record<string, any>
): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.rpc('log_activity', {
      p_user_id: user.id,
      p_business_id: businessId,
      p_action: action,
      p_resource_type: resourceType || null,
      p_resource_id: resourceId || null,
      p_details: details || {}
    });
  } catch (error) {
    console.error('Error logging activity:', error);
  }
}
