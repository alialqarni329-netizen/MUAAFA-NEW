/*
  # إصلاح صلاحيات جدول الرسائل (chat_messages)
  
  ## المشكلة
  - خطأ PGRST2 عند إرسال الرسائل
  - سياسة INSERT لا تتحقق من ملكية المحادثة
  
  ## الحل
  1. حذف سياسة INSERT القديمة
  2. إنشاء سياسة INSERT جديدة مع التحقق من الملكية
  3. إضافة سياسة WITH CHECK للتأكد من أن المحادثة تنتمي للمستخدم
  
  ## الأمان
  - المستخدمون يمكنهم فقط إضافة رسائل في محادثاتهم الخاصة
  - منع إضافة رسائل في محادثات الآخرين
*/

-- حذف السياسة القديمة
DROP POLICY IF EXISTS "Users can create messages in own conversations" ON chat_messages;

-- إنشاء سياسة جديدة مع التحقق الصحيح
CREATE POLICY "Users can insert messages in own conversations"
  ON chat_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM chat_conversations
      WHERE chat_conversations.id = chat_messages.conversation_id
      AND chat_conversations.user_id = auth.uid()
    )
  );

-- التأكد من وجود سياسة UPDATE (إذا احتجنا لها لاحقاً)
DROP POLICY IF EXISTS "Users can update messages in own conversations" ON chat_messages;

CREATE POLICY "Users can update messages in own conversations"
  ON chat_messages
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM chat_conversations
      WHERE chat_conversations.id = chat_messages.conversation_id
      AND chat_conversations.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM chat_conversations
      WHERE chat_conversations.id = chat_messages.conversation_id
      AND chat_conversations.user_id = auth.uid()
    )
  );

-- التأكد من وجود سياسة DELETE
DROP POLICY IF EXISTS "Users can delete messages in own conversations" ON chat_messages;

CREATE POLICY "Users can delete messages in own conversations"
  ON chat_messages
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM chat_conversations
      WHERE chat_conversations.id = chat_messages.conversation_id
      AND chat_conversations.user_id = auth.uid()
    )
  );
