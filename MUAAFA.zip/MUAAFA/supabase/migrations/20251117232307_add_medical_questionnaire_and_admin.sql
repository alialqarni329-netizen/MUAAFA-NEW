/*
  # إضافة ميزات جديدة لـ MOODi Health

  ## الجداول الجديدة

  ### 1. medical_questionnaire
  - `id` (uuid, primary key)
  - `user_id` (uuid, references users)
  - `has_chronic_diseases` (boolean)
  - `chronic_diseases` (text array)
  - `has_allergies` (boolean)
  - `allergies` (text array)
  - `current_medications` (text array)
  - `previous_surgeries` (text array)
  - `family_medical_history` (text)
  - `smoking_status` (text)
  - `alcohol_consumption` (text)
  - `exercise_frequency` (text)
  - `sleep_hours` (integer)
  - `stress_level` (text)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. admin_users
  - `id` (uuid, primary key, references auth.users)
  - `role` (text: 'owner', 'admin', 'moderator')
  - `permissions` (text array)
  - `created_at` (timestamptz)

  ### 3. تحديث sessions
  - إضافة `session_mode` (text: 'instant', 'scheduled')

  ## الأمان
  - RLS على جميع الجداول الجديدة
*/

-- إضافة جدول الاستبيان الطبي
CREATE TABLE IF NOT EXISTS medical_questionnaire (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  has_chronic_diseases boolean DEFAULT false,
  chronic_diseases text[] DEFAULT '{}',
  has_allergies boolean DEFAULT false,
  allergies text[] DEFAULT '{}',
  current_medications text[] DEFAULT '{}',
  previous_surgeries text[] DEFAULT '{}',
  family_medical_history text DEFAULT '',
  smoking_status text DEFAULT 'never' CHECK (smoking_status IN ('never', 'former', 'current')),
  alcohol_consumption text DEFAULT 'never' CHECK (alcohol_consumption IN ('never', 'occasionally', 'regularly')),
  exercise_frequency text DEFAULT 'sedentary' CHECK (exercise_frequency IN ('sedentary', 'light', 'moderate', 'active', 'very_active')),
  sleep_hours integer DEFAULT 7,
  stress_level text DEFAULT 'moderate' CHECK (stress_level IN ('low', 'moderate', 'high', 'very_high')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE medical_questionnaire ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own questionnaire"
  ON medical_questionnaire FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own questionnaire"
  ON medical_questionnaire FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own questionnaire"
  ON medical_questionnaire FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- إضافة جدول المسؤولين
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'moderator' CHECK (role IN ('owner', 'admin', 'moderator')),
  permissions text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view admin users"
  ON admin_users FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = auth.uid()
    )
  );

-- تحديث جدول sessions لإضافة نوع الجلسة
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'sessions' AND column_name = 'session_mode'
  ) THEN
    ALTER TABLE sessions ADD COLUMN session_mode text DEFAULT 'scheduled' CHECK (session_mode IN ('instant', 'scheduled'));
  END IF;
END $$;

-- إنشاء indexes
CREATE INDEX IF NOT EXISTS idx_medical_questionnaire_user_id ON medical_questionnaire(user_id);
CREATE INDEX IF NOT EXISTS idx_admin_users_role ON admin_users(role);
CREATE INDEX IF NOT EXISTS idx_sessions_mode ON sessions(session_mode);
