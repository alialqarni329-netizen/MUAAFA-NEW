/*
  # فرض الدفع قبل التأكيد - قيود حرجة للأمان

  1. التغييرات
    - منع تأكيد الجلسات الطبية بدون دفع
    - منع تأكيد طلبات الصيدلية بدون دفع
    - Triggers للتأكيد التلقائي بعد الدفع
    - Check constraints لضمان الأمان

  2. الأمان
    - لا يمكن تأكيد أي خدمة بدون payment_status = 'paid'
    - يتم التأكيد تلقائياً عند الدفع
    - حماية على مستوى قاعدة البيانات
*/

-- 1. دالة للتأكيد التلقائي للجلسات الطبية بعد الدفع
CREATE OR REPLACE FUNCTION auto_confirm_medical_session()
RETURNS TRIGGER AS $$
BEGIN
  -- عند تغيير payment_status إلى paid
  IF NEW.payment_status = 'paid' AND OLD.payment_status != 'paid' THEN
    -- تأكيد الجلسة تلقائياً
    NEW.session_status := 'confirmed';
    NEW.paid_at := COALESCE(NEW.paid_at, NOW());
    NEW.confirmed_at := NOW();
  END IF;

  -- منع التأكيد بدون دفع
  IF NEW.session_status = 'confirmed' AND NEW.payment_status != 'paid' THEN
    RAISE EXCEPTION 'Cannot confirm session without payment. Payment status must be paid first.';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 2. Trigger على medical_sessions
DROP TRIGGER IF EXISTS enforce_payment_before_session_confirmation ON medical_sessions;
CREATE TRIGGER enforce_payment_before_session_confirmation
  BEFORE UPDATE ON medical_sessions
  FOR EACH ROW
  EXECUTE FUNCTION auto_confirm_medical_session();

-- 3. دالة للتأكيد التلقائي لطلبات الصيدلية بعد الدفع
CREATE OR REPLACE FUNCTION auto_confirm_pharmacy_order()
RETURNS TRIGGER AS $$
BEGIN
  -- عند تغيير payment_status إلى paid
  IF NEW.payment_status = 'paid' AND OLD.payment_status != 'paid' THEN
    -- تأكيد الطلب تلقائياً
    NEW.order_status := 'confirmed';
    NEW.paid_at := COALESCE(NEW.paid_at, NOW());
    NEW.confirmed_at := NOW();
  END IF;

  -- منع التأكيد بدون دفع
  IF NEW.order_status = 'confirmed' AND NEW.payment_status != 'paid' THEN
    RAISE EXCEPTION 'Cannot confirm order without payment. Payment status must be paid first.';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 4. Trigger على pharmacy_orders
DROP TRIGGER IF EXISTS enforce_payment_before_order_confirmation ON pharmacy_orders;
CREATE TRIGGER enforce_payment_before_order_confirmation
  BEFORE UPDATE ON pharmacy_orders
  FOR EACH ROW
  EXECUTE FUNCTION auto_confirm_pharmacy_order();

-- 5. دالة لتوليد الفاتورة تلقائياً بعد الدفع
CREATE OR REPLACE FUNCTION auto_generate_invoice()
RETURNS TRIGGER AS $$
DECLARE
  v_invoice_number TEXT;
  v_total_amount NUMERIC;
  v_reference_type TEXT;
BEGIN
  -- فقط عند تغيير payment_status إلى paid
  IF NEW.payment_status = 'paid' AND OLD.payment_status != 'paid' THEN
    
    -- توليد رقم فاتورة
    SELECT generate_invoice_number() INTO v_invoice_number;
    
    -- تحديد نوع المرجع
    IF TG_TABLE_NAME = 'medical_sessions' THEN
      v_reference_type := 'medical_session';
      v_total_amount := NEW.price;
    ELSIF TG_TABLE_NAME = 'pharmacy_orders' THEN
      v_reference_type := 'pharmacy_order';
      v_total_amount := NEW.total_price;
    END IF;
    
    -- التحقق من عدم وجود فاتورة مسبقاً
    IF NOT EXISTS (
      SELECT 1 FROM invoices
      WHERE reference_type = v_reference_type
      AND reference_id = NEW.id
    ) THEN
      -- إنشاء الفاتورة
      INSERT INTO invoices (
        invoice_number,
        user_id,
        reference_type,
        reference_id,
        amount_paid,
        insurance_covered,
        tax_amount,
        total_amount,
        payment_method,
        invoice_date,
        created_at
      ) VALUES (
        v_invoice_number,
        NEW.user_id,
        v_reference_type,
        NEW.id,
        NEW.user_payable,
        COALESCE(NEW.insurance_covered, 0),
        0,
        v_total_amount,
        COALESCE(NEW.payment_method, 'zedpay'),
        NOW(),
        NOW()
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 6. Triggers لتوليد الفواتير تلقائياً
DROP TRIGGER IF EXISTS auto_generate_invoice_for_session ON medical_sessions;
CREATE TRIGGER auto_generate_invoice_for_session
  AFTER UPDATE ON medical_sessions
  FOR EACH ROW
  EXECUTE FUNCTION auto_generate_invoice();

DROP TRIGGER IF EXISTS auto_generate_invoice_for_order ON pharmacy_orders;
CREATE TRIGGER auto_generate_invoice_for_order
  AFTER UPDATE ON pharmacy_orders
  FOR EACH ROW
  EXECUTE FUNCTION auto_generate_invoice();

-- 7. إضافة أعمدة paid_at و confirmed_at إذا لم تكن موجودة
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'medical_sessions' AND column_name = 'paid_at'
  ) THEN
    ALTER TABLE medical_sessions ADD COLUMN paid_at TIMESTAMPTZ;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'medical_sessions' AND column_name = 'confirmed_at'
  ) THEN
    ALTER TABLE medical_sessions ADD COLUMN confirmed_at TIMESTAMPTZ;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pharmacy_orders' AND column_name = 'paid_at'
  ) THEN
    ALTER TABLE pharmacy_orders ADD COLUMN paid_at TIMESTAMPTZ;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pharmacy_orders' AND column_name = 'confirmed_at'
  ) THEN
    ALTER TABLE pharmacy_orders ADD COLUMN confirmed_at TIMESTAMPTZ;
  END IF;
END $$;

-- 8. إضافة تعليقات
COMMENT ON FUNCTION auto_confirm_medical_session IS 'يمنع تأكيد الجلسات بدون دفع ويؤكدها تلقائياً عند الدفع';
COMMENT ON FUNCTION auto_confirm_pharmacy_order IS 'يمنع تأكيد الطلبات بدون دفع ويؤكدها تلقائياً عند الدفع';
COMMENT ON FUNCTION auto_generate_invoice IS 'يولد الفاتورة تلقائياً بعد الدفع الناجح';

-- 9. إنشاء دالة generate_invoice_number إذا لم تكن موجودة
CREATE OR REPLACE FUNCTION generate_invoice_number()
RETURNS TEXT AS $$
DECLARE
  v_year TEXT;
  v_count INTEGER;
  v_invoice_number TEXT;
BEGIN
  v_year := TO_CHAR(NOW(), 'YYYY');
  
  SELECT COUNT(*) + 1 INTO v_count
  FROM invoices
  WHERE EXTRACT(YEAR FROM invoice_date) = EXTRACT(YEAR FROM NOW());
  
  v_invoice_number := 'INV-' || v_year || '-' || LPAD(v_count::TEXT, 4, '0');
  
  RETURN v_invoice_number;
END;
$$ LANGUAGE plpgsql;

-- 10. منح الصلاحيات
GRANT EXECUTE ON FUNCTION generate_invoice_number TO authenticated;
GRANT EXECUTE ON FUNCTION generate_invoice_number TO service_role;