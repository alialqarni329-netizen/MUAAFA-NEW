/*
  # إصلاح أداء RLS Policies - إصلاح INSERT policies
  
  ## التحسينات
  
  ### إصلاح INSERT policies
  استخدام WITH CHECK بدلاً من USING في INSERT policies
  
  ## الجداول المحدثة
  - users
  - business_registrations
  - business_verification
  - subscription_payments
  - health_questions
  - bot_responses
  - forms
  - policies
  - questionnaire_responses
  - ip_restrictions
*/

-- users table
DROP POLICY IF EXISTS "Users can update own profile" ON users;
CREATE POLICY "Users can update own profile"
  ON users
  FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = id)
  WITH CHECK ((select auth.uid()) = id);

-- business_registrations
DROP POLICY IF EXISTS "Owners can update business registrations" ON business_registrations;
CREATE POLICY "Owners can update business registrations"
  ON business_registrations
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Owners can view all business registrations" ON business_registrations;
CREATE POLICY "Owners can view all business registrations"
  ON business_registrations
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- business_verification
DROP POLICY IF EXISTS "Admins can manage all verifications" ON business_verification;
CREATE POLICY "Admins can manage all verifications"
  ON business_verification
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role IN ('owner', 'business_admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role IN ('owner', 'business_admin')
    )
  );

-- subscription_payments
DROP POLICY IF EXISTS "Admins can view all subscription payments" ON subscription_payments;
CREATE POLICY "Admins can view all subscription payments"
  ON subscription_payments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role IN ('owner', 'business_admin')
    )
  );

DROP POLICY IF EXISTS "Users can create own subscription payments" ON subscription_payments;
CREATE POLICY "Users can create own subscription payments"
  ON subscription_payments
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can view own subscription payments" ON subscription_payments;
CREATE POLICY "Users can view own subscription payments"
  ON subscription_payments
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

-- health_questions
DROP POLICY IF EXISTS "Allow owner to manage health questions" ON health_questions;
CREATE POLICY "Allow owner to manage health questions"
  ON health_questions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owner to update health questions" ON health_questions;
CREATE POLICY "Allow owner to update health questions"
  ON health_questions
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owner to view health questions" ON health_questions;
CREATE POLICY "Allow owner to view health questions"
  ON health_questions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- bot_responses
DROP POLICY IF EXISTS "Allow owner to manage bot responses" ON bot_responses;
CREATE POLICY "Allow owner to manage bot responses"
  ON bot_responses
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owner to update bot responses" ON bot_responses;
CREATE POLICY "Allow owner to update bot responses"
  ON bot_responses
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owner to view bot responses" ON bot_responses;
CREATE POLICY "Allow owner to view bot responses"
  ON bot_responses
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- forms
DROP POLICY IF EXISTS "Allow owner to manage forms" ON forms;
CREATE POLICY "Allow owner to manage forms"
  ON forms
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owner to update forms" ON forms;
CREATE POLICY "Allow owner to update forms"
  ON forms
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owner to view forms" ON forms;
CREATE POLICY "Allow owner to view forms"
  ON forms
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- policies
DROP POLICY IF EXISTS "Allow owner to manage policies" ON policies;
CREATE POLICY "Allow owner to manage policies"
  ON policies
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owner to update policies" ON policies;
CREATE POLICY "Allow owner to update policies"
  ON policies
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owner to view policies" ON policies;
CREATE POLICY "Allow owner to view policies"
  ON policies
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- content_limits
DROP POLICY IF EXISTS "Allow owner to view content limits" ON content_limits;
CREATE POLICY "Allow owner to view content limits"
  ON content_limits
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- content_reviews
DROP POLICY IF EXISTS "Allow owner to view content reviews" ON content_reviews;
CREATE POLICY "Allow owner to view content reviews"
  ON content_reviews
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- questionnaire_responses
DROP POLICY IF EXISTS "Allow users to submit responses" ON questionnaire_responses;
CREATE POLICY "Allow users to submit responses"
  ON questionnaire_responses
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Allow users to view their own responses" ON questionnaire_responses;
CREATE POLICY "Allow users to view their own responses"
  ON questionnaire_responses
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

-- failed_login_attempts
DROP POLICY IF EXISTS "Allow owners to view failed login attempts" ON failed_login_attempts;
CREATE POLICY "Allow owners to view failed login attempts"
  ON failed_login_attempts
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- user_sessions
DROP POLICY IF EXISTS "Allow owners to view sessions" ON user_sessions;
CREATE POLICY "Allow owners to view sessions"
  ON user_sessions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- ip_restrictions
DROP POLICY IF EXISTS "Allow owners to delete IP restrictions" ON ip_restrictions;
CREATE POLICY "Allow owners to delete IP restrictions"
  ON ip_restrictions
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owners to insert IP restrictions" ON ip_restrictions;
CREATE POLICY "Allow owners to insert IP restrictions"
  ON ip_restrictions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owners to update IP restrictions" ON ip_restrictions;
CREATE POLICY "Allow owners to update IP restrictions"
  ON ip_restrictions
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Allow owners to view IP restrictions" ON ip_restrictions;
CREATE POLICY "Allow owners to view IP restrictions"
  ON ip_restrictions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );

-- security_metrics
DROP POLICY IF EXISTS "Allow owners to view security metrics" ON security_metrics;
CREATE POLICY "Allow owners to view security metrics"
  ON security_metrics
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = (select auth.uid()) 
      AND users.user_role = 'owner'
    )
  );
