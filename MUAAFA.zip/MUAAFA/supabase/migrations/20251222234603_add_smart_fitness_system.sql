-- Smart Fitness System Migration
-- Creates tables for AI-powered fitness coaching

-- Health Scans Table (for face/body scanning)
CREATE TABLE IF NOT EXISTS health_scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  scan_type text CHECK (scan_type IN ('face', 'body', 'vitals')) DEFAULT 'face',
  stress_level integer CHECK (stress_level BETWEEN 1 AND 10) DEFAULT 5,
  hydration_level integer CHECK (hydration_level BETWEEN 1 AND 10) DEFAULT 5,
  fatigue_level integer CHECK (fatigue_level BETWEEN 1 AND 10) DEFAULT 5,
  skin_condition text,
  heart_rate integer,
  blood_pressure text,
  recommendations jsonb DEFAULT '[]'::jsonb,
  scan_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE health_scans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own health scans"
  ON health_scans FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own health scans"
  ON health_scans FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- AI Fitness Recommendations Table
CREATE TABLE IF NOT EXISTS fitness_ai_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  recommendation_type text CHECK (recommendation_type IN ('workout', 'rest', 'hydration', 'nutrition', 'stretching')) NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  reason text,
  priority integer DEFAULT 1 CHECK (priority BETWEEN 1 AND 5),
  based_on_scan_id uuid REFERENCES health_scans(id),
  is_read boolean DEFAULT false,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fitness_ai_recommendations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own recommendations"
  ON fitness_ai_recommendations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own recommendations"
  ON fitness_ai_recommendations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Fitness Coupons Table
CREATE TABLE IF NOT EXISTS fitness_coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  coupon_code text UNIQUE NOT NULL,
  discount_type text CHECK (discount_type IN ('percentage', 'fixed')) DEFAULT 'percentage',
  discount_value numeric(10,2) NOT NULL,
  earned_from_steps integer DEFAULT 0,
  earned_from_calories integer DEFAULT 0,
  min_purchase_amount numeric(10,2) DEFAULT 0,
  status text CHECK (status IN ('active', 'used', 'expired')) DEFAULT 'active',
  used_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fitness_coupons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own coupons"
  ON fitness_coupons FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own coupons"
  ON fitness_coupons FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Smart Nudges Table
CREATE TABLE IF NOT EXISTS fitness_nudges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  nudge_type text CHECK (nudge_type IN ('movement', 'water', 'rest', 'achievement', 'goal_reminder')) NOT NULL,
  message text NOT NULL,
  triggered_at timestamptz DEFAULT now(),
  trigger_reason text,
  is_shown boolean DEFAULT false,
  shown_at timestamptz
);

ALTER TABLE fitness_nudges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own nudges"
  ON fitness_nudges FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own nudges"
  ON fitness_nudges FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Workout Types Table
CREATE TABLE IF NOT EXISTS workout_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar text NOT NULL,
  name_en text NOT NULL,
  icon text,
  category text CHECK (category IN ('cardio', 'strength', 'flexibility', 'sports', 'other')) DEFAULT 'other',
  calories_per_hour integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE workout_types ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view workout types"
  ON workout_types FOR SELECT
  TO authenticated
  USING (is_active = true);

-- Insert default workout types
INSERT INTO workout_types (name_ar, name_en, icon, category, calories_per_hour) VALUES
  ('المشي', 'Walking', 'footprints', 'cardio', 200),
  ('الجري', 'Running', 'flame', 'cardio', 600),
  ('السباحة', 'Swimming', 'waves', 'cardio', 500),
  ('ركوب الدراجة', 'Cycling', 'bike', 'cardio', 400),
  ('حمل الأثقال', 'Weight Lifting', 'dumbbell', 'strength', 300),
  ('اليوغا', 'Yoga', 'lotus', 'flexibility', 150),
  ('تمارين الإطالة', 'Stretching', 'stretching', 'flexibility', 100),
  ('كرة القدم', 'Football', 'football', 'sports', 550),
  ('كرة السلة', 'Basketball', 'basketball', 'sports', 600),
  ('التمارين المنزلية', 'Home Workout', 'home', 'other', 250)
ON CONFLICT DO NOTHING;

-- Add fields to fitness_activities for better tracking
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'fitness_activities' AND column_name = 'water_intake_ml'
  ) THEN
    ALTER TABLE fitness_activities ADD COLUMN water_intake_ml integer DEFAULT 0;
    ALTER TABLE fitness_activities ADD COLUMN shared_with_doctor boolean DEFAULT false;
    ALTER TABLE fitness_activities ADD COLUMN mood text CHECK (mood IN ('excellent', 'good', 'okay', 'tired', 'stressed'));
  END IF;
END $$;

-- Add loyalty points source tracking
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'loyalty_points' AND column_name = 'fitness_earnings'
  ) THEN
    ALTER TABLE loyalty_points ADD COLUMN fitness_earnings integer DEFAULT 0;
    ALTER TABLE loyalty_points ADD COLUMN last_fitness_sync timestamptz;
  END IF;
END $$;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_health_scans_user_created ON health_scans(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_fitness_ai_recommendations_user_priority ON fitness_ai_recommendations(user_id, priority DESC, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_fitness_coupons_user_status ON fitness_coupons(user_id, status);
CREATE INDEX IF NOT EXISTS idx_fitness_nudges_user_shown ON fitness_nudges(user_id, is_shown);
CREATE INDEX IF NOT EXISTS idx_fitness_activities_user_date ON fitness_activities(user_id, activity_date DESC);