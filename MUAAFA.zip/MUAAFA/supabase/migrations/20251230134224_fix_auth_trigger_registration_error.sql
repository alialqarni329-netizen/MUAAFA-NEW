/*
  # Fix Authentication Trigger for Registration

  ## Problem
  The current trigger function `handle_new_user` was trying to access fields incorrectly:
  - It tried to read `NEW.phone` directly (which doesn't exist during signUp)
  - It tried to cast `user_role` from metadata which might not be in correct format

  ## Solution
  1. Update the trigger function to read phone from raw_user_meta_data
  2. Handle role casting more gracefully with proper error handling
  3. Set default values when metadata fields are missing

  ## Changes
  - Modified `handle_new_user()` function to read phone from metadata
  - Added proper role handling with fallback to 'individual_user'
  - Improved error handling
*/

-- Drop existing trigger first
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Drop and recreate the function with fixes
DROP FUNCTION IF EXISTS handle_new_user CASCADE;

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_phone TEXT;
  v_full_name TEXT;
  v_user_role user_role;
BEGIN
  -- Extract phone from metadata
  v_phone := COALESCE(NEW.raw_user_meta_data->>'phone', '');
  
  -- Extract full_name from metadata
  v_full_name := COALESCE(NEW.raw_user_meta_data->>'full_name', '');
  
  -- Extract and cast role with proper error handling
  BEGIN
    IF NEW.raw_user_meta_data->>'user_role' IS NOT NULL THEN
      v_user_role := (NEW.raw_user_meta_data->>'user_role')::user_role;
    ELSIF NEW.raw_user_meta_data->>'role' = 'individual' THEN
      v_user_role := 'individual_user'::user_role;
    ELSIF NEW.raw_user_meta_data->>'account_type' = 'business' THEN
      v_user_role := 'business_admin'::user_role;
    ELSE
      v_user_role := 'individual_user'::user_role;
    END IF;
  EXCEPTION WHEN OTHERS THEN
    -- Default to individual_user if casting fails
    v_user_role := 'individual_user'::user_role;
  END;
  
  -- Insert or update user in public.users table
  INSERT INTO public.users (
    id,
    email,
    phone,
    full_name,
    user_role,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    NEW.email,
    v_phone,
    v_full_name,
    v_user_role,
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = COALESCE(EXCLUDED.email, users.email),
    phone = CASE 
      WHEN EXCLUDED.phone != '' THEN EXCLUDED.phone 
      ELSE users.phone 
    END,
    full_name = CASE 
      WHEN EXCLUDED.full_name != '' THEN EXCLUDED.full_name 
      ELSE users.full_name 
    END,
    user_role = EXCLUDED.user_role,
    updated_at = NOW();
  
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log error but don't fail the auth.users insert
  RAISE WARNING 'Error in handle_new_user: %', SQLERRM;
  RETURN NEW;
END;
$$;

-- Recreate the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Add comment
COMMENT ON FUNCTION handle_new_user IS 'Automatically creates or updates user record in public.users when auth.users row is inserted';
