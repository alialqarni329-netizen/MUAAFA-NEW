/*
  # تحسين نظام الاشتراكات والدفع
  
  ## التحديثات:
  
  1. تحديث جدول subscription_plans:
     - إضافة حقول اللغة العربية والإنجليزية
     - إضافة نوع الباقة (free, premium, enterprise)
     - تحديث الميزات
  
  2. تحديث جدول user_subscriptions:
     - إضافة حقول التجديد التلقائي
     - تحسين الحقول الموجودة
  
  3. إنشاء جدول payment_transactions:
     - سجل المعاملات المالية
     - دعم Apple Pay و Mada
  
  4. تحديث جدول cart_items:
     - دعم أنواع متعددة (subscription, medication, service)
  
  5. تحديث جدول users:
     - إضافة حقول الاشتراك
  
  ## الأمان:
  - Row Level Security على جميع الجداول
  - سياسات محدودة للمستخدمين
*/

-- تحديث جدول subscription_plans
DO $$
BEGIN
  -- إضافة حقول اللغة العربية
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscription_plans' AND column_name = 'name_ar'
  ) THEN
    ALTER TABLE subscription_plans ADD COLUMN name_ar text;
    ALTER TABLE subscription_plans ADD COLUMN name_en text;
    ALTER TABLE subscription_plans ADD COLUMN description_ar text;
    ALTER TABLE subscription_plans ADD COLUMN description_en text;
  END IF;
  
  -- إضافة نوع الباقة
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscription_plans' AND column_name = 'plan_type'
  ) THEN
    ALTER TABLE subscription_plans ADD COLUMN plan_type text DEFAULT 'premium';
  END IF;
  
  -- إضافة ترتيب العرض
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscription_plans' AND column_name = 'sort_order'
  ) THEN
    ALTER TABLE subscription_plans ADD COLUMN sort_order integer DEFAULT 0;
  END IF;
END $$;

-- تحديث جدول user_subscriptions
DO $$
BEGIN
  -- إعادة تسمية الحقول إذا لزم الأمر
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_subscriptions' AND column_name = 'current_period_start'
  ) THEN
    ALTER TABLE user_subscriptions RENAME COLUMN current_period_start TO start_date;
    ALTER TABLE user_subscriptions RENAME COLUMN current_period_end TO end_date;
  END IF;
  
  -- إضافة حقل التجديد التلقائي
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_subscriptions' AND column_name = 'auto_renew'
  ) THEN
    ALTER TABLE user_subscriptions ADD COLUMN auto_renew boolean DEFAULT true;
  END IF;
END $$;

-- إنشاء جدول payment_transactions
CREATE TABLE IF NOT EXISTS payment_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  subscription_id uuid REFERENCES user_subscriptions(id) ON DELETE SET NULL,
  amount numeric(10,2) NOT NULL,
  currency text DEFAULT 'SAR',
  payment_method text NOT NULL CHECK (payment_method IN ('apple_pay', 'mada', 'visa', 'mastercard', 'stc_pay')),
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending', 'completed', 'failed', 'refunded')),
  transaction_id text,
  invoice_url text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- تحديث جدول users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'subscription_status'
  ) THEN
    ALTER TABLE users ADD COLUMN subscription_status text DEFAULT 'free';
    ALTER TABLE users ADD COLUMN subscription_end_date timestamptz;
  END IF;
END $$;

-- تفعيل RLS على payment_transactions
ALTER TABLE payment_transactions ENABLE ROW LEVEL SECURITY;

-- سياسات payment_transactions
DROP POLICY IF EXISTS "Users can view own transactions" ON payment_transactions;
CREATE POLICY "Users can view own transactions"
  ON payment_transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can create transactions" ON payment_transactions;
CREATE POLICY "Users can create transactions"
  ON payment_transactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- إنشاء فهارس للأداء
CREATE INDEX IF NOT EXISTS idx_payment_transactions_user_id ON payment_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_status ON payment_transactions(payment_status);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_subscription_id ON payment_transactions(subscription_id);

-- تحديث باقات الاشتراك بالبيانات العربية
UPDATE subscription_plans
SET 
  name_ar = CASE 
    WHEN name = 'مُعافى الأساسية' THEN 'مُعافى الأساسية'
    WHEN name LIKE '%Basic%' OR name LIKE '%أساسية%' THEN 'مُعافى الأساسية'
    WHEN name LIKE '%Premium%' OR name LIKE '%بريميوم%' THEN 'مُعافى بريميوم'
    ELSE name
  END,
  name_en = CASE
    WHEN name = 'مُعافى الأساسية' THEN 'Muafa Basic'
    WHEN name LIKE '%Basic%' OR name LIKE '%أساسية%' THEN 'Muafa Basic'
    WHEN name LIKE '%Premium%' OR name LIKE '%بريميوم%' THEN 'Muafa Premium'
    ELSE name
  END,
  plan_type = CASE
    WHEN price_monthly = 0 THEN 'free'
    ELSE 'premium'
  END
WHERE name_ar IS NULL;

-- إدراج باقات الاشتراك الافتراضية إذا كانت الجداول فارغة
INSERT INTO subscription_plans (name, name_ar, name_en, description, description_ar, description_en, price_monthly, price_yearly, plan_type, features, sort_order)
SELECT 
  'مُعافى الأساسية',
  'مُعافى الأساسية',
  'Muafa Basic',
  'الباقة المجانية مع الميزات الأساسية',
  'الباقة المجانية مع الميزات الأساسية',
  'Free plan with basic features',
  0,
  0,
  'free',
  '[
    {"ar": "استشارات محدودة شهرياً", "en": "Limited monthly consultations", "included": true},
    {"ar": "خصومات صيدلية أساسية", "en": "Basic pharmacy discounts", "included": true},
    {"ar": "تحليل الوجه مرة واحدة", "en": "One-time face analysis", "included": true},
    {"ar": "الوصول للتقارير الطبية", "en": "Access to medical reports", "included": true}
  ]'::jsonb,
  1
WHERE NOT EXISTS (SELECT 1 FROM subscription_plans WHERE plan_type = 'free');

INSERT INTO subscription_plans (name, name_ar, name_en, description, description_ar, description_en, price_monthly, price_yearly, plan_type, features, sort_order)
SELECT
  'مُعافى بريميوم',
  'مُعافى بريميوم',
  'Muafa Premium',
  'الباقة المميزة مع مزايا غير محدودة',
  'الباقة المميزة مع مزايا غير محدودة',
  'Premium plan with unlimited features',
  49.99,
  499.99,
  'premium',
  '[
    {"ar": "استشارات فيديو غير محدودة", "en": "Unlimited video consultations", "included": true},
    {"ar": "خصومات صيدلية تصل إلى 30%", "en": "Pharmacy discounts up to 30%", "included": true},
    {"ar": "تحليل وجه غير محدود", "en": "Unlimited face analysis", "included": true},
    {"ar": "تحليل طبي ذكي بالـ AI", "en": "AI-powered medical analysis", "included": true},
    {"ar": "أولوية في الحجز", "en": "Priority booking", "included": true},
    {"ar": "تقارير صحية مفصلة", "en": "Detailed health reports", "included": true}
  ]'::jsonb,
  2
WHERE NOT EXISTS (SELECT 1 FROM subscription_plans WHERE plan_type = 'premium');
