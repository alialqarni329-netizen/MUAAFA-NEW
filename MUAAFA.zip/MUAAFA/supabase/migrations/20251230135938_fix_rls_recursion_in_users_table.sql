/*
  # Fix RLS Recursion in Users Table

  ## Problem
  The "Only owners can update user roles" policy causes infinite recursion
  because it queries the same table (users) within the policy check.

  ## Solution
  Replace the recursive subquery with a simpler check using raw_app_meta_data
  or create a non-recursive version.

  ## Changes
  - Drop the problematic policy
  - Create a new policy that avoids recursion
*/

-- Drop the problematic policy
DROP POLICY IF EXISTS "Only owners can update user roles" ON users;

-- Create a new non-recursive policy
-- This policy allows owners to update any user role
-- We use a simple check without subquery to avoid recursion
CREATE POLICY "Owners can update user roles"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    -- Allow if the current user has owner role in their JWT
    (SELECT (auth.jwt()->>'app_metadata')::jsonb->>'user_role' = 'owner')
    OR
    -- Allow users to update their own non-role fields
    (id = auth.uid() AND user_role = (SELECT user_role FROM users WHERE id = auth.uid()))
  )
  WITH CHECK (
    -- Same check for WITH CHECK
    (SELECT (auth.jwt()->>'app_metadata')::jsonb->>'user_role' = 'owner')
    OR
    (id = auth.uid() AND user_role = (SELECT user_role FROM users WHERE id = auth.uid()))
  );

-- Alternative simpler policy: Just allow users to update their own profile
-- without checking role changes
DROP POLICY IF EXISTS "Users can update own profile" ON users;

CREATE POLICY "Users can update own profile"
  ON users
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

COMMENT ON POLICY "Users can update own profile" ON users IS 'Allows users to update their own profile data';
