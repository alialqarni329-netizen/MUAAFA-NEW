/*
  # إضافة حقل رقم الهوية للمستخدمين

  1. التعديلات
    - إضافة عمود `national_id` في جدول `users`
    - حقل رقم الهوية اختياري (nullable) للمستخدمين الحاليين
    - تحديث الفهارس للبحث السريع

  2. الأمان
    - RLS موجود بالفعل على جدول users
    - لا تغيير في السياسات الأمنية
*/

-- إضافة حقل رقم الهوية
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'national_id'
  ) THEN
    ALTER TABLE users ADD COLUMN national_id text;
  END IF;
END $$;

-- إضافة فهرس للبحث السريع برقم الهوية
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE tablename = 'users' AND indexname = 'idx_users_national_id'
  ) THEN
    CREATE INDEX idx_users_national_id ON users(national_id);
  END IF;
END $$;
