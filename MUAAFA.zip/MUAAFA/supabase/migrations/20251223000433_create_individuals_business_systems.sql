-- Complete Individuals and Business Systems Migration
-- Creates comprehensive onboarding and management systems

-- Health Profiles Table (Individual System)
CREATE TABLE IF NOT EXISTS health_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) UNIQUE NOT NULL,
  full_name text NOT NULL,
  phone text NOT NULL,
  date_of_birth date NOT NULL,
  gender text CHECK (gender IN ('male', 'female')) NOT NULL,
  height_cm integer,
  weight_kg numeric(5,2),
  blood_type text CHECK (blood_type IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')),
  chronic_diseases text[] DEFAULT '{}',
  drug_allergies text[] DEFAULT '{}',
  food_allergies text[] DEFAULT '{}',
  current_medications jsonb DEFAULT '[]',
  emergency_contact_name text,
  emergency_contact_phone text,
  national_id text,
  insurance_details jsonb DEFAULT '{}',
  terms_accepted boolean DEFAULT false,
  terms_accepted_at timestamptz,
  privacy_accepted boolean DEFAULT false,
  privacy_accepted_at timestamptz,
  onboarding_completed boolean DEFAULT false,
  onboarding_completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE health_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own health profile"
  ON health_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own health profile"
  ON health_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own health profile"
  ON health_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Permissions Table
CREATE TABLE IF NOT EXISTS user_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) UNIQUE NOT NULL,
  camera_permission boolean DEFAULT false,
  location_permission boolean DEFAULT false,
  notifications_permission boolean DEFAULT false,
  photos_permission boolean DEFAULT false,
  camera_granted_at timestamptz,
  location_granted_at timestamptz,
  notifications_granted_at timestamptz,
  photos_granted_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own permissions"
  ON user_permissions FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Business Verification Table
CREATE TABLE IF NOT EXISTS business_verification (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) UNIQUE NOT NULL,
  business_type text CHECK (business_type IN ('pharmacy', 'hospital', 'delivery', 'insurance')) NOT NULL,
  business_name text NOT NULL,
  commercial_registration text UNIQUE NOT NULL,
  health_license text,
  headquarters_location text NOT NULL,
  headquarters_latitude numeric(10, 6),
  headquarters_longitude numeric(10, 6),
  admin_contact_phone text NOT NULL,
  admin_contact_email text NOT NULL,
  verification_status text CHECK (verification_status IN ('pending', 'active', 'rejected', 'suspended')) DEFAULT 'pending',
  verification_documents jsonb DEFAULT '[]',
  verified_by uuid REFERENCES auth.users(id),
  verified_at timestamptz,
  rejection_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE business_verification ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Business users can view own verification"
  ON business_verification FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Business users can insert own verification"
  ON business_verification FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage all verifications"
  ON business_verification FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = auth.uid()
    )
  );

-- Pharmacy Inventory Management
CREATE TABLE IF NOT EXISTS pharmacy_stock (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pharmacy_id uuid REFERENCES business_verification(id) NOT NULL,
  medication_name text NOT NULL,
  medication_barcode text,
  scientific_name text,
  quantity integer DEFAULT 0,
  price numeric(10,2) NOT NULL,
  requires_prescription boolean DEFAULT false,
  expiry_date date,
  category text,
  manufacturer text,
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE pharmacy_stock ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Pharmacies can manage own stock"
  ON pharmacy_stock FOR ALL
  TO authenticated
  USING (
    pharmacy_id IN (
      SELECT id FROM business_verification
      WHERE user_id = auth.uid()
      AND business_type = 'pharmacy'
      AND verification_status = 'active'
    )
  );

CREATE POLICY "Users can view available pharmacy stock"
  ON pharmacy_stock FOR SELECT
  TO authenticated
  USING (is_available = true);

-- Delivery Assignments Table
CREATE TABLE IF NOT EXISTS delivery_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) NOT NULL,
  delivery_company_id uuid REFERENCES business_verification(id) NOT NULL,
  driver_user_id uuid REFERENCES auth.users(id),
  driver_name text,
  driver_phone text,
  vehicle_type text,
  vehicle_plate text,
  status text CHECK (status IN ('assigned', 'picked_up', 'in_transit', 'delivered', 'cancelled')) DEFAULT 'assigned',
  assigned_at timestamptz DEFAULT now(),
  picked_up_at timestamptz,
  delivered_at timestamptz,
  current_latitude numeric(10, 6),
  current_longitude numeric(10, 6),
  estimated_arrival timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE delivery_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own delivery assignments"
  ON delivery_assignments FOR SELECT
  TO authenticated
  USING (
    order_id IN (SELECT id FROM orders WHERE user_id = auth.uid())
    OR driver_user_id = auth.uid()
    OR delivery_company_id IN (
      SELECT id FROM business_verification WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Delivery companies can manage own assignments"
  ON delivery_assignments FOR ALL
  TO authenticated
  USING (
    delivery_company_id IN (
      SELECT id FROM business_verification
      WHERE user_id = auth.uid()
      AND business_type = 'delivery'
      AND verification_status = 'active'
    )
  );

-- Order Timeline Table
CREATE TABLE IF NOT EXISTS order_timeline (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) NOT NULL,
  status text NOT NULL,
  title text NOT NULL,
  description text,
  icon text,
  created_by uuid REFERENCES auth.users(id),
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_timeline ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own order timeline"
  ON order_timeline FOR SELECT
  TO authenticated
  USING (
    order_id IN (
      SELECT id FROM orders WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Business users can view relevant order timeline"
  ON order_timeline FOR SELECT
  TO authenticated
  USING (
    order_id IN (
      SELECT o.id FROM orders o
      JOIN business_verification bv ON (
        (bv.id = o.pharmacy_id)
      )
      WHERE bv.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM delivery_assignments da
        WHERE da.order_id = o.id
        AND da.driver_user_id = auth.uid()
      )
    )
  );

-- Pharmacy Order Requests
CREATE TABLE IF NOT EXISTS pharmacy_order_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) NOT NULL,
  pharmacy_id uuid REFERENCES business_verification(id) NOT NULL,
  status text CHECK (status IN ('pending', 'accepted', 'rejected', 'preparing', 'ready')) DEFAULT 'pending',
  estimated_preparation_time integer,
  rejection_reason text,
  accepted_at timestamptz,
  ready_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE pharmacy_order_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view requests for own orders"
  ON pharmacy_order_requests FOR SELECT
  TO authenticated
  USING (
    order_id IN (SELECT id FROM orders WHERE user_id = auth.uid())
  );

CREATE POLICY "Pharmacies can manage own requests"
  ON pharmacy_order_requests FOR ALL
  TO authenticated
  USING (
    pharmacy_id IN (
      SELECT id FROM business_verification
      WHERE user_id = auth.uid()
      AND business_type = 'pharmacy'
      AND verification_status = 'active'
    )
  );

-- Notifications Table
CREATE TABLE IF NOT EXISTS app_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  data jsonb DEFAULT '{}',
  is_read boolean DEFAULT false,
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE app_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications"
  ON app_notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications"
  ON app_notifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_health_profiles_user_id ON health_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_business_verification_user_status ON business_verification(user_id, verification_status);
CREATE INDEX IF NOT EXISTS idx_pharmacy_stock_pharmacy_available ON pharmacy_stock(pharmacy_id, is_available);
CREATE INDEX IF NOT EXISTS idx_order_timeline_order_created ON order_timeline(order_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_delivery_assignments_order_status ON delivery_assignments(order_id, status);
CREATE INDEX IF NOT EXISTS idx_pharmacy_order_requests_status ON pharmacy_order_requests(pharmacy_id, status);
CREATE INDEX IF NOT EXISTS idx_app_notifications_user_read ON app_notifications(user_id, is_read, created_at DESC);