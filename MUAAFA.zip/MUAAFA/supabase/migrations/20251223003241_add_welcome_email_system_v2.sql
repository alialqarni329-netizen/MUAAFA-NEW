/*
  # نظام رسائل الترحيب للعملاء الجدد (v2)
  # Welcome Email System for New Customers (v2)
  
  1. New Tables
    - email_templates: قوالب البريد الإلكتروني
    - email_logs: سجل رسائل البريد المرسلة
    
  2. Functions
    - send_welcome_notification: إرسال إشعار ترحيب تلقائي
    
  3. Triggers
    - trigger_welcome_notification: يُفعّل عند إنشاء مستخدم جديد في auth.users
    
  4. Security
    - Enable RLS on all tables
    - Proper policies for admins only
*/

-- Email Templates Table
CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_key text UNIQUE NOT NULL,
  template_type text CHECK (template_type IN ('welcome', 'verification', 'notification', 'marketing')) NOT NULL,
  subject_ar text NOT NULL,
  subject_en text NOT NULL,
  body_ar text NOT NULL,
  body_en text NOT NULL,
  variables jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only admins can manage email templates"
  ON email_templates FOR ALL
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admin_users WHERE id = auth.uid())
  );

-- Email Logs Table
CREATE TABLE IF NOT EXISTS email_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  template_key text,
  recipient_email text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  status text CHECK (status IN ('pending', 'sent', 'failed', 'bounced')) DEFAULT 'pending',
  error_message text,
  sent_at timestamptz,
  opened_at timestamptz,
  clicked_at timestamptz,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE email_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own email logs"
  ON email_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all email logs"
  ON email_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admin_users WHERE id = auth.uid())
  );

CREATE POLICY "System can create email logs"
  ON email_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Insert Welcome Email Template (Arabic & English)
INSERT INTO email_templates (
  template_key,
  template_type,
  subject_ar,
  subject_en,
  body_ar,
  body_en,
  variables,
  is_active
) VALUES (
  'welcome_email',
  'welcome',
  'أهلاً بك في مُعافى | رحلتك نحو صحة أذكى تبدأ الآن 🛡️',
  'Welcome to Muaafa | Your Journey to Smarter Healthcare Starts Now 🛡️',
  
  -- Arabic Body
  'أهلاً بك {{user_name}}،

شكراً لانضمامك إلى مُعافى | MUAAFA، الشريك الرقمي الذي يضع صحتك في مقدمة أولوياته. نحن هنا لنغير مفهوم الرعاية الصحية ونجعلها في متناول يدك دائماً.

ماذا يمكنك أن تفعل الآن؟

✨ تحدث مع مساعدك الذكي: ابدأ أول دردشة صحية للحصول على إرشادات توعوية فورية.

💊 اكتشف الصيدلية الذكية: قارن أسعار الأدوية واطلب وصفاتك بضغطة زر.

📋 جهز ملفك الصحي: ارفع تقاريرك ووثق بيانات تأمينك لضمان تجربة سلسة.

نحن نعدك بالخصوصية التامة والابتكار المستمر. إذا كان لديك أي استفسار، فريقنا جاهز لخدمتك.

دمت مُعافى،
فريق تطبيق مُعافى

---
تطبيق مُعافى | MUAAFA
المملكة العربية السعودية
support@muaafa.app',

  -- English Body
  'Welcome {{user_name}},

Thank you for joining Muaafa | MUAAFA, your digital healthcare partner that puts your health first. We are here to transform healthcare and make it always at your fingertips.

What can you do now?

✨ Talk to Your Smart Assistant: Start your first health chat for instant health guidance.

💊 Discover the Smart Pharmacy: Compare medicine prices and order your prescriptions with one tap.

📋 Prepare Your Health File: Upload your reports and document your insurance data for a seamless experience.

We promise you complete privacy and continuous innovation. If you have any questions, our team is ready to serve you.

Stay Healthy,
Muaafa App Team

---
Muaafa App | مُعافى
Kingdom of Saudi Arabia
support@muaafa.app',

  '{"user_name": "string"}'::jsonb,
  true
) ON CONFLICT (template_key) DO UPDATE SET
  subject_ar = EXCLUDED.subject_ar,
  subject_en = EXCLUDED.subject_en,
  body_ar = EXCLUDED.body_ar,
  body_en = EXCLUDED.body_en,
  updated_at = now();

-- Additional Email Templates

-- Verification Email
INSERT INTO email_templates (
  template_key,
  template_type,
  subject_ar,
  subject_en,
  body_ar,
  body_en,
  variables,
  is_active
) VALUES (
  'email_verification',
  'verification',
  'تأكيد بريدك الإلكتروني - مُعافى',
  'Verify Your Email - Muaafa',
  
  'مرحباً {{user_name}},

يرجى النقر على الرابط أدناه لتأكيد بريدك الإلكتروني:

{{verification_link}}

هذا الرابط صالح لمدة 24 ساعة.

إذا لم تقم بإنشاء هذا الحساب، يرجى تجاهل هذا البريد.

فريق مُعافى',

  'Hello {{user_name}},

Please click the link below to verify your email address:

{{verification_link}}

This link is valid for 24 hours.

If you did not create this account, please ignore this email.

Muaafa Team',

  '{"user_name": "string", "verification_link": "url"}'::jsonb,
  true
) ON CONFLICT (template_key) DO NOTHING;

-- Order Confirmation Email
INSERT INTO email_templates (
  template_key,
  template_type,
  subject_ar,
  subject_en,
  body_ar,
  body_en,
  variables,
  is_active
) VALUES (
  'order_confirmation',
  'notification',
  'تأكيد طلبك #{{order_number}} - مُعافى',
  'Order Confirmation #{{order_number}} - Muaafa',
  
  'عزيزي {{user_name}},

تم استلام طلبك بنجاح!

رقم الطلب: {{order_number}}
المبلغ الإجمالي: {{total_amount}} ريال
الحالة: {{status}}

يمكنك تتبع طلبك من خلال التطبيق.

شكراً لثقتك بمُعافى!

فريق مُعافى',

  'Dear {{user_name}},

Your order has been received successfully!

Order Number: {{order_number}}
Total Amount: {{total_amount}} SAR
Status: {{status}}

You can track your order through the app.

Thank you for trusting Muaafa!

Muaafa Team',

  '{"user_name": "string", "order_number": "string", "total_amount": "number", "status": "string"}'::jsonb,
  true
) ON CONFLICT (template_key) DO NOTHING;

-- Insurance Approval Email
INSERT INTO email_templates (
  template_key,
  template_type,
  subject_ar,
  subject_en,
  body_ar,
  body_en,
  variables,
  is_active
) VALUES (
  'insurance_approved',
  'notification',
  'تمت الموافقة على طلبك التأميني - مُعافى',
  'Your Insurance Request Approved - Muaafa',
  
  'عزيزي {{user_name}},

يسرنا إبلاغك بأنه تمت الموافقة على طلبك التأميني!

التفاصيل:
- التغطية التأمينية: {{coverage_percentage}}%
- المبلغ المغطى: {{covered_amount}} ريال
- المبلغ المتبقي: {{patient_amount}} ريال

يمكنك الآن المتابعة للدفع من خلال التطبيق.

فريق مُعافى',

  'Dear {{user_name}},

We are pleased to inform you that your insurance request has been approved!

Details:
- Insurance Coverage: {{coverage_percentage}}%
- Covered Amount: {{covered_amount}} SAR
- Patient Amount: {{patient_amount}} SAR

You can now proceed to payment through the app.

Muaafa Team',

  '{"user_name": "string", "coverage_percentage": "number", "covered_amount": "number", "patient_amount": "number"}'::jsonb,
  true
) ON CONFLICT (template_key) DO NOTHING;

-- Delivery Notification Email
INSERT INTO email_templates (
  template_key,
  template_type,
  subject_ar,
  subject_en,
  body_ar,
  body_en,
  variables,
  is_active
) VALUES (
  'delivery_notification',
  'notification',
  'طلبك في الطريق إليك - مُعافى',
  'Your Order is On Its Way - Muaafa',
  
  'عزيزي {{user_name}},

طلبك الآن في الطريق إليك!

السائق: {{driver_name}}
رقم الجوال: {{driver_phone}}
نوع المركبة: {{vehicle_type}}
رقم اللوحة: {{vehicle_plate}}

يمكنك تتبع السائق مباشرة من خلال التطبيق.

نتمنى لك الشفاء العاجل!

فريق مُعافى',

  'Dear {{user_name}},

Your order is now on its way to you!

Driver: {{driver_name}}
Phone: {{driver_phone}}
Vehicle Type: {{vehicle_type}}
Plate Number: {{vehicle_plate}}

You can track the driver live through the app.

Wishing you a speedy recovery!

Muaafa Team',

  '{"user_name": "string", "driver_name": "string", "driver_phone": "string", "vehicle_type": "string", "vehicle_plate": "string"}'::jsonb,
  true
) ON CONFLICT (template_key) DO NOTHING;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_email_logs_user_status ON email_logs(user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_logs_template ON email_logs(template_key, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_templates_active ON email_templates(template_key) WHERE is_active = true;
