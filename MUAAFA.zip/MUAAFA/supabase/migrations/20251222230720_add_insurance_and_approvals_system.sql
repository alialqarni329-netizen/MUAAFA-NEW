/*
  # نظام التأمين والموافقات الطبية - المحفظة الصحية
  
  ## الجداول الجديدة:
  
  1. **insurance_details** - تفاصيل التأمين الصحي
     - `id` (uuid, primary key)
     - `user_id` (uuid, foreign key -> auth.users)
     - `insurance_company` (text) - اسم شركة التأمين
     - `policy_number` (text) - رقم البوليصة
     - `insurance_category` (text) - فئة التأمين (A, B, C, etc.)
     - `start_date` (date) - تاريخ البداية
     - `end_date` (date) - تاريخ الانتهاء
     - `card_front_image` (text) - صورة البطاقة الأمامية
     - `card_back_image` (text) - صورة البطاقة الخلفية
     - `coverage_details` (jsonb) - تفاصيل التغطية
     - `is_active` (boolean) - هل التأمين نشط
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)
  
  2. **insurance_requests** - طلبات الموافقات الطبية
     - `id` (uuid, primary key)
     - `user_id` (uuid, foreign key)
     - `insurance_id` (uuid, foreign key -> insurance_details)
     - `request_type` (text) - نوع الطلب (appointment, medication, procedure, etc.)
     - `related_id` (uuid) - معرف الجلسة أو الدواء المرتبط
     - `status` (text) - الحالة (submitted, under_review, approved, rejected, appealed)
     - `request_date` (timestamptz) - تاريخ الطلب
     - `review_date` (timestamptz) - تاريخ المراجعة
     - `approval_date` (timestamptz) - تاريخ الموافقة
     - `rejection_reason` (text) - سبب الرفض
     - `approval_number` (text) - رقم الموافقة
     - `coverage_amount` (numeric) - المبلغ المغطى
     - `documents` (jsonb) - المستندات المرفقة
     - `hospital_id` (uuid) - معرف المستشفى
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)
  
  3. **insurance_appeals** - الاعتراضات والطعون
     - `id` (uuid, primary key)
     - `request_id` (uuid, foreign key -> insurance_requests)
     - `user_id` (uuid, foreign key)
     - `appeal_reason` (text) - سبب الاعتراض
     - `additional_documents` (jsonb) - مستندات إضافية
     - `doctor_letter` (text) - رسالة من الطبيب
     - `status` (text) - حالة الاعتراض (submitted, under_review, accepted, rejected)
     - `appeal_date` (timestamptz) - تاريخ الاعتراض
     - `response_date` (timestamptz) - تاريخ الرد
     - `response_message` (text) - رد شركة التأمين
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)
  
  4. **covered_facilities** - الفروع والمنشآت المغطاة
     - `id` (uuid, primary key)
     - `insurance_company` (text) - شركة التأمين
     - `facility_name` (text) - اسم المنشأة
     - `facility_type` (text) - نوع المنشأة (hospital, clinic, pharmacy)
     - `category_coverage` (text[]) - الفئات المغطاة
     - `address` (text) - العنوان
     - `city` (text) - المدينة
     - `phone` (text) - الهاتف
     - `coordinates` (jsonb) - الإحداثيات
     - `services` (text[]) - الخدمات المتاحة
     - `is_active` (boolean) - هل المنشأة نشطة
     - `created_at` (timestamptz)
  
  5. **medical_documents** - أرشيف المستندات الطبية
     - `id` (uuid, primary key)
     - `user_id` (uuid, foreign key)
     - `document_type` (text) - نوع المستند (report, xray, bill, approval, prescription)
     - `document_name` (text) - اسم المستند
     - `file_url` (text) - رابط الملف
     - `file_size` (bigint) - حجم الملف
     - `upload_date` (timestamptz) - تاريخ الرفع
     - `related_request_id` (uuid) - معرف الطلب المرتبط
     - `is_encrypted` (boolean) - هل الملف مشفر
     - `ai_summary` (text) - ملخص AI للمستند
     - `tags` (text[]) - العلامات
     - `folder` (text) - المجلد
     - `created_at` (timestamptz)
  
  ## الأمان:
  - تفعيل RLS على جميع الجداول
  - سياسات قراءة/كتابة محدودة للمستخدم المالك فقط
  - تشفير البيانات الحساسة
  
  ## الملاحظات المهمة:
  1. جميع بيانات التأمين حساسة ويجب تشفيرها
  2. الموافقات تتطلب توثيق كامل
  3. نظام الاعتراضات يحتاج متابعة دقيقة
  4. التكامل مع المستشفيات يتطلب API خاص
*/

-- إنشاء جدول تفاصيل التأمين
CREATE TABLE IF NOT EXISTS insurance_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  insurance_company text NOT NULL,
  policy_number text NOT NULL,
  insurance_category text DEFAULT 'C',
  start_date date NOT NULL,
  end_date date NOT NULL,
  card_front_image text,
  card_back_image text,
  coverage_details jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول طلبات الموافقات
CREATE TABLE IF NOT EXISTS insurance_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  insurance_id uuid REFERENCES insurance_details(id) ON DELETE SET NULL,
  request_type text NOT NULL,
  related_id uuid,
  status text DEFAULT 'submitted' CHECK (status IN ('submitted', 'under_review', 'approved', 'rejected', 'appealed')),
  request_date timestamptz DEFAULT now(),
  review_date timestamptz,
  approval_date timestamptz,
  rejection_reason text,
  approval_number text,
  coverage_amount numeric(10,2),
  documents jsonb DEFAULT '[]',
  hospital_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول الاعتراضات
CREATE TABLE IF NOT EXISTS insurance_appeals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid REFERENCES insurance_requests(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  appeal_reason text NOT NULL,
  additional_documents jsonb DEFAULT '[]',
  doctor_letter text,
  status text DEFAULT 'submitted' CHECK (status IN ('submitted', 'under_review', 'accepted', 'rejected')),
  appeal_date timestamptz DEFAULT now(),
  response_date timestamptz,
  response_message text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول المنشآت المغطاة
CREATE TABLE IF NOT EXISTS covered_facilities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  insurance_company text NOT NULL,
  facility_name text NOT NULL,
  facility_type text NOT NULL CHECK (facility_type IN ('hospital', 'clinic', 'pharmacy', 'lab')),
  category_coverage text[] DEFAULT ARRAY['A', 'B', 'C'],
  address text,
  city text,
  phone text,
  coordinates jsonb,
  services text[] DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- إنشاء جدول المستندات الطبية
CREATE TABLE IF NOT EXISTS medical_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  document_type text NOT NULL CHECK (document_type IN ('report', 'xray', 'bill', 'approval', 'prescription', 'other')),
  document_name text NOT NULL,
  file_url text NOT NULL,
  file_size bigint,
  upload_date timestamptz DEFAULT now(),
  related_request_id uuid REFERENCES insurance_requests(id) ON DELETE SET NULL,
  is_encrypted boolean DEFAULT true,
  ai_summary text,
  tags text[] DEFAULT '{}',
  folder text DEFAULT 'general',
  created_at timestamptz DEFAULT now()
);

-- تفعيل RLS على جميع الجداول
ALTER TABLE insurance_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE insurance_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE insurance_appeals ENABLE ROW LEVEL SECURITY;
ALTER TABLE covered_facilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE medical_documents ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان لجدول insurance_details
CREATE POLICY "Users can view own insurance details"
  ON insurance_details FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own insurance details"
  ON insurance_details FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own insurance details"
  ON insurance_details FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسات الأمان لجدول insurance_requests
CREATE POLICY "Users can view own insurance requests"
  ON insurance_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create insurance requests"
  ON insurance_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own insurance requests"
  ON insurance_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسات الأمان لجدول insurance_appeals
CREATE POLICY "Users can view own appeals"
  ON insurance_appeals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create appeals"
  ON insurance_appeals FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own appeals"
  ON insurance_appeals FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسات الأمان لجدول covered_facilities (عام للجميع)
CREATE POLICY "Anyone can view covered facilities"
  ON covered_facilities FOR SELECT
  TO authenticated
  USING (is_active = true);

-- سياسات الأمان لجدول medical_documents
CREATE POLICY "Users can view own documents"
  ON medical_documents FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can upload documents"
  ON medical_documents FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own documents"
  ON medical_documents FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- إنشاء فهارس للأداء
CREATE INDEX IF NOT EXISTS idx_insurance_details_user_id ON insurance_details(user_id);
CREATE INDEX IF NOT EXISTS idx_insurance_requests_user_id ON insurance_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_insurance_requests_status ON insurance_requests(status);
CREATE INDEX IF NOT EXISTS idx_insurance_appeals_request_id ON insurance_appeals(request_id);
CREATE INDEX IF NOT EXISTS idx_covered_facilities_company ON covered_facilities(insurance_company);
CREATE INDEX IF NOT EXISTS idx_medical_documents_user_id ON medical_documents(user_id);
CREATE INDEX IF NOT EXISTS idx_medical_documents_type ON medical_documents(document_type);

-- دالة لتحديث updated_at تلقائياً
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- إضافة triggers لتحديث updated_at
DROP TRIGGER IF EXISTS update_insurance_details_updated_at ON insurance_details;
CREATE TRIGGER update_insurance_details_updated_at
  BEFORE UPDATE ON insurance_details
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_insurance_requests_updated_at ON insurance_requests;
CREATE TRIGGER update_insurance_requests_updated_at
  BEFORE UPDATE ON insurance_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_insurance_appeals_updated_at ON insurance_appeals;
CREATE TRIGGER update_insurance_appeals_updated_at
  BEFORE UPDATE ON insurance_appeals
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
