/*
  # Enhance Chat System for Health Chatbot

  1. Changes to chat_conversations
    - Add `language` column for detected language
    - Add `last_message_at` column for sorting conversations

  2. Changes to chat_messages
    - Add `severity_level` column for symptom analysis
    - Add `suggested_action` column for recommendations
    - Add `app_features_mentioned` column for feature integration

  3. Functions and Triggers
    - Function to update conversation timestamp
    - Trigger on new message insertion
*/

-- Add missing columns to chat_conversations
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'chat_conversations' AND column_name = 'language'
  ) THEN
    ALTER TABLE chat_conversations ADD COLUMN language text DEFAULT 'ar';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'chat_conversations' AND column_name = 'last_message_at'
  ) THEN
    ALTER TABLE chat_conversations ADD COLUMN last_message_at timestamptz DEFAULT now();
  END IF;
END $$;

-- Add missing columns to chat_messages
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'chat_messages' AND column_name = 'severity_level'
  ) THEN
    ALTER TABLE chat_messages ADD COLUMN severity_level text CHECK (severity_level IN ('mild', 'moderate', 'severe', 'emergency', 'none'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'chat_messages' AND column_name = 'suggested_action'
  ) THEN
    ALTER TABLE chat_messages ADD COLUMN suggested_action text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'chat_messages' AND column_name = 'app_features_mentioned'
  ) THEN
    ALTER TABLE chat_messages ADD COLUMN app_features_mentioned text[] DEFAULT '{}';
  END IF;
END $$;

-- Create or replace function to update conversation timestamp
CREATE OR REPLACE FUNCTION update_conversation_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE chat_conversations
  SET 
    last_message_at = NEW.created_at,
    updated_at = now()
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if exists and create new one
DROP TRIGGER IF EXISTS update_conversation_on_message ON chat_messages;
CREATE TRIGGER update_conversation_on_message
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION update_conversation_timestamp();

-- Create index if not exists
CREATE INDEX IF NOT EXISTS idx_chat_conversations_last_message ON chat_conversations(last_message_at DESC);