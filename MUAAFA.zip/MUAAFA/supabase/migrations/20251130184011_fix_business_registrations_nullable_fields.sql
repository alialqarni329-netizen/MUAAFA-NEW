/*
  # Fix Business Registrations Nullable Fields
  
  This migration makes optional fields nullable to prevent registration errors.
  
  ## Changes
  - Make registration_expiry nullable (optional field)
  - Make owner_national_id nullable (optional field)
  
  ## Security
  - No changes to RLS policies
  - Maintains data integrity
*/

-- Make registration_expiry nullable
ALTER TABLE business_registrations 
ALTER COLUMN registration_expiry DROP NOT NULL;

-- Make owner_national_id nullable
ALTER TABLE business_registrations 
ALTER COLUMN owner_national_id DROP NOT NULL;