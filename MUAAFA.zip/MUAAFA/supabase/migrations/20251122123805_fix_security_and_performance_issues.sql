/*
  # Fix Security and Performance Issues

  ## Changes
  
  1. **Add Missing Index**
     - Add index on uploaded_images.conversation_id for FK performance
  
  2. **Optimize All RLS Policies**
     - Replace auth.uid() with (select auth.uid()) in all policies
     - This prevents re-evaluation for each row, improving performance at scale
  
  3. **Remove Unused Indexes**
     - Drop indexes that are not being used by queries
  
  4. **Fix Multiple Permissive Policies**
     - Combine admin_users SELECT policies into single optimized policy
  
  ## Tables Affected
  - uploaded_images (new index)
  - users (RLS optimization)
  - chat_conversations (RLS optimization)
  - chat_messages (RLS optimization)
  - sessions (RLS optimization)
  - subscriptions (RLS optimization)
  - usage_logs (RLS optimization)
  - image_analysis (RLS optimization)
  - medical_questionnaire (RLS optimization)
  - session_recordings (RLS optimization)
  - admin_users (RLS optimization + policy fix)
*/

-- ============================================
-- 1. ADD MISSING INDEX
-- ============================================

-- Add index for uploaded_images foreign key
CREATE INDEX IF NOT EXISTS idx_uploaded_images_conversation_id 
ON uploaded_images(conversation_id);

-- ============================================
-- 2. OPTIMIZE RLS POLICIES - USERS TABLE
-- ============================================

DROP POLICY IF EXISTS "Users can read own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;
DROP POLICY IF EXISTS "Users can insert own data" ON users;

CREATE POLICY "Users can read own data"
  ON users FOR SELECT
  TO authenticated
  USING (id = (select auth.uid()));

CREATE POLICY "Users can update own data"
  ON users FOR UPDATE
  TO authenticated
  USING (id = (select auth.uid()))
  WITH CHECK (id = (select auth.uid()));

CREATE POLICY "Users can insert own data"
  ON users FOR INSERT
  TO authenticated
  WITH CHECK (id = (select auth.uid()));

-- ============================================
-- 3. OPTIMIZE RLS POLICIES - CHAT_CONVERSATIONS
-- ============================================

DROP POLICY IF EXISTS "Users can view own conversations" ON chat_conversations;
DROP POLICY IF EXISTS "Users can create own conversations" ON chat_conversations;
DROP POLICY IF EXISTS "Users can update own conversations" ON chat_conversations;
DROP POLICY IF EXISTS "Users can delete own conversations" ON chat_conversations;

CREATE POLICY "Users can view own conversations"
  ON chat_conversations FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can create own conversations"
  ON chat_conversations FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own conversations"
  ON chat_conversations FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own conversations"
  ON chat_conversations FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================
-- 4. OPTIMIZE RLS POLICIES - CHAT_MESSAGES
-- ============================================

DROP POLICY IF EXISTS "Users can view messages in own conversations" ON chat_messages;
DROP POLICY IF EXISTS "Users can create messages in own conversations" ON chat_messages;

CREATE POLICY "Users can view messages in own conversations"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM chat_conversations
      WHERE chat_conversations.id = chat_messages.conversation_id
      AND chat_conversations.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Users can create messages in own conversations"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM chat_conversations
      WHERE chat_conversations.id = chat_messages.conversation_id
      AND chat_conversations.user_id = (select auth.uid())
    )
  );

-- ============================================
-- 5. OPTIMIZE RLS POLICIES - SESSIONS
-- ============================================

DROP POLICY IF EXISTS "Users can view own sessions" ON sessions;
DROP POLICY IF EXISTS "Users can create own sessions" ON sessions;
DROP POLICY IF EXISTS "Users can update own sessions" ON sessions;

CREATE POLICY "Users can view own sessions"
  ON sessions FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can create own sessions"
  ON sessions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own sessions"
  ON sessions FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================
-- 6. OPTIMIZE RLS POLICIES - UPLOADED_IMAGES
-- ============================================

DROP POLICY IF EXISTS "Users can view own uploaded images" ON uploaded_images;
DROP POLICY IF EXISTS "Users can upload images" ON uploaded_images;
DROP POLICY IF EXISTS "Users can delete own images" ON uploaded_images;

CREATE POLICY "Users can view own uploaded images"
  ON uploaded_images FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can upload images"
  ON uploaded_images FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own images"
  ON uploaded_images FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================
-- 7. OPTIMIZE RLS POLICIES - SUBSCRIPTIONS
-- ============================================

DROP POLICY IF EXISTS "Users can view own subscriptions" ON subscriptions;
DROP POLICY IF EXISTS "Users can create own subscriptions" ON subscriptions;
DROP POLICY IF EXISTS "Users can update own subscriptions" ON subscriptions;

CREATE POLICY "Users can view own subscriptions"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can create own subscriptions"
  ON subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own subscriptions"
  ON subscriptions FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================
-- 8. OPTIMIZE RLS POLICIES - USAGE_LOGS
-- ============================================

DROP POLICY IF EXISTS "Users can view own usage logs" ON usage_logs;
DROP POLICY IF EXISTS "Users can create usage logs" ON usage_logs;

CREATE POLICY "Users can view own usage logs"
  ON usage_logs FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can create usage logs"
  ON usage_logs FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================
-- 9. OPTIMIZE RLS POLICIES - IMAGE_ANALYSIS
-- ============================================

DROP POLICY IF EXISTS "Users can view own image analyses" ON image_analysis;
DROP POLICY IF EXISTS "Users can create image analyses" ON image_analysis;
DROP POLICY IF EXISTS "Users can delete own image analyses" ON image_analysis;

CREATE POLICY "Users can view own image analyses"
  ON image_analysis FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can create image analyses"
  ON image_analysis FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can delete own image analyses"
  ON image_analysis FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================
-- 10. OPTIMIZE RLS POLICIES - MEDICAL_QUESTIONNAIRE
-- ============================================

DROP POLICY IF EXISTS "Users can view own questionnaire" ON medical_questionnaire;
DROP POLICY IF EXISTS "Users can insert own questionnaire" ON medical_questionnaire;
DROP POLICY IF EXISTS "Users can update own questionnaire" ON medical_questionnaire;

CREATE POLICY "Users can view own questionnaire"
  ON medical_questionnaire FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

CREATE POLICY "Users can insert own questionnaire"
  ON medical_questionnaire FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

CREATE POLICY "Users can update own questionnaire"
  ON medical_questionnaire FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================
-- 11. OPTIMIZE RLS POLICIES - SESSION_RECORDINGS
-- ============================================

DROP POLICY IF EXISTS "Users can view their own session recordings" ON session_recordings;
DROP POLICY IF EXISTS "Users can delete their own session recordings" ON session_recordings;
DROP POLICY IF EXISTS "System can create session recordings" ON session_recordings;
DROP POLICY IF EXISTS "System can update session recordings" ON session_recordings;

CREATE POLICY "Users can view their own session recordings"
  ON session_recordings FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = (select auth.uid())
    )
  );

CREATE POLICY "Users can delete their own session recordings"
  ON session_recordings FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = (select auth.uid())
    )
  );

CREATE POLICY "System can create session recordings"
  ON session_recordings FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = (select auth.uid())
    )
  );

CREATE POLICY "System can update session recordings"
  ON session_recordings FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = (select auth.uid())
    )
  );

-- ============================================
-- 12. FIX ADMIN_USERS POLICIES (Multiple Permissive Policies Issue)
-- ============================================

-- Drop existing policies
DROP POLICY IF EXISTS "Users can check their own admin status" ON admin_users;
DROP POLICY IF EXISTS "Admins can view all admin users" ON admin_users;

-- Create single combined policy for SELECT
CREATE POLICY "Users can check admin status"
  ON admin_users FOR SELECT
  TO authenticated
  USING (
    -- Users can check their own admin status
    id = (select auth.uid())
    OR
    -- Admins can view all admin users
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.id = (select auth.uid())
      AND au.role IN ('owner', 'admin')
    )
  );

-- ============================================
-- 13. REMOVE UNUSED INDEXES
-- ============================================

-- These indexes are not being used by queries
DROP INDEX IF EXISTS idx_session_recordings_session_id;
DROP INDEX IF EXISTS idx_subscriptions_user_id;
DROP INDEX IF EXISTS idx_usage_logs_user_id;
DROP INDEX IF EXISTS idx_medical_questionnaire_user_id;
DROP INDEX IF EXISTS idx_admin_users_role;
DROP INDEX IF EXISTS idx_sessions_mode;
DROP INDEX IF EXISTS idx_session_recordings_status;
DROP INDEX IF EXISTS idx_chat_messages_conversation_id;
DROP INDEX IF EXISTS idx_sessions_doctor_id;
DROP INDEX IF EXISTS idx_uploaded_images_user_id;
DROP INDEX IF EXISTS idx_health_articles_category;
