/*
  # نظام الصلاحيات RBAC (Role-Based Access Control)
  # Professional RBAC System

  1. الجداول الجديدة
    - permissions: جدول الصلاحيات
    - role_permissions: ربط الصلاحيات بالأدوار
    - user_activity_log: سجل نشاط المستخدمين
    
  2. التحديثات
    - تحديث staff_roles بإضافة role_type وصلاحيات أفضل
    
  3. الأمان
    - RLS على جميع الجداول
    - دوال للتحقق من الصلاحيات
    
  4. الفهارس
    - فهارس لتسريع الاستعلامات
*/

-- ==========================================
-- 1. جدول الصلاحيات (Permissions)
-- ==========================================

CREATE TABLE IF NOT EXISTS permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  name_ar text NOT NULL,
  category text NOT NULL CHECK (category IN ('general', 'medical', 'financial', 'pharmacy', 'insurance')),
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- فهرس
CREATE INDEX IF NOT EXISTS idx_permissions_category ON permissions(category);

-- RLS
ALTER TABLE permissions ENABLE ROW LEVEL SECURITY;

-- سياسة: الجميع يمكنه قراءة الصلاحيات
CREATE POLICY "Anyone can view permissions"
  ON permissions FOR SELECT
  TO authenticated
  USING (true);

-- ==========================================
-- 2. تحديث جدول الأدوار (Staff Roles)
-- ==========================================

-- إضافة حقول جديدة
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'staff_roles' AND column_name = 'role_type'
  ) THEN
    ALTER TABLE staff_roles 
    ADD COLUMN role_type text CHECK (role_type IN ('owner', 'manager', 'staff', 'specialized'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'staff_roles' AND column_name = 'is_system_role'
  ) THEN
    ALTER TABLE staff_roles 
    ADD COLUMN is_system_role boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'staff_roles' AND column_name = 'priority'
  ) THEN
    ALTER TABLE staff_roles 
    ADD COLUMN priority integer DEFAULT 0;
  END IF;
END $$;

-- ==========================================
-- 3. جدول ربط الصلاحيات بالأدوار
-- ==========================================

CREATE TABLE IF NOT EXISTS role_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id uuid NOT NULL REFERENCES staff_roles(id) ON DELETE CASCADE,
  permission_id uuid NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  granted_at timestamptz DEFAULT now(),
  granted_by uuid REFERENCES auth.users(id),
  
  UNIQUE(role_id, permission_id)
);

-- فهارس
CREATE INDEX IF NOT EXISTS idx_role_permissions_role_id ON role_permissions(role_id);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission_id ON role_permissions(permission_id);

-- RLS
ALTER TABLE role_permissions ENABLE ROW LEVEL SECURITY;

-- سياسة: الجميع يمكنه رؤية صلاحيات الأدوار
CREATE POLICY "Anyone can view role permissions"
  ON role_permissions FOR SELECT
  TO authenticated
  USING (true);

-- سياسة: فقط مالك المنشأة يمكنه تعديل الصلاحيات
CREATE POLICY "Business owners can manage role permissions"
  ON role_permissions FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_roles sr
      JOIN business_registrations br ON sr.business_type = br.business_type OR sr.business_type = 'all'
      WHERE sr.id = role_permissions.role_id
      AND br.user_id = auth.uid()
    )
  );

-- ==========================================
-- 4. جدول سجل نشاط المستخدمين
-- ==========================================

CREATE TABLE IF NOT EXISTS user_activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  staff_id uuid REFERENCES staff_members(id) ON DELETE SET NULL,
  business_id uuid REFERENCES business_registrations(id) ON DELETE CASCADE,
  action text NOT NULL,
  resource_type text,
  resource_id uuid,
  details jsonb DEFAULT '{}'::jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- فهارس
CREATE INDEX IF NOT EXISTS idx_user_activity_user_id ON user_activity_log(user_id);
CREATE INDEX IF NOT EXISTS idx_user_activity_business_id ON user_activity_log(business_id);
CREATE INDEX IF NOT EXISTS idx_user_activity_created_at ON user_activity_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_activity_action ON user_activity_log(action);

-- RLS
ALTER TABLE user_activity_log ENABLE ROW LEVEL SECURITY;

-- سياسة: يمكن للمنشأة رؤية سجل نشاطها
CREATE POLICY "Business can view their activity log"
  ON user_activity_log FOR SELECT
  TO authenticated
  USING (
    business_id IN (
      SELECT id FROM business_registrations WHERE user_id = auth.uid()
    )
  );

-- سياسة: السماح بإدراج سجلات جديدة
CREATE POLICY "Allow inserting activity logs"
  ON user_activity_log FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- ==========================================
-- 5. إدراج الصلاحيات الأساسية
-- ==========================================

-- صلاحيات عامة
INSERT INTO permissions (name, name_ar, category, description) VALUES
('view_dashboard', 'عرض لوحة التحكم', 'general', 'الوصول إلى لوحة التحكم الرئيسية'),
('manage_settings', 'إدارة الإعدادات', 'general', 'تعديل إعدادات المنشأة'),
('manage_staff', 'إدارة الموظفين', 'general', 'إضافة وتعديل وحذف الموظفين'),
('view_reports', 'عرض التقارير', 'general', 'الوصول إلى التقارير والإحصائيات'),
('view_statistics', 'عرض الإحصائيات', 'general', 'عرض الإحصائيات والتحليلات'),
('view_audit_log', 'عرض سجل النشاط', 'general', 'الوصول إلى سجل النشاط والأحداث')
ON CONFLICT (name) DO NOTHING;

-- صلاحيات طبية
INSERT INTO permissions (name, name_ar, category, description) VALUES
('manage_sessions', 'إدارة الجلسات', 'medical', 'جدولة وإدارة الجلسات الصحية'),
('view_medical_records', 'عرض السجلات الطبية', 'medical', 'الوصول إلى السجلات الطبية للمرضى'),
('upload_medical_reports', 'رفع التقارير الطبية', 'medical', 'رفع وإدارة التقارير الطبية'),
('manage_appointments', 'إدارة المواعيد', 'medical', 'حجز وتعديل المواعيد'),
('view_patients', 'عرض المرضى', 'medical', 'الوصول إلى قائمة المرضى')
ON CONFLICT (name) DO NOTHING;

-- صلاحيات مالية
INSERT INTO permissions (name, name_ar, category, description) VALUES
('view_invoices', 'عرض الفواتير', 'financial', 'الوصول إلى الفواتير'),
('manage_payments', 'إدارة المدفوعات', 'financial', 'معالجة المدفوعات والتحصيل'),
('view_financial_reports', 'عرض التقارير المالية', 'financial', 'الوصول إلى التقارير المالية')
ON CONFLICT (name) DO NOTHING;

-- صلاحيات الصيدلية
INSERT INTO permissions (name, name_ar, category, description) VALUES
('manage_medicines', 'إدارة الأدوية', 'pharmacy', 'إضافة وتعديل وحذف الأدوية'),
('view_orders', 'عرض الطلبات', 'pharmacy', 'الوصول إلى طلبات الأدوية'),
('fulfill_orders', 'تنفيذ الطلبات', 'pharmacy', 'معالجة وتنفيذ الطلبات'),
('manage_inventory', 'إدارة المخزون', 'pharmacy', 'إدارة مخزون الأدوية')
ON CONFLICT (name) DO NOTHING;

-- صلاحيات التأمين
INSERT INTO permissions (name, name_ar, category, description) VALUES
('manage_claims', 'إدارة المطالبات', 'insurance', 'معالجة المطالبات التأمينية'),
('approve_claims', 'الموافقة على المطالبات', 'insurance', 'الموافقة أو رفض المطالبات'),
('view_claims', 'عرض المطالبات', 'insurance', 'الوصول إلى المطالبات التأمينية'),
('request_documents', 'طلب مستندات', 'insurance', 'طلب مستندات إضافية من المستخدمين')
ON CONFLICT (name) DO NOTHING;

-- ==========================================
-- 6. تحديث الأدوار الموجودة
-- ==========================================

-- تحديث أدوار شركات التأمين
UPDATE staff_roles SET role_type = 'specialized', is_system_role = true, priority = 10
WHERE name_en = 'claims_officer' AND business_type = 'insurance';

UPDATE staff_roles SET role_type = 'manager', is_system_role = true, priority = 20
WHERE name_en = 'approvals_manager' AND business_type = 'insurance';

UPDATE staff_roles SET role_type = 'owner', is_system_role = true, priority = 30
WHERE name_en = 'general_supervisor' AND business_type = 'insurance';

-- تحديث أدوار المستشفيات
UPDATE staff_roles SET role_type = 'specialized', is_system_role = true, priority = 10
WHERE name_en = 'doctor' AND business_type = 'hospital';

UPDATE staff_roles SET role_type = 'staff', is_system_role = true, priority = 5
WHERE name_en = 'receptionist' AND business_type = 'hospital';

UPDATE staff_roles SET role_type = 'manager', is_system_role = true, priority = 20
WHERE name_en = 'medical_admin' AND business_type = 'hospital';

UPDATE staff_roles SET role_type = 'owner', is_system_role = true, priority = 30
WHERE name_en = 'facility_manager' AND business_type = 'hospital';

-- تحديث أدوار الصيدليات
UPDATE staff_roles SET role_type = 'specialized', is_system_role = true, priority = 10
WHERE name_en = 'pharmacist' AND business_type = 'pharmacy';

UPDATE staff_roles SET role_type = 'staff', is_system_role = true, priority = 5
WHERE name_en = 'cashier' AND business_type = 'pharmacy';

UPDATE staff_roles SET role_type = 'owner', is_system_role = true, priority = 30
WHERE name_en = 'branch_manager' AND business_type = 'pharmacy';

-- ==========================================
-- 7. ربط الصلاحيات بالأدوار
-- ==========================================

-- دالة مساعدة لربط الصلاحيات
CREATE OR REPLACE FUNCTION link_permissions_to_role(
  p_role_name_en text,
  p_permission_names text[]
) RETURNS void AS $$
DECLARE
  v_role_id uuid;
  v_permission_name text;
  v_permission_id uuid;
BEGIN
  -- الحصول على معرف الدور
  SELECT id INTO v_role_id FROM staff_roles WHERE name_en = p_role_name_en LIMIT 1;
  
  IF v_role_id IS NULL THEN
    RAISE NOTICE 'Role % not found', p_role_name_en;
    RETURN;
  END IF;
  
  -- ربط كل صلاحية
  FOREACH v_permission_name IN ARRAY p_permission_names
  LOOP
    SELECT id INTO v_permission_id FROM permissions WHERE name = v_permission_name;
    
    IF v_permission_id IS NOT NULL THEN
      INSERT INTO role_permissions (role_id, permission_id)
      VALUES (v_role_id, v_permission_id)
      ON CONFLICT (role_id, permission_id) DO NOTHING;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- صلاحيات موظف المطالبات (شركات التأمين)
SELECT link_permissions_to_role('claims_officer', ARRAY[
  'view_dashboard',
  'view_claims',
  'manage_claims',
  'request_documents',
  'view_reports'
]);

-- صلاحيات مدير الموافقات (شركات التأمين)
SELECT link_permissions_to_role('approvals_manager', ARRAY[
  'view_dashboard',
  'view_claims',
  'manage_claims',
  'approve_claims',
  'request_documents',
  'view_reports',
  'view_statistics',
  'view_financial_reports'
]);

-- صلاحيات المشرف العام (شركات التأمين)
SELECT link_permissions_to_role('general_supervisor', ARRAY[
  'view_dashboard',
  'manage_settings',
  'manage_staff',
  'view_claims',
  'manage_claims',
  'approve_claims',
  'request_documents',
  'view_reports',
  'view_statistics',
  'view_financial_reports',
  'view_audit_log',
  'view_invoices',
  'manage_payments'
]);

-- صلاحيات الطبيب (مستشفيات)
SELECT link_permissions_to_role('doctor', ARRAY[
  'view_dashboard',
  'manage_sessions',
  'view_medical_records',
  'upload_medical_reports',
  'manage_appointments',
  'view_patients'
]);

-- صلاحيات الاستقبال (مستشفيات)
SELECT link_permissions_to_role('receptionist', ARRAY[
  'view_dashboard',
  'manage_appointments',
  'view_patients',
  'view_sessions'
]);

-- صلاحيات الإدارة الطبية (مستشفيات)
SELECT link_permissions_to_role('medical_admin', ARRAY[
  'view_dashboard',
  'manage_sessions',
  'view_medical_records',
  'view_patients',
  'view_reports',
  'view_statistics',
  'manage_appointments'
]);

-- صلاحيات مدير المنشأة (مستشفيات)
SELECT link_permissions_to_role('facility_manager', ARRAY[
  'view_dashboard',
  'manage_settings',
  'manage_staff',
  'manage_sessions',
  'view_medical_records',
  'upload_medical_reports',
  'manage_appointments',
  'view_patients',
  'view_reports',
  'view_statistics',
  'view_financial_reports',
  'view_audit_log',
  'view_invoices',
  'manage_payments'
]);

-- صلاحيات الصيدلي (صيدليات)
SELECT link_permissions_to_role('pharmacist', ARRAY[
  'view_dashboard',
  'manage_medicines',
  'view_orders',
  'fulfill_orders',
  'manage_inventory',
  'view_reports'
]);

-- صلاحيات الكاشير (صيدليات)
SELECT link_permissions_to_role('cashier', ARRAY[
  'view_dashboard',
  'view_orders',
  'fulfill_orders',
  'view_invoices',
  'manage_payments'
]);

-- صلاحيات مدير الفرع (صيدليات)
SELECT link_permissions_to_role('branch_manager', ARRAY[
  'view_dashboard',
  'manage_settings',
  'manage_staff',
  'manage_medicines',
  'view_orders',
  'fulfill_orders',
  'manage_inventory',
  'view_reports',
  'view_statistics',
  'view_financial_reports',
  'view_audit_log',
  'view_invoices',
  'manage_payments'
]);

-- ==========================================
-- 8. دوال التحقق من الصلاحيات المحسّنة
-- ==========================================

-- دالة للتحقق من صلاحية محددة
CREATE OR REPLACE FUNCTION has_permission(
  p_user_id uuid,
  p_business_id uuid,
  p_permission_name text
) RETURNS boolean AS $$
DECLARE
  v_has_permission boolean := false;
BEGIN
  -- التحقق من أن المستخدم هو مالك المنشأة
  SELECT EXISTS (
    SELECT 1 FROM business_registrations
    WHERE id = p_business_id AND user_id = p_user_id
  ) INTO v_has_permission;
  
  -- إذا كان المالك، لديه جميع الصلاحيات
  IF v_has_permission THEN
    RETURN true;
  END IF;
  
  -- التحقق من صلاحيات الموظف
  SELECT EXISTS (
    SELECT 1
    FROM staff_members sm
    JOIN staff_roles sr ON sm.role_id = sr.id
    JOIN role_permissions rp ON sr.id = rp.role_id
    JOIN permissions p ON rp.permission_id = p.id
    WHERE sm.business_id = p_business_id
      AND sm.user_id = p_user_id
      AND sm.status = 'active'
      AND p.name = p_permission_name
  ) INTO v_has_permission;
  
  RETURN v_has_permission;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- دالة للحصول على جميع صلاحيات المستخدم
CREATE OR REPLACE FUNCTION get_user_permissions(
  p_user_id uuid,
  p_business_id uuid
) RETURNS TABLE(permission_name text, permission_name_ar text, category text) AS $$
BEGIN
  -- إذا كان المستخدم هو المالك، أرجع جميع الصلاحيات
  IF EXISTS (
    SELECT 1 FROM business_registrations
    WHERE id = p_business_id AND user_id = p_user_id
  ) THEN
    RETURN QUERY SELECT p.name, p.name_ar, p.category FROM permissions p;
    RETURN;
  END IF;
  
  -- إذا كان موظف، أرجع صلاحياته فقط
  RETURN QUERY
  SELECT DISTINCT p.name, p.name_ar, p.category
  FROM staff_members sm
  JOIN staff_roles sr ON sm.role_id = sr.id
  JOIN role_permissions rp ON sr.id = rp.role_id
  JOIN permissions p ON rp.permission_id = p.id
  WHERE sm.business_id = p_business_id
    AND sm.user_id = p_user_id
    AND sm.status = 'active';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- دالة لتسجيل النشاط
CREATE OR REPLACE FUNCTION log_activity(
  p_user_id uuid,
  p_business_id uuid,
  p_action text,
  p_resource_type text DEFAULT NULL,
  p_resource_id uuid DEFAULT NULL,
  p_details jsonb DEFAULT '{}'::jsonb
) RETURNS uuid AS $$
DECLARE
  v_activity_id uuid;
  v_staff_id uuid;
BEGIN
  -- الحصول على معرف الموظف إن وجد
  SELECT id INTO v_staff_id
  FROM staff_members
  WHERE user_id = p_user_id AND business_id = p_business_id
  LIMIT 1;
  
  -- إدراج السجل
  INSERT INTO user_activity_log (
    user_id, staff_id, business_id, action,
    resource_type, resource_id, details
  ) VALUES (
    p_user_id, v_staff_id, p_business_id, p_action,
    p_resource_type, p_resource_id, p_details
  ) RETURNING id INTO v_activity_id;
  
  RETURN v_activity_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==========================================
-- 9. View لعرض الأدوار مع الصلاحيات
-- ==========================================

CREATE OR REPLACE VIEW roles_with_permissions AS
SELECT 
  sr.id as role_id,
  sr.name as role_name,
  sr.name_en as role_name_en,
  sr.business_type,
  sr.role_type,
  sr.priority,
  json_agg(
    json_build_object(
      'permission_id', p.id,
      'permission_name', p.name,
      'permission_name_ar', p.name_ar,
      'category', p.category
    )
  ) as permissions
FROM staff_roles sr
LEFT JOIN role_permissions rp ON sr.id = rp.role_id
LEFT JOIN permissions p ON rp.permission_id = p.id
GROUP BY sr.id, sr.name, sr.name_en, sr.business_type, sr.role_type, sr.priority;

-- منح صلاحيات القراءة على الـ view
GRANT SELECT ON roles_with_permissions TO authenticated;

-- ==========================================
-- 10. Triggers
-- ==========================================

-- Trigger لتحديث updated_at
DROP TRIGGER IF EXISTS update_permissions_updated_at ON permissions;
CREATE TRIGGER update_permissions_updated_at
  BEFORE UPDATE ON permissions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- حذف دالة الربط المساعدة (لم نعد بحاجة إليها)
DROP FUNCTION IF EXISTS link_permissions_to_role(text, text[]);

-- ==========================================
-- 11. إنشاء دور Business Owner الافتراضي
-- ==========================================

-- دور Business Owner (يُعطى تلقائياً لمالك المنشأة)
INSERT INTO staff_roles (name, name_en, business_type, role_type, is_system_role, priority, description) VALUES
('مالك المنشأة', 'business_owner', 'all', 'owner', true, 100, 'المالك الرئيسي للمنشأة - صلاحيات كاملة')
ON CONFLICT (name_en, business_type) DO UPDATE
SET role_type = 'owner', priority = 100, is_system_role = true;

-- إعطاء جميع الصلاحيات لمالك المنشأة
DO $$
DECLARE
  v_role_id uuid;
  v_permission record;
BEGIN
  SELECT id INTO v_role_id FROM staff_roles WHERE name_en = 'business_owner' AND business_type = 'all';
  
  IF v_role_id IS NOT NULL THEN
    FOR v_permission IN SELECT id FROM permissions
    LOOP
      INSERT INTO role_permissions (role_id, permission_id)
      VALUES (v_role_id, v_permission.id)
      ON CONFLICT (role_id, permission_id) DO NOTHING;
    END LOOP;
  END IF;
END $$;
