/*
  # معافى - نظام الصيدلية المتقدم
  
  ## ملخص التعديلات
  هذا التحديث يضيف مزايا جوهرية متقدمة لتطبيق "معافى" تجعله منصة صيدلانية ذكية ومتكاملة
  
  ## الجداول الجديدة
  
  ### 1. medicine_cabinet - خزانة الأدوية الرقمية
  - `id` - معرف فريد
  - `user_id` - معرف المستخدم
  - `medicine_name` - اسم الدواء
  - `medicine_barcode` - الباركود
  - `quantity` - الكمية المتبقية
  - `expiry_date` - تاريخ الانتهاء
  - `reminder_enabled` - تفعيل التذكير
  - `daily_dosage` - الجرعة اليومية
  - `notes` - ملاحظات
  
  ### 2. prescriptions - الوصفات الطبية
  - `id` - معرف فريد
  - `user_id` - معرف المستخدم
  - `image_url` - صورة الوصفة
  - `ocr_text` - النص المستخرج بالـ OCR
  - `medicines` - قائمة الأدوية (JSON)
  - `doctor_name` - اسم الطبيب
  - `processed` - تمت المعالجة
  
  ### 3. medicine_alternatives - البدائل الدوائية
  - `id` - معرف فريد
  - `original_medicine` - الدواء الأصلي
  - `alternative_medicine` - البديل
  - `active_ingredient` - المادة الفعالة
  - `price_difference` - فرق السعر
  - `manufacturer` - الشركة المصنعة
  - `availability` - التوفر
  
  ### 4. pharmacy_prices - أسعار الصيدليات
  - `id` - معرف فريد
  - `medicine_name` - اسم الدواء
  - `pharmacy_id` - معرف الصيدلية
  - `pharmacy_name` - اسم الصيدلية
  - `price` - السعر
  - `availability` - متوفر
  - `distance` - المسافة من المستخدم
  
  ### 5. loyalty_points - نقاط الولاء
  - `id` - معرف فريد
  - `user_id` - معرف المستخدم
  - `points` - النقاط الحالية
  - `total_earned` - إجمالي النقاط المكتسبة
  - `transactions` - سجل المعاملات (JSON)
  
  ### 6. drug_interactions - التفاعلات الدوائية
  - `id` - معرف فريد
  - `medicine_a` - الدواء الأول
  - `medicine_b` - الدواء الثاني
  - `severity` - درجة الخطورة (low/medium/high/severe)
  - `description` - وصف التفاعل
  - `recommendation` - التوصية
  
  ### 7. emergency_deliveries - التوصيل العاجل
  - `id` - معرف فريد
  - `user_id` - معرف المستخدم
  - `order_id` - معرف الطلب
  - `pharmacy_id` - معرف الصيدلية
  - `status` - الحالة (pending/assigned/in_transit/delivered)
  - `delivery_address` - عنوان التوصيل
  - `delivery_latitude` - خط العرض
  - `delivery_longitude` - خط الطول
  - `estimated_time` - الوقت المتوقع (بالدقائق)
  - `driver_name` - اسم السائق
  - `driver_phone` - رقم السائق
  - `tracking_url` - رابط التتبع
  
  ### 8. pharmacist_consultations - الاستشارات الصيدلانية
  - `id` - معرف فريد
  - `user_id` - معرف المستخدم
  - `pharmacist_id` - معرف الصيدلي
  - `medicine_name` - الدواء المستفسر عنه
  - `question` - السؤال
  - `answer` - الجواب
  - `status` - الحالة (pending/answered)
  
  ### 9. ai_prescription_recommendations - توصيات البوت الذكي
  - `id` - معرف فريد
  - `user_id` - معرف المستخدم
  - `chat_session_id` - معرف جلسة الدردشة
  - `symptoms` - الأعراض
  - `recommended_medicines` - الأدوية الموصى بها (JSON)
  - `added_to_cart` - تمت الإضافة للسلة
  
  ## الأمان
  - تفعيل RLS على جميع الجداول
  - سياسات تسمح للمستخدمين بالوصول لبياناتهم فقط
  - سياسات للصيادلة للوصول لاستشاراتهم
*/

-- خزانة الأدوية الرقمية
CREATE TABLE IF NOT EXISTS medicine_cabinet (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  medicine_name text NOT NULL,
  medicine_barcode text,
  quantity integer DEFAULT 0,
  expiry_date date,
  reminder_enabled boolean DEFAULT true,
  daily_dosage text,
  notes text,
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- الوصفات الطبية
CREATE TABLE IF NOT EXISTS prescriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  image_url text NOT NULL,
  ocr_text text,
  medicines jsonb DEFAULT '[]'::jsonb,
  doctor_name text,
  prescription_date date DEFAULT CURRENT_DATE,
  processed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- البدائل الدوائية
CREATE TABLE IF NOT EXISTS medicine_alternatives (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_medicine text NOT NULL,
  alternative_medicine text NOT NULL,
  active_ingredient text NOT NULL,
  price_difference decimal(10,2),
  manufacturer text,
  availability text DEFAULT 'available',
  notes text,
  created_at timestamptz DEFAULT now()
);

-- أسعار الصيدليات
CREATE TABLE IF NOT EXISTS pharmacy_prices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  medicine_name text NOT NULL,
  pharmacy_id text NOT NULL,
  pharmacy_name text NOT NULL,
  pharmacy_chain text,
  price decimal(10,2) NOT NULL,
  availability boolean DEFAULT true,
  distance decimal(10,2),
  latitude decimal(10,6),
  longitude decimal(10,6),
  last_updated timestamptz DEFAULT now()
);

-- نقاط الولاء
CREATE TABLE IF NOT EXISTS loyalty_points (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  points integer DEFAULT 0,
  total_earned integer DEFAULT 0,
  transactions jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- التفاعلات الدوائية
CREATE TABLE IF NOT EXISTS drug_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  medicine_a text NOT NULL,
  medicine_b text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'severe')),
  description text NOT NULL,
  recommendation text,
  created_at timestamptz DEFAULT now()
);

-- التوصيل العاجل
CREATE TABLE IF NOT EXISTS emergency_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  pharmacy_id text NOT NULL,
  pharmacy_name text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in_transit', 'delivered', 'cancelled')),
  delivery_address text NOT NULL,
  delivery_latitude decimal(10,6),
  delivery_longitude decimal(10,6),
  estimated_time integer DEFAULT 30,
  driver_name text,
  driver_phone text,
  tracking_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- الاستشارات الصيدلانية
CREATE TABLE IF NOT EXISTS pharmacist_consultations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  pharmacist_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  medicine_name text,
  question text NOT NULL,
  answer text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'answered', 'closed')),
  created_at timestamptz DEFAULT now(),
  answered_at timestamptz
);

-- توصيات البوت الذكي
CREATE TABLE IF NOT EXISTS ai_prescription_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  chat_session_id uuid,
  symptoms text,
  recommended_medicines jsonb DEFAULT '[]'::jsonb,
  added_to_cart boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- إنشاء الفهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_medicine_cabinet_user ON medicine_cabinet(user_id);
CREATE INDEX IF NOT EXISTS idx_medicine_cabinet_expiry ON medicine_cabinet(expiry_date) WHERE expiry_date IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_prescriptions_user ON prescriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_pharmacy_prices_medicine ON pharmacy_prices(medicine_name);
CREATE INDEX IF NOT EXISTS idx_pharmacy_prices_pharmacy ON pharmacy_prices(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_loyalty_points_user ON loyalty_points(user_id);
CREATE INDEX IF NOT EXISTS idx_emergency_deliveries_user ON emergency_deliveries(user_id);
CREATE INDEX IF NOT EXISTS idx_emergency_deliveries_status ON emergency_deliveries(status);
CREATE INDEX IF NOT EXISTS idx_pharmacist_consultations_user ON pharmacist_consultations(user_id);
CREATE INDEX IF NOT EXISTS idx_pharmacist_consultations_status ON pharmacist_consultations(status);
CREATE INDEX IF NOT EXISTS idx_ai_recommendations_user ON ai_prescription_recommendations(user_id);

-- تفعيل RLS على جميع الجداول
ALTER TABLE medicine_cabinet ENABLE ROW LEVEL SECURITY;
ALTER TABLE prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE medicine_alternatives ENABLE ROW LEVEL SECURITY;
ALTER TABLE pharmacy_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE loyalty_points ENABLE ROW LEVEL SECURITY;
ALTER TABLE drug_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE pharmacist_consultations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_prescription_recommendations ENABLE ROW LEVEL SECURITY;

-- سياسات RLS - خزانة الأدوية
CREATE POLICY "Users can view own medicine cabinet"
  ON medicine_cabinet FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert into own medicine cabinet"
  ON medicine_cabinet FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own medicine cabinet"
  ON medicine_cabinet FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete from own medicine cabinet"
  ON medicine_cabinet FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- سياسات RLS - الوصفات الطبية
CREATE POLICY "Users can view own prescriptions"
  ON prescriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can upload prescriptions"
  ON prescriptions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- سياسات RLS - البدائل الدوائية (عامة للقراءة)
CREATE POLICY "Anyone can view medicine alternatives"
  ON medicine_alternatives FOR SELECT
  TO authenticated
  USING (true);

-- سياسات RLS - أسعار الصيدليات (عامة للقراءة)
CREATE POLICY "Anyone can view pharmacy prices"
  ON pharmacy_prices FOR SELECT
  TO authenticated
  USING (true);

-- سياسات RLS - نقاط الولاء
CREATE POLICY "Users can view own loyalty points"
  ON loyalty_points FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own loyalty points"
  ON loyalty_points FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own loyalty points"
  ON loyalty_points FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسات RLS - التفاعلات الدوائية (عامة للقراءة)
CREATE POLICY "Anyone can view drug interactions"
  ON drug_interactions FOR SELECT
  TO authenticated
  USING (true);

-- سياسات RLS - التوصيل العاجل
CREATE POLICY "Users can view own emergency deliveries"
  ON emergency_deliveries FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create emergency deliveries"
  ON emergency_deliveries FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own emergency deliveries"
  ON emergency_deliveries FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسات RLS - الاستشارات الصيدلانية
CREATE POLICY "Users can view own consultations"
  ON pharmacist_consultations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create consultations"
  ON pharmacist_consultations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- سياسات RLS - توصيات البوت
CREATE POLICY "Users can view own AI recommendations"
  ON ai_prescription_recommendations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create AI recommendations"
  ON ai_prescription_recommendations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own AI recommendations"
  ON ai_prescription_recommendations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- دالة للتحقق من التفاعلات الدوائية
CREATE OR REPLACE FUNCTION check_drug_interactions(medicines text[])
RETURNS TABLE (
  medicine_pair text,
  severity text,
  description text,
  recommendation text
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    medicine_a || ' + ' || medicine_b as medicine_pair,
    di.severity,
    di.description,
    di.recommendation
  FROM drug_interactions di
  WHERE 
    (di.medicine_a = ANY(medicines) AND di.medicine_b = ANY(medicines))
    OR (di.medicine_b = ANY(medicines) AND di.medicine_a = ANY(medicines));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- دالة لإضافة نقاط ولاء
CREATE OR REPLACE FUNCTION add_loyalty_points(
  p_user_id uuid,
  p_points integer,
  p_reason text
)
RETURNS void AS $$
DECLARE
  v_current_points integer;
BEGIN
  -- الحصول على النقاط الحالية أو إنشاء سجل جديد
  INSERT INTO loyalty_points (user_id, points, total_earned, transactions)
  VALUES (
    p_user_id,
    p_points,
    p_points,
    jsonb_build_array(
      jsonb_build_object(
        'points', p_points,
        'reason', p_reason,
        'date', now()
      )
    )
  )
  ON CONFLICT (user_id) DO UPDATE
  SET 
    points = loyalty_points.points + p_points,
    total_earned = loyalty_points.total_earned + p_points,
    transactions = loyalty_points.transactions || jsonb_build_object(
      'points', p_points,
      'reason', p_reason,
      'date', now()
    ),
    updated_at = now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- إضافة بيانات أمثلة للتفاعلات الدوائية
INSERT INTO drug_interactions (medicine_a, medicine_b, severity, description, recommendation) VALUES
('وارفارين', 'أسبرين', 'high', 'زيادة خطر النزيف بشكل كبير', 'استشر طبيبك فوراً قبل الجمع بين هذين الدوائين'),
('ليثيوم', 'إيبوبروفين', 'high', 'قد يزيد من مستويات الليثيوم في الدم مما يسبب سمية', 'تجنب الاستخدام المتزامن أو راقب مستويات الليثيوم'),
('ميتفورمين', 'كحول', 'medium', 'زيادة خطر الحماض اللبني', 'تجنب تناول الكحول أثناء العلاج بالميتفورمين'),
('سيمفاستاتين', 'كلاريثرومايسين', 'severe', 'زيادة خطر تلف العضلات (انحلال الربيدات)', 'لا تستخدم هذين الدوائين معاً - استشر طبيبك للبدائل'),
('ديجوكسين', 'فوروسيميد', 'medium', 'قد يؤدي إلى انخفاض البوتاسيوم وزيادة سمية الديجوكسين', 'راقب مستويات البوتاسيوم والديجوكسين')
ON CONFLICT DO NOTHING;

-- إضافة بعض البدائل الدوائية الشائعة
INSERT INTO medicine_alternatives (original_medicine, alternative_medicine, active_ingredient, price_difference, manufacturer, availability) VALUES
('بنادول', 'باراسيتامول', 'باراسيتامول', -15.00, 'مختلف', 'available'),
('فولتارين', 'ديكلوفيناك', 'ديكلوفيناك الصوديوم', -20.00, 'مختلف', 'available'),
('زيرتك', 'سيتريزين', 'سيتريزين', -25.00, 'مختلف', 'available'),
('نيكسيوم', 'إيزوميبرازول', 'إيزوميبرازول', -30.00, 'مختلف', 'available'),
('ليبيتور', 'أتورفاستاتين', 'أتورفاستاتين', -45.00, 'مختلف', 'available')
ON CONFLICT DO NOTHING;