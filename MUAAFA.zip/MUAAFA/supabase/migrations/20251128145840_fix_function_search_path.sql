/*
  # إصلاح Function Search Path
  
  1. المشكلة
    - Function generate_order_number له search_path قابل للتغيير
    - يشكل خطر أمني محتمل
  
  2. الحل
    - إضافة SECURITY DEFINER
    - تحديد search_path ثابت
    - استخدام schema-qualified names
*/

-- إعادة إنشاء الدالة مع search path آمن
CREATE OR REPLACE FUNCTION public.generate_order_number()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  new_number text;
  date_part text;
  sequence_part int;
BEGIN
  -- استخدام التاريخ الحالي
  date_part := to_char(now(), 'YYYYMMDD');
  
  -- الحصول على الرقم التسلسلي لهذا اليوم
  SELECT COUNT(*) + 1 INTO sequence_part
  FROM public.orders
  WHERE order_number LIKE 'ORD-' || date_part || '-%';
  
  -- إنشاء رقم الطلب
  new_number := 'ORD-' || date_part || '-' || LPAD(sequence_part::text, 4, '0');
  
  RETURN new_number;
END;
$$;

-- التأكد من الصلاحيات
GRANT EXECUTE ON FUNCTION public.generate_order_number() TO authenticated;
GRANT EXECUTE ON FUNCTION public.generate_order_number() TO service_role;
