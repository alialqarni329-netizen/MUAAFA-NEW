/*
  # Security & Performance Fixes - Part 1: Foreign Key Indexes

  ## Changes Made
  1. Add missing indexes for all foreign keys (27 indexes)
  
  ## Foreign Key Indexes Added
  - appointment_slots: user_id
  - business_verification: verified_by
  - delivery_assignments: delivery_company_id, driver_user_id
  - delivery_proof: order_id, verified_by
  - email_templates: created_by
  - emergency_deliveries: order_id
  - fitness_ai_recommendations: based_on_scan_id
  - insurance_appeals: user_id
  - insurance_approvals: approved_by, insurance_company_id, order_id
  - insurance_requests: insurance_id
  - medical_documents: related_request_id
  - order_timeline: created_by
  - orders: insurance_company_id
  - pharmacist_consultations: pharmacist_id
  - pharmacy_order_requests: order_id
  - post_session_notes: doctor_id, user_id
  - provider_offers: insurance_approval_id, provider_id
  - transactions: order_id
  - uploaded_images: conversation_id
  - waiting_room: user_id

  ## Performance Impact
  - Significantly improves query performance on foreign key lookups
  - Reduces database load for JOIN operations
*/

-- Add indexes for foreign keys that don't have covering indexes

CREATE INDEX IF NOT EXISTS idx_appointment_slots_user_id_fk 
  ON appointment_slots(user_id);

CREATE INDEX IF NOT EXISTS idx_business_verification_verified_by_fk 
  ON business_verification(verified_by);

CREATE INDEX IF NOT EXISTS idx_delivery_assignments_delivery_company_id_fk 
  ON delivery_assignments(delivery_company_id);

CREATE INDEX IF NOT EXISTS idx_delivery_assignments_driver_user_id_fk 
  ON delivery_assignments(driver_user_id);

CREATE INDEX IF NOT EXISTS idx_delivery_proof_order_id_fk 
  ON delivery_proof(order_id);

CREATE INDEX IF NOT EXISTS idx_delivery_proof_verified_by_fk 
  ON delivery_proof(verified_by);

CREATE INDEX IF NOT EXISTS idx_email_templates_created_by_fk 
  ON email_templates(created_by);

CREATE INDEX IF NOT EXISTS idx_emergency_deliveries_order_id_fk 
  ON emergency_deliveries(order_id);

CREATE INDEX IF NOT EXISTS idx_fitness_ai_recommendations_based_on_scan_id_fk 
  ON fitness_ai_recommendations(based_on_scan_id);

CREATE INDEX IF NOT EXISTS idx_insurance_appeals_user_id_fk 
  ON insurance_appeals(user_id);

CREATE INDEX IF NOT EXISTS idx_insurance_approvals_approved_by_fk 
  ON insurance_approvals(approved_by);

CREATE INDEX IF NOT EXISTS idx_insurance_approvals_insurance_company_id_fk 
  ON insurance_approvals(insurance_company_id);

CREATE INDEX IF NOT EXISTS idx_insurance_approvals_order_id_fk 
  ON insurance_approvals(order_id);

CREATE INDEX IF NOT EXISTS idx_insurance_requests_insurance_id_fk 
  ON insurance_requests(insurance_id);

CREATE INDEX IF NOT EXISTS idx_medical_documents_related_request_id_fk 
  ON medical_documents(related_request_id);

CREATE INDEX IF NOT EXISTS idx_order_timeline_created_by_fk 
  ON order_timeline(created_by);

CREATE INDEX IF NOT EXISTS idx_orders_insurance_company_id_fk 
  ON orders(insurance_company_id);

CREATE INDEX IF NOT EXISTS idx_pharmacist_consultations_pharmacist_id_fk 
  ON pharmacist_consultations(pharmacist_id);

CREATE INDEX IF NOT EXISTS idx_pharmacy_order_requests_order_id_fk 
  ON pharmacy_order_requests(order_id);

CREATE INDEX IF NOT EXISTS idx_post_session_notes_doctor_id_fk 
  ON post_session_notes(doctor_id);

CREATE INDEX IF NOT EXISTS idx_post_session_notes_user_id_fk 
  ON post_session_notes(user_id);

CREATE INDEX IF NOT EXISTS idx_provider_offers_insurance_approval_id_fk 
  ON provider_offers(insurance_approval_id);

CREATE INDEX IF NOT EXISTS idx_provider_offers_provider_id_fk 
  ON provider_offers(provider_id);

CREATE INDEX IF NOT EXISTS idx_transactions_order_id_fk 
  ON transactions(order_id);

CREATE INDEX IF NOT EXISTS idx_uploaded_images_conversation_id_fk 
  ON uploaded_images(conversation_id);

CREATE INDEX IF NOT EXISTS idx_waiting_room_user_id_fk 
  ON waiting_room(user_id);
