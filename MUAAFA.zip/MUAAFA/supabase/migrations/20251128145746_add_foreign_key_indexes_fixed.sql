/*
  # إضافة Indexes لجميع Foreign Keys
  
  1. الأداء
    - إضافة indexes لجميع foreign keys لتحسين أداء الاستعلامات
    - تسريع JOIN operations
    - تحسين أداء RLS policies
  
  2. Tables المعالجة (30 foreign key)
    - activity_logs, business_employees, business_registrations
    - cart_items, chat_messages, fitness_goals, fitness_schedules
    - fitness_workouts, hospital_reports, medical_reports
    - nutrition_plans, order_items, orders, pharmacy_inventory
    - prescriptions, products, session_recordings, sessions
    - subscriptions, treatment_categories, uploaded_images
    - usage_logs, user_subscriptions
*/

-- activity_logs
CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON public.activity_logs(user_id);

-- business_employees
CREATE INDEX IF NOT EXISTS idx_business_employees_business_id ON public.business_employees(business_id);
CREATE INDEX IF NOT EXISTS idx_business_employees_user_id ON public.business_employees(user_id);

-- business_registrations
CREATE INDEX IF NOT EXISTS idx_business_registrations_user_id ON public.business_registrations(user_id);

-- cart_items
CREATE INDEX IF NOT EXISTS idx_cart_items_product_id ON public.cart_items(product_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_user_id ON public.cart_items(user_id);

-- chat_messages
CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation_id ON public.chat_messages(conversation_id);

-- fitness_goals
CREATE INDEX IF NOT EXISTS idx_fitness_goals_user_id ON public.fitness_goals(user_id);

-- fitness_schedules
CREATE INDEX IF NOT EXISTS idx_fitness_schedules_user_id ON public.fitness_schedules(user_id);

-- fitness_workouts
CREATE INDEX IF NOT EXISTS idx_fitness_workouts_user_id ON public.fitness_workouts(user_id);

-- hospital_reports
CREATE INDEX IF NOT EXISTS idx_hospital_reports_user_id ON public.hospital_reports(user_id);

-- medical_reports
CREATE INDEX IF NOT EXISTS idx_medical_reports_user_id ON public.medical_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_medical_reports_reviewed_by ON public.medical_reports(reviewed_by);

-- nutrition_plans
CREATE INDEX IF NOT EXISTS idx_nutrition_plans_user_id ON public.nutrition_plans(user_id);

-- order_items
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_medication_id ON public.order_items(medication_id);

-- orders
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_pharmacy_id ON public.orders(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_orders_prescription_id ON public.orders(prescription_id);

-- pharmacy_inventory
CREATE INDEX IF NOT EXISTS idx_pharmacy_inventory_medication_id ON public.pharmacy_inventory(medication_id);

-- prescriptions
CREATE INDEX IF NOT EXISTS idx_prescriptions_user_id ON public.prescriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_reviewed_by ON public.prescriptions(reviewed_by);

-- products
CREATE INDEX IF NOT EXISTS idx_products_treatment_category_id ON public.products(treatment_category_id);

-- session_recordings
CREATE INDEX IF NOT EXISTS idx_session_recordings_session_id ON public.session_recordings(session_id);

-- sessions
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON public.sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_doctor_id ON public.sessions(doctor_id);

-- subscriptions
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON public.subscriptions(user_id);

-- treatment_categories
CREATE INDEX IF NOT EXISTS idx_treatment_categories_pharmacy_category_id ON public.treatment_categories(pharmacy_category_id);

-- uploaded_images
CREATE INDEX IF NOT EXISTS idx_uploaded_images_user_id ON public.uploaded_images(user_id);

-- usage_logs
CREATE INDEX IF NOT EXISTS idx_usage_logs_user_id ON public.usage_logs(user_id);

-- user_subscriptions
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_user_id ON public.user_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_plan_id ON public.user_subscriptions(plan_id);

-- Additional composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_activity_logs_user_deleted ON public.activity_logs(user_id, deleted_by_user);
CREATE INDEX IF NOT EXISTS idx_activity_logs_type_created ON public.activity_logs(activity_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_user_status ON public.orders(user_id, status);
CREATE INDEX IF NOT EXISTS idx_cart_items_user_product ON public.cart_items(user_id, product_id);
