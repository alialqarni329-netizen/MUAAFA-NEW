/*
  # Security & Performance Fixes - Part 3: RLS Policy Optimization (Part 2)

  ## Changes Made
  1. Continue fixing RLS policies to use `(select auth.uid())`
  2. Fix remaining critical tables
  
  ## Tables Fixed (Part 2)
  - pharmacist_consultations
  - ai_prescription_recommendations
  - appointments
  - medical_briefs
  - post_session_notes
  - emergency_deliveries
  - medicine_cabinet
  - prescriptions
  - loyalty_points
  - waiting_room
  - insurance_details
  - insurance_requests
  - insurance_appeals
  - medical_documents
  - payment_transactions

  ## Performance Impact
  - Continues optimization for remaining tables
  - Completes RLS performance improvements
*/

-- Pharmacist Consultations
DROP POLICY IF EXISTS "Users can create consultations" ON pharmacist_consultations;
CREATE POLICY "Users can create consultations"
  ON pharmacist_consultations FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can view own consultations" ON pharmacist_consultations;
CREATE POLICY "Users can view own consultations"
  ON pharmacist_consultations FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

-- AI Prescription Recommendations
DROP POLICY IF EXISTS "Users can view own AI recommendations" ON ai_prescription_recommendations;
CREATE POLICY "Users can view own AI recommendations"
  ON ai_prescription_recommendations FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create AI recommendations" ON ai_prescription_recommendations;
CREATE POLICY "Users can create AI recommendations"
  ON ai_prescription_recommendations FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own AI recommendations" ON ai_prescription_recommendations;
CREATE POLICY "Users can update own AI recommendations"
  ON ai_prescription_recommendations FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Appointments
DROP POLICY IF EXISTS "Users can view own appointments" ON appointments;
CREATE POLICY "Users can view own appointments"
  ON appointments FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create own appointments" ON appointments;
CREATE POLICY "Users can create own appointments"
  ON appointments FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own appointments" ON appointments;
CREATE POLICY "Users can update own appointments"
  ON appointments FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Medical Briefs
DROP POLICY IF EXISTS "Users can view own medical briefs" ON medical_briefs;
CREATE POLICY "Users can view own medical briefs"
  ON medical_briefs FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create own medical briefs" ON medical_briefs;
CREATE POLICY "Users can create own medical briefs"
  ON medical_briefs FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own medical briefs" ON medical_briefs;
CREATE POLICY "Users can update own medical briefs"
  ON medical_briefs FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Post Session Notes
DROP POLICY IF EXISTS "Users can view own session notes" ON post_session_notes;
CREATE POLICY "Users can view own session notes"
  ON post_session_notes FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create own session notes" ON post_session_notes;
CREATE POLICY "Users can create own session notes"
  ON post_session_notes FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own session notes" ON post_session_notes;
CREATE POLICY "Users can update own session notes"
  ON post_session_notes FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Emergency Deliveries
DROP POLICY IF EXISTS "Users can view own emergency deliveries" ON emergency_deliveries;
CREATE POLICY "Users can view own emergency deliveries"
  ON emergency_deliveries FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders 
    WHERE id = order_id AND user_id = (select auth.uid())
  ));

DROP POLICY IF EXISTS "Users can create emergency deliveries" ON emergency_deliveries;
CREATE POLICY "Users can create emergency deliveries"
  ON emergency_deliveries FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM orders 
    WHERE id = order_id AND user_id = (select auth.uid())
  ));

DROP POLICY IF EXISTS "Users can update own emergency deliveries" ON emergency_deliveries;
CREATE POLICY "Users can update own emergency deliveries"
  ON emergency_deliveries FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders 
    WHERE id = order_id AND user_id = (select auth.uid())
  ));

-- Medicine Cabinet
DROP POLICY IF EXISTS "Users can view own medicine cabinet" ON medicine_cabinet;
CREATE POLICY "Users can view own medicine cabinet"
  ON medicine_cabinet FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert into own medicine cabinet" ON medicine_cabinet;
CREATE POLICY "Users can insert into own medicine cabinet"
  ON medicine_cabinet FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own medicine cabinet" ON medicine_cabinet;
CREATE POLICY "Users can update own medicine cabinet"
  ON medicine_cabinet FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete from own medicine cabinet" ON medicine_cabinet;
CREATE POLICY "Users can delete from own medicine cabinet"
  ON medicine_cabinet FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Prescriptions
DROP POLICY IF EXISTS "Users can view own prescriptions" ON prescriptions;
CREATE POLICY "Users can view own prescriptions"
  ON prescriptions FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can upload prescriptions" ON prescriptions;
CREATE POLICY "Users can upload prescriptions"
  ON prescriptions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- Loyalty Points
DROP POLICY IF EXISTS "Users can view own loyalty points" ON loyalty_points;
CREATE POLICY "Users can view own loyalty points"
  ON loyalty_points FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own loyalty points" ON loyalty_points;
CREATE POLICY "Users can insert own loyalty points"
  ON loyalty_points FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own loyalty points" ON loyalty_points;
CREATE POLICY "Users can update own loyalty points"
  ON loyalty_points FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Waiting Room
DROP POLICY IF EXISTS "Users can view own waiting room" ON waiting_room;
CREATE POLICY "Users can view own waiting room"
  ON waiting_room FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create own waiting room entry" ON waiting_room;
CREATE POLICY "Users can create own waiting room entry"
  ON waiting_room FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own waiting room entry" ON waiting_room;
CREATE POLICY "Users can update own waiting room entry"
  ON waiting_room FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Insurance Details
DROP POLICY IF EXISTS "Users can view own insurance details" ON insurance_details;
CREATE POLICY "Users can view own insurance details"
  ON insurance_details FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own insurance details" ON insurance_details;
CREATE POLICY "Users can insert own insurance details"
  ON insurance_details FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own insurance details" ON insurance_details;
CREATE POLICY "Users can update own insurance details"
  ON insurance_details FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Insurance Requests
DROP POLICY IF EXISTS "Users can view own insurance requests" ON insurance_requests;
CREATE POLICY "Users can view own insurance requests"
  ON insurance_requests FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create insurance requests" ON insurance_requests;
CREATE POLICY "Users can create insurance requests"
  ON insurance_requests FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own insurance requests" ON insurance_requests;
CREATE POLICY "Users can update own insurance requests"
  ON insurance_requests FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Insurance Appeals
DROP POLICY IF EXISTS "Users can view own appeals" ON insurance_appeals;
CREATE POLICY "Users can view own appeals"
  ON insurance_appeals FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create appeals" ON insurance_appeals;
CREATE POLICY "Users can create appeals"
  ON insurance_appeals FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own appeals" ON insurance_appeals;
CREATE POLICY "Users can update own appeals"
  ON insurance_appeals FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Medical Documents
DROP POLICY IF EXISTS "Users can view own documents" ON medical_documents;
CREATE POLICY "Users can view own documents"
  ON medical_documents FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can upload documents" ON medical_documents;
CREATE POLICY "Users can upload documents"
  ON medical_documents FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own documents" ON medical_documents;
CREATE POLICY "Users can delete own documents"
  ON medical_documents FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Payment Transactions
DROP POLICY IF EXISTS "Users can view own transactions" ON payment_transactions;
CREATE POLICY "Users can view own transactions"
  ON payment_transactions FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create transactions" ON payment_transactions;
CREATE POLICY "Users can create transactions"
  ON payment_transactions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));
