/*
  # إصلاح مشاكل الأمان والأداء الحرجة - النسخة النهائية

  1. الأمان الحرج (CRITICAL SECURITY)
    - تفعيل RLS على الجداول العامة
    - إصلاح RLS policies للأداء

  2. الأداء (PERFORMANCE)
    - إضافة indexes للـ foreign keys
    - تحسين RLS policies (wrap auth functions)
    - إصلاح search_path للدوال
    - حذف duplicate constraints
*/

-- ================================================================================
-- PART 1: CRITICAL SECURITY - Enable RLS on Public Tables
-- ================================================================================

ALTER TABLE IF EXISTS app_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Owners can manage app settings" ON app_settings;
CREATE POLICY "Owners can manage app settings"
  ON app_settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Public can read app settings" ON app_settings;
CREATE POLICY "Public can read app settings"
  ON app_settings
  FOR SELECT
  TO authenticated
  USING (true);

ALTER TABLE IF EXISTS system_config ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Owners can manage system config" ON system_config;
CREATE POLICY "Owners can manage system config"
  ON system_config
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- ================================================================================
-- PART 2: ADD MISSING FOREIGN KEY INDEXES (CRITICAL for PERFORMANCE)
-- ================================================================================

CREATE INDEX IF NOT EXISTS idx_appointments_insurance_id ON appointments(insurance_id);
CREATE INDEX IF NOT EXISTS idx_appointments_journey_id ON appointments(journey_id);
CREATE INDEX IF NOT EXISTS idx_appointments_payment_id ON appointments(payment_id);
CREATE INDEX IF NOT EXISTS idx_invoices_insurance_id_fk ON invoices(insurance_id);
CREATE INDEX IF NOT EXISTS idx_medical_sessions_insurance_policy_id_fk ON medical_sessions(insurance_policy_id);
CREATE INDEX IF NOT EXISTS idx_patient_journeys_insurance_id_fk ON patient_journeys(insurance_id);
CREATE INDEX IF NOT EXISTS idx_pharmacy_cart_prescription_id_fk ON pharmacy_cart(prescription_id);
CREATE INDEX IF NOT EXISTS idx_pharmacy_orders_insurance_policy_id_fk ON pharmacy_orders(insurance_policy_id);
CREATE INDEX IF NOT EXISTS idx_session_archives_provider_id_fk ON session_archives(provider_id);

-- ================================================================================
-- PART 3: FIX RLS POLICIES PERFORMANCE (Wrap auth functions with SELECT)
-- ================================================================================

-- insurance_policies
DROP POLICY IF EXISTS "Users can view own insurance policies" ON insurance_policies;
CREATE POLICY "Users can view own insurance policies"
  ON insurance_policies
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can insert own insurance policies" ON insurance_policies;
CREATE POLICY "Users can insert own insurance policies"
  ON insurance_policies
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can update own insurance policies" ON insurance_policies;
CREATE POLICY "Users can update own insurance policies"
  ON insurance_policies
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- medical_sessions
DROP POLICY IF EXISTS "Users can view own sessions" ON medical_sessions;
CREATE POLICY "Users can view own sessions"
  ON medical_sessions
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can insert own sessions" ON medical_sessions;
CREATE POLICY "Users can insert own sessions"
  ON medical_sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can update own pending sessions" ON medical_sessions;
CREATE POLICY "Users can update own pending sessions"
  ON medical_sessions
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- pharmacy_orders
DROP POLICY IF EXISTS "Users can view own pharmacy orders" ON pharmacy_orders;
CREATE POLICY "Users can view own pharmacy orders"
  ON pharmacy_orders
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can insert own pharmacy orders" ON pharmacy_orders;
CREATE POLICY "Users can insert own pharmacy orders"
  ON pharmacy_orders
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can update own pending orders" ON pharmacy_orders;
CREATE POLICY "Users can update own pending orders"
  ON pharmacy_orders
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- delivery_assignments
DROP POLICY IF EXISTS "Delivery companies can manage own assignments" ON delivery_assignments;
CREATE POLICY "Delivery companies can manage own assignments"
  ON delivery_assignments
  FOR ALL
  TO authenticated
  USING (driver_user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can view own delivery assignments" ON delivery_assignments;
CREATE POLICY "Users can view own delivery assignments"
  ON delivery_assignments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM pharmacy_orders po
      WHERE po.user_id = (SELECT auth.uid())
      AND delivery_assignments.order_id = po.id
    )
  );

-- order_timeline
DROP POLICY IF EXISTS "Business users can view relevant order timeline" ON order_timeline;
CREATE POLICY "Business users can view relevant order timeline"
  ON order_timeline
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM pharmacy_orders po
      WHERE po.user_id = (SELECT auth.uid())
      AND order_timeline.order_id = po.id
    )
  );

-- pharmacy_order_requests
DROP POLICY IF EXISTS "Pharmacies can manage own requests" ON pharmacy_order_requests;
CREATE POLICY "Pharmacies can manage own requests"
  ON pharmacy_order_requests
  FOR ALL
  TO authenticated
  USING (pharmacy_id IS NOT NULL);

DROP POLICY IF EXISTS "Users can view requests for own orders" ON pharmacy_order_requests;
CREATE POLICY "Users can view requests for own orders"
  ON pharmacy_order_requests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM pharmacy_orders po
      WHERE po.user_id = (SELECT auth.uid())
      AND pharmacy_order_requests.order_id = po.id
    )
  );

-- email_templates
DROP POLICY IF EXISTS "Only admins can manage email templates" ON email_templates;
CREATE POLICY "Only admins can manage email templates"
  ON email_templates
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- users
DROP POLICY IF EXISTS "Only owners can update user roles" ON users;
CREATE POLICY "Only owners can update user roles"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users u
      WHERE u.id = (SELECT auth.uid())
      AND u.user_role = 'owner'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users u
      WHERE u.id = (SELECT auth.uid())
      AND u.user_role = 'owner'
    )
  );

-- system_status
DROP POLICY IF EXISTS "Owners can view system status" ON system_status;
CREATE POLICY "Owners can view system status"
  ON system_status
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Owners can insert system status" ON system_status;
CREATE POLICY "Owners can insert system status"
  ON system_status
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Owners can update system status" ON system_status;
CREATE POLICY "Owners can update system status"
  ON system_status
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- business_permissions
DROP POLICY IF EXISTS "Owner full access permissions" ON business_permissions;
CREATE POLICY "Owner full access permissions"
  ON business_permissions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- business_settings
DROP POLICY IF EXISTS "Owner full access settings" ON business_settings;
CREATE POLICY "Owner full access settings"
  ON business_settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- user_analytics
DROP POLICY IF EXISTS "Owner full access analytics" ON user_analytics;
CREATE POLICY "Owner full access analytics"
  ON user_analytics
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- session_archives
DROP POLICY IF EXISTS "Owner view all archives" ON session_archives;
CREATE POLICY "Owner view all archives"
  ON session_archives
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- patient_journeys
DROP POLICY IF EXISTS "Owners can view all journeys" ON patient_journeys;
CREATE POLICY "Owners can view all journeys"
  ON patient_journeys
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Users can create own journeys" ON patient_journeys;
CREATE POLICY "Users can create own journeys"
  ON patient_journeys
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can view own journeys" ON patient_journeys;
CREATE POLICY "Users can view own journeys"
  ON patient_journeys
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- pharmacy_cart
DROP POLICY IF EXISTS "Users can manage own cart" ON pharmacy_cart;
CREATE POLICY "Users can manage own cart"
  ON pharmacy_cart
  FOR ALL
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- payments
DROP POLICY IF EXISTS "Owners can view all payments" ON payments;
CREATE POLICY "Owners can view all payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Users can view own payments" ON payments;
CREATE POLICY "Users can view own payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- invoices
DROP POLICY IF EXISTS "Owners can view all invoices" ON invoices;
CREATE POLICY "Owners can view all invoices"
  ON invoices
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Users can view own invoices" ON invoices;
CREATE POLICY "Users can view own invoices"
  ON invoices
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- settlements
DROP POLICY IF EXISTS "Owners can manage all settlements" ON settlements;
CREATE POLICY "Owners can manage all settlements"
  ON settlements
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

DROP POLICY IF EXISTS "Providers can view own settlements" ON settlements;
CREATE POLICY "Providers can view own settlements"
  ON settlements
  FOR SELECT
  TO authenticated
  USING (provider_id = (SELECT auth.uid()));

-- medical_questionnaire
DROP POLICY IF EXISTS "Users can view own questionnaire" ON medical_questionnaire;
CREATE POLICY "Users can view own questionnaire"
  ON medical_questionnaire
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can insert own questionnaire" ON medical_questionnaire;
CREATE POLICY "Users can insert own questionnaire"
  ON medical_questionnaire
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can update own questionnaire" ON medical_questionnaire;
CREATE POLICY "Users can update own questionnaire"
  ON medical_questionnaire
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- legal_pages
DROP POLICY IF EXISTS "Owner manage legal pages" ON legal_pages;
CREATE POLICY "Owner manage legal pages"
  ON legal_pages
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- ================================================================================
-- PART 4: FIX FUNCTION SEARCH PATH (CRITICAL for SECURITY)
-- ================================================================================

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION check_drug_interactions_enhanced SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION check_drug_interactions SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION notify_business_status_change SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION update_system_status_timestamp SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION generate_invoice_number SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION calculate_user_payable SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION update_session_after_payment SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION update_order_after_payment SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION check_duplicate_user_data SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION check_duplicate_business_data SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION auto_confirm_medical_session SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION auto_confirm_pharmacy_order SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION auto_generate_invoice SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION handle_insurance_approval_update SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION add_loyalty_points SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION update_updated_at_column SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION update_conversation_timestamp SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION check_subscription_status SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION grant_trial_subscription SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION create_trial_subscription_record SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION check_expiring_subscriptions SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER FUNCTION check_feature_access SET search_path = public, pg_temp';
EXCEPTION WHEN undefined_function THEN NULL;
END $$;

-- ================================================================================
-- PART 5: DROP DUPLICATE CONSTRAINT (Keep only one)
-- ================================================================================

ALTER TABLE business_registrations DROP CONSTRAINT IF EXISTS business_registrations_commercial_registration_key;