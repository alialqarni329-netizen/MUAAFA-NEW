/*
  # Security and Performance Fixes - Part 6: RLS Optimization (Batch 5)

  This migration continues optimizing Row Level Security (RLS) policies by replacing
  direct auth.uid() calls with (select auth.uid()) to prevent function re-evaluation
  for each row, significantly improving query performance at scale.

  ## Tables Optimized in This Batch:
  1. users - policies for user profile access
  2. sessions - policies for telehealth sessions
  3. session_recordings - policies for session recordings (checks via sessions)

  ## Performance Impact:
  - Reduces auth function calls from O(n) to O(1) per query
  - Improves response times for large result sets
  - Reduces database CPU usage

  ## Security:
  - Maintains identical security guarantees
  - No changes to access control logic
*/

-- ============================================================================
-- users (auth table with id column)
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own profile" ON users;
CREATE POLICY "Users can view own profile" ON users
  FOR SELECT
  TO authenticated
  USING (id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own profile" ON users;
CREATE POLICY "Users can update own profile" ON users
  FOR UPDATE
  TO authenticated
  USING (id = (select auth.uid()))
  WITH CHECK (id = (select auth.uid()));

-- ============================================================================
-- sessions (telehealth sessions)
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own sessions" ON sessions;
CREATE POLICY "Users can view own sessions" ON sessions
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own sessions" ON sessions;
CREATE POLICY "Users can insert own sessions" ON sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own sessions" ON sessions;
CREATE POLICY "Users can update own sessions" ON sessions
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own sessions" ON sessions;
CREATE POLICY "Users can delete own sessions" ON sessions
  FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================================================
-- session_recordings (checks via sessions.user_id)
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own session recordings" ON session_recordings;
CREATE POLICY "Users can view own session recordings" ON session_recordings
  FOR SELECT
  TO authenticated
  USING (
    session_id IN (
      SELECT id FROM sessions
      WHERE user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Users can insert own session recordings" ON session_recordings;
CREATE POLICY "Users can insert own session recordings" ON session_recordings
  FOR INSERT
  TO authenticated
  WITH CHECK (
    session_id IN (
      SELECT id FROM sessions
      WHERE user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Users can update own session recordings" ON session_recordings;
CREATE POLICY "Users can update own session recordings" ON session_recordings
  FOR UPDATE
  TO authenticated
  USING (
    session_id IN (
      SELECT id FROM sessions
      WHERE user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    session_id IN (
      SELECT id FROM sessions
      WHERE user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Users can delete own session recordings" ON session_recordings;
CREATE POLICY "Users can delete own session recordings" ON session_recordings
  FOR DELETE
  TO authenticated
  USING (
    session_id IN (
      SELECT id FROM sessions
      WHERE user_id = (select auth.uid())
    )
  );
