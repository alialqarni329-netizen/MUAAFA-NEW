/*
  # إضافة Indexes للـ Foreign Keys - الجزء الثاني
  
  ## Indexes للجداول (Part 2)
  - insurance_policies: user_id
  - insurance_requests: insurance_id
  - invoices: insurance_id, journey_id, payment_id, provider_id, user_id
  - ip_restrictions: created_by
  - medical_briefs: appointment_id
  - medical_documents: related_request_id
  - medical_questionnaire: user_id
  - medical_sessions: insurance_policy_id, user_id
  - order_items: medication_id, order_id
  - order_timeline: order_id
  - orders: insurance_company_id, pharmacy_id, prescription_id
*/

-- insurance_policies
CREATE INDEX IF NOT EXISTS idx_insurance_policies_user_id 
ON insurance_policies(user_id);

-- insurance_requests
CREATE INDEX IF NOT EXISTS idx_insurance_requests_insurance_id 
ON insurance_requests(insurance_id);

-- invoices
CREATE INDEX IF NOT EXISTS idx_invoices_insurance_id 
ON invoices(insurance_id);

CREATE INDEX IF NOT EXISTS idx_invoices_journey_id 
ON invoices(journey_id);

CREATE INDEX IF NOT EXISTS idx_invoices_payment_id 
ON invoices(payment_id);

CREATE INDEX IF NOT EXISTS idx_invoices_provider_id 
ON invoices(provider_id);

CREATE INDEX IF NOT EXISTS idx_invoices_user_id 
ON invoices(user_id);

-- ip_restrictions
CREATE INDEX IF NOT EXISTS idx_ip_restrictions_created_by 
ON ip_restrictions(created_by);

-- medical_briefs
CREATE INDEX IF NOT EXISTS idx_medical_briefs_appointment_id 
ON medical_briefs(appointment_id);

-- medical_documents
CREATE INDEX IF NOT EXISTS idx_medical_documents_related_request_id 
ON medical_documents(related_request_id);

-- medical_questionnaire
CREATE INDEX IF NOT EXISTS idx_medical_questionnaire_user_id 
ON medical_questionnaire(user_id);

-- medical_sessions
CREATE INDEX IF NOT EXISTS idx_medical_sessions_insurance_policy_id 
ON medical_sessions(insurance_policy_id);

CREATE INDEX IF NOT EXISTS idx_medical_sessions_user_id 
ON medical_sessions(user_id);

-- order_items
CREATE INDEX IF NOT EXISTS idx_order_items_medication_id 
ON order_items(medication_id);

CREATE INDEX IF NOT EXISTS idx_order_items_order_id 
ON order_items(order_id);

-- order_timeline
CREATE INDEX IF NOT EXISTS idx_order_timeline_order_id 
ON order_timeline(order_id);

-- orders
CREATE INDEX IF NOT EXISTS idx_orders_insurance_company_id 
ON orders(insurance_company_id);

CREATE INDEX IF NOT EXISTS idx_orders_pharmacy_id 
ON orders(pharmacy_id);

CREATE INDEX IF NOT EXISTS idx_orders_prescription_id 
ON orders(prescription_id);
