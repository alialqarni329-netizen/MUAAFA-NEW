/*
  # Create Chat Images Storage Bucket

  1. Storage Bucket
    - Creates `chat-images` bucket for storing user-uploaded images in AI Doctor chats
    - Public bucket to allow easy access to images in chat
    - Organized by user ID and conversation ID

  2. Security
    - Users can only upload images to their own folders
    - Users can view images from their own conversations
    - Images are publicly accessible via URL (for chat display)
    - File size limited to 5MB per image
    - Only image file types allowed (jpg, jpeg, png, gif, webp)
*/

-- Create the storage bucket for chat images
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-images', 'chat-images', true)
ON CONFLICT (id) DO NOTHING;

-- Policy: Allow authenticated users to upload images to their own folder
CREATE POLICY "Users can upload images to own folder"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'chat-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy: Allow authenticated users to view their own images
CREATE POLICY "Users can view own images"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'chat-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy: Allow authenticated users to delete their own images
CREATE POLICY "Users can delete own images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'chat-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy: Allow public read access to all chat images (for displaying in chat)
CREATE POLICY "Public read access to chat images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'chat-images');