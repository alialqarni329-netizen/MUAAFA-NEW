/*
  # تحديث أسماء الباقات لتتوافق مع الباقات الموجودة

  ## التغييرات
  - تحديث دالة check_feature_access لتستخدم الأسماء الفعلية للباقات
  - الباقات: free, plus, vip
  - الأسعار: free = 0، plus = 79/شهر أو 948/سنة، vip = 199/شهر أو 2388/سنة
*/

-- تحديث دالة التحقق من الوصول للميزات
CREATE OR REPLACE FUNCTION check_feature_access(
  user_id_param uuid,
  feature_name text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  subscription_info record;
BEGIN
  -- جلب حالة الاشتراك
  SELECT * INTO subscription_info
  FROM check_subscription_status(user_id_param);

  -- الميزات المتاحة دائماً (حتى بدون اشتراك)
  IF feature_name IN ('health_records', 'reports', 'profile', 'settings') THEN
    RETURN true;
  END IF;

  -- إذا كان الاشتراك نشط (تجريبي أو مدفوع)
  IF subscription_info.is_active THEN
    -- الباقة المجانية/الأساسية (free)
    IF subscription_info.plan_type IN ('free', 'basic') THEN
      RETURN feature_name IN (
        'health_records',
        'reports', 
        'profile',
        'settings',
        'health_chatbot_limited',
        'smart_wallet_limited',
        'fitness_steps_only'
      );
    END IF;

    -- باقة مُعافى بلس (plus)
    IF subscription_info.plan_type = 'plus' THEN
      RETURN feature_name IN (
        'health_records',
        'reports',
        'profile',
        'settings',
        'health_chatbot',
        'smart_wallet',
        'pharmacy_discount_10',
        'virtual_sessions_10',
        'fitness_programs',
        'fitness_tracking',
        'activity_tracking',
        'pharmacy_browse',
        'medication_reminders',
        'prescription_scan',
        'barcode_scan',
        'nearby_pharmacies'
      );
    END IF;

    -- باقة مُعافى VIP (vip)
    IF subscription_info.plan_type = 'vip' THEN
      RETURN true; -- وصول لجميع الميزات
    END IF;
  END IF;

  RETURN false;
END;
$$;

-- تحديث دالة التحقق من الاشتراكات المنتهية
CREATE OR REPLACE FUNCTION check_expiring_subscriptions()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  sub_record record;
  plan_name_ar text;
BEGIN
  FOR sub_record IN 
    SELECT s.*
    FROM subscriptions s
    WHERE s.status = 'active'
      AND s.end_date BETWEEN now() AND (now() + interval '3 days')
      AND (s.notification_sent = false OR s.notification_sent IS NULL)
  LOOP
    -- تحديد اسم الباقة بالعربي
    plan_name_ar := CASE sub_record.plan_type
      WHEN 'free' THEN 'الباقة الأساسية'
      WHEN 'basic' THEN 'الباقة الأساسية'
      WHEN 'plus' THEN 'مُعافى بلس'
      WHEN 'vip' THEN 'مُعافى VIP'
      ELSE sub_record.plan_type
    END;

    -- إنشاء تنبيه للمستخدم
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data,
      priority
    ) VALUES (
      sub_record.user_id,
      'subscription_expiring',
      'اشتراكك على وشك الانتهاء',
      format('اشتراكك في %s سينتهي في %s. جدد اشتراكك الآن لتستمر في الاستفادة من جميع الميزات.', 
        plan_name_ar,
        to_char(sub_record.end_date, 'YYYY-MM-DD')
      ),
      jsonb_build_object(
        'subscription_id', sub_record.id,
        'plan_type', sub_record.plan_type,
        'expires_at', sub_record.end_date,
        'action', 'renew_subscription'
      ),
      'high'
    );

    -- تحديث حالة الإشعار
    UPDATE subscriptions
    SET 
      notification_sent = true,
      last_notification_at = now()
    WHERE id = sub_record.id;
  END LOOP;
END;
$$;

-- تحديث trigger لمنح الباقة المجانية بدلاً من basic
CREATE OR REPLACE FUNCTION grant_trial_subscription()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- تحديث معلومات التجربة المجانية
  NEW.trial_started_at := now();
  NEW.trial_ends_at := now() + interval '10 days';
  NEW.has_active_subscription := true;
  NEW.current_plan_type := 'free';

  RETURN NEW;
END;
$$;

-- تحديث trigger لإنشاء سجل اشتراك بالباقة المجانية
CREATE OR REPLACE FUNCTION create_trial_subscription_record()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- إنشاء سجل اشتراك تجريبي بالباقة المجانية
  INSERT INTO subscriptions (
    user_id,
    plan_type,
    status,
    start_date,
    end_date,
    is_trial,
    auto_renew
  ) VALUES (
    NEW.id,
    'free',
    'active',
    now(),
    now() + interval '10 days',
    true,
    false
  );

  RETURN NEW;
END;
$$;

-- تعليقات
COMMENT ON FUNCTION check_feature_access IS 'التحقق من الوصول للميزات حسب الباقة: free (مجاني), plus (79 ريال/شهر), vip (199 ريال/شهر)';
