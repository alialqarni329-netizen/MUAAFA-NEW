/*
  # Add Telehealth Appointments System
  
  1. New Tables
    - `appointments` - جدول المواعيد الطبية
      - معلومات الحجز الأساسية
      - روابط الاجتماعات (Zoom/Teams)
      - حالة الموعد
      - ملخص الحالة الطبية
    
    - `medical_briefs` - موجز مُعافى للطبيب
      - ملخص المحادثات مع البوت
      - نتائج المؤشرات الحيوية
      - تاريخ الحالة الطبية
    
    - `post_session_notes` - ملاحظات ما بعد الجلسة
      - الخطة العلاجية
      - توصيات الطبيب
      - الأدوية الموصوفة
  
  2. Security
    - Enable RLS على جميع الجداول
    - سياسات أمان لضمان الخصوصية
    - تشفير البيانات الحساسة
*/

-- Create appointments table
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  doctor_id uuid REFERENCES doctors(id) NOT NULL,
  
  -- Appointment details
  appointment_type text NOT NULL CHECK (appointment_type IN ('video', 'chat', 'instant')),
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'waiting', 'in_progress', 'completed', 'cancelled', 'no_show')),
  scheduled_date date NOT NULL,
  scheduled_time time NOT NULL,
  duration_minutes integer DEFAULT 30,
  
  -- Meeting links
  meeting_platform text CHECK (meeting_platform IN ('zoom', 'teams', 'other')),
  meeting_url text,
  meeting_id text,
  meeting_password text,
  
  -- Medical information
  reason_for_visit text,
  symptoms jsonb DEFAULT '[]'::jsonb,
  medical_brief_sent boolean DEFAULT false,
  medical_brief_id uuid,
  
  -- Privacy consent
  privacy_consent_accepted boolean DEFAULT false,
  privacy_consent_at timestamptz,
  
  -- Notifications
  reminder_sent boolean DEFAULT false,
  reminder_sent_at timestamptz,
  
  -- Session tracking
  joined_at timestamptz,
  ended_at timestamptz,
  actual_duration_minutes integer,
  
  -- Metadata
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create medical_briefs table
CREATE TABLE IF NOT EXISTS medical_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  appointment_id uuid REFERENCES appointments(id),
  
  -- Chat history summary
  recent_conversations jsonb DEFAULT '[]'::jsonb,
  main_concerns text[],
  
  -- Vital signs from fitness tab
  latest_vitals jsonb DEFAULT '{}'::jsonb,
  fitness_summary text,
  
  -- Medical history
  current_medications text[],
  allergies text[],
  chronic_conditions text[],
  
  -- AI generated summary
  ai_summary text,
  summary_generated_at timestamptz,
  
  -- Sharing status
  shared_with_doctor boolean DEFAULT false,
  shared_at timestamptz,
  doctor_viewed boolean DEFAULT false,
  doctor_viewed_at timestamptz,
  
  created_at timestamptz DEFAULT now()
);

-- Create post_session_notes table
CREATE TABLE IF NOT EXISTS post_session_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid REFERENCES appointments(id) NOT NULL,
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  doctor_id uuid REFERENCES doctors(id) NOT NULL,
  
  -- Doctor's notes
  diagnosis text,
  treatment_plan text,
  prescriptions jsonb DEFAULT '[]'::jsonb,
  follow_up_required boolean DEFAULT false,
  follow_up_date date,
  
  -- Documents
  prescription_files text[],
  report_files text[],
  
  -- Patient feedback
  patient_rating integer CHECK (patient_rating >= 1 AND patient_rating <= 5),
  patient_feedback text,
  
  -- AI processing
  converted_to_tasks boolean DEFAULT false,
  tasks_created_at timestamptz,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create waiting_room table for pre-session experience
CREATE TABLE IF NOT EXISTS waiting_room (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid REFERENCES appointments(id) NOT NULL,
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  
  -- Waiting room status
  status text NOT NULL DEFAULT 'preparing' CHECK (status IN ('preparing', 'ready', 'joined')),
  entered_at timestamptz DEFAULT now(),
  
  -- Health tips shown
  health_tips_shown jsonb DEFAULT '[]'::jsonb,
  
  -- Technical checks
  camera_check_passed boolean DEFAULT false,
  microphone_check_passed boolean DEFAULT false,
  connection_check_passed boolean DEFAULT false,
  
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE medical_briefs ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_session_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE waiting_room ENABLE ROW LEVEL SECURITY;

-- RLS Policies for appointments
CREATE POLICY "Users can view own appointments"
  ON appointments FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own appointments"
  ON appointments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own appointments"
  ON appointments FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for medical_briefs
CREATE POLICY "Users can view own medical briefs"
  ON medical_briefs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own medical briefs"
  ON medical_briefs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own medical briefs"
  ON medical_briefs FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for post_session_notes
CREATE POLICY "Users can view own session notes"
  ON post_session_notes FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own session notes"
  ON post_session_notes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own session notes"
  ON post_session_notes FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for waiting_room
CREATE POLICY "Users can view own waiting room"
  ON waiting_room FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own waiting room entry"
  ON waiting_room FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own waiting room entry"
  ON waiting_room FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_appointments_user_id ON appointments(user_id);
CREATE INDEX IF NOT EXISTS idx_appointments_doctor_id ON appointments(doctor_id);
CREATE INDEX IF NOT EXISTS idx_appointments_scheduled_date ON appointments(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);
CREATE INDEX IF NOT EXISTS idx_medical_briefs_user_id ON medical_briefs(user_id);
CREATE INDEX IF NOT EXISTS idx_medical_briefs_appointment_id ON medical_briefs(appointment_id);
CREATE INDEX IF NOT EXISTS idx_post_session_notes_appointment_id ON post_session_notes(appointment_id);
CREATE INDEX IF NOT EXISTS idx_waiting_room_appointment_id ON waiting_room(appointment_id);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_appointments_updated_at'
  ) THEN
    CREATE TRIGGER update_appointments_updated_at
      BEFORE UPDATE ON appointments
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_post_session_notes_updated_at'
  ) THEN
    CREATE TRIGGER update_post_session_notes_updated_at
      BEFORE UPDATE ON post_session_notes
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;