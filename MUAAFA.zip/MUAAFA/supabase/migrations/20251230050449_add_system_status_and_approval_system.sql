/*
  # إضافة جدول حالة النظام ونظام الموافقات

  ## التغييرات

  ### 1. جدول حالة الخدمات (system_status)
    - `id` (uuid, primary key)
    - `service_name` (text) - اسم الخدمة
    - `service_key` (text, unique) - مفتاح الخدمة (otp, payment, notifications, email)
    - `status` (text) - الحالة (active, warning, error, maintenance)
    - `message` (text) - رسالة الحالة
    - `last_check` (timestamptz) - آخر فحص
    - `response_time_ms` (integer) - وقت الاستجابة بالميلي ثانية
    - `uptime_percentage` (numeric) - نسبة التشغيل
    - `created_at` (timestamptz)
    - `updated_at` (timestamptz)

  ### 2. تحديثات على جدول business_registrations
    - إضافة `reviewed_by` (uuid) - معرف من راجع الطلب
    - إضافة `reviewed_at` (timestamptz) - وقت المراجعة
    - إضافة `rejection_reason` (text) - سبب الرفض
    - إضافة `approval_notes` (text) - ملاحظات الموافقة

  ### 3. الأمان
    - تفعيل RLS على جدول system_status
    - سياسات للمالكين فقط
    - تفعيل triggers للإشعارات عند الموافقة/الرفض

  ### 4. بيانات افتراضية
    - إدراج الخدمات الأساسية في system_status
*/

-- إنشاء جدول حالة النظام
CREATE TABLE IF NOT EXISTS system_status (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_name text NOT NULL,
  service_key text UNIQUE NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'warning', 'error', 'maintenance')),
  message text NOT NULL DEFAULT 'تعمل بشكل طبيعي',
  last_check timestamptz DEFAULT now(),
  response_time_ms integer DEFAULT 0,
  uptime_percentage numeric(5,2) DEFAULT 100.00,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إضافة indexes لجدول system_status
CREATE INDEX IF NOT EXISTS idx_system_status_key ON system_status(service_key);
CREATE INDEX IF NOT EXISTS idx_system_status_status ON system_status(status);

-- تحديث جدول business_registrations
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' AND column_name = 'reviewed_by'
  ) THEN
    ALTER TABLE business_registrations ADD COLUMN reviewed_by uuid REFERENCES users(id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' AND column_name = 'reviewed_at'
  ) THEN
    ALTER TABLE business_registrations ADD COLUMN reviewed_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' AND column_name = 'rejection_reason'
  ) THEN
    ALTER TABLE business_registrations ADD COLUMN rejection_reason text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' AND column_name = 'approval_notes'
  ) THEN
    ALTER TABLE business_registrations ADD COLUMN approval_notes text;
  END IF;
END $$;

-- إضافة index على reviewed_by
CREATE INDEX IF NOT EXISTS idx_business_registrations_reviewed_by ON business_registrations(reviewed_by);

-- تفعيل RLS على جدول system_status
ALTER TABLE system_status ENABLE ROW LEVEL SECURITY;

-- سياسات RLS لجدول system_status
-- المالكون فقط يمكنهم القراءة والتعديل
CREATE POLICY "Owners can view system status"
  ON system_status FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

CREATE POLICY "Owners can update system status"
  ON system_status FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

CREATE POLICY "Owners can insert system status"
  ON system_status FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

-- دالة لإرسال إشعار عند الموافقة/الرفض
CREATE OR REPLACE FUNCTION notify_business_status_change()
RETURNS TRIGGER AS $$
DECLARE
  v_title text;
  v_message text;
  v_owner_id uuid;
BEGIN
  -- الحصول على معرف صاحب الشركة
  SELECT user_id INTO v_owner_id
  FROM business_registrations
  WHERE id = NEW.id;

  -- إذا تغيرت الحالة إلى موافق عليها
  IF NEW.status = 'approved' AND OLD.status = 'pending' THEN
    v_title := 'تم الموافقة على طلب التسجيل';
    v_message := 'تم الموافقة على طلب تسجيل منشأة ' || NEW.business_name;

    -- إدراج إشعار
    INSERT INTO notifications (
      user_id,
      title,
      message,
      type,
      is_read
    ) VALUES (
      v_owner_id,
      v_title,
      v_message,
      'business_approved',
      false
    );

  -- إذا تغيرت الحالة إلى مرفوضة
  ELSIF NEW.status = 'rejected' AND OLD.status = 'pending' THEN
    v_title := 'تم رفض طلب التسجيل';
    v_message := 'تم رفض طلب تسجيل منشأة ' || NEW.business_name;
    IF NEW.rejection_reason IS NOT NULL THEN
      v_message := v_message || '. السبب: ' || NEW.rejection_reason;
    END IF;

    -- إدراج إشعار
    INSERT INTO notifications (
      user_id,
      title,
      message,
      type,
      is_read
    ) VALUES (
      v_owner_id,
      v_title,
      v_message,
      'business_rejected',
      false
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- إنشاء trigger للإشعارات
DROP TRIGGER IF EXISTS trigger_notify_business_status ON business_registrations;
CREATE TRIGGER trigger_notify_business_status
  AFTER UPDATE OF status ON business_registrations
  FOR EACH ROW
  WHEN (OLD.status IS DISTINCT FROM NEW.status)
  EXECUTE FUNCTION notify_business_status_change();

-- إدراج البيانات الافتراضية للخدمات
INSERT INTO system_status (service_name, service_key, status, message, response_time_ms, uptime_percentage)
VALUES
  ('خدمة OTP', 'otp', 'active', 'تعمل بشكل طبيعي', 120, 99.9),
  ('بوابة الدفع', 'payment', 'active', 'تعمل بشكل طبيعي', 250, 99.5),
  ('خدمة الإشعارات', 'notifications', 'active', 'تعمل بشكل طبيعي', 80, 99.8),
  ('خدمة البريد الإلكتروني', 'email', 'active', 'تعمل بشكل طبيعي', 350, 99.2)
ON CONFLICT (service_key) DO UPDATE SET
  status = EXCLUDED.status,
  message = EXCLUDED.message,
  response_time_ms = EXCLUDED.response_time_ms,
  uptime_percentage = EXCLUDED.uptime_percentage,
  last_check = now(),
  updated_at = now();

-- دالة لتحديث timestamp عند التعديل
CREATE OR REPLACE FUNCTION update_system_status_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger لتحديث timestamp
DROP TRIGGER IF EXISTS trigger_update_system_status_timestamp ON system_status;
CREATE TRIGGER trigger_update_system_status_timestamp
  BEFORE UPDATE ON system_status
  FOR EACH ROW
  EXECUTE FUNCTION update_system_status_timestamp();
