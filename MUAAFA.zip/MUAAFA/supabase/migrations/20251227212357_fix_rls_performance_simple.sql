/*
  # Fix RLS Performance Issues - Simple Approach

  1. Remove duplicate policies that don't use SELECT wrapping
  2. Keep the optimized policies that already have SELECT wrapping
  3. This fixes the performance warnings from Supabase

  Tables Fixed:
    - fitness_ai_recommendations
    - fitness_coupons
    - fitness_nudges
*/

-- fitness_ai_recommendations: Remove non-optimized policies, keep optimized ones
DROP POLICY IF EXISTS "Users can update own recommendations" ON public.fitness_ai_recommendations;
DROP POLICY IF EXISTS "Users can view own recommendations" ON public.fitness_ai_recommendations;

-- fitness_coupons: Remove non-optimized policies, keep optimized ones
DROP POLICY IF EXISTS "Users can update own coupons" ON public.fitness_coupons;
DROP POLICY IF EXISTS "Users can view own coupons" ON public.fitness_coupons;

-- fitness_nudges: Remove non-optimized policies, keep optimized ones
DROP POLICY IF EXISTS "Users can update own nudges" ON public.fitness_nudges;
DROP POLICY IF EXISTS "Users can view own nudges" ON public.fitness_nudges;

-- Remove other duplicate policies across the database
DROP POLICY IF EXISTS "Users can delete from cart" ON public.cart_items;
DROP POLICY IF EXISTS "Users can add to cart" ON public.cart_items;
DROP POLICY IF EXISTS "Users can view their cart" ON public.cart_items;
DROP POLICY IF EXISTS "Users can update cart" ON public.cart_items;

-- Remove Arabic duplicate policies
DROP POLICY IF EXISTS "المستخدمون يمكنهم إضافة أنشطتهم" ON public.fitness_activities;
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية أنشطتهم" ON public.fitness_activities;
DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث أنشطتهم" ON public.fitness_activities;
DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء أهدافهم" ON public.fitness_goals;
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية أهدافهم" ON public.fitness_goals;
DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث أهدافهم" ON public.fitness_goals;
DROP POLICY IF EXISTS "المستخدمون يمكنهم إضافة تمارينهم" ON public.fitness_workouts;
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية تمارينهم" ON public.fitness_workouts;
DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء تقاريرهم" ON public.medical_reports;
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية تقاريرهم" ON public.medical_reports;
DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث تقاريرهم" ON public.medical_reports;
DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء طلباتهم" ON public.orders;
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية طلباتهم" ON public.orders;
DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث طلباتهم" ON public.orders;
DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء وصفاتهم" ON public.prescriptions;
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية وصفاتهم" ON public.prescriptions;

-- Remove other English duplicate policies
DROP POLICY IF EXISTS "Users can delete their own session recordings" ON public.session_recordings;
DROP POLICY IF EXISTS "Users can view their own session recordings" ON public.session_recordings;
DROP POLICY IF EXISTS "Users can create own sessions" ON public.sessions;
DROP POLICY IF EXISTS "Users can create own subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Users can read own data" ON public.users;
DROP POLICY IF EXISTS "Users can update own data" ON public.users;
DROP POLICY IF EXISTS "Delivery staff can view own assignments" ON public.delivery_assignments;
DROP POLICY IF EXISTS "Delivery staff can update own assignments" ON public.delivery_assignments;
DROP POLICY IF EXISTS "Users can view own pharmacy orders" ON public.pharmacy_order_requests;
DROP POLICY IF EXISTS "Providers can manage own offers" ON public.provider_offers;
