/*
  # تفعيل حماية كلمات المرور المخترقة
  
  ## الإعدادات
  
  ### Leaked Password Protection
  تفعيل الحماية من كلمات المرور المخترقة عبر HaveIBeenPwned.org
  
  ## ملاحظة مهمة
  هذا الإعداد يتم تفعيله من لوحة تحكم Supabase:
  
  1. اذهب إلى: Project Settings > Auth > Password Protection
  2. قم بتفعيل: "Password Breach Protection"
  3. هذا سيمنع المستخدمين من استخدام كلمات مرور معروفة أنها مخترقة
  
  ## الفوائد
  - حماية أفضل للمستخدمين
  - منع استخدام كلمات المرور الضعيفة
  - تحسين الأمان العام للتطبيق
*/

-- هذا Migration للتوثيق فقط
-- الإعداد الفعلي يتم من لوحة التحكم

SELECT 'Password Breach Protection should be enabled in Supabase Dashboard' as reminder;
