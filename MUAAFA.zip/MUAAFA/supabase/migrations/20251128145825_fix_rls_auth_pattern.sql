/*
  # إصلاح RLS Policies لاستخدام SELECT Pattern
  
  1. المشكلة
    - استخدام auth.uid() مباشرة يؤدي لإعادة تقييم في كل صف
    - يسبب بطء في الأداء عند وجود عدد كبير من الصفوف
  
  2. الحل
    - استبدال auth.uid() بـ (SELECT auth.uid())
    - تقييم مرة واحدة فقط لكل استعلام
  
  3. Tables المعالجة
    - activity_logs, cart_items, business_registrations, business_employees
    - user_subscriptions, prescriptions, orders, order_items
    - medical_reports, fitness_activities, fitness_goals, fitness_workouts
    - business_accounts, hospital_reports, fitness_schedules, nutrition_plans
*/

-- ====================================
-- activity_logs
-- ====================================
DROP POLICY IF EXISTS "Users can view their logs" ON public.activity_logs;
CREATE POLICY "Users can view their logs"
  ON public.activity_logs
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()) AND deleted_by_user = false);

DROP POLICY IF EXISTS "Users can soft delete logs" ON public.activity_logs;
CREATE POLICY "Users can soft delete logs"
  ON public.activity_logs
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- cart_items
-- ====================================
DROP POLICY IF EXISTS "Users can view their cart" ON public.cart_items;
CREATE POLICY "Users can view their cart"
  ON public.cart_items
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can add to cart" ON public.cart_items;
CREATE POLICY "Users can add to cart"
  ON public.cart_items
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can update cart" ON public.cart_items;
CREATE POLICY "Users can update cart"
  ON public.cart_items
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can delete from cart" ON public.cart_items;
CREATE POLICY "Users can delete from cart"
  ON public.cart_items
  FOR DELETE
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- ====================================
-- business_registrations
-- ====================================
DROP POLICY IF EXISTS "Users can view their registrations" ON public.business_registrations;
CREATE POLICY "Users can view their registrations"
  ON public.business_registrations
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "Users can create registrations" ON public.business_registrations;
CREATE POLICY "Users can create registrations"
  ON public.business_registrations
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- business_employees
-- ====================================
DROP POLICY IF EXISTS "Employees can view their data" ON public.business_employees;
CREATE POLICY "Employees can view their data"
  ON public.business_employees
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- ====================================
-- user_subscriptions
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية اشتراكاتهم" ON public.user_subscriptions;
CREATE POLICY "المستخدمون يمكنهم رؤية اشتراكاتهم"
  ON public.user_subscriptions
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء اشتراكاته" ON public.user_subscriptions;
CREATE POLICY "المستخدمون يمكنهم إنشاء اشتراكاته"
  ON public.user_subscriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث اشتراكاته" ON public.user_subscriptions;
CREATE POLICY "المستخدمون يمكنهم تحديث اشتراكاته"
  ON public.user_subscriptions
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- prescriptions
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية وصفاتهم" ON public.prescriptions;
CREATE POLICY "المستخدمون يمكنهم رؤية وصفاتهم"
  ON public.prescriptions
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء وصفاتهم" ON public.prescriptions;
CREATE POLICY "المستخدمون يمكنهم إنشاء وصفاتهم"
  ON public.prescriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- orders
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية طلباتهم" ON public.orders;
CREATE POLICY "المستخدمون يمكنهم رؤية طلباتهم"
  ON public.orders
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء طلباتهم" ON public.orders;
CREATE POLICY "المستخدمون يمكنهم إنشاء طلباتهم"
  ON public.orders
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث طلباتهم" ON public.orders;
CREATE POLICY "المستخدمون يمكنهم تحديث طلباتهم"
  ON public.orders
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- order_items
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية عناصر طلبا" ON public.order_items;
CREATE POLICY "المستخدمون يمكنهم رؤية عناصر طلبا"
  ON public.order_items
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.orders 
      WHERE orders.id = order_items.order_id 
      AND orders.user_id = (SELECT auth.uid())
    )
  );

-- ====================================
-- medical_reports
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية تقاريرهم" ON public.medical_reports;
CREATE POLICY "المستخدمون يمكنهم رؤية تقاريرهم"
  ON public.medical_reports
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء تقاريرهم" ON public.medical_reports;
CREATE POLICY "المستخدمون يمكنهم إنشاء تقاريرهم"
  ON public.medical_reports
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث تقاريرهم" ON public.medical_reports;
CREATE POLICY "المستخدمون يمكنهم تحديث تقاريرهم"
  ON public.medical_reports
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- fitness_activities
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية أنشطتهم" ON public.fitness_activities;
CREATE POLICY "المستخدمون يمكنهم رؤية أنشطتهم"
  ON public.fitness_activities
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم إضافة أنشطتهم" ON public.fitness_activities;
CREATE POLICY "المستخدمون يمكنهم إضافة أنشطتهم"
  ON public.fitness_activities
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث أنشطتهم" ON public.fitness_activities;
CREATE POLICY "المستخدمون يمكنهم تحديث أنشطتهم"
  ON public.fitness_activities
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- fitness_goals
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية أهدافهم" ON public.fitness_goals;
CREATE POLICY "المستخدمون يمكنهم رؤية أهدافهم"
  ON public.fitness_goals
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم إنشاء أهدافهم" ON public.fitness_goals;
CREATE POLICY "المستخدمون يمكنهم إنشاء أهدافهم"
  ON public.fitness_goals
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم تحديث أهدافهم" ON public.fitness_goals;
CREATE POLICY "المستخدمون يمكنهم تحديث أهدافهم"
  ON public.fitness_goals
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- fitness_workouts
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية تمارينهم" ON public.fitness_workouts;
CREATE POLICY "المستخدمون يمكنهم رؤية تمارينهم"
  ON public.fitness_workouts
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

DROP POLICY IF EXISTS "المستخدمون يمكنهم إضافة تمارينهم" ON public.fitness_workouts;
CREATE POLICY "المستخدمون يمكنهم إضافة تمارينهم"
  ON public.fitness_workouts
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- business_accounts
-- ====================================
DROP POLICY IF EXISTS "المستخدمون يمكنهم رؤية حساباتهم ا" ON public.business_accounts;
CREATE POLICY "المستخدمون يمكنهم رؤية حساباتهم ا"
  ON public.business_accounts
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- ====================================
-- hospital_reports
-- ====================================
DROP POLICY IF EXISTS "Users can view hospital reports" ON public.hospital_reports;
CREATE POLICY "Users can view hospital reports"
  ON public.hospital_reports
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- ====================================
-- fitness_schedules
-- ====================================
DROP POLICY IF EXISTS "Users manage schedules" ON public.fitness_schedules;
CREATE POLICY "Users manage schedules"
  ON public.fitness_schedules
  FOR ALL
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- ====================================
-- nutrition_plans
-- ====================================
DROP POLICY IF EXISTS "Users manage nutrition plans" ON public.nutrition_plans;
CREATE POLICY "Users manage nutrition plans"
  ON public.nutrition_plans
  FOR ALL
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));
