/*
  # إضافة Indexes للـ Foreign Keys - الجزء الثالث
  
  ## Indexes للجداول (Part 3)
  - patient_journeys: hospital_id, insurance_id, pharmacy_id, user_id
  - payment_transactions: subscription_id
  - payments: appointment_id, insurance_id, journey_id, user_id
  - pharmacy_cart: medication_id, pharmacy_id, prescription_id
  - pharmacy_order_requests: order_id, pharmacy_id
  - pharmacy_orders: insurance_policy_id, user_id
  - pharmacy_stock: pharmacy_id
  - policies: created_by
  - post_session_notes: appointment_id, doctor_id
  - provider_offers: insurance_approval_id, order_id, provider_id
  - session_archives: provider_id, user_id
  - session_recordings: session_id
  - sessions: doctor_id
  - subscriptions: plan_id
  - transactions: business_id, order_id
  - treatment_categories: pharmacy_category_id
  - user_subscriptions: plan_id
  - waiting_room: appointment_id
*/

-- patient_journeys
CREATE INDEX IF NOT EXISTS idx_patient_journeys_hospital_id 
ON patient_journeys(hospital_id);

CREATE INDEX IF NOT EXISTS idx_patient_journeys_insurance_id 
ON patient_journeys(insurance_id);

CREATE INDEX IF NOT EXISTS idx_patient_journeys_pharmacy_id 
ON patient_journeys(pharmacy_id);

CREATE INDEX IF NOT EXISTS idx_patient_journeys_user_id 
ON patient_journeys(user_id);

-- payment_transactions
CREATE INDEX IF NOT EXISTS idx_payment_transactions_subscription_id 
ON payment_transactions(subscription_id);

-- payments
CREATE INDEX IF NOT EXISTS idx_payments_appointment_id 
ON payments(appointment_id);

CREATE INDEX IF NOT EXISTS idx_payments_insurance_id 
ON payments(insurance_id);

CREATE INDEX IF NOT EXISTS idx_payments_journey_id 
ON payments(journey_id);

CREATE INDEX IF NOT EXISTS idx_payments_user_id 
ON payments(user_id);

-- pharmacy_cart
CREATE INDEX IF NOT EXISTS idx_pharmacy_cart_medication_id 
ON pharmacy_cart(medication_id);

CREATE INDEX IF NOT EXISTS idx_pharmacy_cart_pharmacy_id 
ON pharmacy_cart(pharmacy_id);

CREATE INDEX IF NOT EXISTS idx_pharmacy_cart_prescription_id 
ON pharmacy_cart(prescription_id);

-- pharmacy_order_requests
CREATE INDEX IF NOT EXISTS idx_pharmacy_order_requests_order_id 
ON pharmacy_order_requests(order_id);

CREATE INDEX IF NOT EXISTS idx_pharmacy_order_requests_pharmacy_id 
ON pharmacy_order_requests(pharmacy_id);

-- pharmacy_orders
CREATE INDEX IF NOT EXISTS idx_pharmacy_orders_insurance_policy_id 
ON pharmacy_orders(insurance_policy_id);

CREATE INDEX IF NOT EXISTS idx_pharmacy_orders_user_id 
ON pharmacy_orders(user_id);

-- pharmacy_stock
CREATE INDEX IF NOT EXISTS idx_pharmacy_stock_pharmacy_id 
ON pharmacy_stock(pharmacy_id);

-- policies
CREATE INDEX IF NOT EXISTS idx_policies_created_by 
ON policies(created_by);

-- post_session_notes
CREATE INDEX IF NOT EXISTS idx_post_session_notes_appointment_id 
ON post_session_notes(appointment_id);

CREATE INDEX IF NOT EXISTS idx_post_session_notes_doctor_id 
ON post_session_notes(doctor_id);

-- provider_offers
CREATE INDEX IF NOT EXISTS idx_provider_offers_insurance_approval_id 
ON provider_offers(insurance_approval_id);

CREATE INDEX IF NOT EXISTS idx_provider_offers_order_id 
ON provider_offers(order_id);

CREATE INDEX IF NOT EXISTS idx_provider_offers_provider_id 
ON provider_offers(provider_id);

-- session_archives
CREATE INDEX IF NOT EXISTS idx_session_archives_provider_id 
ON session_archives(provider_id);

CREATE INDEX IF NOT EXISTS idx_session_archives_user_id 
ON session_archives(user_id);

-- session_recordings
CREATE INDEX IF NOT EXISTS idx_session_recordings_session_id 
ON session_recordings(session_id);

-- sessions
CREATE INDEX IF NOT EXISTS idx_sessions_doctor_id 
ON sessions(doctor_id);

-- subscriptions
CREATE INDEX IF NOT EXISTS idx_subscriptions_plan_id 
ON subscriptions(plan_id);

-- transactions
CREATE INDEX IF NOT EXISTS idx_transactions_business_id 
ON transactions(business_id);

CREATE INDEX IF NOT EXISTS idx_transactions_order_id 
ON transactions(order_id);

-- treatment_categories
CREATE INDEX IF NOT EXISTS idx_treatment_categories_pharmacy_category_id 
ON treatment_categories(pharmacy_category_id);

-- user_subscriptions
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_plan_id 
ON user_subscriptions(plan_id);

-- waiting_room
CREATE INDEX IF NOT EXISTS idx_waiting_room_appointment_id 
ON waiting_room(appointment_id);
