/*
  # Fix Users Table Recursion - Final Fix

  1. Problem
    - The "Owners can update user roles" policy causes infinite recursion
    - The policy's USING and WITH CHECK clauses contain a subquery that selects from users table
    - This creates a loop: users table policy → subquery on users table → policy check again

  2. Solution
    - Drop the problematic "Owners can update user roles" policy
    - Keep only "Users can update own profile" which is simple and doesn't cause recursion
    - Remove the attempt to update user_role from business registration code

  3. Security
    - Users can only update their own profile
    - user_role is set by the trigger function, not by user updates
    - This prevents users from elevating their own privileges
*/

-- Drop the problematic policy that causes recursion
DROP POLICY IF EXISTS "Owners can update user roles" ON users;

-- Keep the simple policy for users updating their own profile
-- This policy already exists and doesn't cause recursion
