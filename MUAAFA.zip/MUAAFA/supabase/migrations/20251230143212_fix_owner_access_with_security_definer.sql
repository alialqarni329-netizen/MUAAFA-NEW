/*
  # Fix Owner Access with SECURITY DEFINER Function

  1. Problem
    - Direct queries to admin_users in RLS policies cause infinite recursion
    - The admin_users table has its own RLS policies that trigger recursion

  2. Solution
    - Create a SECURITY DEFINER function to safely check if user is owner/admin
    - This function bypasses RLS and queries admin_users directly
    - Update business_registrations policies to use this function

  3. Security
    - Function is SECURITY DEFINER so it runs with creator privileges
    - Only checks role, doesn't expose other data
    - Safe for use in RLS policies
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Owners can view all business registrations" ON business_registrations;
DROP POLICY IF EXISTS "Owners can update business registrations" ON business_registrations;

-- Create a secure function to check if user is owner/admin
CREATE OR REPLACE FUNCTION is_owner_or_admin(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM admin_users
    WHERE id = user_id
    AND role IN ('owner', 'admin')
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION is_owner_or_admin(uuid) TO authenticated;

-- Create new policies using the secure function
CREATE POLICY "Owners can view all business registrations"
  ON business_registrations
  FOR SELECT
  TO authenticated
  USING (
    is_owner_or_admin(auth.uid())
  );

CREATE POLICY "Owners can update business registrations"
  ON business_registrations
  FOR UPDATE
  TO authenticated
  USING (
    is_owner_or_admin(auth.uid())
  )
  WITH CHECK (
    is_owner_or_admin(auth.uid())
  );
