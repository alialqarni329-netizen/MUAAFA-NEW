/*
  # Bot Usage Tracking and Rate Limiting System
  
  1. New Tables
    - `bot_usage_tracking`
      - Tracks daily usage per user
      - Enforces 20 messages per day limit
      - Stores token consumption
    
    - `bot_rate_limits`
      - Tracks requests per minute/hour/day
      - Prevents abuse and viral attacks
      
    - `bot_response_cache`
      - Caches similar queries for 6 hours
      - Reduces API costs significantly
    
    - `bot_usage_logs`
      - Comprehensive logging for monitoring
      - Tracks costs and performance
  
  2. Security
    - Enable RLS on all tables
    - Users can only read their own usage data
    - Only authenticated users can access bot
  
  3. Functions
    - check_user_daily_limit(): Validates daily message limit
    - check_rate_limit(): Validates rate limits
    - get_cached_response(): Retrieves cached responses
    - log_bot_usage(): Logs all bot interactions
*/

-- Bot Usage Tracking Table
CREATE TABLE IF NOT EXISTS bot_usage_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  usage_date date NOT NULL DEFAULT CURRENT_DATE,
  messages_count integer NOT NULL DEFAULT 0,
  tokens_used integer NOT NULL DEFAULT 0,
  last_message_at timestamptz,
  warned_at_80_percent boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, usage_date)
);

-- Bot Rate Limits Table
CREATE TABLE IF NOT EXISTS bot_rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  ip_address inet,
  requests_this_minute integer DEFAULT 0,
  requests_this_hour integer DEFAULT 0,
  requests_this_day integer DEFAULT 0,
  minute_window_start timestamptz DEFAULT now(),
  hour_window_start timestamptz DEFAULT now(),
  day_window_start timestamptz DEFAULT now(),
  blocked_until timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, ip_address)
);

-- Bot Response Cache Table
CREATE TABLE IF NOT EXISTS bot_response_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  query_hash text NOT NULL UNIQUE,
  user_query text NOT NULL,
  bot_response text NOT NULL,
  analysis jsonb,
  cache_hits integer DEFAULT 0,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '6 hours'),
  created_at timestamptz DEFAULT now(),
  last_accessed_at timestamptz DEFAULT now()
);

-- Bot Usage Logs Table
CREATE TABLE IF NOT EXISTS bot_usage_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  conversation_id uuid,
  user_message text NOT NULL,
  bot_response text NOT NULL,
  tokens_used integer,
  response_time_ms integer,
  cached boolean DEFAULT false,
  severity_level text,
  cost_estimate numeric(10, 6),
  ip_address inet,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_bot_usage_tracking_user_date ON bot_usage_tracking(user_id, usage_date);
CREATE INDEX IF NOT EXISTS idx_bot_rate_limits_user ON bot_rate_limits(user_id);
CREATE INDEX IF NOT EXISTS idx_bot_rate_limits_ip ON bot_rate_limits(ip_address);
CREATE INDEX IF NOT EXISTS idx_bot_response_cache_hash ON bot_response_cache(query_hash);
CREATE INDEX IF NOT EXISTS idx_bot_response_cache_expires ON bot_response_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_bot_usage_logs_user ON bot_usage_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_bot_usage_logs_created ON bot_usage_logs(created_at DESC);

-- Enable RLS
ALTER TABLE bot_usage_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_rate_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_response_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_usage_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for bot_usage_tracking
CREATE POLICY "Users can view own usage tracking"
  ON bot_usage_tracking FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage usage tracking"
  ON bot_usage_tracking FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- RLS Policies for bot_rate_limits
CREATE POLICY "Users can view own rate limits"
  ON bot_rate_limits FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage rate limits"
  ON bot_rate_limits FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- RLS Policies for bot_response_cache
CREATE POLICY "Authenticated users can read cache"
  ON bot_response_cache FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Service role can manage cache"
  ON bot_response_cache FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- RLS Policies for bot_usage_logs
CREATE POLICY "Users can view own logs"
  ON bot_usage_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage logs"
  ON bot_usage_logs FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Function: Check user daily limit
CREATE OR REPLACE FUNCTION check_user_daily_limit(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_messages_count integer;
  v_max_daily_limit integer := 20;
  v_warning_threshold integer := 16; -- 80% of 20
  v_result jsonb;
BEGIN
  -- Get or create today's usage record
  INSERT INTO bot_usage_tracking (user_id, usage_date, messages_count)
  VALUES (p_user_id, CURRENT_DATE, 0)
  ON CONFLICT (user_id, usage_date)
  DO NOTHING;

  -- Get current count
  SELECT messages_count INTO v_messages_count
  FROM bot_usage_tracking
  WHERE user_id = p_user_id AND usage_date = CURRENT_DATE;

  -- Check if user exceeded limit
  IF v_messages_count >= v_max_daily_limit THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'messages_used', v_messages_count,
      'messages_remaining', 0,
      'reset_time', (CURRENT_DATE + interval '1 day')::text,
      'message', 'لقد وصلت الحد الأقصى لليوم، يرجى العودة غدًا ويفتح من جديد بعد 20 ساعة.'
    );
  END IF;

  -- Check if approaching limit (80%)
  IF v_messages_count >= v_warning_threshold THEN
    -- Update warned flag
    UPDATE bot_usage_tracking
    SET warned_at_80_percent = true
    WHERE user_id = p_user_id AND usage_date = CURRENT_DATE;

    RETURN jsonb_build_object(
      'allowed', true,
      'messages_used', v_messages_count,
      'messages_remaining', v_max_daily_limit - v_messages_count,
      'warning', true,
      'warning_message', 'تنبيه: لديك ' || (v_max_daily_limit - v_messages_count)::text || ' رسائل متبقية فقط اليوم.'
    );
  END IF;

  -- Normal case
  RETURN jsonb_build_object(
    'allowed', true,
    'messages_used', v_messages_count,
    'messages_remaining', v_max_daily_limit - v_messages_count,
    'warning', false
  );
END;
$$;

-- Function: Check rate limit
CREATE OR REPLACE FUNCTION check_rate_limit(p_user_id uuid, p_ip_address inet)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_record RECORD;
  v_max_per_minute integer := 200;
  v_max_per_hour integer := 1200;
  v_max_per_day integer := 10000;
  v_now timestamptz := now();
BEGIN
  -- Get or create rate limit record
  INSERT INTO bot_rate_limits (user_id, ip_address)
  VALUES (p_user_id, p_ip_address)
  ON CONFLICT (user_id, ip_address)
  DO NOTHING;

  -- Get current record
  SELECT * INTO v_record
  FROM bot_rate_limits
  WHERE user_id = p_user_id AND ip_address = p_ip_address;

  -- Check if blocked
  IF v_record.blocked_until IS NOT NULL AND v_record.blocked_until > v_now THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'reason', 'rate_limit_exceeded',
      'blocked_until', v_record.blocked_until::text
    );
  END IF;

  -- Reset minute window
  IF v_now - v_record.minute_window_start > interval '1 minute' THEN
    UPDATE bot_rate_limits
    SET requests_this_minute = 0,
        minute_window_start = v_now
    WHERE user_id = p_user_id AND ip_address = p_ip_address;
    v_record.requests_this_minute := 0;
  END IF;

  -- Reset hour window
  IF v_now - v_record.hour_window_start > interval '1 hour' THEN
    UPDATE bot_rate_limits
    SET requests_this_hour = 0,
        hour_window_start = v_now
    WHERE user_id = p_user_id AND ip_address = p_ip_address;
    v_record.requests_this_hour := 0;
  END IF;

  -- Reset day window
  IF v_now - v_record.day_window_start > interval '1 day' THEN
    UPDATE bot_rate_limits
    SET requests_this_day = 0,
        day_window_start = v_now
    WHERE user_id = p_user_id AND ip_address = p_ip_address;
    v_record.requests_this_day := 0;
  END IF;

  -- Check limits
  IF v_record.requests_this_minute >= v_max_per_minute THEN
    UPDATE bot_rate_limits
    SET blocked_until = v_now + interval '1 minute'
    WHERE user_id = p_user_id AND ip_address = p_ip_address;
    
    RETURN jsonb_build_object(
      'allowed', false,
      'reason', 'too_many_requests_per_minute'
    );
  END IF;

  IF v_record.requests_this_hour >= v_max_per_hour THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'reason', 'too_many_requests_per_hour'
    );
  END IF;

  IF v_record.requests_this_day >= v_max_per_day THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'reason', 'too_many_requests_per_day'
    );
  END IF;

  -- Increment counters
  UPDATE bot_rate_limits
  SET requests_this_minute = requests_this_minute + 1,
      requests_this_hour = requests_this_hour + 1,
      requests_this_day = requests_this_day + 1,
      updated_at = v_now
  WHERE user_id = p_user_id AND ip_address = p_ip_address;

  RETURN jsonb_build_object(
    'allowed', true
  );
END;
$$;

-- Function: Get cached response
CREATE OR REPLACE FUNCTION get_cached_response(p_query_hash text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_cached_record RECORD;
BEGIN
  -- Check if cache exists and not expired
  SELECT * INTO v_cached_record
  FROM bot_response_cache
  WHERE query_hash = p_query_hash
    AND expires_at > now();

  IF FOUND THEN
    -- Update cache hits and last accessed
    UPDATE bot_response_cache
    SET cache_hits = cache_hits + 1,
        last_accessed_at = now()
    WHERE query_hash = p_query_hash;

    RETURN jsonb_build_object(
      'cached', true,
      'response', v_cached_record.bot_response,
      'analysis', v_cached_record.analysis
    );
  END IF;

  RETURN jsonb_build_object('cached', false);
END;
$$;

-- Function: Increment user message count
CREATE OR REPLACE FUNCTION increment_user_message_count(p_user_id uuid, p_tokens_used integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE bot_usage_tracking
  SET messages_count = messages_count + 1,
      tokens_used = tokens_used + p_tokens_used,
      last_message_at = now(),
      updated_at = now()
  WHERE user_id = p_user_id AND usage_date = CURRENT_DATE;
END;
$$;

-- Cleanup function for expired cache
CREATE OR REPLACE FUNCTION cleanup_expired_cache()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM bot_response_cache
  WHERE expires_at < now();
END;
$$;