/*
  # نظام الدفع الإلزامي - الجداول الأساسية
  
  1. الجداول
    - insurance_policies: بوليصات التأمين
    - medical_sessions: الجلسات الطبية
    - pharmacy_orders: طلبات الصيدلية
  
  2. القواعد
    - لا يمكن تأكيد جلسة أو طلب بدون payment_status = 'paid'
    - التأمين يُطبق تلقائياً
*/

-- 1️⃣ جدول بوليصات التأمين
CREATE TABLE IF NOT EXISTS insurance_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  policy_number TEXT UNIQUE NOT NULL,
  provider_name TEXT NOT NULL,
  coverage_percentage NUMERIC(5,2) NOT NULL CHECK (coverage_percentage >= 0 AND coverage_percentage <= 100),
  coverage_limit NUMERIC(10,2),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT CHECK (status IN ('active', 'expired', 'cancelled')) DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_insurance_policies_user_id ON insurance_policies(user_id);
CREATE INDEX IF NOT EXISTS idx_insurance_policies_status ON insurance_policies(status);

ALTER TABLE insurance_policies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own insurance policies" ON insurance_policies;
CREATE POLICY "Users can view own insurance policies"
  ON insurance_policies FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert own insurance policies" ON insurance_policies;
CREATE POLICY "Users can insert own insurance policies"
  ON insurance_policies FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own insurance policies" ON insurance_policies;
CREATE POLICY "Users can update own insurance policies"
  ON insurance_policies FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 2️⃣ جدول الجلسات الطبية
CREATE TABLE IF NOT EXISTS medical_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doctor_name TEXT NOT NULL,
  specialty TEXT NOT NULL,
  session_date TIMESTAMPTZ NOT NULL,
  duration_minutes INTEGER DEFAULT 30,
  price NUMERIC(10,2) NOT NULL CHECK (price >= 0),
  insurance_policy_id UUID REFERENCES insurance_policies(id),
  insurance_covered NUMERIC(10,2) DEFAULT 0 CHECK (insurance_covered >= 0),
  user_payable NUMERIC(10,2) NOT NULL CHECK (user_payable >= 0),
  payment_status TEXT CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')) DEFAULT 'pending',
  payment_method TEXT CHECK (payment_method IN ('zedpay', 'credit_card', 'insurance', 'wallet')),
  session_status TEXT CHECK (session_status IN ('pending', 'confirmed', 'completed', 'cancelled')) DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  paid_at TIMESTAMPTZ,
  confirmed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_medical_sessions_user_id ON medical_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_medical_sessions_payment_status ON medical_sessions(payment_status);
CREATE INDEX IF NOT EXISTS idx_medical_sessions_session_status ON medical_sessions(session_status);
CREATE INDEX IF NOT EXISTS idx_medical_sessions_session_date ON medical_sessions(session_date);

ALTER TABLE medical_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own sessions" ON medical_sessions;
CREATE POLICY "Users can view own sessions"
  ON medical_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert own sessions" ON medical_sessions;
CREATE POLICY "Users can insert own sessions"
  ON medical_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own pending sessions" ON medical_sessions;
CREATE POLICY "Users can update own pending sessions"
  ON medical_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 3️⃣ جدول طلبات الصيدلية
CREATE TABLE IF NOT EXISTS pharmacy_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pharmacy_id UUID,
  pharmacy_name TEXT NOT NULL,
  items JSONB NOT NULL DEFAULT '[]',
  total_price NUMERIC(10,2) NOT NULL CHECK (total_price >= 0),
  insurance_policy_id UUID REFERENCES insurance_policies(id),
  insurance_covered NUMERIC(10,2) DEFAULT 0 CHECK (insurance_covered >= 0),
  user_payable NUMERIC(10,2) NOT NULL CHECK (user_payable >= 0),
  payment_status TEXT CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')) DEFAULT 'pending',
  payment_method TEXT CHECK (payment_method IN ('zedpay', 'credit_card', 'insurance', 'wallet')),
  order_status TEXT CHECK (order_status IN ('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled')) DEFAULT 'pending',
  delivery_address TEXT,
  delivery_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  paid_at TIMESTAMPTZ,
  confirmed_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_pharmacy_orders_user_id ON pharmacy_orders(user_id);
CREATE INDEX IF NOT EXISTS idx_pharmacy_orders_payment_status ON pharmacy_orders(payment_status);
CREATE INDEX IF NOT EXISTS idx_pharmacy_orders_order_status ON pharmacy_orders(order_status);

ALTER TABLE pharmacy_orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own pharmacy orders" ON pharmacy_orders;
CREATE POLICY "Users can view own pharmacy orders"
  ON pharmacy_orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert own pharmacy orders" ON pharmacy_orders;
CREATE POLICY "Users can insert own pharmacy orders"
  ON pharmacy_orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own pending orders" ON pharmacy_orders;
CREATE POLICY "Users can update own pending orders"
  ON pharmacy_orders FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Grant permissions
GRANT ALL ON insurance_policies TO authenticated;
GRANT ALL ON medical_sessions TO authenticated;
GRANT ALL ON pharmacy_orders TO authenticated;