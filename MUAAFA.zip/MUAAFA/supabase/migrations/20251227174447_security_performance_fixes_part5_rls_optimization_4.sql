/*
  # Security and Performance Fixes - Part 5: RLS Optimization (Batch 4)

  This migration continues optimizing Row Level Security (RLS) policies by replacing
  direct auth.uid() calls with (select auth.uid()) to prevent function re-evaluation
  for each row, significantly improving query performance at scale.

  ## Tables Optimized in This Batch:
  1. cart_items - policies for user cart access
  2. fitness_activities - policies for user fitness data
  3. fitness_goals - policies for user goals
  4. fitness_workouts - policies for user workouts
  5. subscriptions - policies for user subscriptions
  6. orders - policies for user orders
  7. medical_reports - policies for user medical reports

  ## Performance Impact:
  - Reduces auth function calls from O(n) to O(1) per query
  - Improves response times for large result sets
  - Reduces database CPU usage

  ## Security:
  - Maintains identical security guarantees
  - No changes to access control logic
*/

-- ============================================================================
-- cart_items
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own cart" ON cart_items;
CREATE POLICY "Users can view own cart" ON cart_items
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert to own cart" ON cart_items;
CREATE POLICY "Users can insert to own cart" ON cart_items
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own cart" ON cart_items;
CREATE POLICY "Users can update own cart" ON cart_items
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete from own cart" ON cart_items;
CREATE POLICY "Users can delete from own cart" ON cart_items
  FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================================================
-- fitness_activities
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own fitness activities" ON fitness_activities;
CREATE POLICY "Users can view own fitness activities" ON fitness_activities
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own fitness activities" ON fitness_activities;
CREATE POLICY "Users can insert own fitness activities" ON fitness_activities
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own fitness activities" ON fitness_activities;
CREATE POLICY "Users can update own fitness activities" ON fitness_activities
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own fitness activities" ON fitness_activities;
CREATE POLICY "Users can delete own fitness activities" ON fitness_activities
  FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================================================
-- fitness_goals
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own fitness goals" ON fitness_goals;
CREATE POLICY "Users can view own fitness goals" ON fitness_goals
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own fitness goals" ON fitness_goals;
CREATE POLICY "Users can insert own fitness goals" ON fitness_goals
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own fitness goals" ON fitness_goals;
CREATE POLICY "Users can update own fitness goals" ON fitness_goals
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own fitness goals" ON fitness_goals;
CREATE POLICY "Users can delete own fitness goals" ON fitness_goals
  FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================================================
-- fitness_workouts
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own fitness workouts" ON fitness_workouts;
CREATE POLICY "Users can view own fitness workouts" ON fitness_workouts
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own fitness workouts" ON fitness_workouts;
CREATE POLICY "Users can insert own fitness workouts" ON fitness_workouts
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own fitness workouts" ON fitness_workouts;
CREATE POLICY "Users can update own fitness workouts" ON fitness_workouts
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own fitness workouts" ON fitness_workouts;
CREATE POLICY "Users can delete own fitness workouts" ON fitness_workouts
  FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================================================
-- subscriptions
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own subscriptions" ON subscriptions;
CREATE POLICY "Users can view own subscriptions" ON subscriptions
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own subscriptions" ON subscriptions;
CREATE POLICY "Users can insert own subscriptions" ON subscriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own subscriptions" ON subscriptions;
CREATE POLICY "Users can update own subscriptions" ON subscriptions
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================================================
-- orders
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own orders" ON orders;
CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own orders" ON orders;
CREATE POLICY "Users can insert own orders" ON orders
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own orders" ON orders;
CREATE POLICY "Users can update own orders" ON orders
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================================================
-- medical_reports
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own medical reports" ON medical_reports;
CREATE POLICY "Users can view own medical reports" ON medical_reports
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own medical reports" ON medical_reports;
CREATE POLICY "Users can insert own medical reports" ON medical_reports
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own medical reports" ON medical_reports;
CREATE POLICY "Users can update own medical reports" ON medical_reports
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own medical reports" ON medical_reports;
CREATE POLICY "Users can delete own medical reports" ON medical_reports
  FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));
