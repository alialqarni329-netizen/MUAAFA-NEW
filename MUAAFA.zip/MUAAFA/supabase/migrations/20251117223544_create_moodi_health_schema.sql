/*
  # إنشاء قاعدة بيانات MOODi Health

  ## الجداول الجديدة

  ### 1. users
  - `id` (uuid, primary key, references auth.users)
  - `full_name` (text)
  - `phone` (text)
  - `date_of_birth` (date)
  - `language` (text, default 'ar')
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. chat_conversations
  - `id` (uuid, primary key)
  - `user_id` (uuid, references users)
  - `title` (text)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 3. chat_messages
  - `id` (uuid, primary key)
  - `conversation_id` (uuid, references chat_conversations)
  - `sender_type` (text: 'user' or 'ai')
  - `content` (text)
  - `image_url` (text, nullable)
  - `created_at` (timestamptz)

  ### 4. doctors
  - `id` (uuid, primary key)
  - `full_name` (text)
  - `specialty` (text)
  - `bio` (text)
  - `rating` (numeric)
  - `is_available` (boolean, default true)
  - `created_at` (timestamptz)

  ### 5. sessions
  - `id` (uuid, primary key)
  - `user_id` (uuid, references users)
  - `doctor_id` (uuid, references doctors)
  - `session_type` (text: 'video' or 'chat')
  - `status` (text: 'upcoming', 'completed', 'cancelled')
  - `scheduled_date` (date)
  - `scheduled_time` (time)
  - `notes` (text)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 6. uploaded_images
  - `id` (uuid, primary key)
  - `user_id` (uuid, references users)
  - `conversation_id` (uuid, references chat_conversations, nullable)
  - `image_url` (text)
  - `analysis_result` (text, nullable)
  - `created_at` (timestamptz)

  ### 7. health_articles
  - `id` (uuid, primary key)
  - `title` (text)
  - `content` (text)
  - `category` (text)
  - `image_url` (text, nullable)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ## الأمان
  - تفعيل RLS على جميع الجداول
  - إضافة سياسات للسماح للمستخدمين بالوصول إلى بياناتهم فقط
  - سياسات القراءة العامة للأطباء والمقالات

  ## ملاحظات مهمة
  - جميع الجداول تحتوي على timestamps للتتبع
  - استخدام UUID كمفاتيح أساسية
  - العلاقات المناسبة بين الجداول
  - القيم الافتراضية المناسبة للأعمدة
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  date_of_birth date,
  language text DEFAULT 'ar',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own data"
  ON users FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create chat_conversations table
CREATE TABLE IF NOT EXISTS chat_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'محادثة جديدة',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE chat_conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own conversations"
  ON chat_conversations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own conversations"
  ON chat_conversations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own conversations"
  ON chat_conversations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own conversations"
  ON chat_conversations FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create chat_messages table
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
  sender_type text NOT NULL CHECK (sender_type IN ('user', 'ai')),
  content text NOT NULL,
  image_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view messages in own conversations"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM chat_conversations
      WHERE chat_conversations.id = chat_messages.conversation_id
      AND chat_conversations.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create messages in own conversations"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM chat_conversations
      WHERE chat_conversations.id = chat_messages.conversation_id
      AND chat_conversations.user_id = auth.uid()
    )
  );

-- Create doctors table
CREATE TABLE IF NOT EXISTS doctors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  specialty text NOT NULL,
  bio text DEFAULT '',
  rating numeric DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view available doctors"
  ON doctors FOR SELECT
  TO authenticated
  USING (is_available = true);

-- Create sessions table
CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doctor_id uuid NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  session_type text NOT NULL CHECK (session_type IN ('video', 'chat')),
  status text NOT NULL DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'completed', 'cancelled')),
  scheduled_date date NOT NULL,
  scheduled_time time NOT NULL,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own sessions"
  ON sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own sessions"
  ON sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own sessions"
  ON sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create uploaded_images table
CREATE TABLE IF NOT EXISTS uploaded_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  conversation_id uuid REFERENCES chat_conversations(id) ON DELETE SET NULL,
  image_url text NOT NULL,
  analysis_result text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE uploaded_images ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own uploaded images"
  ON uploaded_images FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can upload images"
  ON uploaded_images FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own images"
  ON uploaded_images FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create health_articles table
CREATE TABLE IF NOT EXISTS health_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  category text NOT NULL DEFAULT 'عام',
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE health_articles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view health articles"
  ON health_articles FOR SELECT
  TO authenticated
  USING (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_chat_conversations_user_id ON chat_conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation_id ON chat_messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_doctor_id ON sessions(doctor_id);
CREATE INDEX IF NOT EXISTS idx_uploaded_images_user_id ON uploaded_images(user_id);
CREATE INDEX IF NOT EXISTS idx_health_articles_category ON health_articles(category);
