/*
  # استبدال الاشتراك التجريبي بالباقة الأساسية المجانية
  
  ## التعديلات:
  
  1. **تحديث Trigger**
    - تغيير plan_type من 'trial' إلى 'free'
    - إزالة تاريخ الانتهاء (باقة دائمة)
    
  2. **تحديث الاشتراكات الحالية**
    - تحويل جميع اشتراكات trial إلى free
    - إزالة تاريخ الانتهاء للباقة المجانية
    
  ## الميزات الأساسية:
    - دردشة صحية ذكية (3 استشارات شهرياً)
    - المحفظة الذكية (ملفين طبيين)
    - تتبع النشاط البدني (الخطوات فقط)
    - لا توجد جلسات افتراضية
    - لا توجد خصومات صيدلية
    - لا توجد برامج رياضية مخصصة
*/

-- التأكد من أن جدول subscriptions يدعم end_date كـ NULL
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' 
    AND column_name = 'end_date'
    AND is_nullable = 'NO'
  ) THEN
    ALTER TABLE subscriptions ALTER COLUMN end_date DROP NOT NULL;
  END IF;
END $$;

-- تحديث قيود plan_type لدعم 'free' (يجب أن يحدث قبل تحديث البيانات)
DO $$
BEGIN
  -- حذف القيد القديم إن وُجد
  ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_plan_type_check;
  
  -- إضافة قيد جديد يدعم free, plus, vip
  ALTER TABLE subscriptions 
  ADD CONSTRAINT subscriptions_plan_type_check 
  CHECK (plan_type IN ('free', 'plus', 'vip', 'weekly', 'monthly', 'yearly', 'trial'));
END $$;

-- تحديث جميع الاشتراكات التجريبية الحالية إلى باقة أساسية
UPDATE subscriptions
SET 
  plan_type = 'free',
  end_date = NULL,
  updated_at = NOW()
WHERE plan_type = 'trial' AND status = 'active';

-- حذف الـ Trigger والدالة القديمة
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- إنشاء دالة جديدة لإنشاء ملف المستخدم مع الباقة الأساسية
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- إنشاء سجل في جدول users
  INSERT INTO public.users (id, created_at, updated_at)
  VALUES (NEW.id, NOW(), NOW())
  ON CONFLICT (id) DO NOTHING;
  
  -- إنشاء اشتراك الباقة الأساسية (مجاني ودائم)
  INSERT INTO public.subscriptions (
    user_id,
    plan_type,
    status,
    start_date,
    end_date
  )
  VALUES (
    NEW.id,
    'free',
    'active',
    NOW(),
    NULL
  )
  ON CONFLICT (user_id) 
  WHERE status = 'active'
  DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- إنشاء Trigger جديد
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- إنشاء فهرس على plan_type لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_subscriptions_plan_type 
ON subscriptions(plan_type) 
WHERE status = 'active';

-- تعليقات توضيحية
COMMENT ON COLUMN subscriptions.plan_type IS 'نوع الباقة: free (مجاني دائم), plus (79 ريال/شهر), vip (199 ريال/شهر)';
COMMENT ON COLUMN subscriptions.end_date IS 'تاريخ انتهاء الاشتراك (NULL للباقة المجانية الدائمة)';
