/*
  # Security and Performance Fixes - Part 7: Remove Duplicate Indexes

  This migration removes duplicate and redundant indexes to improve database performance
  and reduce storage overhead. Duplicate indexes provide no benefit and only slow down
  write operations (INSERT, UPDATE, DELETE) while consuming extra disk space.

  ## Indexes Removed:

  ### Exact Duplicates:
  1. prescriptions table:
     - Remove: idx_prescriptions_user_id (duplicate of idx_prescriptions_user)
     - Keep: idx_prescriptions_user (original index on user_id)

  2. subscriptions table:
     - Remove: idx_subscriptions_user_id_status (duplicate of idx_subscriptions_user_active)
     - Keep: idx_subscriptions_user_active (original partial index on user_id, status)

  ### Redundant Indexes:
  3. business_verification table:
     - Remove: idx_business_verification_user_id (redundant with unique constraint)
     - Keep: business_verification_user_id_key (unique index provides same coverage)
     - Remove: idx_business_verification_commercial_reg (redundant with unique constraint)
     - Keep: business_verification_commercial_registration_key (unique index provides coverage)

  4. cart_items table:
     - Remove: idx_cart_items_user_product (redundant with unique constraint)
     - Keep: cart_items_user_id_product_id_key (unique index provides same coverage)
     - Keep: idx_cart_items_user_id (needed for standalone user_id queries)

  5. delivery_proof table:
     - Remove: idx_delivery_proof_assignment (redundant with unique constraint)
     - Keep: delivery_proof_delivery_assignment_id_key (unique index provides coverage)

  ## Performance Impact:
  - Reduces index maintenance overhead on writes
  - Frees disk space
  - Improves query planner performance (fewer index choices to evaluate)
  - No negative impact on query performance (covered by remaining indexes)
*/

-- ============================================================================
-- Remove duplicate indexes on prescriptions table
-- ============================================================================
DROP INDEX IF EXISTS idx_prescriptions_user_id;
-- Kept: idx_prescriptions_user (provides same coverage)

-- ============================================================================
-- Remove duplicate indexes on subscriptions table
-- ============================================================================
DROP INDEX IF EXISTS idx_subscriptions_user_id_status;
-- Kept: idx_subscriptions_user_active (provides same coverage with same WHERE clause)

-- ============================================================================
-- Remove redundant indexes on business_verification table
-- ============================================================================
DROP INDEX IF EXISTS idx_business_verification_user_id;
-- Kept: business_verification_user_id_key (UNIQUE index provides better coverage)

DROP INDEX IF EXISTS idx_business_verification_commercial_reg;
-- Kept: business_verification_commercial_registration_key (UNIQUE index provides better coverage)

-- ============================================================================
-- Remove redundant indexes on cart_items table
-- ============================================================================
DROP INDEX IF EXISTS idx_cart_items_user_product;
-- Kept: cart_items_user_id_product_id_key (UNIQUE index provides same coverage)
-- Kept: idx_cart_items_user_id (still useful for standalone user_id queries)

-- ============================================================================
-- Remove redundant indexes on delivery_proof table
-- ============================================================================
DROP INDEX IF EXISTS idx_delivery_proof_assignment;
-- Kept: delivery_proof_delivery_assignment_id_key (UNIQUE index provides same coverage)
