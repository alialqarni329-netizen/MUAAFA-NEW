/*
  # Add Owner/Admin Access to Business Registrations

  1. Problem
    - business_registrations table only has policies for users to view their own registrations
    - Owners and admins cannot see pending business registration requests
    - This prevents the owner portal from displaying pending approval requests

  2. Solution
    - Add SELECT policy for owners to view all business registrations
    - Add UPDATE policy for owners to approve/reject registrations
    - Keep existing policies for regular users

  3. Security
    - Only authenticated users with 'owner' or 'admin' role in admin_users can access
    - Regular users can still only see their own registrations
    - Maintains separation between user and admin access
*/

-- Allow owners and admins to view all business registrations
CREATE POLICY "Owners can view all business registrations"
  ON business_registrations
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM admin_users
      WHERE admin_users.id = auth.uid()
      AND admin_users.role IN ('owner', 'admin')
    )
  );

-- Allow owners and admins to update business registrations (approve/reject)
CREATE POLICY "Owners can update business registrations"
  ON business_registrations
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM admin_users
      WHERE admin_users.id = auth.uid()
      AND admin_users.role IN ('owner', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM admin_users
      WHERE admin_users.id = auth.uid()
      AND admin_users.role IN ('owner', 'admin')
    )
  );
