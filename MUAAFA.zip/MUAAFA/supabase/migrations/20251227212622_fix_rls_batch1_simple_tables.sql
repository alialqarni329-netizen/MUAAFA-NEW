/*
  # Fix RLS Performance - Batch 1: Simple Tables

  Fix RLS performance for tables with direct user_id columns
  
  Tables:
    - email_logs
    - medical_recommendations_history
*/

-- email_logs
DROP POLICY IF EXISTS "Admins can view all email logs" ON public.email_logs;
DROP POLICY IF EXISTS "Users can view own email logs" ON public.email_logs;

CREATE POLICY "Admins can view all email logs"
  ON public.email_logs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.admin_users
      WHERE user_id = (SELECT auth.uid())
    )
  );

CREATE POLICY "Users can view own email logs"
  ON public.email_logs
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- medical_recommendations_history
DROP POLICY IF EXISTS "Users can insert own medical recommendations" ON public.medical_recommendations_history;
DROP POLICY IF EXISTS "Users can update own recommendation viewed status" ON public.medical_recommendations_history;
DROP POLICY IF EXISTS "Users can view own medical recommendations" ON public.medical_recommendations_history;

CREATE POLICY "Users can insert own medical recommendations"
  ON public.medical_recommendations_history
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can update own recommendation viewed status"
  ON public.medical_recommendations_history
  FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can view own medical recommendations"
  ON public.medical_recommendations_history
  FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));
