/*
  # Add User Role System
  
  1. Changes
    - Add user_role enum type with values: 'owner', 'business_admin', 'individual_user'
    - Add user_role column to users table with default 'individual_user'
    - Update existing admin users to have 'owner' role
    - Create index on user_role for faster queries
  
  2. Security
    - Only owners can modify user roles
    - Users can read their own role
*/

-- Create user role enum
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('owner', 'business_admin', 'individual_user');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Add user_role column to users table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'user_role'
  ) THEN
    ALTER TABLE users ADD COLUMN user_role user_role DEFAULT 'individual_user';
  END IF;
END $$;

-- Update existing admin users to have owner role
UPDATE users 
SET user_role = 'owner'
WHERE id IN (SELECT id FROM admin_users WHERE role = 'owner');

-- Update business admins
UPDATE users 
SET user_role = 'business_admin'
WHERE id IN (
  SELECT user_id FROM business_registrations WHERE status = 'approved'
);

-- Create index for faster role queries
CREATE INDEX IF NOT EXISTS idx_users_user_role ON users(user_role);

-- Drop existing policies that might conflict
DROP POLICY IF EXISTS "Users can update own role" ON users;

-- Policy: Only owners can update user roles
CREATE POLICY "Only owners can update user roles"
  ON users
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.id = auth.uid() 
      AND admin_users.role = 'owner'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.id = auth.uid() 
      AND admin_users.role = 'owner'
    )
  );