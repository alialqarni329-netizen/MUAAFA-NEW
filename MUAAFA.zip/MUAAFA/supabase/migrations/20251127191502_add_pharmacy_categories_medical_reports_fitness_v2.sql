/*
  # إضافة أنظمة الصيدليات المتقدمة، التقارير الطبية، والفتنس

  ## الجداول الجديدة:
  
  ### 1. pharmacy_categories (فئات الصيدليات)
  ### 2. treatment_categories (أقسام العلاج)
  ### 3. products (المنتجات)
  ### 4. medical_reports (التقارير الطبية)
  ### 5. fitness_activities (أنشطة اللياقة)
  ### 6. fitness_goals (أهداف اللياقة)
  ### 7. fitness_workouts (تمارين)
  ### 8. business_accounts (حسابات الأعمال)
*/

-- 1. فئات الصيدليات
CREATE TABLE IF NOT EXISTS pharmacy_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_en text,
  description text,
  icon text,
  sort_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE pharmacy_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "الجميع يمكنهم رؤية الفئات النشطة"
  ON pharmacy_categories FOR SELECT
  USING (is_active = true);

-- 2. أقسام العلاج
CREATE TABLE IF NOT EXISTS treatment_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pharmacy_category_id uuid REFERENCES pharmacy_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  name_en text,
  description text,
  icon text,
  sort_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE treatment_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "الجميع يمكنهم رؤية أقسام العلاج النشطة"
  ON treatment_categories FOR SELECT
  USING (is_active = true);

-- 3. المنتجات
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  treatment_category_id uuid REFERENCES treatment_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  name_en text,
  description text,
  price numeric NOT NULL,
  stock_quantity integer DEFAULT 0,
  image_url text,
  is_available boolean DEFAULT true,
  requires_prescription boolean DEFAULT false,
  delivery_options jsonb DEFAULT '{"standard": true, "express": false}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "الجميع يمكنهم رؤية المنتجات المتاحة"
  ON products FOR SELECT
  USING (is_available = true);

-- 4. التقارير الطبية
CREATE TABLE IF NOT EXISTS medical_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  report_type text NOT NULL CHECK (report_type IN ('insurance', 'health_approval')),
  title text NOT NULL,
  description text,
  documents text[] DEFAULT '{}',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'in_review', 'completed', 'rejected', 'awaiting_info')),
  submitted_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES auth.users(id),
  rejection_reason text,
  pdf_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE medical_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية تقاريرهم"
  ON medical_reports FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم إنشاء تقاريرهم"
  ON medical_reports FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم تحديث تقاريرهم"
  ON medical_reports FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- 5. أنشطة اللياقة
CREATE TABLE IF NOT EXISTS fitness_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  activity_date date NOT NULL DEFAULT CURRENT_DATE,
  steps integer DEFAULT 0,
  calories_burned integer DEFAULT 0,
  heart_rate_avg integer DEFAULT 0,
  sleep_hours numeric DEFAULT 0,
  distance_km numeric DEFAULT 0,
  active_minutes integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, activity_date)
);

ALTER TABLE fitness_activities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية أنشطتهم"
  ON fitness_activities FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم إضافة أنشطتهم"
  ON fitness_activities FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم تحديث أنشطتهم"
  ON fitness_activities FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- 6. أهداف اللياقة
CREATE TABLE IF NOT EXISTS fitness_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  goal_type text NOT NULL CHECK (goal_type IN ('steps', 'calories', 'weight', 'sleep')),
  target_value numeric NOT NULL,
  current_value numeric DEFAULT 0,
  start_date date DEFAULT CURRENT_DATE,
  end_date date NOT NULL,
  is_completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fitness_goals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية أهدافهم"
  ON fitness_goals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم إنشاء أهدافهم"
  ON fitness_goals FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم تحديث أهدافهم"
  ON fitness_goals FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- 7. تمارين اللياقة
CREATE TABLE IF NOT EXISTS fitness_workouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workout_name text NOT NULL,
  duration_minutes integer NOT NULL,
  calories_burned integer DEFAULT 0,
  workout_date timestamptz DEFAULT now(),
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fitness_workouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية تمارينهم"
  ON fitness_workouts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم إضافة تمارينهم"
  ON fitness_workouts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- 8. حسابات الأعمال
CREATE TABLE IF NOT EXISTS business_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  business_type text NOT NULL CHECK (business_type IN ('pharmacy', 'clinic', 'insurance', 'fitness')),
  business_name text NOT NULL,
  license_number text,
  contact_email text NOT NULL,
  contact_phone text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'suspended')),
  permissions jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE business_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية حساباتهم التجارية"
  ON business_accounts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- إضافة بيانات تجريبية لفئات الصيدليات
INSERT INTO pharmacy_categories (name, name_en, description, icon, sort_order) VALUES
('صيدليات عامة', 'General Pharmacies', 'أدوية عامة ومستلزمات طبية', 'pill', 1),
('صيدليات تجميل', 'Beauty Pharmacies', 'منتجات العناية والتجميل', 'sparkles', 2),
('صيدليات عناية', 'Care Pharmacies', 'منتجات العناية الشخصية والصحية', 'heart', 3),
('صيدليات لوازم طبية', 'Medical Supplies', 'أجهزة ومستلزمات طبية', 'stethoscope', 4)
ON CONFLICT DO NOTHING;

-- إضافة أقسام العلاج
WITH cat_ids AS (
  SELECT id, name FROM pharmacy_categories WHERE name = 'صيدليات عامة' LIMIT 1
)
INSERT INTO treatment_categories (pharmacy_category_id, name, name_en, icon, sort_order)
SELECT 
  c.id,
  'مسكنات',
  'Pain Relief',
  'pill',
  1
FROM cat_ids c
UNION ALL
SELECT c.id, 'أجهزة طبية', 'Medical Devices', 'activity', 2 FROM cat_ids c
UNION ALL
SELECT c.id, 'فيتامينات', 'Vitamins', 'zap', 3 FROM cat_ids c
UNION ALL
SELECT c.id, 'أمراض مزمنة', 'Chronic Diseases', 'heart-pulse', 4 FROM cat_ids c
UNION ALL
SELECT c.id, 'أطفال', 'Children', 'baby', 5 FROM cat_ids c
UNION ALL
SELECT c.id, 'تجميل', 'Beauty', 'sparkles', 6 FROM cat_ids c
UNION ALL
SELECT c.id, 'عناية', 'Care', 'droplet', 7 FROM cat_ids c
ON CONFLICT DO NOTHING;
