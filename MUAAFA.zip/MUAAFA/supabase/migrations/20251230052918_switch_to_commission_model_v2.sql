/*
  # التحول إلى نموذج العمولات

  ## التغييرات الرئيسية

  ### 1. إلغاء نظام الاشتراكات
    - تعطيل التحقق من الاشتراكات
    - جعل جميع المزايا مجانية للمستخدم

  ### 2. نظام رحلة المريض (Patient Journey)
    - جدول `patient_journeys` لتتبع رحلة العلاج الكاملة
    - ربط بالمستشفى والصيدلية والتأمين
    - حساب إجمالي التكاليف

  ### 3. سلة الصيدلية (Pharmacy Cart)
    - جدول `pharmacy_cart` للسلة الدائمة
    - حفظ الأدوية حتى بعد الخروج

  ### 4. نظام المدفوعات (Payments)
    - جدول `payments` لجميع المدفوعات
    - دعم الدفع الجزئي مع التأمين
    - ربط بالفواتير

  ### 5. الفواتير الإلكترونية (Invoices)
    - جدول `invoices` للفواتير الإلكترونية
    - إصدار فاتورة لكل عملية دفع

  ### 6. التحاسب الشهري (Settlements)
    - جدول `settlements` للتحاسب مع المستشفيات والصيدليات
    - حساب العمولات (10% للمستشفيات، 5-8% للصيدليات)

  ### 7. تحديث حجز الجلسات
    - إضافة حقول الدفع والتأمين
    - ربط بـ patient_journey
    - منع الحجز بدون دفع
*/

-- =============================================
-- 1. جدول رحلة المريض (Patient Journey)
-- =============================================
CREATE TABLE IF NOT EXISTS patient_journeys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- معلومات الرحلة
  journey_type text NOT NULL CHECK (journey_type IN ('consultation', 'treatment', 'pharmacy_only')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
  
  -- الجهات المرتبطة
  hospital_id uuid REFERENCES business_registrations(id),
  pharmacy_id uuid REFERENCES business_registrations(id),
  insurance_id uuid REFERENCES business_registrations(id),
  
  -- التكاليف
  total_amount numeric(10,2) DEFAULT 0,
  insurance_coverage numeric(10,2) DEFAULT 0,
  patient_paid numeric(10,2) DEFAULT 0,
  
  -- عمولة معافى
  muaafa_commission_rate numeric(5,2) DEFAULT 10.00,
  muaafa_commission_amount numeric(10,2) DEFAULT 0,
  
  -- التواريخ
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  
  -- ملاحظات
  notes text,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_patient_journeys_user ON patient_journeys(user_id);
CREATE INDEX IF NOT EXISTS idx_patient_journeys_hospital ON patient_journeys(hospital_id);
CREATE INDEX IF NOT EXISTS idx_patient_journeys_pharmacy ON patient_journeys(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_patient_journeys_status ON patient_journeys(status);
CREATE INDEX IF NOT EXISTS idx_patient_journeys_dates ON patient_journeys(started_at, completed_at);

-- =============================================
-- 2. سلة الصيدلية (Pharmacy Cart)
-- =============================================
CREATE TABLE IF NOT EXISTS pharmacy_cart (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  medication_id uuid NOT NULL REFERENCES medications(id) ON DELETE CASCADE,
  pharmacy_id uuid NOT NULL REFERENCES business_registrations(id) ON DELETE CASCADE,
  
  -- معلومات المنتج
  quantity integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price numeric(10,2) NOT NULL,
  total_price numeric(10,2) NOT NULL,
  
  -- معلومات التأمين
  insurance_coverage_percent numeric(5,2) DEFAULT 0,
  insurance_coverage_amount numeric(10,2) DEFAULT 0,
  patient_amount numeric(10,2) NOT NULL,
  
  -- الحالة
  is_prescription_required boolean DEFAULT false,
  prescription_id uuid REFERENCES medical_reports(id),
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Index unique لمنع التكرار
CREATE UNIQUE INDEX IF NOT EXISTS idx_pharmacy_cart_unique 
  ON pharmacy_cart(user_id, medication_id, pharmacy_id);

-- Indexes أخرى
CREATE INDEX IF NOT EXISTS idx_pharmacy_cart_user ON pharmacy_cart(user_id);
CREATE INDEX IF NOT EXISTS idx_pharmacy_cart_pharmacy ON pharmacy_cart(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_pharmacy_cart_medication ON pharmacy_cart(medication_id);

-- =============================================
-- 3. نظام المدفوعات (Payments)
-- =============================================
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- معلومات المستخدم
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- نوع الدفع
  payment_type text NOT NULL CHECK (payment_type IN ('consultation', 'pharmacy', 'treatment')),
  
  -- المبالغ
  total_amount numeric(10,2) NOT NULL,
  insurance_coverage numeric(10,2) DEFAULT 0,
  patient_paid numeric(10,2) NOT NULL,
  
  -- معلومات التأمين
  insurance_id uuid REFERENCES business_registrations(id),
  insurance_claim_number text,
  
  -- معلومات بوابة الدفع
  payment_method text NOT NULL CHECK (payment_method IN ('card', 'apple_pay', 'stc_pay', 'mada')),
  payment_gateway text NOT NULL DEFAULT 'stripe',
  payment_gateway_id text,
  payment_status text NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'processing', 'completed', 'failed', 'refunded')),
  
  -- الربط
  appointment_id uuid REFERENCES appointments(id),
  journey_id uuid REFERENCES patient_journeys(id),
  
  -- التواريخ
  paid_at timestamptz,
  failed_at timestamptz,
  refunded_at timestamptz,
  
  -- تفاصيل إضافية
  failure_reason text,
  metadata jsonb DEFAULT '{}',
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_appointment ON payments(appointment_id);
CREATE INDEX IF NOT EXISTS idx_payments_journey ON payments(journey_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(payment_status);
CREATE INDEX IF NOT EXISTS idx_payments_gateway_id ON payments(payment_gateway_id);
CREATE INDEX IF NOT EXISTS idx_payments_insurance ON payments(insurance_id);

-- =============================================
-- 4. الفواتير الإلكترونية (Invoices)
-- =============================================
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- رقم الفاتورة
  invoice_number text UNIQUE NOT NULL,
  
  -- معلومات الفاتورة
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payment_id uuid NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
  journey_id uuid REFERENCES patient_journeys(id),
  
  -- المبالغ
  subtotal numeric(10,2) NOT NULL,
  tax_amount numeric(10,2) DEFAULT 0,
  tax_rate numeric(5,2) DEFAULT 15.00,
  total_amount numeric(10,2) NOT NULL,
  insurance_coverage numeric(10,2) DEFAULT 0,
  amount_paid numeric(10,2) NOT NULL,
  
  -- معلومات الجهة
  provider_id uuid REFERENCES business_registrations(id),
  provider_name text NOT NULL,
  provider_type text NOT NULL CHECK (provider_type IN ('hospital', 'pharmacy', 'clinic')),
  
  -- معلومات التأمين
  insurance_id uuid REFERENCES business_registrations(id),
  insurance_name text,
  
  -- التفاصيل
  items jsonb NOT NULL DEFAULT '[]',
  
  -- الحالة
  status text NOT NULL DEFAULT 'issued' CHECK (status IN ('draft', 'issued', 'paid', 'cancelled')),
  
  -- التواريخ
  issue_date timestamptz DEFAULT now(),
  due_date timestamptz,
  paid_at timestamptz,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_invoices_user ON invoices(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_payment ON invoices(payment_id);
CREATE INDEX IF NOT EXISTS idx_invoices_journey ON invoices(journey_id);
CREATE INDEX IF NOT EXISTS idx_invoices_provider ON invoices(provider_id);
CREATE INDEX IF NOT EXISTS idx_invoices_number ON invoices(invoice_number);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);

-- =============================================
-- 5. التحاسب الشهري (Settlements)
-- =============================================
CREATE TABLE IF NOT EXISTS settlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- معلومات الجهة
  provider_id uuid NOT NULL REFERENCES business_registrations(id) ON DELETE CASCADE,
  provider_name text NOT NULL,
  provider_type text NOT NULL CHECK (provider_type IN ('hospital', 'pharmacy', 'clinic')),
  
  -- الفترة
  period_start date NOT NULL,
  period_end date NOT NULL,
  
  -- الإحصائيات
  total_transactions integer DEFAULT 0,
  total_patients integer DEFAULT 0,
  
  -- المبالغ
  gross_amount numeric(10,2) DEFAULT 0,
  commission_rate numeric(5,2) NOT NULL,
  commission_amount numeric(10,2) DEFAULT 0,
  net_amount numeric(10,2) DEFAULT 0,
  
  -- التفاصيل
  transactions jsonb DEFAULT '[]',
  
  -- الحالة
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'paid', 'cancelled')),
  
  -- التواريخ
  approved_at timestamptz,
  paid_at timestamptz,
  
  -- ملاحظات
  notes text,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Index unique للفترة
CREATE UNIQUE INDEX IF NOT EXISTS idx_settlements_unique
  ON settlements(provider_id, period_start, period_end);

-- Indexes أخرى
CREATE INDEX IF NOT EXISTS idx_settlements_provider ON settlements(provider_id);
CREATE INDEX IF NOT EXISTS idx_settlements_period ON settlements(period_start, period_end);
CREATE INDEX IF NOT EXISTS idx_settlements_status ON settlements(status);

-- =============================================
-- 6. تحديث جدول حجز الجلسات (appointments)
-- =============================================
DO $$
BEGIN
  -- إضافة حقل الدفع
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'appointments' AND column_name = 'payment_required'
  ) THEN
    ALTER TABLE appointments ADD COLUMN payment_required boolean DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'appointments' AND column_name = 'payment_id'
  ) THEN
    ALTER TABLE appointments ADD COLUMN payment_id uuid REFERENCES payments(id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'appointments' AND column_name = 'journey_id'
  ) THEN
    ALTER TABLE appointments ADD COLUMN journey_id uuid REFERENCES patient_journeys(id);
  END IF;

  -- معلومات التكلفة
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'appointments' AND column_name = 'consultation_fee'
  ) THEN
    ALTER TABLE appointments ADD COLUMN consultation_fee numeric(10,2) DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'appointments' AND column_name = 'insurance_coverage'
  ) THEN
    ALTER TABLE appointments ADD COLUMN insurance_coverage numeric(10,2) DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'appointments' AND column_name = 'patient_amount'
  ) THEN
    ALTER TABLE appointments ADD COLUMN patient_amount numeric(10,2) DEFAULT 0;
  END IF;

  -- معلومات التأمين
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'appointments' AND column_name = 'insurance_id'
  ) THEN
    ALTER TABLE appointments ADD COLUMN insurance_id uuid REFERENCES business_registrations(id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'appointments' AND column_name = 'insurance_coverage_percent'
  ) THEN
    ALTER TABLE appointments ADD COLUMN insurance_coverage_percent numeric(5,2) DEFAULT 0;
  END IF;
END $$;

-- =============================================
-- 7. Row Level Security (RLS)
-- =============================================

-- Patient Journeys
ALTER TABLE patient_journeys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own journeys"
  ON patient_journeys FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own journeys"
  ON patient_journeys FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owners can view all journeys"
  ON patient_journeys FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

-- Pharmacy Cart
ALTER TABLE pharmacy_cart ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own cart"
  ON pharmacy_cart FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Payments
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own payments"
  ON payments FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Owners can view all payments"
  ON payments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

-- Invoices
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own invoices"
  ON invoices FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Owners can view all invoices"
  ON invoices FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

-- Settlements
ALTER TABLE settlements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Providers can view own settlements"
  ON settlements FOR SELECT
  TO authenticated
  USING (
    provider_id IN (
      SELECT id FROM business_registrations
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Owners can manage all settlements"
  ON settlements FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

-- =============================================
-- 8. دالة لتوليد رقم الفاتورة
-- =============================================
CREATE OR REPLACE FUNCTION generate_invoice_number()
RETURNS text AS $$
DECLARE
  v_year text;
  v_month text;
  v_count integer;
  v_number text;
BEGIN
  v_year := TO_CHAR(CURRENT_DATE, 'YY');
  v_month := TO_CHAR(CURRENT_DATE, 'MM');
  
  SELECT COUNT(*) + 1 INTO v_count
  FROM invoices
  WHERE EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM CURRENT_DATE)
  AND EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM CURRENT_DATE);
  
  v_number := 'INV-' || v_year || v_month || '-' || LPAD(v_count::text, 5, '0');
  
  RETURN v_number;
END;
$$ LANGUAGE plpgsql;

-- =============================================
-- 9. Triggers لتحديث timestamps
-- =============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Patient Journeys
DROP TRIGGER IF EXISTS update_patient_journeys_updated_at ON patient_journeys;
CREATE TRIGGER update_patient_journeys_updated_at
  BEFORE UPDATE ON patient_journeys
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Pharmacy Cart
DROP TRIGGER IF EXISTS update_pharmacy_cart_updated_at ON pharmacy_cart;
CREATE TRIGGER update_pharmacy_cart_updated_at
  BEFORE UPDATE ON pharmacy_cart
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Payments
DROP TRIGGER IF EXISTS update_payments_updated_at ON payments;
CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON payments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Invoices
DROP TRIGGER IF EXISTS update_invoices_updated_at ON invoices;
CREATE TRIGGER update_invoices_updated_at
  BEFORE UPDATE ON invoices
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Settlements
DROP TRIGGER IF EXISTS update_settlements_updated_at ON settlements;
CREATE TRIGGER update_settlements_updated_at
  BEFORE UPDATE ON settlements
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
