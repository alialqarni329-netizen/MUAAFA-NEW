-- Create content management tables for Owner Portal

-- Health Questions (stored questions from medical_questionnaire for management)
CREATE TABLE IF NOT EXISTS health_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  question_text TEXT NOT NULL,
  question_type TEXT DEFAULT 'text' CHECK (question_type IN ('text', 'multiple_choice', 'yes_no', 'rating')),
  options JSONB DEFAULT NULL,
  is_required BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Bot Responses (AI chatbot responses)
CREATE TABLE IF NOT EXISTS bot_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trigger_keyword TEXT NOT NULL,
  response_text TEXT NOT NULL,
  response_type TEXT DEFAULT 'text' CHECK (response_type IN ('text', 'recommendation', 'referral')),
  confidence_score NUMERIC DEFAULT 0.5,
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Custom Forms
CREATE TABLE IF NOT EXISTS forms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  form_name TEXT NOT NULL,
  description TEXT,
  form_fields JSONB NOT NULL DEFAULT '[]',
  is_active BOOLEAN DEFAULT true,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Policies/Legal Pages (references legal_pages table)
CREATE TABLE IF NOT EXISTS policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  policy_type TEXT DEFAULT 'privacy' CHECK (policy_type IN ('privacy', 'terms', 'cookies', 'other')),
  version TEXT DEFAULT '1.0',
  is_published BOOLEAN DEFAULT false,
  created_by UUID REFERENCES auth.users(id),
  published_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Content Limits/Rate Limits
CREATE TABLE IF NOT EXISTS content_limits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  limit_type TEXT NOT NULL CHECK (limit_type IN ('api_calls', 'messages_per_day', 'forms_per_day', 'storage_gb')),
  limit_value INTEGER NOT NULL,
  period TEXT DEFAULT 'daily' CHECK (period IN ('daily', 'monthly', 'yearly')),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Content Reviews/Moderation
CREATE TABLE IF NOT EXISTS content_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID,
  content_type TEXT NOT NULL CHECK (content_type IN ('question', 'response', 'form', 'policy')),
  title TEXT NOT NULL,
  content_preview TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'needs_revision')),
  reviewer_id UUID REFERENCES auth.users(id),
  review_notes TEXT,
  revision_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  reviewed_at TIMESTAMP WITH TIME ZONE
);

-- User Response Submissions (tracks responses to questionnaires)
CREATE TABLE IF NOT EXISTS questionnaire_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  question_id UUID NOT NULL REFERENCES health_questions(id),
  answer TEXT NOT NULL,
  answer_value NUMERIC,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_health_questions_category ON health_questions(category);
CREATE INDEX IF NOT EXISTS idx_health_questions_active ON health_questions(is_active);
CREATE INDEX IF NOT EXISTS idx_bot_responses_active ON bot_responses(is_active);
CREATE INDEX IF NOT EXISTS idx_forms_active ON forms(is_active);
CREATE INDEX IF NOT EXISTS idx_policies_published ON policies(is_published);
CREATE INDEX IF NOT EXISTS idx_content_reviews_status ON content_reviews(status);
CREATE INDEX IF NOT EXISTS idx_questionnaire_responses_user ON questionnaire_responses(user_id);
CREATE INDEX IF NOT EXISTS idx_questionnaire_responses_question ON questionnaire_responses(question_id);

-- Enable RLS (Row Level Security) on all tables
ALTER TABLE health_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE forms ENABLE ROW LEVEL SECURITY;
ALTER TABLE policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE questionnaire_responses ENABLE ROW LEVEL SECURITY;

-- RLS Policies for viewing (owner/admin only)
CREATE POLICY "Allow owner to view health questions" ON health_questions
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to view bot responses" ON bot_responses
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to view forms" ON forms
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to view policies" ON policies
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to view content limits" ON content_limits
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to view content reviews" ON content_reviews
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow users to view their own responses" ON questionnaire_responses
  FOR SELECT USING (user_id = auth.uid());

-- RLS Policies for inserting/updating (owner/admin only)
CREATE POLICY "Allow owner to manage health questions" ON health_questions
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to update health questions" ON health_questions
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to manage bot responses" ON bot_responses
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to update bot responses" ON bot_responses
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to manage forms" ON forms
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to update forms" ON forms
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to manage policies" ON policies
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow owner to update policies" ON policies
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.id = auth.uid()
  ));

CREATE POLICY "Allow users to submit responses" ON questionnaire_responses
  FOR INSERT WITH CHECK (user_id = auth.uid());
