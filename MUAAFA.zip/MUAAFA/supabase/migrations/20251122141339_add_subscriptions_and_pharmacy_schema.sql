/*
  # إضافة نظام الاشتراكات والصيدلية

  ## الجداول الجديدة:
  
  ### 1. subscription_plans (خطط الاشتراك)
    - `id` (uuid, primary key)
    - `name` (text) - اسم الخطة (Basic/Standard/Premium)
    - `description` (text) - وصف الخطة
    - `price_weekly` (numeric) - السعر الأسبوعي
    - `price_monthly` (numeric) - السعر الشهري
    - `price_yearly` (numeric) - السعر السنوي
    - `features` (jsonb) - مميزات الخطة
    - `is_active` (boolean) - هل الخطة نشطة
    - `created_at` (timestamptz)
    
  ### 2. user_subscriptions (اشتراكات المستخدمين)
    - `id` (uuid, primary key)
    - `user_id` (uuid, foreign key)
    - `plan_id` (uuid, foreign key)
    - `status` (text) - trial/active/cancelled/expired
    - `billing_period` (text) - weekly/monthly/yearly
    - `trial_expires_at` (timestamptz)
    - `current_period_start` (timestamptz)
    - `current_period_end` (timestamptz)
    - `cancel_at_period_end` (boolean)
    - `payment_method` (text)
    - `created_at` (timestamptz)
    - `updated_at` (timestamptz)
    
  ### 3. pharmacies (الصيدليات)
    - `id` (uuid, primary key)
    - `name` (text) - اسم الصيدلية
    - `name_en` (text) - الاسم بالإنجليزية
    - `phone` (text)
    - `address` (text)
    - `city` (text)
    - `latitude` (numeric)
    - `longitude` (numeric)
    - `rating` (numeric)
    - `is_24_hours` (boolean)
    - `has_instant_delivery` (boolean)
    - `delivery_time_minutes` (integer)
    - `is_active` (boolean)
    - `created_at` (timestamptz)
    
  ### 4. medications (الأدوية)
    - `id` (uuid, primary key)
    - `name` (text)
    - `name_en` (text)
    - `category` (text)
    - `description` (text)
    - `requires_prescription` (boolean)
    - `image_url` (text)
    - `created_at` (timestamptz)
    
  ### 5. pharmacy_inventory (مخزون الصيدليات)
    - `id` (uuid, primary key)
    - `pharmacy_id` (uuid, foreign key)
    - `medication_id` (uuid, foreign key)
    - `price` (numeric)
    - `stock_quantity` (integer)
    - `is_available` (boolean)
    - `updated_at` (timestamptz)
    
  ### 6. prescriptions (الوصفات)
    - `id` (uuid, primary key)
    - `user_id` (uuid, foreign key)
    - `images` (text[]) - مصفوفة روابط الصور
    - `status` (text) - pending/approved/rejected
    - `notes` (text)
    - `reviewed_by` (uuid)
    - `reviewed_at` (timestamptz)
    - `created_at` (timestamptz)
    
  ### 7. orders (الطلبات)
    - `id` (uuid, primary key)
    - `user_id` (uuid, foreign key)
    - `pharmacy_id` (uuid, foreign key)
    - `prescription_id` (uuid, nullable)
    - `total_amount` (numeric)
    - `delivery_address` (text)
    - `delivery_latitude` (numeric)
    - `delivery_longitude` (numeric)
    - `payment_method` (text)
    - `status` (text) - pending/confirmed/preparing/out_for_delivery/delivered/cancelled
    - `estimated_delivery_time` (timestamptz)
    - `delivered_at` (timestamptz)
    - `created_at` (timestamptz)
    - `updated_at` (timestamptz)
    
  ### 8. order_items (عناصر الطلب)
    - `id` (uuid, primary key)
    - `order_id` (uuid, foreign key)
    - `medication_id` (uuid, foreign key)
    - `quantity` (integer)
    - `price` (numeric)
    - `created_at` (timestamptz)

  ## الأمان:
    - RLS مفعّل على كل الجداول
    - المستخدمون يمكنهم رؤية بياناتهم فقط
    - الصيدليات والأدوية public للقراءة
*/

-- 1. جدول خطط الاشتراك
CREATE TABLE IF NOT EXISTS subscription_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price_weekly numeric NOT NULL DEFAULT 0,
  price_monthly numeric NOT NULL DEFAULT 0,
  price_yearly numeric NOT NULL DEFAULT 0,
  features jsonb DEFAULT '[]'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE subscription_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "الجميع يمكنهم رؤية الخطط النشطة"
  ON subscription_plans FOR SELECT
  USING (is_active = true);

-- 2. جدول اشتراكات المستخدمين
CREATE TABLE IF NOT EXISTS user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  plan_id uuid REFERENCES subscription_plans(id) NOT NULL,
  status text NOT NULL DEFAULT 'trial',
  billing_period text NOT NULL DEFAULT 'monthly',
  trial_expires_at timestamptz,
  current_period_start timestamptz DEFAULT now(),
  current_period_end timestamptz,
  cancel_at_period_end boolean DEFAULT false,
  payment_method text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية اشتراكاتهم"
  ON user_subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم إنشاء اشتراكاتهم"
  ON user_subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم تحديث اشتراكاتهم"
  ON user_subscriptions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- 3. جدول الصيدليات
CREATE TABLE IF NOT EXISTS pharmacies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_en text,
  phone text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  latitude numeric NOT NULL,
  longitude numeric NOT NULL,
  rating numeric DEFAULT 0,
  is_24_hours boolean DEFAULT false,
  has_instant_delivery boolean DEFAULT false,
  delivery_time_minutes integer DEFAULT 30,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE pharmacies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "الجميع يمكنهم رؤية الصيدليات النشطة"
  ON pharmacies FOR SELECT
  USING (is_active = true);

-- 4. جدول الأدوية
CREATE TABLE IF NOT EXISTS medications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_en text,
  category text NOT NULL,
  description text,
  requires_prescription boolean DEFAULT false,
  image_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE medications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "الجميع يمكنهم رؤية الأدوية"
  ON medications FOR SELECT
  USING (true);

-- 5. جدول مخزون الصيدليات
CREATE TABLE IF NOT EXISTS pharmacy_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pharmacy_id uuid REFERENCES pharmacies(id) ON DELETE CASCADE NOT NULL,
  medication_id uuid REFERENCES medications(id) ON DELETE CASCADE NOT NULL,
  price numeric NOT NULL,
  stock_quantity integer DEFAULT 0,
  is_available boolean DEFAULT true,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(pharmacy_id, medication_id)
);

ALTER TABLE pharmacy_inventory ENABLE ROW LEVEL SECURITY;

CREATE POLICY "الجميع يمكنهم رؤية المخزون المتاح"
  ON pharmacy_inventory FOR SELECT
  USING (is_available = true AND stock_quantity > 0);

-- 6. جدول الوصفات
CREATE TABLE IF NOT EXISTS prescriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  images text[] NOT NULL,
  status text DEFAULT 'pending',
  notes text,
  reviewed_by uuid REFERENCES auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE prescriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية وصفاتهم"
  ON prescriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم إنشاء وصفاتهم"
  ON prescriptions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- 7. جدول الطلبات
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  pharmacy_id uuid REFERENCES pharmacies(id) NOT NULL,
  prescription_id uuid REFERENCES prescriptions(id),
  total_amount numeric NOT NULL,
  delivery_address text NOT NULL,
  delivery_latitude numeric,
  delivery_longitude numeric,
  payment_method text NOT NULL,
  status text DEFAULT 'pending',
  estimated_delivery_time timestamptz,
  delivered_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية طلباتهم"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم إنشاء طلباتهم"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "المستخدمون يمكنهم تحديث طلباتهم"
  ON orders FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- 8. جدول عناصر الطلب
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  medication_id uuid REFERENCES medications(id) NOT NULL,
  quantity integer NOT NULL,
  price numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستخدمون يمكنهم رؤية عناصر طلباتهم"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- إضافة بيانات تجريبية لخطط الاشتراك
INSERT INTO subscription_plans (name, description, price_weekly, price_monthly, price_yearly, features) VALUES
('Basic', 'الخطة الأساسية - مثالية للبدء', 29, 99, 999, '["جلسات محدودة", "دعم أساسي", "وصول للمحتوى الأساسي"]'::jsonb),
('Standard', 'الخطة القياسية - الأكثر شيوعاً', 49, 169, 1699, '["جلسات غير محدودة", "دعم أولوية", "وصول كامل للمحتوى", "تحليلات متقدمة"]'::jsonb),
('Premium', 'الخطة المميزة - للاستخدام الكامل', 79, 269, 2699, '["كل مميزات Standard", "استشارات مباشرة", "خطط علاجية مخصصة", "دعم 24/7"]'::jsonb)
ON CONFLICT DO NOTHING;
