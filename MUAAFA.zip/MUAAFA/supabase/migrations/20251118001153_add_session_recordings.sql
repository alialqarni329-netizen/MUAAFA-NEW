/*
  # إضافة نظام تسجيل الجلسات

  1. جدول جديد
    - `session_recordings`
      - `id` (uuid, primary key)
      - `session_id` (uuid, foreign key to sessions)
      - `recording_url` (text) - رابط التسجيل
      - `recording_type` (text) - نوع التسجيل (video, audio, chat)
      - `duration_seconds` (integer) - مدة التسجيل بالثواني
      - `file_size` (bigint) - حجم الملف
      - `storage_path` (text) - مسار الملف في التخزين
      - `status` (text) - حالة التسجيل (processing, completed, failed)
      - `started_at` (timestamptz) - وقت بدء التسجيل
      - `completed_at` (timestamptz) - وقت انتهاء التسجيل
      - `created_at` (timestamptz)

  2. تحديث جدول sessions
    - إضافة `has_recording` (boolean) - هل تم تسجيل الجلسة
    - إضافة `recording_consent` (boolean) - موافقة المستخدم على التسجيل

  3. الأمان
    - تفعيل RLS على جدول session_recordings
    - سياسات للوصول للتسجيلات فقط لأصحابها
*/

-- إنشاء جدول تسجيلات الجلسات
CREATE TABLE IF NOT EXISTS session_recordings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  recording_url text,
  recording_type text NOT NULL CHECK (recording_type IN ('video', 'audio', 'chat')),
  duration_seconds integer DEFAULT 0,
  file_size bigint DEFAULT 0,
  storage_path text,
  status text DEFAULT 'processing' CHECK (status IN ('processing', 'completed', 'failed')),
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- إضافة أعمدة لجدول الجلسات
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'has_recording'
  ) THEN
    ALTER TABLE sessions ADD COLUMN has_recording boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'recording_consent'
  ) THEN
    ALTER TABLE sessions ADD COLUMN recording_consent boolean DEFAULT true;
  END IF;
END $$;

-- تفعيل RLS
ALTER TABLE session_recordings ENABLE ROW LEVEL SECURITY;

-- سياسة: المستخدمون يمكنهم رؤية تسجيلات جلساتهم فقط
CREATE POLICY "Users can view their own session recordings"
  ON session_recordings
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = auth.uid()
    )
  );

-- سياسة: المستخدمون يمكنهم حذف تسجيلات جلساتهم
CREATE POLICY "Users can delete their own session recordings"
  ON session_recordings
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = auth.uid()
    )
  );

-- سياسة: النظام يمكنه إنشاء التسجيلات
CREATE POLICY "System can create session recordings"
  ON session_recordings
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = auth.uid()
    )
  );

-- سياسة: النظام يمكنه تحديث التسجيلات
CREATE POLICY "System can update session recordings"
  ON session_recordings
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sessions
      WHERE sessions.id = session_recordings.session_id
      AND sessions.user_id = auth.uid()
    )
  );

-- إنشاء فهرس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_session_recordings_session_id 
  ON session_recordings(session_id);

CREATE INDEX IF NOT EXISTS idx_session_recordings_status 
  ON session_recordings(status);
