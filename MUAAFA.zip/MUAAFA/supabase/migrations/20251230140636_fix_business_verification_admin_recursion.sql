/*
  # Fix Business Verification Admin Recursion

  1. Problem
    - The "Admins can manage all verifications" policy on business_verification table
      causes infinite recursion by querying admin_users table
    - The WHERE clause was incorrectly checking business_verification.user_id = auth.uid()
      instead of admin_users.id = auth.uid()

  2. Solution
    - Drop the problematic policy
    - Create corrected policy that properly checks if the current user is an admin
    - Use correct WHERE clause: admin_users.id = auth.uid()

  3. Security
    - Maintains admin access control
    - Prevents infinite recursion
    - Only admins and owners can manage all verifications
*/

-- Drop the problematic policy
DROP POLICY IF EXISTS "Admins can manage all verifications" ON business_verification;

-- Create corrected policy without recursion
CREATE POLICY "Admins can manage all verifications"
  ON business_verification
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM admin_users
      WHERE admin_users.id = auth.uid()
      AND admin_users.role IN ('owner', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM admin_users
      WHERE admin_users.id = auth.uid()
      AND admin_users.role IN ('owner', 'admin')
    )
  );
