/*
  # Subscription Payments Table and Owner Access

  ## New Tables:
  1. subscription_payments - Track all subscription payments
     - user_id, plan_id, amount, payment_status, created_at
     - Used for revenue reporting in owner portal

  ## Owner Portal Access:
  - Owners can view all subscription data (read-only)
  - Implement SECURITY DEFINER functions for owner queries
*/

-- Create subscription_payments table
CREATE TABLE IF NOT EXISTS subscription_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id UUID REFERENCES subscription_plans(id),
  subscription_id UUID REFERENCES subscriptions(id) ON DELETE SET NULL,
  amount NUMERIC(10,2) NOT NULL CHECK (amount >= 0),
  currency TEXT DEFAULT 'SAR',
  payment_method TEXT DEFAULT 'stripe',
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'succeeded', 'failed', 'cancelled')),
  transaction_id TEXT UNIQUE,
  invoice_url TEXT,
  metadata JSONB DEFAULT '{}',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  paid_at TIMESTAMPTZ
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_subscription_payments_user_id ON subscription_payments(user_id);
CREATE INDEX IF NOT EXISTS idx_subscription_payments_plan_id ON subscription_payments(plan_id);
CREATE INDEX IF NOT EXISTS idx_subscription_payments_status ON subscription_payments(payment_status);
CREATE INDEX IF NOT EXISTS idx_subscription_payments_created_at ON subscription_payments(created_at);
CREATE INDEX IF NOT EXISTS idx_subscription_payments_subscription_id ON subscription_payments(subscription_id);

-- Enable RLS
ALTER TABLE subscription_payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for authenticated users (view own payments)
DROP POLICY IF EXISTS "Users can view own subscription payments" ON subscription_payments;
CREATE POLICY "Users can view own subscription payments"
  ON subscription_payments FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can create own subscription payments" ON subscription_payments;
CREATE POLICY "Users can create own subscription payments"
  ON subscription_payments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for owner/admin (view all payments)
DROP POLICY IF EXISTS "Admins can view all subscription payments" ON subscription_payments;
CREATE POLICY "Admins can view all subscription payments"
  ON subscription_payments FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.id = auth.uid() 
      LIMIT 1
    )
  );

-- Add subscription_id to subscriptions table if not exists
ALTER TABLE subscriptions 
ADD COLUMN IF NOT EXISTS plan_id UUID REFERENCES subscription_plans(id);

-- Grant permissions
GRANT SELECT ON subscription_payments TO authenticated;
GRANT INSERT ON subscription_payments TO authenticated;
GRANT SELECT ON subscription_payments TO anon;
