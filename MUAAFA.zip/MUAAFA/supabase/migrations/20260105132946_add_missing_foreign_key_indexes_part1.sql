/*
  # إضافة Indexes للـ Foreign Keys - الجزء الأول
  
  ## التحسينات
  
  ### Indexes للجداول (Part 1)
  - appointment_slots: hospital_id
  - appointments: doctor_id, insurance_id, journey_id, payment_id
  - bot_responses: created_by
  - business_permissions: business_id
  - business_registrations: reviewed_by
  - cart_items: product_id
  - content_reviews: reviewer_id
  - delivery_assignments: delivery_company_id, order_id
  - delivery_proof: order_id
  - email_templates: created_by
  - emergency_deliveries: order_id
  - fitness_ai_recommendations: based_on_scan_id
  - forms: created_by
  - insurance_appeals: request_id
  - insurance_approvals: insurance_company_id, order_id, provider_id
  
  ## الفائدة
  - تحسين أداء الاستعلامات التي تستخدم foreign keys
  - تسريع عمليات JOIN
*/

-- appointment_slots
CREATE INDEX IF NOT EXISTS idx_appointment_slots_hospital_id 
ON appointment_slots(hospital_id);

-- appointments
CREATE INDEX IF NOT EXISTS idx_appointments_doctor_id 
ON appointments(doctor_id);

CREATE INDEX IF NOT EXISTS idx_appointments_insurance_id 
ON appointments(insurance_id);

CREATE INDEX IF NOT EXISTS idx_appointments_journey_id 
ON appointments(journey_id);

CREATE INDEX IF NOT EXISTS idx_appointments_payment_id 
ON appointments(payment_id);

-- bot_responses
CREATE INDEX IF NOT EXISTS idx_bot_responses_created_by 
ON bot_responses(created_by);

-- business_permissions
CREATE INDEX IF NOT EXISTS idx_business_permissions_business_id 
ON business_permissions(business_id);

-- business_registrations
CREATE INDEX IF NOT EXISTS idx_business_registrations_reviewed_by 
ON business_registrations(reviewed_by);

-- cart_items
CREATE INDEX IF NOT EXISTS idx_cart_items_product_id 
ON cart_items(product_id);

-- content_reviews
CREATE INDEX IF NOT EXISTS idx_content_reviews_reviewer_id 
ON content_reviews(reviewer_id);

-- delivery_assignments
CREATE INDEX IF NOT EXISTS idx_delivery_assignments_delivery_company_id 
ON delivery_assignments(delivery_company_id);

CREATE INDEX IF NOT EXISTS idx_delivery_assignments_order_id 
ON delivery_assignments(order_id);

-- delivery_proof
CREATE INDEX IF NOT EXISTS idx_delivery_proof_order_id 
ON delivery_proof(order_id);

-- email_templates
CREATE INDEX IF NOT EXISTS idx_email_templates_created_by 
ON email_templates(created_by);

-- emergency_deliveries
CREATE INDEX IF NOT EXISTS idx_emergency_deliveries_order_id 
ON emergency_deliveries(order_id);

-- fitness_ai_recommendations
CREATE INDEX IF NOT EXISTS idx_fitness_ai_recommendations_based_on_scan_id 
ON fitness_ai_recommendations(based_on_scan_id);

-- forms
CREATE INDEX IF NOT EXISTS idx_forms_created_by 
ON forms(created_by);

-- insurance_appeals
CREATE INDEX IF NOT EXISTS idx_insurance_appeals_request_id 
ON insurance_appeals(request_id);

-- insurance_approvals
CREATE INDEX IF NOT EXISTS idx_insurance_approvals_insurance_company_id 
ON insurance_approvals(insurance_company_id);

CREATE INDEX IF NOT EXISTS idx_insurance_approvals_order_id 
ON insurance_approvals(order_id);

CREATE INDEX IF NOT EXISTS idx_insurance_approvals_provider_id 
ON insurance_approvals(provider_id);
