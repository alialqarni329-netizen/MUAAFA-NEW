/*
  # تحسين نظام بوابة الأعمال
  # Enhanced Business Portal System

  1. التعديلات
    - إضافة business_type إلى business_registrations
    - إنشاء جدول staff_members (الموظفين)
    - إنشاء جدول staff_roles (الأدوار)
    - إضافة business_status (حالة المنشأة)
    
  2. الأمان
    - تفعيل RLS على الجداول الجديدة
    - سياسات للوصول حسب الصلاحيات

  3. الفهارس
    - فهارس لتسريع الاستعلامات
*/

-- ==========================================
-- 1. إضافة نوع الجهة وحالة المنشأة
-- ==========================================

DO $$
BEGIN
  -- إضافة business_type إذا لم يكن موجوداً
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' AND column_name = 'business_type'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN business_type text CHECK (business_type IN ('insurance', 'hospital', 'pharmacy'));
  END IF;

  -- إضافة business_status إذا لم يكن موجوداً
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' AND column_name = 'business_status'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN business_status text DEFAULT 'pending_review' CHECK (business_status IN ('pending_review', 'active', 'suspended', 'rejected'));
  END IF;

  -- إضافة configuration إذا لم يكن موجوداً (لإعدادات مخصصة)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' AND column_name = 'configuration'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN configuration jsonb DEFAULT '{}'::jsonb;
  END IF;
END $$;

-- فهارس للبحث السريع
CREATE INDEX IF NOT EXISTS idx_business_type ON business_registrations(business_type);
CREATE INDEX IF NOT EXISTS idx_business_status ON business_registrations(business_status);

-- ==========================================
-- 2. جدول الأدوار (Staff Roles)
-- ==========================================

CREATE TABLE IF NOT EXISTS staff_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_en text NOT NULL,
  business_type text NOT NULL CHECK (business_type IN ('insurance', 'hospital', 'pharmacy', 'all')),
  permissions jsonb DEFAULT '[]'::jsonb,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  UNIQUE(name_en, business_type)
);

-- فهرس
CREATE INDEX IF NOT EXISTS idx_staff_roles_business_type ON staff_roles(business_type);

-- RLS
ALTER TABLE staff_roles ENABLE ROW LEVEL SECURITY;

-- سياسة: الجميع يمكنه قراءة الأدوار
CREATE POLICY "Anyone can view staff roles"
  ON staff_roles FOR SELECT
  TO authenticated
  USING (true);

-- ==========================================
-- 3. جدول الموظفين (Staff Members)
-- ==========================================

CREATE TABLE IF NOT EXISTS staff_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES business_registrations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  
  -- معلومات الموظف
  full_name text NOT NULL,
  email text NOT NULL,
  phone text,
  national_id text,
  
  -- الدور والصلاحيات
  role_id uuid REFERENCES staff_roles(id) ON DELETE SET NULL,
  custom_permissions jsonb DEFAULT '[]'::jsonb,
  
  -- الحالة
  status text DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  hired_at timestamptz DEFAULT now(),
  
  -- التوقيت
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  
  UNIQUE(business_id, email)
);

-- فهارس
CREATE INDEX IF NOT EXISTS idx_staff_members_business_id ON staff_members(business_id);
CREATE INDEX IF NOT EXISTS idx_staff_members_user_id ON staff_members(user_id);
CREATE INDEX IF NOT EXISTS idx_staff_members_role_id ON staff_members(role_id);
CREATE INDEX IF NOT EXISTS idx_staff_members_status ON staff_members(status);

-- RLS
ALTER TABLE staff_members ENABLE ROW LEVEL SECURITY;

-- سياسة: يمكن للمنشأة رؤية موظفيها
CREATE POLICY "Business owners can view their staff"
  ON staff_members FOR SELECT
  TO authenticated
  USING (
    business_id IN (
      SELECT id FROM business_registrations WHERE user_id = auth.uid()
    )
  );

-- سياسة: يمكن للمنشأة إضافة موظفين
CREATE POLICY "Business owners can insert staff"
  ON staff_members FOR INSERT
  TO authenticated
  WITH CHECK (
    business_id IN (
      SELECT id FROM business_registrations WHERE user_id = auth.uid()
    )
  );

-- سياسة: يمكن للمنشأة تعديل موظفيها
CREATE POLICY "Business owners can update their staff"
  ON staff_members FOR UPDATE
  TO authenticated
  USING (
    business_id IN (
      SELECT id FROM business_registrations WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    business_id IN (
      SELECT id FROM business_registrations WHERE user_id = auth.uid()
    )
  );

-- سياسة: يمكن للمنشأة حذف موظفيها
CREATE POLICY "Business owners can delete their staff"
  ON staff_members FOR DELETE
  TO authenticated
  USING (
    business_id IN (
      SELECT id FROM business_registrations WHERE user_id = auth.uid()
    )
  );

-- ==========================================
-- 4. جدول سجل النشاط (Audit Log)
-- ==========================================

CREATE TABLE IF NOT EXISTS business_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES business_registrations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  staff_id uuid REFERENCES staff_members(id) ON DELETE SET NULL,
  
  -- التفاصيل
  action text NOT NULL,
  action_type text CHECK (action_type IN ('create', 'update', 'delete', 'view', 'approve', 'reject')),
  resource_type text,
  resource_id uuid,
  details jsonb DEFAULT '{}'::jsonb,
  
  -- التوقيت
  created_at timestamptz DEFAULT now(),
  ip_address text,
  user_agent text
);

-- فهارس
CREATE INDEX IF NOT EXISTS idx_audit_log_business_id ON business_audit_log(business_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_user_id ON business_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_created_at ON business_audit_log(created_at DESC);

-- RLS
ALTER TABLE business_audit_log ENABLE ROW LEVEL SECURITY;

-- سياسة: يمكن للمنشأة رؤية سجل النشاط الخاص بها
CREATE POLICY "Business owners can view their audit log"
  ON business_audit_log FOR SELECT
  TO authenticated
  USING (
    business_id IN (
      SELECT id FROM business_registrations WHERE user_id = auth.uid()
    )
  );

-- سياسة: السماح بإضافة سجلات جديدة
CREATE POLICY "Allow inserting audit logs"
  ON business_audit_log FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- ==========================================
-- 5. إدراج الأدوار الافتراضية
-- ==========================================

-- أدوار شركات التأمين
INSERT INTO staff_roles (name, name_en, business_type, permissions, description) VALUES
('موظف مطالبات', 'claims_officer', 'insurance', 
 '["view_claims", "process_claims", "request_documents"]'::jsonb,
 'يمكنه استعراض ومعالجة المطالبات التأمينية'),
('مدير موافقات', 'approvals_manager', 'insurance', 
 '["view_claims", "process_claims", "approve_claims", "reject_claims", "view_reports"]'::jsonb,
 'يمكنه الموافقة على المطالبات ورفضها'),
('مشرف عام', 'general_supervisor', 'insurance', 
 '["all"]'::jsonb,
 'صلاحيات كاملة على جميع الأقسام')
ON CONFLICT (name_en, business_type) DO NOTHING;

-- أدوار المستشفيات
INSERT INTO staff_roles (name, name_en, business_type, permissions, description) VALUES
('طبيب', 'doctor', 'hospital', 
 '["view_sessions", "manage_sessions", "upload_reports", "view_patients"]'::jsonb,
 'يمكنه إدارة الجلسات الصحية ورفع التقارير'),
('استقبال', 'receptionist', 'hospital', 
 '["view_sessions", "schedule_appointments", "view_patients"]'::jsonb,
 'يمكنه جدولة المواعيد واستقبال المرضى'),
('إدارة طبية', 'medical_admin', 'hospital', 
 '["view_sessions", "manage_sessions", "view_reports", "view_statistics"]'::jsonb,
 'يمكنه الإشراف على العمليات الطبية'),
('مدير منشأة', 'facility_manager', 'hospital', 
 '["all"]'::jsonb,
 'صلاحيات كاملة على المنشأة')
ON CONFLICT (name_en, business_type) DO NOTHING;

-- أدوار الصيدليات
INSERT INTO staff_roles (name, name_en, business_type, permissions, description) VALUES
('صيدلي', 'pharmacist', 'pharmacy', 
 '["manage_medications", "process_prescriptions", "manage_orders"]'::jsonb,
 'يمكنه إدارة الأدوية ومعالجة الوصفات'),
('كاشير', 'cashier', 'pharmacy', 
 '["process_orders", "view_orders", "manage_payments"]'::jsonb,
 'يمكنه معالجة الطلبات والمدفوعات'),
('مدير فرع', 'branch_manager', 'pharmacy', 
 '["all"]'::jsonb,
 'صلاحيات كاملة على الفرع')
ON CONFLICT (name_en, business_type) DO NOTHING;

-- ==========================================
-- 6. Triggers لتحديث updated_at
-- ==========================================

DROP TRIGGER IF EXISTS update_staff_roles_updated_at ON staff_roles;
CREATE TRIGGER update_staff_roles_updated_at
  BEFORE UPDATE ON staff_roles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_staff_members_updated_at ON staff_members;
CREATE TRIGGER update_staff_members_updated_at
  BEFORE UPDATE ON staff_members
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ==========================================
-- 7. دوال مساعدة
-- ==========================================

-- دالة للتحقق من صلاحيات الموظف
CREATE OR REPLACE FUNCTION check_staff_permission(
  p_business_id uuid,
  p_user_id uuid,
  p_permission text
) RETURNS boolean AS $$
DECLARE
  v_has_permission boolean := false;
  v_permissions jsonb;
BEGIN
  -- جلب صلاحيات الموظف
  SELECT 
    COALESCE(sm.custom_permissions, sr.permissions, '[]'::jsonb)
  INTO v_permissions
  FROM staff_members sm
  LEFT JOIN staff_roles sr ON sm.role_id = sr.id
  WHERE sm.business_id = p_business_id
    AND sm.user_id = p_user_id
    AND sm.status = 'active';
  
  IF NOT FOUND THEN
    RETURN false;
  END IF;
  
  -- التحقق من الصلاحية
  IF v_permissions ? 'all' OR v_permissions @> to_jsonb(ARRAY[p_permission]) THEN
    v_has_permission := true;
  END IF;
  
  RETURN v_has_permission;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- دالة لجلب نوع المنشأة للمستخدم الحالي
CREATE OR REPLACE FUNCTION get_user_business_type()
RETURNS text AS $$
DECLARE
  v_business_type text;
BEGIN
  SELECT business_type INTO v_business_type
  FROM business_registrations
  WHERE user_id = auth.uid()
  LIMIT 1;
  
  RETURN v_business_type;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==========================================
-- 8. تحديث بيانات business_registrations الموجودة
-- ==========================================

-- تحديث السجلات القديمة لتكون بحالة 'active' افتراضياً
UPDATE business_registrations 
SET business_status = 'active'
WHERE business_status IS NULL;

-- ==========================================
-- 9. Views مساعدة
-- ==========================================

-- View لعرض الموظفين مع أدوارهم
CREATE OR REPLACE VIEW staff_members_with_roles AS
SELECT 
  sm.id,
  sm.business_id,
  sm.user_id,
  sm.full_name,
  sm.email,
  sm.phone,
  sm.status,
  sr.name as role_name,
  sr.name_en as role_name_en,
  sr.permissions as role_permissions,
  sm.custom_permissions,
  sm.hired_at,
  sm.created_at
FROM staff_members sm
LEFT JOIN staff_roles sr ON sm.role_id = sr.id;

-- منح صلاحيات القراءة على الـ view
GRANT SELECT ON staff_members_with_roles TO authenticated;
