/*
  # إضافة قيود الأمان ومنع التكرار

  1. التغييرات
    - تنظيف البيانات المكررة
    - إضافة unique constraints
    - إضافة دوال التحقق

  2. الأمان
    - منع التسجيل المكرر
    - حماية البيانات
*/

-- 1. تنظيف الهواتف المكررة في users
WITH duplicates AS (
  SELECT
    id,
    phone,
    ROW_NUMBER() OVER (PARTITION BY phone ORDER BY created_at DESC NULLS LAST) as rn
  FROM users
  WHERE phone IS NOT NULL AND phone != ''
)
UPDATE users
SET phone = phone || '-old' || substring(id::text, 1, 6)
WHERE id IN (SELECT id FROM duplicates WHERE rn > 1);

-- 2. تنظيف الهويات المكررة في users
WITH duplicates AS (
  SELECT
    id,
    national_id,
    ROW_NUMBER() OVER (PARTITION BY national_id ORDER BY created_at DESC NULLS LAST) as rn
  FROM users
  WHERE national_id IS NOT NULL AND national_id != ''
)
UPDATE users
SET national_id = national_id || '-old' || substring(id::text, 1, 6)
WHERE id IN (SELECT id FROM duplicates WHERE rn > 1);

-- 3. إضافة unique constraints لـ users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'users_phone_unique'
  ) THEN
    ALTER TABLE users ADD CONSTRAINT users_phone_unique UNIQUE (phone);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'users_national_id_unique'
  ) THEN
    ALTER TABLE users ADD CONSTRAINT users_national_id_unique UNIQUE (national_id);
  END IF;
END $$;

-- 4. إضافة indexes لـ users
CREATE INDEX IF NOT EXISTS idx_users_phone ON users (phone) WHERE phone IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_national_id ON users (national_id) WHERE national_id IS NOT NULL;

-- 5. تنظيف الهواتف المكررة في business_registrations
WITH duplicates AS (
  SELECT
    id,
    phone,
    ROW_NUMBER() OVER (PARTITION BY phone ORDER BY created_at DESC NULLS LAST) as rn
  FROM business_registrations
  WHERE phone IS NOT NULL AND phone != ''
)
UPDATE business_registrations
SET phone = phone || '-old' || substring(id::text, 1, 6)
WHERE id IN (SELECT id FROM duplicates WHERE rn > 1);

-- 6. تنظيف البريد المكرر في business_registrations
WITH duplicates AS (
  SELECT
    id,
    email,
    ROW_NUMBER() OVER (PARTITION BY lower(email) ORDER BY created_at DESC NULLS LAST) as rn
  FROM business_registrations
  WHERE email IS NOT NULL AND email != ''
)
UPDATE business_registrations
SET email = 'old' || substring(id::text, 1, 6) || '_' || email
WHERE id IN (SELECT id FROM duplicates WHERE rn > 1);

-- 7. تنظيف السجل التجاري المكرر
WITH duplicates AS (
  SELECT
    id,
    commercial_registration,
    ROW_NUMBER() OVER (PARTITION BY commercial_registration ORDER BY created_at DESC NULLS LAST) as rn
  FROM business_registrations
  WHERE commercial_registration IS NOT NULL AND commercial_registration != ''
)
UPDATE business_registrations
SET commercial_registration = commercial_registration || '-old' || substring(id::text, 1, 6)
WHERE id IN (SELECT id FROM duplicates WHERE rn > 1);

-- 8. إضافة unique constraints لـ business_registrations
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'business_registrations_phone_unique'
  ) THEN
    ALTER TABLE business_registrations ADD CONSTRAINT business_registrations_phone_unique UNIQUE (phone);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'business_registrations_email_unique'
  ) THEN
    ALTER TABLE business_registrations ADD CONSTRAINT business_registrations_email_unique UNIQUE (email);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'business_registrations_cr_unique'
  ) THEN
    ALTER TABLE business_registrations ADD CONSTRAINT business_registrations_cr_unique UNIQUE (commercial_registration);
  END IF;
END $$;

-- 9. إضافة indexes لـ business_registrations
CREATE INDEX IF NOT EXISTS idx_business_phone ON business_registrations (phone) WHERE phone IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_business_email ON business_registrations (lower(email)) WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_business_cr ON business_registrations (commercial_registration) WHERE commercial_registration IS NOT NULL;

-- 10. دالة التحقق من تكرار المستخدمين
CREATE OR REPLACE FUNCTION check_duplicate_user_data(
  p_phone TEXT DEFAULT NULL,
  p_national_id TEXT DEFAULT NULL,
  p_email TEXT DEFAULT NULL
)
RETURNS TABLE (
  is_duplicate BOOLEAN,
  duplicate_field TEXT,
  error_message TEXT
) AS $$
BEGIN
  IF p_phone IS NOT NULL AND p_phone != '' THEN
    IF EXISTS (SELECT 1 FROM users WHERE phone = p_phone) THEN
      RETURN QUERY SELECT TRUE, 'phone'::TEXT, 'رقم الهاتف مسجل مسبقاً'::TEXT;
      RETURN;
    END IF;
  END IF;

  IF p_national_id IS NOT NULL AND p_national_id != '' THEN
    IF EXISTS (SELECT 1 FROM users WHERE national_id = p_national_id) THEN
      RETURN QUERY SELECT TRUE, 'national_id'::TEXT, 'رقم الهوية مسجل مسبقاً'::TEXT;
      RETURN;
    END IF;
  END IF;

  IF p_email IS NOT NULL AND p_email != '' THEN
    IF EXISTS (SELECT 1 FROM auth.users WHERE lower(email) = lower(p_email)) THEN
      RETURN QUERY SELECT TRUE, 'email'::TEXT, 'البريد الإلكتروني مسجل مسبقاً'::TEXT;
      RETURN;
    END IF;
  END IF;

  RETURN QUERY SELECT FALSE, NULL::TEXT, NULL::TEXT;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 11. دالة التحقق من تكرار المنشآت
CREATE OR REPLACE FUNCTION check_duplicate_business_data(
  p_phone TEXT DEFAULT NULL,
  p_email TEXT DEFAULT NULL,
  p_commercial_registration TEXT DEFAULT NULL
)
RETURNS TABLE (
  is_duplicate BOOLEAN,
  duplicate_field TEXT,
  error_message TEXT
) AS $$
BEGIN
  IF p_phone IS NOT NULL AND p_phone != '' THEN
    IF EXISTS (SELECT 1 FROM business_registrations WHERE phone = p_phone) THEN
      RETURN QUERY SELECT TRUE, 'phone'::TEXT, 'رقم الهاتف مسجل مسبقاً'::TEXT;
      RETURN;
    END IF;
  END IF;

  IF p_email IS NOT NULL AND p_email != '' THEN
    IF EXISTS (SELECT 1 FROM business_registrations WHERE lower(email) = lower(p_email)) THEN
      RETURN QUERY SELECT TRUE, 'email'::TEXT, 'البريد الإلكتروني مسجل مسبقاً'::TEXT;
      RETURN;
    END IF;
  END IF;

  IF p_commercial_registration IS NOT NULL AND p_commercial_registration != '' THEN
    IF EXISTS (SELECT 1 FROM business_registrations WHERE commercial_registration = p_commercial_registration) THEN
      RETURN QUERY SELECT TRUE, 'commercial_registration'::TEXT, 'رقم السجل التجاري مسجل مسبقاً'::TEXT;
      RETURN;
    END IF;
  END IF;

  RETURN QUERY SELECT FALSE, NULL::TEXT, NULL::TEXT;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 12. منح الصلاحيات
GRANT EXECUTE ON FUNCTION check_duplicate_user_data TO authenticated, anon;
GRANT EXECUTE ON FUNCTION check_duplicate_business_data TO authenticated, anon;