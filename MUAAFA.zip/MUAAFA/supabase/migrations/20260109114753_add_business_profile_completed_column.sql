/*
  # إضافة عمود profile_completed لجدول business_registrations

  1. التغييرات
    - إضافة عمود profile_completed (boolean) لتتبع حالة إكمال البروفايل
    - القيمة الافتراضية false
    - الأعمال المسجلة سابقاً ستكون قيمتها true تلقائياً

  2. الفائدة
    - إجبار الأعمال الجديدة على إكمال معلومات البروفايل بعد الموافقة
    - تحسين جودة البيانات
*/

-- إضافة عمود profile_completed إذا لم يكن موجوداً
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' 
    AND column_name = 'profile_completed'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN profile_completed boolean DEFAULT false;
    
    -- تحديث الأعمال الموجودة لتكون قيمتها true
    UPDATE business_registrations 
    SET profile_completed = true 
    WHERE status = 'approved';
    
    -- إضافة تعليق على العمود
    COMMENT ON COLUMN business_registrations.profile_completed IS 'تم إكمال معلومات البروفايل';
  END IF;
END $$;

-- إضافة الأعمدة الإضافية إذا لم تكن موجودة
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' 
    AND column_name = 'description'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN description text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' 
    AND column_name = 'address'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN address text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' 
    AND column_name = 'city'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN city text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' 
    AND column_name = 'employees_count'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN employees_count integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_registrations' 
    AND column_name = 'service_areas'
  ) THEN
    ALTER TABLE business_registrations 
    ADD COLUMN service_areas text;
  END IF;
END $$;
