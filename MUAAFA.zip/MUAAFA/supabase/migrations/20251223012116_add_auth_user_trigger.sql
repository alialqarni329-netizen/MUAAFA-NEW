/*
  # إضافة Trigger تلقائي لإنشاء ملف المستخدم
  
  ## التعديلات
  
  1. **إنشاء Function**
    - دالة تلقائية تُنشئ سجل في جدول users عند إنشاء مستخدم جديد في Auth
    
  2. **إنشاء Trigger**
    - Trigger يتم تفعيله تلقائياً عند إنشاء مستخدم جديد
    
  3. **إنشاء اشتراك تجريبي**
    - يتم إنشاء اشتراك تجريبي لمدة 5 أيام تلقائياً
    
  ## السماحيات
    - ضمان عدم فقدان بيانات المستخدمين
    - تسهيل عملية التسجيل والدخول
*/

-- دالة لإنشاء ملف المستخدم تلقائياً
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- إنشاء سجل في جدول users
  INSERT INTO public.users (id, created_at, updated_at)
  VALUES (NEW.id, NOW(), NOW())
  ON CONFLICT (id) DO NOTHING;
  
  -- إنشاء اشتراك تجريبي لمدة 5 أيام
  INSERT INTO public.subscriptions (
    user_id,
    plan_type,
    status,
    start_date,
    end_date
  )
  VALUES (
    NEW.id,
    'trial',
    'active',
    NOW(),
    NOW() + INTERVAL '5 days'
  )
  ON CONFLICT (user_id) 
  WHERE status = 'active'
  DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- حذف Trigger القديم إن وُجد
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- إنشاء Trigger جديد
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- التأكد من وجود فهرس على user_id في جدول subscriptions
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id_status
ON subscriptions(user_id, status)
WHERE status = 'active';
