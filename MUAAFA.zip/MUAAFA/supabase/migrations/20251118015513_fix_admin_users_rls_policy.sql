/*
  # Fix admin_users RLS policy

  1. Changes
    - Drop existing restrictive policy
    - Create new policy that allows users to check their own admin status
    - This fixes the circular dependency issue

  2. Security
    - Users can only view their own admin status
    - Still secure and follows principle of least privilege
*/

-- Drop existing policy
DROP POLICY IF EXISTS "Admins can view admin users" ON admin_users;

-- Create new policy: users can check their own admin status
CREATE POLICY "Users can check their own admin status"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- Create policy: admins can view all admin users
CREATE POLICY "Admins can view all admin users"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE id = auth.uid()
      AND role IN ('owner', 'admin')
    )
  );
