/*
  # Fix Admin Users RLS Recursion

  1. Problem
    - The "Users can check admin status" policy causes infinite recursion
    - It queries admin_users table within the policy itself
    - This creates a loop when checking permissions

  2. Solution
    - Drop the problematic policy
    - Keep only the safe_read_admin policy that allows simple reads
    - The is_owner_or_admin function (SECURITY DEFINER) will handle permission checks safely

  3. Security
    - safe_read_admin allows public read access to admin_users
    - This is safe because the table only contains user IDs and roles
    - Actual permission checks are done through SECURITY DEFINER functions
*/

-- Drop the problematic recursive policy
DROP POLICY IF EXISTS "Users can check admin status" ON admin_users;

-- Ensure safe_read_admin policy exists (it should already exist)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_policies
    WHERE tablename = 'admin_users'
    AND policyname = 'safe_read_admin'
  ) THEN
    CREATE POLICY "safe_read_admin"
      ON admin_users
      FOR SELECT
      TO public
      USING (true);
  END IF;
END $$;
