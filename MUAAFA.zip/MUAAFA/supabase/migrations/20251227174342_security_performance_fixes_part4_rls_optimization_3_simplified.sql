/*
  # Security and Performance Fixes - Part 4: RLS Optimization (Batch 3)

  This migration continues optimizing Row Level Security (RLS) policies by replacing
  direct auth.uid() calls with (select auth.uid()) to prevent function re-evaluation
  for each row, significantly improving query performance at scale.

  ## Tables Optimized in This Batch:
  1. health_scans - 2 policies (SELECT, INSERT)
  2. fitness_ai_recommendations - 2 policies (SELECT, INSERT)
  3. fitness_coupons - 2 policies (SELECT, INSERT)
  4. fitness_nudges - 2 policies (SELECT, INSERT)
  5. health_profiles - 3 policies (SELECT, INSERT, UPDATE)
  6. user_permissions - 1 policy (SELECT)
  7. business_verification - 3 additional policies (INSERT, UPDATE, DELETE)
  8. delivery_assignments - 2 policies (SELECT, UPDATE)
  9. order_timeline - 1 policy (SELECT for users)
  10. pharmacy_order_requests - 1 policy (SELECT for users)
  11. app_notifications - 2 policies (SELECT, UPDATE)

  ## Performance Impact:
  - Reduces auth function calls from O(n) to O(1) per query
  - Improves response times for large result sets
  - Reduces database CPU usage

  ## Security:
  - Maintains identical security guarantees
  - No changes to access control logic
*/

-- ============================================================================
-- health_scans
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own health scans" ON health_scans;
CREATE POLICY "Users can view own health scans" ON health_scans
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own health scans" ON health_scans;
CREATE POLICY "Users can insert own health scans" ON health_scans
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================================================
-- fitness_ai_recommendations
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own fitness recommendations" ON fitness_ai_recommendations;
CREATE POLICY "Users can view own fitness recommendations" ON fitness_ai_recommendations
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own fitness recommendations" ON fitness_ai_recommendations;
CREATE POLICY "Users can insert own fitness recommendations" ON fitness_ai_recommendations
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================================================
-- fitness_coupons
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own fitness coupons" ON fitness_coupons;
CREATE POLICY "Users can view own fitness coupons" ON fitness_coupons
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own fitness coupons" ON fitness_coupons;
CREATE POLICY "Users can insert own fitness coupons" ON fitness_coupons
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================================================
-- fitness_nudges
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own fitness nudges" ON fitness_nudges;
CREATE POLICY "Users can view own fitness nudges" ON fitness_nudges
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own fitness nudges" ON fitness_nudges;
CREATE POLICY "Users can insert own fitness nudges" ON fitness_nudges
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================================================
-- health_profiles
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own health profile" ON health_profiles;
CREATE POLICY "Users can view own health profile" ON health_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own health profile" ON health_profiles;
CREATE POLICY "Users can insert own health profile" ON health_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own health profile" ON health_profiles;
CREATE POLICY "Users can update own health profile" ON health_profiles
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- ============================================================================
-- user_permissions
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own permissions" ON user_permissions;
CREATE POLICY "Users can view own permissions" ON user_permissions
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================================================
-- business_verification (remaining policies)
-- ============================================================================
DROP POLICY IF EXISTS "Businesses can insert own verification" ON business_verification;
CREATE POLICY "Businesses can insert own verification" ON business_verification
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Businesses can update own verification" ON business_verification;
CREATE POLICY "Businesses can update own verification" ON business_verification
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Businesses can delete own verification" ON business_verification;
CREATE POLICY "Businesses can delete own verification" ON business_verification
  FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ============================================================================
-- delivery_assignments (uses driver_user_id column)
-- ============================================================================
DROP POLICY IF EXISTS "Delivery staff can view own assignments" ON delivery_assignments;
CREATE POLICY "Delivery staff can view own assignments" ON delivery_assignments
  FOR SELECT
  TO authenticated
  USING (driver_user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Delivery staff can update own assignments" ON delivery_assignments;
CREATE POLICY "Delivery staff can update own assignments" ON delivery_assignments
  FOR UPDATE
  TO authenticated
  USING (driver_user_id = (select auth.uid()))
  WITH CHECK (driver_user_id = (select auth.uid()));

-- ============================================================================
-- order_timeline (checks via orders.user_id for user access)
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own order timeline" ON order_timeline;
CREATE POLICY "Users can view own order timeline" ON order_timeline
  FOR SELECT
  TO authenticated
  USING (
    order_id IN (
      SELECT id FROM orders
      WHERE user_id = (select auth.uid())
    )
  );

-- ============================================================================
-- pharmacy_order_requests (checks via orders.user_id for user access)
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own pharmacy orders" ON pharmacy_order_requests;
CREATE POLICY "Users can view own pharmacy orders" ON pharmacy_order_requests
  FOR SELECT
  TO authenticated
  USING (
    order_id IN (
      SELECT id FROM orders
      WHERE user_id = (select auth.uid())
    )
  );

-- ============================================================================
-- app_notifications
-- ============================================================================
DROP POLICY IF EXISTS "Users can view own notifications" ON app_notifications;
CREATE POLICY "Users can view own notifications" ON app_notifications
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own notifications" ON app_notifications;
CREATE POLICY "Users can update own notifications" ON app_notifications
  FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));
