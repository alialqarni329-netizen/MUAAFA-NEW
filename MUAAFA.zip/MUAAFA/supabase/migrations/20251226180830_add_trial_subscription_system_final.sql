/*
  # نظام الاشتراكات والتجربة المجانية - 10 أيام

  ## نظرة عامة
  عند تسجيل المستخدم الجديد:
  - يحصل تلقائياً على الباقة الأساسية لمدة 10 أيام
  - بعد انتهاء التجربة، يتم قفل جميع الميزات ما عدا السجلات الصحية
  - بعد الاشتراك والدفع، تفتح ميزات الباقة المختارة فوراً
  - نظام تنبيهات قبل انتهاء الاشتراك بـ 3 أيام

  ## التغييرات
  1. أعمدة جديدة في جدول users للتجربة المجانية
  2. أعمدة جديدة في جدول subscriptions للتتبع
  3. دوال للتحقق من حالة الاشتراك والوصول للميزات
  4. trigger تلقائي لمنح التجربة المجانية عند التسجيل
  5. دالة للتحقق من الاشتراكات المنتهية وإرسال التنبيهات
*/

-- تحديث جدول users
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS trial_started_at timestamptz DEFAULT now(),
ADD COLUMN IF NOT EXISTS trial_ends_at timestamptz DEFAULT (now() + interval '10 days'),
ADD COLUMN IF NOT EXISTS has_active_subscription boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS current_plan_type text DEFAULT 'trial';

-- تحديث جدول subscriptions
ALTER TABLE subscriptions
ADD COLUMN IF NOT EXISTS is_trial boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS auto_renew boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS notification_sent boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS last_notification_at timestamptz;

-- دالة للتحقق من حالة الاشتراك
CREATE OR REPLACE FUNCTION check_subscription_status(user_id_param uuid)
RETURNS TABLE (
  is_active boolean,
  plan_type text,
  expires_at timestamptz,
  is_trial boolean,
  days_remaining integer
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  user_trial_ends timestamptz;
  user_has_subscription boolean;
  active_sub record;
BEGIN
  -- جلب معلومات المستخدم
  SELECT trial_ends_at, has_active_subscription
  INTO user_trial_ends, user_has_subscription
  FROM users
  WHERE id = user_id_param;

  -- البحث عن اشتراك نشط مدفوع
  SELECT * INTO active_sub
  FROM subscriptions
  WHERE subscriptions.user_id = user_id_param
    AND subscriptions.status = 'active'
    AND subscriptions.is_trial = false
    AND subscriptions.end_date > now()
  ORDER BY subscriptions.end_date DESC
  LIMIT 1;

  -- إذا كان لديه اشتراك مدفوع نشط
  IF active_sub.id IS NOT NULL THEN
    RETURN QUERY SELECT 
      true,
      active_sub.plan_type,
      active_sub.end_date,
      false,
      EXTRACT(DAY FROM (active_sub.end_date - now()))::integer;
    RETURN;
  END IF;

  -- إذا كان في فترة التجربة المجانية
  IF user_trial_ends > now() THEN
    RETURN QUERY SELECT 
      true,
      'basic'::text,
      user_trial_ends,
      true,
      EXTRACT(DAY FROM (user_trial_ends - now()))::integer;
    RETURN;
  END IF;

  -- انتهت التجربة ولا يوجد اشتراك
  RETURN QUERY SELECT 
    false,
    'none'::text,
    null::timestamptz,
    false,
    0;
END;
$$;

-- دالة منح الباقة التجريبية عند التسجيل
CREATE OR REPLACE FUNCTION grant_trial_subscription()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- تحديث معلومات التجربة المجانية
  NEW.trial_started_at := now();
  NEW.trial_ends_at := now() + interval '10 days';
  NEW.has_active_subscription := true;
  NEW.current_plan_type := 'basic';

  RETURN NEW;
END;
$$;

-- دالة لإنشاء سجل الاشتراك التجريبي
CREATE OR REPLACE FUNCTION create_trial_subscription_record()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- إنشاء سجل اشتراك تجريبي
  INSERT INTO subscriptions (
    user_id,
    plan_type,
    status,
    start_date,
    end_date,
    is_trial,
    auto_renew
  ) VALUES (
    NEW.id,
    'basic',
    'active',
    now(),
    now() + interval '10 days',
    true,
    false
  );

  RETURN NEW;
END;
$$;

-- Trigger لتحديث بيانات التجربة المجانية
DROP TRIGGER IF EXISTS set_trial_on_signup ON users;
CREATE TRIGGER set_trial_on_signup
  BEFORE INSERT ON users
  FOR EACH ROW
  EXECUTE FUNCTION grant_trial_subscription();

-- Trigger لإنشاء سجل الاشتراك
DROP TRIGGER IF EXISTS create_trial_record_on_signup ON users;
CREATE TRIGGER create_trial_record_on_signup
  AFTER INSERT ON users
  FOR EACH ROW
  EXECUTE FUNCTION create_trial_subscription_record();

-- دالة للتحقق من الوصول للميزات
CREATE OR REPLACE FUNCTION check_feature_access(
  user_id_param uuid,
  feature_name text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  subscription_info record;
BEGIN
  -- جلب حالة الاشتراك
  SELECT * INTO subscription_info
  FROM check_subscription_status(user_id_param);

  -- الميزات المتاحة دائماً (حتى بدون اشتراك)
  IF feature_name IN ('health_records', 'reports', 'profile', 'settings') THEN
    RETURN true;
  END IF;

  -- إذا كان الاشتراك نشط (تجريبي أو مدفوع)
  IF subscription_info.is_active THEN
    -- الباقة الأساسية (تجريبية أو مدفوعة)
    IF subscription_info.plan_type = 'basic' THEN
      RETURN feature_name IN (
        'health_records',
        'reports', 
        'profile',
        'settings',
        'pharmacy_browse',
        'medication_reminders',
        'health_chatbot',
        'fitness_tracking',
        'prescription_scan',
        'barcode_scan',
        'nearby_pharmacies'
      );
    END IF;

    -- الباقة الشاملة
    IF subscription_info.plan_type = 'comprehensive' THEN
      RETURN feature_name IN (
        'health_records',
        'reports',
        'profile',
        'settings',
        'pharmacy_browse',
        'pharmacy_purchase',
        'medication_reminders',
        'health_chatbot',
        'fitness_tracking',
        'telehealth',
        'virtual_sessions',
        'prescription_scan',
        'barcode_scan',
        'nearby_pharmacies',
        'priority_support'
      );
    END IF;

    -- الباقة المميزة - جميع الميزات
    IF subscription_info.plan_type = 'premium' THEN
      RETURN true;
    END IF;
  END IF;

  RETURN false;
END;
$$;

-- دالة للتحقق من الاشتراكات المنتهية وإرسال التنبيهات
CREATE OR REPLACE FUNCTION check_expiring_subscriptions()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  sub_record record;
  plan_name_ar text;
BEGIN
  -- البحث عن الاشتراكات التي ستنتهي خلال 3 أيام ولم يتم إرسال تنبيه لها
  FOR sub_record IN 
    SELECT s.*
    FROM subscriptions s
    WHERE s.status = 'active'
      AND s.end_date BETWEEN now() AND (now() + interval '3 days')
      AND (s.notification_sent = false OR s.notification_sent IS NULL)
  LOOP
    -- تحديد اسم الباقة بالعربي
    plan_name_ar := CASE sub_record.plan_type
      WHEN 'basic' THEN 'الباقة الأساسية'
      WHEN 'comprehensive' THEN 'الباقة الشاملة'
      WHEN 'premium' THEN 'الباقة المميزة'
      ELSE sub_record.plan_type
    END;

    -- إنشاء تنبيه للمستخدم
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data,
      priority
    ) VALUES (
      sub_record.user_id,
      'subscription_expiring',
      'اشتراكك على وشك الانتهاء',
      format('اشتراكك في %s سينتهي في %s. جدد اشتراكك الآن لتستمر في الاستفادة من جميع الميزات.', 
        plan_name_ar,
        to_char(sub_record.end_date, 'YYYY-MM-DD')
      ),
      jsonb_build_object(
        'subscription_id', sub_record.id,
        'plan_type', sub_record.plan_type,
        'expires_at', sub_record.end_date,
        'action', 'renew_subscription'
      ),
      'high'
    );

    -- تحديث حالة الإشعار
    UPDATE subscriptions
    SET 
      notification_sent = true,
      last_notification_at = now()
    WHERE id = sub_record.id;
  END LOOP;
END;
$$;

-- عرض للاشتراكات النشطة
CREATE OR REPLACE VIEW active_subscriptions AS
SELECT 
  s.id,
  s.user_id,
  s.plan_type,
  s.status,
  s.start_date,
  s.end_date,
  s.is_trial,
  s.auto_renew,
  u.full_name,
  u.phone,
  EXTRACT(DAY FROM (s.end_date - now()))::integer as days_remaining,
  CASE 
    WHEN s.end_date <= now() THEN 'expired'
    WHEN s.end_date <= (now() + interval '3 days') THEN 'expiring_soon'
    ELSE 'active'
  END as alert_status
FROM subscriptions s
JOIN users u ON s.user_id = u.id
WHERE s.status = 'active';

-- منح الصلاحيات
GRANT EXECUTE ON FUNCTION check_subscription_status(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION check_feature_access(uuid, text) TO authenticated;
GRANT SELECT ON active_subscriptions TO authenticated;

-- فهرسة للأداء
CREATE INDEX IF NOT EXISTS idx_users_trial_ends ON users(trial_ends_at) WHERE trial_ends_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_subscriptions_expiry ON subscriptions(end_date, status) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_active ON subscriptions(user_id, status) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_subscriptions_notification ON subscriptions(notification_sent, end_date) WHERE status = 'active';

-- تعليق
COMMENT ON FUNCTION check_subscription_status IS 'فحص حالة اشتراك المستخدم وإرجاع التفاصيل';
COMMENT ON FUNCTION check_feature_access IS 'التحقق من إمكانية الوصول لميزة معينة بناءً على حالة الاشتراك';
COMMENT ON FUNCTION check_expiring_subscriptions IS 'فحص الاشتراكات المنتهية وإرسال التنبيهات';
