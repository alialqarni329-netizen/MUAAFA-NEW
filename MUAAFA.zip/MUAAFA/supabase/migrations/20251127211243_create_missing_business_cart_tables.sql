/*
  # إنشاء الجداول الناقصة لبوابة الأعمال والسلة
*/

-- 1. تسجيل المنشآت
CREATE TABLE IF NOT EXISTS business_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  business_name text NOT NULL,
  commercial_registration text NOT NULL UNIQUE,
  registration_expiry date NOT NULL,
  owner_national_id text NOT NULL,
  phone text NOT NULL,
  email text NOT NULL,
  password_hash text,
  verification_code text,
  phone_verified boolean DEFAULT false,
  email_verified boolean DEFAULT false,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE business_registrations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their registrations"
  ON business_registrations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create registrations"
  ON business_registrations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- 2. موظفي المنشآت
CREATE TABLE IF NOT EXISTS business_employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid REFERENCES business_registrations(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role text NOT NULL CHECK (role IN ('owner', 'manager', 'employee')),
  permissions jsonb DEFAULT '[]'::jsonb,
  status text DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE business_employees ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Employees can view their data"
  ON business_employees FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- 3. السلة
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  quantity integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their cart"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can add to cart"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update cart"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete from cart"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 4. سجل النشاط
CREATE TABLE IF NOT EXISTS activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  activity_type text NOT NULL CHECK (activity_type IN ('treatment', 'session', 'pharmacy_order', 'test', 'payment', 'report', 'workout', 'other')),
  title text NOT NULL,
  description text,
  metadata jsonb DEFAULT '{}'::jsonb,
  amount numeric,
  created_at timestamptz DEFAULT now(),
  deleted_by_user boolean DEFAULT false
);

ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their logs"
  ON activity_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id AND deleted_by_user = false);

CREATE POLICY "Users can soft delete logs"
  ON activity_logs FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 5. تقارير المستشفيات
CREATE TABLE IF NOT EXISTS hospital_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  hospital_name text NOT NULL,
  report_type text NOT NULL CHECK (report_type IN ('xray', 'lab_test', 'medical_report', 'prescription')),
  report_date date NOT NULL,
  report_data jsonb NOT NULL,
  file_urls text[],
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hospital_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view hospital reports"
  ON hospital_reports FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- 6. جداول التمارين
CREATE TABLE IF NOT EXISTS fitness_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  day_of_week integer NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  workout_time time NOT NULL,
  workout_type text NOT NULL,
  duration_minutes integer NOT NULL,
  reminder_enabled boolean DEFAULT true,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fitness_schedules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage schedules"
  ON fitness_schedules FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 7. خطط التغذية
CREATE TABLE IF NOT EXISTS nutrition_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  current_weight numeric NOT NULL,
  target_weight numeric,
  goal text NOT NULL CHECK (goal IN ('lose_weight', 'gain_weight', 'maintain', 'build_muscle')),
  daily_calories integer NOT NULL,
  meal_plan jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE nutrition_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage nutrition plans"
  ON nutrition_plans FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Functions
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TEXT AS $$
BEGIN
  RETURN 'ORD-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
END;
$$ LANGUAGE plpgsql;
