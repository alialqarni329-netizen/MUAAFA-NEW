/*
  # إصلاح جذري لتدفق التسجيل والاستبيان الطبي v2

  ## المشكلة
  - الاستبيان الطبي يُحفظ قبل إنشاء المستخدم
  - Foreign Key غير صحيح
  - RLS Policies قد تسبب infinite recursion

  ## الحل
  1. إصلاح جدول medical_questionnaire مع FK صحيح
  2. RLS policies بسيطة بدون loops
  3. Trigger آمن لإنشاء المستخدم
*/

-- 1️⃣ إصلاح جدول medical_questionnaire
DROP TABLE IF EXISTS medical_questionnaire CASCADE;

CREATE TABLE medical_questionnaire (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  age INT,
  gender TEXT,
  height DECIMAL,
  weight DECIMAL,
  chronic_diseases TEXT[],
  current_medications TEXT[],
  allergies TEXT[],
  previous_surgeries TEXT[],
  family_history TEXT[],
  lifestyle_smoking BOOLEAN DEFAULT FALSE,
  lifestyle_alcohol BOOLEAN DEFAULT FALSE,
  lifestyle_exercise TEXT,
  emergency_contact_name TEXT,
  emergency_contact_phone TEXT,
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  CONSTRAINT medical_questionnaire_user_id_fkey
    FOREIGN KEY (user_id)
    REFERENCES users(id)
    ON DELETE CASCADE
);

CREATE INDEX idx_medical_questionnaire_user_id ON medical_questionnaire(user_id);

-- 2️⃣ تفعيل RLS
ALTER TABLE medical_questionnaire ENABLE ROW LEVEL SECURITY;

-- 3️⃣ حذف policies القديمة للـ medical_questionnaire
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view own questionnaire" ON medical_questionnaire;
  DROP POLICY IF EXISTS "Users can insert own questionnaire" ON medical_questionnaire;
  DROP POLICY IF EXISTS "Users can update own questionnaire" ON medical_questionnaire;
  DROP POLICY IF EXISTS "User manages own questionnaire" ON medical_questionnaire;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- 4️⃣ إنشاء policies جديدة للـ medical_questionnaire
CREATE POLICY "Users can view own questionnaire"
  ON medical_questionnaire FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own questionnaire"
  ON medical_questionnaire FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own questionnaire"
  ON medical_questionnaire FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 5️⃣ إزالة أي triggers قديمة
DROP TRIGGER IF EXISTS handle_new_user ON auth.users;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS create_user_on_signup ON auth.users;

DROP FUNCTION IF EXISTS handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS create_user_on_signup() CASCADE;

-- 6️⃣ إنشاء trigger بسيط وآمن
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.users (id, email, phone_number, full_name, role, status)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.phone,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'role', 'individual'),
    'active'
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    phone_number = EXCLUDED.phone_number,
    updated_at = NOW();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 7️⃣ ربط الـ trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW 
  EXECUTE FUNCTION public.handle_new_user();

-- 8️⃣ Grant permissions
GRANT ALL ON medical_questionnaire TO authenticated;
