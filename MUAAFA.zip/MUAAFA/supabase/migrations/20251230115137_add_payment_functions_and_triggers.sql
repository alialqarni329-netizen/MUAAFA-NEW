/*
  # دوال ومحفزات نظام الدفع
  
  1. الدوال
    - calculate_user_payable: حساب المبلغ بعد التأمين
    - generate_invoice_number: توليد رقم فاتورة
  
  2. المحفزات
    - تحديث حالة الجلسة بعد الدفع
    - تحديث حالة الطلب بعد الدفع
*/

-- 1️⃣ دالة لحساب المبلغ المستحق بعد التأمين
CREATE OR REPLACE FUNCTION calculate_user_payable(
  total_price NUMERIC,
  insurance_policy_id UUID
)
RETURNS TABLE (
  insurance_covered NUMERIC,
  user_payable NUMERIC
) AS $$
DECLARE
  coverage_percentage NUMERIC;
  covered_amount NUMERIC;
BEGIN
  IF insurance_policy_id IS NULL THEN
    RETURN QUERY SELECT 0::NUMERIC, total_price;
  ELSE
    SELECT ip.coverage_percentage INTO coverage_percentage
    FROM insurance_policies ip
    WHERE ip.id = insurance_policy_id
      AND ip.status = 'active'
      AND CURRENT_DATE BETWEEN ip.start_date AND ip.end_date;
    
    IF coverage_percentage IS NULL THEN
      RETURN QUERY SELECT 0::NUMERIC, total_price;
    ELSE
      covered_amount := total_price * (coverage_percentage / 100);
      RETURN QUERY SELECT covered_amount, (total_price - covered_amount);
    END IF;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2️⃣ دالة لتوليد رقم فاتورة فريد
CREATE OR REPLACE FUNCTION generate_invoice_number()
RETURNS TEXT AS $$
DECLARE
  new_number TEXT;
  prefix TEXT := 'INV';
  date_part TEXT := TO_CHAR(NOW(), 'YYYYMMDD');
  random_part TEXT;
BEGIN
  random_part := LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
  new_number := prefix || '-' || date_part || '-' || random_part;
  
  WHILE EXISTS (SELECT 1 FROM invoices WHERE invoice_number = new_number) LOOP
    random_part := LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
    new_number := prefix || '-' || date_part || '-' || random_part;
  END LOOP;
  
  RETURN new_number;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3️⃣ دالة لتحديث حالة الجلسة بعد الدفع
CREATE OR REPLACE FUNCTION update_session_after_payment()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.payment_status = 'paid' AND (OLD.payment_status IS NULL OR OLD.payment_status != 'paid') THEN
    NEW.session_status := 'confirmed';
    NEW.paid_at := NOW();
    NEW.confirmed_at := NOW();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS medical_session_payment_trigger ON medical_sessions;
CREATE TRIGGER medical_session_payment_trigger
  BEFORE UPDATE ON medical_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_session_after_payment();

-- 4️⃣ دالة لتحديث حالة الطلب بعد الدفع
CREATE OR REPLACE FUNCTION update_order_after_payment()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.payment_status = 'paid' AND (OLD.payment_status IS NULL OR OLD.payment_status != 'paid') THEN
    NEW.order_status := 'confirmed';
    NEW.paid_at := NOW();
    NEW.confirmed_at := NOW();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS pharmacy_order_payment_trigger ON pharmacy_orders;
CREATE TRIGGER pharmacy_order_payment_trigger
  BEFORE UPDATE ON pharmacy_orders
  FOR EACH ROW
  EXECUTE FUNCTION update_order_after_payment();