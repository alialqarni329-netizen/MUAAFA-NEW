/*
  # Business Portal Enhancements
  
  1. New Fields in business_verification
    - tax_number: الرقم الضريبي
    - authorized_person_name: اسم المفوض
    - authorized_person_phone: جوال المفوض
    - commercial_registration_image: صورة السجل التجاري
    - geographic_address: العنوان الجغرافي التفصيلي
    
  2. New Tables
    - insurance_approvals: نظام الموافقات التأمينية
    - transactions: المعاملات المالية والعمولات
    - delivery_proof: إثبات التسليم
    - provider_offers: عروض الأسعار من الصيدليات
    
  3. Security
    - Enable RLS on all tables
    - Proper policies for each user type
*/

-- Add new fields to business_verification
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'business_verification' AND column_name = 'tax_number'
  ) THEN
    ALTER TABLE business_verification 
    ADD COLUMN tax_number text,
    ADD COLUMN authorized_person_name text,
    ADD COLUMN authorized_person_phone text,
    ADD COLUMN commercial_registration_image text,
    ADD COLUMN geographic_address text;
  END IF;
END $$;

-- Insurance Approvals Table (الميزة الكبرى!)
CREATE TABLE IF NOT EXISTS insurance_approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) NOT NULL,
  insurance_company_id uuid REFERENCES business_verification(id) NOT NULL,
  provider_id uuid REFERENCES business_verification(id) NOT NULL,
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  request_type text CHECK (request_type IN ('medication', 'procedure', 'consultation', 'hospitalization')) NOT NULL,
  total_amount numeric(10,2) NOT NULL,
  coverage_percentage numeric(5,2) DEFAULT 0,
  covered_amount numeric(10,2) DEFAULT 0,
  patient_amount numeric(10,2) DEFAULT 0,
  prescription_images text[] DEFAULT '{}',
  medical_reports text[] DEFAULT '{}',
  diagnosis_code text,
  diagnosis_description text,
  treatment_plan text,
  status text CHECK (status IN ('pending', 'approved', 'rejected', 'more_info_needed')) DEFAULT 'pending',
  rejection_reason text,
  additional_info_request text,
  approved_by uuid REFERENCES auth.users(id),
  approved_at timestamptz,
  reviewed_at timestamptz,
  expires_at timestamptz,
  notes text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE insurance_approvals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own insurance approvals"
  ON insurance_approvals FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id
    OR insurance_company_id IN (
      SELECT id FROM business_verification WHERE user_id = auth.uid()
    )
    OR provider_id IN (
      SELECT id FROM business_verification WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Providers can create insurance approvals"
  ON insurance_approvals FOR INSERT
  TO authenticated
  WITH CHECK (
    provider_id IN (
      SELECT id FROM business_verification 
      WHERE user_id = auth.uid() 
      AND business_type IN ('pharmacy', 'hospital')
      AND verification_status = 'active'
    )
  );

CREATE POLICY "Insurance companies can update approvals"
  ON insurance_approvals FOR UPDATE
  TO authenticated
  USING (
    insurance_company_id IN (
      SELECT id FROM business_verification
      WHERE user_id = auth.uid()
      AND business_type = 'insurance'
      AND verification_status = 'active'
    )
  );

-- Provider Offers Table (عروض الأسعار)
CREATE TABLE IF NOT EXISTS provider_offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) NOT NULL,
  provider_id uuid REFERENCES business_verification(id) NOT NULL,
  item_name text NOT NULL,
  quantity integer NOT NULL,
  unit_price numeric(10,2) NOT NULL,
  total_price numeric(10,2) NOT NULL,
  requires_insurance_approval boolean DEFAULT false,
  insurance_approval_id uuid REFERENCES insurance_approvals(id),
  available_at timestamptz,
  expires_at timestamptz,
  notes text,
  status text CHECK (status IN ('pending', 'accepted', 'rejected', 'expired')) DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE provider_offers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own provider offers"
  ON provider_offers FOR SELECT
  TO authenticated
  USING (
    order_id IN (SELECT id FROM orders WHERE user_id = auth.uid())
    OR provider_id IN (
      SELECT id FROM business_verification WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Providers can manage own offers"
  ON provider_offers FOR ALL
  TO authenticated
  USING (
    provider_id IN (
      SELECT id FROM business_verification
      WHERE user_id = auth.uid()
      AND business_type IN ('pharmacy', 'hospital')
      AND verification_status = 'active'
    )
  );

-- Transactions Table (المعاملات المالية)
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  business_id uuid REFERENCES business_verification(id),
  transaction_type text CHECK (transaction_type IN (
    'payment', 'refund', 'commission', 'insurance_coverage', 'provider_payout', 'delivery_fee'
  )) NOT NULL,
  amount numeric(10,2) NOT NULL,
  currency text DEFAULT 'SAR',
  status text CHECK (status IN ('pending', 'completed', 'failed', 'cancelled')) DEFAULT 'pending',
  payment_method text CHECK (payment_method IN ('card', 'wallet', 'insurance', 'cash')) DEFAULT 'card',
  payment_gateway text,
  payment_reference text,
  description text,
  commission_rate numeric(5,2),
  commission_amount numeric(10,2),
  metadata jsonb DEFAULT '{}',
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own transactions"
  ON transactions FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id
    OR business_id IN (
      SELECT id FROM business_verification WHERE user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM admin_users WHERE id = auth.uid()
    )
  );

CREATE POLICY "System can create transactions"
  ON transactions FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Delivery Proof Table (إثبات التسليم)
CREATE TABLE IF NOT EXISTS delivery_proof (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_assignment_id uuid REFERENCES delivery_assignments(id) UNIQUE NOT NULL,
  order_id uuid REFERENCES orders(id) NOT NULL,
  proof_type text CHECK (proof_type IN ('photo', 'code', 'signature')) NOT NULL,
  proof_image text,
  verification_code text,
  signature_data text,
  customer_name text,
  customer_notes text,
  location_latitude numeric(10, 6),
  location_longitude numeric(10, 6),
  verified_at timestamptz DEFAULT now(),
  verified_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE delivery_proof ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own delivery proof"
  ON delivery_proof FOR SELECT
  TO authenticated
  USING (
    order_id IN (SELECT id FROM orders WHERE user_id = auth.uid())
    OR delivery_assignment_id IN (
      SELECT id FROM delivery_assignments 
      WHERE driver_user_id = auth.uid()
      OR delivery_company_id IN (
        SELECT id FROM business_verification WHERE user_id = auth.uid()
      )
    )
  );

CREATE POLICY "Drivers can create delivery proof"
  ON delivery_proof FOR INSERT
  TO authenticated
  WITH CHECK (
    delivery_assignment_id IN (
      SELECT id FROM delivery_assignments WHERE driver_user_id = auth.uid()
    )
  );

-- Appointment Slots for Hospitals (مواعيد المستشفيات)
CREATE TABLE IF NOT EXISTS appointment_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hospital_id uuid REFERENCES business_verification(id) NOT NULL,
  doctor_name text NOT NULL,
  specialty text NOT NULL,
  slot_date date NOT NULL,
  slot_time time NOT NULL,
  duration_minutes integer DEFAULT 30,
  is_available boolean DEFAULT true,
  is_virtual boolean DEFAULT false,
  meeting_link text,
  meeting_platform text CHECK (meeting_platform IN ('zoom', 'teams', 'google_meet')),
  price numeric(10,2),
  user_id uuid REFERENCES auth.users(id),
  booked_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE appointment_slots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view available slots"
  ON appointment_slots FOR SELECT
  TO authenticated
  USING (
    is_available = true
    OR user_id = auth.uid()
    OR hospital_id IN (
      SELECT id FROM business_verification WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Hospitals can manage own slots"
  ON appointment_slots FOR ALL
  TO authenticated
  USING (
    hospital_id IN (
      SELECT id FROM business_verification
      WHERE user_id = auth.uid()
      AND business_type = 'hospital'
      AND verification_status = 'active'
    )
  );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_insurance_approvals_status ON insurance_approvals(status, insurance_company_id);
CREATE INDEX IF NOT EXISTS idx_insurance_approvals_provider ON insurance_approvals(provider_id, status);
CREATE INDEX IF NOT EXISTS idx_insurance_approvals_user ON insurance_approvals(user_id, status);
CREATE INDEX IF NOT EXISTS idx_provider_offers_order ON provider_offers(order_id, status);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_business ON transactions(business_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_delivery_proof_assignment ON delivery_proof(delivery_assignment_id);
CREATE INDEX IF NOT EXISTS idx_appointment_slots_hospital_date ON appointment_slots(hospital_id, slot_date, is_available);

-- Function to update insurance approval and notify
CREATE OR REPLACE FUNCTION handle_insurance_approval_update()
RETURNS TRIGGER AS $$
BEGIN
  -- Update order status based on insurance decision
  IF NEW.status = 'approved' THEN
    UPDATE orders 
    SET insurance_approved = true,
        insurance_covered_amount = NEW.covered_amount,
        patient_amount = NEW.patient_amount
    WHERE id = NEW.order_id;
    
    -- Notify user
    INSERT INTO app_notifications (user_id, type, title, body, data)
    VALUES (
      NEW.user_id,
      'insurance_approved',
      'تمت الموافقة على التأمين',
      'تمت الموافقة على طلب التأمين الخاص بك. يمكنك المتابعة للدفع.',
      jsonb_build_object('order_id', NEW.order_id, 'approval_id', NEW.id)
    );
    
    -- Notify provider
    INSERT INTO app_notifications (
      user_id, type, title, body, data
    )
    SELECT 
      bv.user_id,
      'insurance_approved',
      'موافقة تأمينية جديدة',
      'تمت الموافقة على طلب التأمين. يمكنك المتابعة.',
      jsonb_build_object('order_id', NEW.order_id, 'approval_id', NEW.id)
    FROM business_verification bv
    WHERE bv.id = NEW.provider_id;
    
  ELSIF NEW.status = 'rejected' THEN
    -- Notify user of rejection
    INSERT INTO app_notifications (user_id, type, title, body, data)
    VALUES (
      NEW.user_id,
      'insurance_rejected',
      'تم رفض طلب التأمين',
      'تم رفض طلب التأمين: ' || COALESCE(NEW.rejection_reason, 'غير محدد'),
      jsonb_build_object('order_id', NEW.order_id, 'approval_id', NEW.id)
    );
    
  ELSIF NEW.status = 'more_info_needed' THEN
    -- Notify provider to provide more info
    INSERT INTO app_notifications (
      user_id, type, title, body, data
    )
    SELECT 
      bv.user_id,
      'insurance_more_info',
      'مطلوب معلومات إضافية',
      NEW.additional_info_request,
      jsonb_build_object('order_id', NEW.order_id, 'approval_id', NEW.id)
    FROM business_verification bv
    WHERE bv.id = NEW.provider_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for insurance approval updates
DROP TRIGGER IF EXISTS trigger_insurance_approval_update ON insurance_approvals;
CREATE TRIGGER trigger_insurance_approval_update
  AFTER UPDATE OF status ON insurance_approvals
  FOR EACH ROW
  WHEN (OLD.status IS DISTINCT FROM NEW.status)
  EXECUTE FUNCTION handle_insurance_approval_update();

-- Add insurance fields to orders table if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'insurance_approved'
  ) THEN
    ALTER TABLE orders 
    ADD COLUMN insurance_approved boolean DEFAULT false,
    ADD COLUMN insurance_company_id uuid REFERENCES business_verification(id),
    ADD COLUMN insurance_covered_amount numeric(10,2) DEFAULT 0,
    ADD COLUMN patient_amount numeric(10,2);
  END IF;
END $$;