/*
  # Medical Recommendations History & Enhanced Drug Interactions System

  ## New Tables
  
  ### `medical_recommendations_history`
  - Stores all medical recommendations from the Smart Doctor AI
  - Tracks user questions, AI responses, severity levels, and drug interactions
  - Enables complete medical history tracking
  
  **Columns:**
  - `id` (uuid, primary key)
  - `user_id` (uuid, foreign key to users)
  - `user_question` (text) - Original user question
  - `ai_response` (text) - Full AI response
  - `severity_level` (text) - mild, moderate, severe, emergency, none
  - `suggested_action` (text) - Recommended next steps
  - `medications_mentioned` (jsonb) - List of medications with cart integration
  - `drug_interactions` (jsonb) - Detected dangerous interactions
  - `critical_warning` (text) - Critical safety warnings
  - `app_features_mentioned` (text[]) - Features referenced in conversation
  - `created_at` (timestamptz)
  - `viewed_at` (timestamptz) - When user viewed this recommendation
  
  ## Enhanced Functions
  
  ### `check_drug_interactions_enhanced`
  - Ultra-strict drug interaction checker
  - Includes critical interactions (Aspirin + Warfarin, etc.)
  - Returns severity levels: low, medium, high, severe, critical
  
  ## Security
  - RLS enabled on all tables
  - Users can only access their own recommendations
*/

-- Create medical_recommendations_history table
CREATE TABLE IF NOT EXISTS medical_recommendations_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  user_question text NOT NULL,
  ai_response text NOT NULL,
  severity_level text CHECK (severity_level IN ('mild', 'moderate', 'severe', 'emergency', 'none')) DEFAULT 'none',
  suggested_action text,
  medications_mentioned jsonb DEFAULT '[]'::jsonb,
  drug_interactions jsonb DEFAULT '[]'::jsonb,
  critical_warning text,
  app_features_mentioned text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  viewed_at timestamptz,
  CONSTRAINT valid_severity CHECK (severity_level IN ('mild', 'moderate', 'severe', 'emergency', 'none'))
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_med_recommendations_user ON medical_recommendations_history(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_med_recommendations_severity ON medical_recommendations_history(severity_level) WHERE severity_level IN ('severe', 'emergency');
CREATE INDEX IF NOT EXISTS idx_med_recommendations_critical ON medical_recommendations_history(user_id) WHERE critical_warning IS NOT NULL;

-- Enable RLS
ALTER TABLE medical_recommendations_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for medical_recommendations_history
CREATE POLICY "Users can view own medical recommendations"
  ON medical_recommendations_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own medical recommendations"
  ON medical_recommendations_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own recommendation viewed status"
  ON medical_recommendations_history FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Service role can access all (for Edge Functions)
CREATE POLICY "Service role has full access to recommendations"
  ON medical_recommendations_history FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Enhanced drug interaction checker function
CREATE OR REPLACE FUNCTION check_drug_interactions_enhanced(medicine_names text[])
RETURNS TABLE (
  medicine_pair text,
  severity text,
  description text,
  recommendation text,
  interaction_type text
) AS $$
DECLARE
  med1 text;
  med2 text;
  med1_lower text;
  med2_lower text;
BEGIN
  -- Loop through all medicine pairs
  FOR i IN 1..array_length(medicine_names, 1) LOOP
    FOR j IN (i+1)..array_length(medicine_names, 1) LOOP
      med1 := medicine_names[i];
      med2 := medicine_names[j];
      med1_lower := lower(med1);
      med2_lower := lower(med2);

      -- CRITICAL INTERACTION: Aspirin + Warfarin
      IF (med1_lower LIKE '%aspirin%' OR med1_lower LIKE '%أسبرين%') AND 
         (med2_lower LIKE '%warfarin%' OR med2_lower LIKE '%وارفارين%' OR med2_lower LIKE '%coumadin%') THEN
        medicine_pair := med1 || ' + ' || med2;
        severity := 'critical';
        description := 'تحذير طبي خطير 🚨: تفاعل دوائي خطير قد يسبب نزيفاً حاداً، استشر الطبيب فوراً! CRITICAL: Severe bleeding risk.';
        recommendation := 'اتصل بطبيبك فوراً. قد تحتاج لتعديل الجرعات أو وقف أحد الدوائين. مراقبة INR ضرورية.';
        interaction_type := 'bleeding_risk_critical';
        RETURN NEXT;
      
      -- CRITICAL: Aspirin + Clopidogrel
      ELSIF (med1_lower LIKE '%aspirin%' OR med1_lower LIKE '%أسبرين%') AND 
            (med2_lower LIKE '%clopidogrel%' OR med2_lower LIKE '%كلوبيدوجريل%' OR med2_lower LIKE '%plavix%') THEN
        medicine_pair := med1 || ' + ' || med2;
        severity := 'critical';
        description := 'تحذير خطير ⚠️: خطر نزيف كبير عند استخدامهما معاً. Severe bleeding risk with dual antiplatelet therapy.';
        recommendation := 'استشر طبيبك. يُستخدم هذا المزيج فقط تحت إشراف طبي دقيق لحالات خاصة.';
        interaction_type := 'bleeding_risk_dual_antiplatelet';
        RETURN NEXT;

      -- SEVERE: NSAIDs + Warfarin
      ELSIF (med1_lower LIKE '%ibuprofen%' OR med1_lower LIKE '%brufen%' OR med1_lower LIKE '%بروفين%' OR 
             med1_lower LIKE '%diclofenac%' OR med1_lower LIKE '%voltaren%' OR med1_lower LIKE '%فولتارين%') AND
            (med2_lower LIKE '%warfarin%' OR med2_lower LIKE '%وارفارين%') THEN
        medicine_pair := med1 || ' + ' || med2;
        severity := 'severe';
        description := 'تحذير شديد: زيادة كبيرة في خطر النزيف. Increased bleeding risk with NSAIDs + anticoagulants.';
        recommendation := 'تجنب المسكنات المضادة للالتهاب. استخدم بنادول (Paracetamol) بدلاً منها.';
        interaction_type := 'nsaid_anticoagulant';
        RETURN NEXT;

      -- CRITICAL: Metformin + Contrast Dye
      ELSIF (med1_lower LIKE '%metformin%' OR med1_lower LIKE '%ميتفورمين%' OR med1_lower LIKE '%glucophage%') AND
            (med2_lower LIKE '%contrast%' OR med2_lower LIKE '%صبغة%' OR med2_lower LIKE '%dye%') THEN
        medicine_pair := med1 || ' + ' || med2;
        severity := 'critical';
        description := 'تحذير حرج 🚨: خطر الحماض اللبني (Lactic Acidosis). أوقف الميتفورمين قبل الصبغة!';
        recommendation := 'أوقف الميتفورمين 48 ساعة قبل وبعد الصبغة. استشر طبيبك فوراً.';
        interaction_type := 'metformin_contrast';
        RETURN NEXT;

      -- SEVERE: ACE Inhibitors + NSAIDs
      ELSIF (med1_lower LIKE '%enalapril%' OR med1_lower LIKE '%lisinopril%' OR med1_lower LIKE '%captopril%') AND
            (med2_lower LIKE '%ibuprofen%' OR med2_lower LIKE '%brufen%' OR med2_lower LIKE '%diclofenac%') THEN
        medicine_pair := med1 || ' + ' || med2;
        severity := 'high';
        description := 'تحذير: قد يقلل من فعالية علاج الضغط ويضر الكلى. Reduced antihypertensive effect + kidney risk.';
        recommendation := 'راقب ضغط دمك. استخدم بنادول بدلاً من المسكنات المضادة للالتهاب.';
        interaction_type := 'ace_nsaid';
        RETURN NEXT;

      -- HIGH: Antibiotics + Warfarin
      ELSIF (med1_lower LIKE '%azithromycin%' OR med1_lower LIKE '%ciprofloxacin%' OR 
             med1_lower LIKE '%أزيثروميسين%' OR med1_lower LIKE '%سيبروفلوكساسين%') AND
            (med2_lower LIKE '%warfarin%' OR med2_lower LIKE '%وارفارين%') THEN
        medicine_pair := med1 || ' + ' || med2;
        severity := 'high';
        description := 'تحذير: المضادات الحيوية قد تزيد تأثير الوارفارين. Antibiotics can increase INR.';
        recommendation := 'مراقبة INR أسبوعياً خلال فترة المضاد الحيوي.';
        interaction_type := 'antibiotic_warfarin';
        RETURN NEXT;

      -- MEDIUM: Aspirin + NSAIDs
      ELSIF (med1_lower LIKE '%aspirin%' OR med1_lower LIKE '%أسبرين%') AND
            (med2_lower LIKE '%ibuprofen%' OR med1_lower LIKE '%بروفين%' OR med2_lower LIKE '%diclofenac%') THEN
        medicine_pair := med1 || ' + ' || med2;
        severity := 'medium';
        description := 'تنبيه: زيادة خطر قرحة المعدة والنزيف المعدي. Increased GI bleeding risk.';
        recommendation := 'تجنب استخدامهما معاً. استخدم أحدهما فقط أو استشر صيدلي.';
        interaction_type := 'aspirin_nsaid';
        RETURN NEXT;
      
      -- LOW: Calcium + Iron
      ELSIF (med1_lower LIKE '%calcium%' OR med1_lower LIKE '%كالسيوم%') AND
            (med2_lower LIKE '%iron%' OR med2_lower LIKE '%حديد%') THEN
        medicine_pair := med1 || ' + ' || med2;
        severity := 'low';
        description := 'ملاحظة: الكالسيوم يقلل امتصاص الحديد. Calcium reduces iron absorption.';
        recommendation := 'خذ الحديد والكالسيوم في أوقات منفصلة (فارق 2-3 ساعات على الأقل).';
        interaction_type := 'absorption_competition';
        RETURN NEXT;
      END IF;
    END LOOP;
  END LOOP;

  RETURN;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update existing check_drug_interactions to use enhanced version
DROP FUNCTION IF EXISTS check_drug_interactions(text[]);
CREATE OR REPLACE FUNCTION check_drug_interactions(medicines text[])
RETURNS TABLE (
  medicine_pair text,
  severity text,
  description text,
  recommendation text
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    r.medicine_pair,
    r.severity,
    r.description,
    r.recommendation
  FROM check_drug_interactions_enhanced(medicines) r;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION check_drug_interactions TO authenticated;
GRANT EXECUTE ON FUNCTION check_drug_interactions_enhanced TO authenticated;
