/*
  # تفعيل حماية كلمات المرور من الاختراق

  1. وظائف الأمان
    - دالة للتحقق من قوة كلمات المرور
    - قواعد صارمة لكلمات المرور
    
  2. الإعدادات
    - تحديث إعدادات Auth لتطلب كلمات مرور قوية
    - جدول لتتبع حالة Breach Detection
*/

-- ================================================================================
-- PART 1: Password Strength Validation Function
-- ================================================================================

CREATE OR REPLACE FUNCTION validate_password_strength(password text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  result jsonb;
  strength_score int := 0;
  issues text[] := ARRAY[]::text[];
BEGIN
  -- التحقق من الطول الأدنى (8 أحرف)
  IF length(password) < 8 THEN
    issues := array_append(issues, 'Password must be at least 8 characters long');
  ELSE
    strength_score := strength_score + 1;
  END IF;

  -- التحقق من الطول المثالي (12+ حرف)
  IF length(password) >= 12 THEN
    strength_score := strength_score + 1;
  END IF;

  -- التحقق من وجود أحرف كبيرة
  IF password ~ '[A-Z]' THEN
    strength_score := strength_score + 1;
  ELSE
    issues := array_append(issues, 'Password must contain uppercase letters');
  END IF;

  -- التحقق من وجود أحرف صغيرة
  IF password ~ '[a-z]' THEN
    strength_score := strength_score + 1;
  ELSE
    issues := array_append(issues, 'Password must contain lowercase letters');
  END IF;

  -- التحقق من وجود أرقام
  IF password ~ '[0-9]' THEN
    strength_score := strength_score + 1;
  ELSE
    issues := array_append(issues, 'Password must contain numbers');
  END IF;

  -- التحقق من وجود رموز خاصة
  IF password ~ '[!@#$%^&*()_+\-=\[\]{};:''",.<>?/\\|`~]' THEN
    strength_score := strength_score + 1;
  ELSE
    issues := array_append(issues, 'Password must contain special characters');
  END IF;

  -- التحقق من عدم وجود كلمات مرور شائعة
  IF password IN (
    'password', 'Password1', 'Password123', '12345678', 'qwerty123',
    'admin123', 'welcome123', 'letmein123', 'password1', 'abc12345'
  ) THEN
    issues := array_append(issues, 'This password is too common and easily guessed');
    strength_score := 0;
  END IF;

  -- بناء النتيجة
  result := jsonb_build_object(
    'is_valid', array_length(issues, 1) IS NULL OR array_length(issues, 1) = 0,
    'strength_score', strength_score,
    'strength_level', 
      CASE 
        WHEN strength_score >= 5 THEN 'strong'
        WHEN strength_score >= 3 THEN 'medium'
        ELSE 'weak'
      END,
    'issues', to_jsonb(issues),
    'recommendation', 
      CASE 
        WHEN strength_score < 3 THEN 'Your password is weak. Please use a stronger password with mixed characters.'
        WHEN strength_score < 5 THEN 'Your password is medium. Consider adding more character types for better security.'
        ELSE 'Your password is strong!'
      END
  );

  RETURN result;
END;
$$;

-- ================================================================================
-- PART 2: Create Breach Detection Status Table
-- ================================================================================

CREATE TABLE IF NOT EXISTS security_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  config_key text UNIQUE NOT NULL,
  config_value jsonb NOT NULL,
  is_enabled boolean DEFAULT false,
  instructions text,
  last_checked_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE security_config ENABLE ROW LEVEL SECURITY;

-- Only owners can manage security config
DROP POLICY IF EXISTS "Owners can manage security config" ON security_config;
CREATE POLICY "Owners can manage security config"
  ON security_config
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (SELECT auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- Anyone can read security config
DROP POLICY IF EXISTS "Anyone can read security config" ON security_config;
CREATE POLICY "Anyone can read security config"
  ON security_config
  FOR SELECT
  TO authenticated
  USING (true);

-- Insert breach detection config with clear instructions
INSERT INTO security_config (config_key, config_value, is_enabled, instructions)
VALUES (
  'breach_detection',
  '{
    "provider": "HaveIBeenPwned",
    "enabled_in_dashboard": false,
    "auto_check": true,
    "block_compromised": true
  }'::jsonb,
  false,
  '⚠️ يجب تفعيل Breach Detection من Supabase Dashboard

خطوات التفعيل:
═══════════════════════════════════════════════════════
1. افتح Supabase Dashboard: https://app.supabase.com
2. اختر المشروع الخاص بك
3. اذهب إلى: Authentication → Providers
4. اضغط على "Email" provider
5. انزل للأسفل إلى قسم "Security"
6. فعّل "Breach Detection" ✅
7. اضغط "Save"

ماذا يفعل؟
═══════════════════════════════════════════════════════
✅ يفحص كلمات المرور مقابل قاعدة بيانات HaveIBeenPwned
✅ يمنع المستخدمين من استخدام كلمات مرور مخترقة
✅ يحمي من الاختراقات المعروفة
✅ يتحدث تلقائياً مع الاختراقات الجديدة

الحالة الحالية: ❌ غير مفعل (يحتاج تفعيل يدوي)
المدة: دقيقتين فقط
الأهمية: عالية جداً 🔐
'
)
ON CONFLICT (config_key) DO NOTHING;

-- Insert password policy settings
INSERT INTO app_settings (setting_key, setting_value, setting_type, description, is_active)
VALUES 
  (
    'password_policy',
    '{
      "min_length": 8,
      "require_uppercase": true,
      "require_lowercase": true,
      "require_numbers": true,
      "require_special_chars": true,
      "breach_detection_enabled": false,
      "note": "Enable breach detection in Supabase Dashboard"
    }'::jsonb,
    'security',
    'Password strength requirements and security policy',
    true
  )
ON CONFLICT (setting_key) 
DO UPDATE SET 
  setting_value = EXCLUDED.setting_value,
  updated_at = now();

-- ================================================================================
-- PART 3: Function to Check Breach Detection Status
-- ================================================================================

CREATE OR REPLACE FUNCTION get_breach_detection_status()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  status_record record;
  result jsonb;
BEGIN
  SELECT * INTO status_record
  FROM security_config
  WHERE config_key = 'breach_detection';

  IF status_record IS NULL THEN
    result := jsonb_build_object(
      'enabled', false,
      'status', 'not_configured',
      'message', 'Breach detection configuration not found',
      'action_required', true,
      'instructions', 'Please run the security migration first'
    );
  ELSE
    result := jsonb_build_object(
      'enabled', status_record.is_enabled,
      'status', CASE 
        WHEN status_record.is_enabled THEN 'active'
        ELSE 'inactive'
      END,
      'config', status_record.config_value,
      'instructions', status_record.instructions,
      'last_checked', status_record.last_checked_at,
      'action_required', NOT status_record.is_enabled,
      'dashboard_url', 'https://app.supabase.com'
    );
  END IF;

  RETURN result;
END;
$$;

-- ================================================================================
-- PART 4: Trigger for Security Config Updates
-- ================================================================================

CREATE OR REPLACE FUNCTION update_security_config_timestamp()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
BEGIN
  NEW.updated_at = now();
  IF NEW.is_enabled != OLD.is_enabled THEN
    NEW.last_checked_at = now();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS security_config_updated_at ON security_config;
CREATE TRIGGER security_config_updated_at
  BEFORE UPDATE ON security_config
  FOR EACH ROW
  EXECUTE FUNCTION update_security_config_timestamp();

-- ================================================================================
-- PART 5: Grant Permissions
-- ================================================================================

GRANT EXECUTE ON FUNCTION validate_password_strength TO authenticated;
GRANT EXECUTE ON FUNCTION validate_password_strength TO anon;
GRANT EXECUTE ON FUNCTION get_breach_detection_status TO authenticated;
GRANT SELECT ON security_config TO authenticated;