/*
  # إزالة Indexes غير المستخدمة
  
  ## التحسينات
  
  ### إزالة Indexes غير المستخدمة
  تقليل استهلاك المساحة وتحسين أداء INSERT/UPDATE
  
  ## Indexes المحذوفة
  - health_questions: category, active
  - bot_responses: active
  - forms: active
  - policies: published
  - content_reviews: status
  - questionnaire_responses: user, question
  - failed_login_attempts: email, ip, created_at
  - user_sessions: user_id, status, created_at
  - ip_restrictions: type, expires_at
  - security_audit_log: event_type, created_at, resolved_by
  - subscription_payments: user_id, plan_id, status, created_at, subscription_id
*/

-- health_questions
DROP INDEX IF EXISTS idx_health_questions_category;
DROP INDEX IF EXISTS idx_health_questions_active;

-- bot_responses
DROP INDEX IF EXISTS idx_bot_responses_active;

-- forms
DROP INDEX IF EXISTS idx_forms_active;

-- policies
DROP INDEX IF EXISTS idx_policies_published;

-- content_reviews
DROP INDEX IF EXISTS idx_content_reviews_status;

-- questionnaire_responses
DROP INDEX IF EXISTS idx_questionnaire_responses_user;
DROP INDEX IF EXISTS idx_questionnaire_responses_question;

-- failed_login_attempts
DROP INDEX IF EXISTS idx_failed_login_attempts_email;
DROP INDEX IF EXISTS idx_failed_login_attempts_ip;
DROP INDEX IF EXISTS idx_failed_login_attempts_created_at;

-- user_sessions
DROP INDEX IF EXISTS idx_user_sessions_user_id;
DROP INDEX IF EXISTS idx_user_sessions_status;
DROP INDEX IF EXISTS idx_user_sessions_created_at;

-- ip_restrictions
DROP INDEX IF EXISTS idx_ip_restrictions_type;
DROP INDEX IF EXISTS idx_ip_restrictions_expires_at;

-- security_audit_log
DROP INDEX IF EXISTS idx_security_audit_log_event_type;
DROP INDEX IF EXISTS idx_security_audit_log_created_at;
DROP INDEX IF EXISTS idx_security_audit_log_resolved_by;

-- subscription_payments
DROP INDEX IF EXISTS idx_subscription_payments_user_id;
DROP INDEX IF EXISTS idx_subscription_payments_plan_id;
DROP INDEX IF EXISTS idx_subscription_payments_status;
DROP INDEX IF EXISTS idx_subscription_payments_created_at;
DROP INDEX IF EXISTS idx_subscription_payments_subscription_id;
