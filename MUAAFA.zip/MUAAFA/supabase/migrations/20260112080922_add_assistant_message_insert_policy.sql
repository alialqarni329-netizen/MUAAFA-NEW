/*
  # Allow assistant messages to be inserted into chat_messages

  1. Changes
    - Add RLS policy to allow INSERT when sender_type = 'assistant'
    - This enables the health chatbot to save its responses to the database
    
  2. Security
    - Maintains existing user policies
    - Allows authenticated users to insert assistant messages
    - Does not disable RLS or remove existing policies
*/

CREATE POLICY "Allow assistant messages insert"
ON public.chat_messages
FOR INSERT
TO authenticated
WITH CHECK (sender_type = 'assistant');
