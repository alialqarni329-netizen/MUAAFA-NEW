/*
  # إصلاح سياسات الأمان لتسجيل المنشآت الجديدة

  ## المشكلة:
  عند محاولة تسجيل منشأة جديدة عبر business_verification، يظهر خطأ:
  "violates row-level security policy"

  السبب: قد تكون هناك مشكلة في policy الموجودة أو تعارض بين policies

  ## الحل:
  1. حذف وإعادة إنشاء policies بشكل واضح وصريح
  2. التأكد من أن authenticated users يمكنهم INSERT بياناتهم
  3. إضافة SELECT policy للمستخدمين المصادق عليهم
  4. إضافة UPDATE policy لتحديث البيانات الخاصة

  ## الجداول المتأثرة:
  - business_verification
*/

-- التأكد من تفعيل RLS على الجدول
ALTER TABLE business_verification ENABLE ROW LEVEL SECURITY;

-- حذف جميع الـ policies القديمة لتجنب التعارض
DROP POLICY IF EXISTS "Business users can view own verification" ON business_verification;
DROP POLICY IF EXISTS "Business users can insert own verification" ON business_verification;
DROP POLICY IF EXISTS "Business users can update own verification" ON business_verification;
DROP POLICY IF EXISTS "Admins can view all verifications" ON business_verification;
DROP POLICY IF EXISTS "Admins can update verifications" ON business_verification;
DROP POLICY IF EXISTS "Service role full access" ON business_verification;

-- 1. Policy للسماح للمستخدمين المصادق عليهم بإدراج بياناتهم الخاصة
CREATE POLICY "Authenticated users can insert own business verification"
  ON business_verification FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- 2. Policy للسماح للمستخدمين بمشاهدة بياناتهم الخاصة
CREATE POLICY "Users can view own business verification"
  ON business_verification FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- 3. Policy للسماح للمستخدمين بتحديث بياناتهم الخاصة (فقط إذا كانت pending)
CREATE POLICY "Users can update own pending verification"
  ON business_verification FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = user_id
    AND verification_status = 'pending'
  )
  WITH CHECK (
    auth.uid() = user_id
    AND verification_status = 'pending'
  );

-- 4. Policy للسماح للإداريين بمشاهدة جميع الطلبات
CREATE POLICY "Admins can view all business verifications"
  ON business_verification FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = auth.uid()
    )
  );

-- 5. Policy للسماح للإداريين بتحديث حالة التحقق
CREATE POLICY "Admins can update business verifications"
  ON business_verification FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = auth.uid()
    )
  );

-- 6. Policy لـ service_role (للاستخدام الداخلي من الـ triggers والـ functions)
CREATE POLICY "Service role has full access to business_verification"
  ON business_verification FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- التأكد من أن الجدول يحتوي على indexes للأداء
CREATE INDEX IF NOT EXISTS idx_business_verification_user_id
  ON business_verification(user_id);

CREATE INDEX IF NOT EXISTS idx_business_verification_status
  ON business_verification(verification_status);

CREATE INDEX IF NOT EXISTS idx_business_verification_commercial_reg
  ON business_verification(commercial_registration);

-- إضافة تعليقات توضيحية
COMMENT ON TABLE business_verification IS 'جدول التحقق من المنشآت - يحتوي على بيانات المنشآت التي تنتظر الموافقة من الإدارة';
COMMENT ON COLUMN business_verification.verification_status IS 'حالة التحقق: pending (قيد المراجعة)، active (مفعّل)، rejected (مرفوض)، suspended (موقوف)';
COMMENT ON COLUMN business_verification.user_id IS 'معرف المستخدم الذي يملك المنشأة - يجب أن يكون مسجل دخول';
