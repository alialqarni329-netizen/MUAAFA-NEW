/*
  # إضافة معلومات العلامة التجارية والشعار

  1. تحديثات
    - تحديث جدول `app_settings` لإضافة معلومات الشعار والعلامة التجارية
    - إضافة سجلات العلامة التجارية الافتراضية

  2. البيانات
    - اسم التطبيق: مُعافى | MUAAFA
    - الألوان: الأزرق السماوي (#0ea5e9)
    - الشعار: شعار الدرع مع نبض القلب
    - الشعار بالعربية: مُعافى
    - الشعار بالإنجليزية: MUAAFA
*/

-- حذف السجلات القديمة إذا كانت موجودة
DELETE FROM app_settings WHERE setting_key IN (
  'app_logo_url', 'app_name_ar', 'app_name_en', 'app_full_name',
  'brand_primary_color', 'brand_background_color', 'logo_description',
  'notification_icon', 'splash_screen_logo', 'favicon_url',
  'brand_tagline_ar', 'brand_tagline_en'
);

-- إضافة معلومات العلامة التجارية
INSERT INTO app_settings (setting_key, setting_value, setting_type, description, is_active) VALUES
-- شعار التطبيق
('app_logo_url', '"/assets/images/icon.png"'::jsonb, 'text', 'رابط شعار التطبيق الرئيسي', true),

-- اسم التطبيق بالعربية
('app_name_ar', '"مُعافى"'::jsonb, 'text', 'اسم التطبيق باللغة العربية', true),

-- اسم التطبيق بالإنجليزية
('app_name_en', '"MUAAFA"'::jsonb, 'text', 'اسم التطبيق باللغة الإنجليزية', true),

-- الاسم الكامل
('app_full_name', '"مُعافى | MUAAFA"'::jsonb, 'text', 'الاسم الكامل للتطبيق', true),

-- اللون الرئيسي
('brand_primary_color', '"#0ea5e9"'::jsonb, 'color', 'اللون الأزرق السماوي - اللون الأساسي للعلامة التجارية', true),

-- لون الخلفية
('brand_background_color', '"#0ea5e9"'::jsonb, 'color', 'لون الخلفية للشاشات الرئيسية', true),

-- وصف الشعار
('logo_description', '"شعار مُعافى يتكون من درع واقي مع حرف M وخط نبض القلب، يرمز إلى الحماية والصحة"'::jsonb, 'text', 'وصف شعار التطبيق', true),

-- الشعار للإشعارات
('notification_icon', '"/assets/images/adaptive-icon.png"'::jsonb, 'text', 'أيقونة الإشعارات', true),

-- شعار شاشة البداية
('splash_screen_logo', '"/assets/images/splash.png"'::jsonb, 'text', 'شعار شاشة البداية', true),

-- Favicon للويب
('favicon_url', '"/assets/images/favicon.png"'::jsonb, 'text', 'أيقونة المتصفح (Favicon)', true),

-- الشعار النصي بالعربية
('brand_tagline_ar', '"صحتك بين يديك"'::jsonb, 'text', 'الشعار النصي باللغة العربية', true),

-- الشعار النصي بالإنجليزية
('brand_tagline_en', '"Your Health in Your Hands"'::jsonb, 'text', 'الشعار النصي باللغة الإنجليزية', true);

-- إنشاء view لسهولة الوصول لمعلومات العلامة التجارية
CREATE OR REPLACE VIEW brand_settings AS
SELECT 
  MAX(CASE WHEN setting_key = 'app_logo_url' THEN setting_value->>0 END) as logo_url,
  MAX(CASE WHEN setting_key = 'app_name_ar' THEN setting_value->>0 END) as name_ar,
  MAX(CASE WHEN setting_key = 'app_name_en' THEN setting_value->>0 END) as name_en,
  MAX(CASE WHEN setting_key = 'app_full_name' THEN setting_value->>0 END) as full_name,
  MAX(CASE WHEN setting_key = 'brand_primary_color' THEN setting_value->>0 END) as primary_color,
  MAX(CASE WHEN setting_key = 'brand_background_color' THEN setting_value->>0 END) as background_color,
  MAX(CASE WHEN setting_key = 'logo_description' THEN setting_value->>0 END) as logo_description,
  MAX(CASE WHEN setting_key = 'notification_icon' THEN setting_value->>0 END) as notification_icon,
  MAX(CASE WHEN setting_key = 'splash_screen_logo' THEN setting_value->>0 END) as splash_logo,
  MAX(CASE WHEN setting_key = 'favicon_url' THEN setting_value->>0 END) as favicon,
  MAX(CASE WHEN setting_key = 'brand_tagline_ar' THEN setting_value->>0 END) as tagline_ar,
  MAX(CASE WHEN setting_key = 'brand_tagline_en' THEN setting_value->>0 END) as tagline_en
FROM app_settings
WHERE setting_key IN (
  'app_logo_url', 'app_name_ar', 'app_name_en', 'app_full_name',
  'brand_primary_color', 'brand_background_color', 'logo_description',
  'notification_icon', 'splash_screen_logo', 'favicon_url',
  'brand_tagline_ar', 'brand_tagline_en'
) AND is_active = true;

-- السماح للجميع بقراءة معلومات العلامة التجارية
GRANT SELECT ON brand_settings TO anon, authenticated;

-- إضافة تعليق على الـ view
COMMENT ON VIEW brand_settings IS 'عرض مبسط لجميع معلومات العلامة التجارية والشعار';
