/*
  # Remove Problematic Notifications Trigger

  1. Problem
    - trigger_notify_business_status executes after status update
    - Function notify_business_status_change tries to insert into notifications table
    - notifications table does not exist
    - This causes all approval/rejection operations to fail

  2. Solution
    - Drop the trigger completely
    - Drop the function completely
    - This allows status updates to work without errors

  3. Notes
    - Notifications system can be re-implemented later if needed
    - For now, the priority is making approval/rejection work
*/

-- Drop the trigger first
DROP TRIGGER IF EXISTS trigger_notify_business_status ON business_registrations;

-- Drop the function
DROP FUNCTION IF EXISTS notify_business_status_change();
