-- Create app_settings table for application-wide settings
CREATE TABLE IF NOT EXISTS app_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key TEXT UNIQUE NOT NULL,
  setting_value JSONB NOT NULL,
  setting_type TEXT NOT NULL, -- 'google_oauth', 'login', 'otp', 'languages', 'themes', 'privacy', 'terms', 'backup', 'general'
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create system_config table for system-level configuration
CREATE TABLE IF NOT EXISTS system_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  config_key TEXT UNIQUE NOT NULL,
  config_value JSONB NOT NULL,
  category TEXT NOT NULL, -- 'security', 'api', 'backup', 'localization', 'theme'
  is_encrypted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_app_settings_type ON app_settings(setting_type);
CREATE INDEX IF NOT EXISTS idx_app_settings_key ON app_settings(setting_key);
CREATE INDEX IF NOT EXISTS idx_system_config_category ON system_config(category);
CREATE INDEX IF NOT EXISTS idx_system_config_key ON system_config(config_key);

-- Insert default settings
INSERT INTO app_settings (setting_key, setting_value, setting_type, description) VALUES
  ('google_oauth_enabled', '{"enabled": false}'::jsonb, 'google_oauth', 'Enable/disable Google OAuth'),
  ('google_client_id', '{"value": ""}'::jsonb, 'google_oauth', 'Google OAuth Client ID'),
  ('google_client_secret', '{"value": ""}'::jsonb, 'google_oauth', 'Google OAuth Client Secret'),
  ('login_max_attempts', '{"value": 5}'::jsonb, 'login', 'Maximum login attempts before lockout'),
  ('login_lockout_duration', '{"value": 30}'::jsonb, 'login', 'Lockout duration in minutes'),
  ('login_session_timeout', '{"value": 1440}'::jsonb, 'login', 'Session timeout in minutes'),
  ('login_force_password_change', '{"enabled": false}'::jsonb, 'login', 'Force password change every 90 days'),
  ('otp_enabled', '{"enabled": false}'::jsonb, 'otp', 'Enable OTP/2FA for all users'),
  ('otp_method', '{"method": "sms"}'::jsonb, 'otp', 'OTP delivery method: sms, email, authenticator'),
  ('otp_expiry', '{"minutes": 5}'::jsonb, 'otp', 'OTP expiry time in minutes'),
  ('default_language', '{"language": "ar"}'::jsonb, 'languages', 'Default application language'),
  ('supported_languages', '{"languages": ["ar", "en"]}'::jsonb, 'languages', 'Supported languages'),
  ('rtl_enabled', '{"enabled": true}'::jsonb, 'languages', 'Enable RTL support'),
  ('theme_mode', '{"mode": "light"}'::jsonb, 'themes', 'Theme mode: light, dark, auto'),
  ('theme_primary_color', '{"color": "#3b82f6"}'::jsonb, 'themes', 'Primary theme color'),
  ('theme_secondary_color', '{"color": "#64748b"}'::jsonb, 'themes', 'Secondary theme color'),
  ('privacy_policy_url', '{"url": ""}'::jsonb, 'privacy', 'Privacy policy URL'),
  ('privacy_policy_version', '{"version": "1.0"}'::jsonb, 'privacy', 'Privacy policy version'),
  ('terms_url', '{"url": ""}'::jsonb, 'terms', 'Terms and conditions URL'),
  ('terms_version', '{"version": "1.0"}'::jsonb, 'terms', 'Terms and conditions version'),
  ('backup_enabled', '{"enabled": true}'::jsonb, 'backup', 'Enable automatic backups'),
  ('backup_frequency', '{"frequency": "daily"}'::jsonb, 'backup', 'Backup frequency: daily, weekly, monthly'),
  ('backup_retention', '{"days": 30}'::jsonb, 'backup', 'Backup retention period in days')
ON CONFLICT (setting_key) DO NOTHING;

-- Insert default system config
INSERT INTO system_config (config_key, config_value, category) VALUES
  ('zidpay_api_key', '{"key": ""}'::jsonb, 'api'),
  ('zidpay_secret', '{"secret": ""}'::jsonb, 'api'),
  ('chatgpt_api_key', '{"key": ""}'::jsonb, 'api'),
  ('chatgpt_model', '{"model": "gpt-4"}'::jsonb, 'api'),
  ('backup_storage_path', '{"path": "/backups"}'::jsonb, 'backup'),
  ('backup_max_size_mb', '{"size": 1000}'::jsonb, 'backup')
ON CONFLICT (config_key) DO NOTHING;