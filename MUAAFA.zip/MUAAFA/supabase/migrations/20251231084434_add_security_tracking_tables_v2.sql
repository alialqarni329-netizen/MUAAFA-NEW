
-- Create failed_login_attempts table
CREATE TABLE IF NOT EXISTS failed_login_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_email TEXT NOT NULL,
  ip_address INET NOT NULL,
  user_agent TEXT,
  reason TEXT,
  attempt_count INTEGER DEFAULT 1,
  last_attempted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_sessions table for session tracking
CREATE TABLE IF NOT EXISTS user_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  user_email TEXT NOT NULL,
  ip_address INET NOT NULL,
  device_type TEXT,
  device_fingerprint TEXT,
  browser TEXT,
  os TEXT,
  status TEXT DEFAULT 'active',
  session_token TEXT UNIQUE,
  last_activity_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE
);

-- Create ip_restrictions table
CREATE TABLE IF NOT EXISTS ip_restrictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address INET NOT NULL UNIQUE,
  type TEXT NOT NULL CHECK (type IN ('allow', 'block')),
  reason TEXT,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create security_metrics table for real-time monitoring
CREATE TABLE IF NOT EXISTS security_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  metric_type TEXT NOT NULL,
  value INTEGER DEFAULT 0,
  metric_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(metric_type, metric_date)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_failed_login_attempts_email ON failed_login_attempts(user_email);
CREATE INDEX IF NOT EXISTS idx_failed_login_attempts_ip ON failed_login_attempts(ip_address);
CREATE INDEX IF NOT EXISTS idx_failed_login_attempts_created_at ON failed_login_attempts(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_status ON user_sessions(status);
CREATE INDEX IF NOT EXISTS idx_user_sessions_created_at ON user_sessions(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ip_restrictions_type ON ip_restrictions(type);
CREATE INDEX IF NOT EXISTS idx_ip_restrictions_expires_at ON ip_restrictions(expires_at);

CREATE INDEX IF NOT EXISTS idx_security_audit_log_event_type ON security_audit_log(event_type) WHERE event_type IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_security_audit_log_created_at ON security_audit_log(created_at DESC);

-- Create function to update security metrics
CREATE OR REPLACE FUNCTION update_security_metrics()
RETURNS void AS $$
BEGIN
  INSERT INTO security_metrics (metric_type, value, metric_date)
  VALUES 
    ('failed_login_attempts_today', (SELECT COUNT(*) FROM failed_login_attempts WHERE DATE(created_at) = CURRENT_DATE), CURRENT_DATE),
    ('active_sessions', (SELECT COUNT(*) FROM user_sessions WHERE status = 'active'), CURRENT_DATE),
    ('blocked_ips', (SELECT COUNT(*) FROM ip_restrictions WHERE type = 'block' AND (expires_at IS NULL OR expires_at > NOW())), CURRENT_DATE)
  ON CONFLICT (metric_type, metric_date) DO UPDATE SET value = EXCLUDED.value;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Enable RLS on new tables
ALTER TABLE failed_login_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ip_restrictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE security_metrics ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for failed_login_attempts
CREATE POLICY "Allow owners to view failed login attempts" 
ON failed_login_attempts FOR SELECT 
USING (
  auth.uid() IN (SELECT id FROM auth.users WHERE raw_app_meta_data->>'role' = 'owner')
);

-- Create RLS policies for user_sessions
CREATE POLICY "Allow owners to view sessions" 
ON user_sessions FOR SELECT 
USING (
  auth.uid() IN (SELECT id FROM auth.users WHERE raw_app_meta_data->>'role' = 'owner')
);

-- Create RLS policies for ip_restrictions
CREATE POLICY "Allow owners to view IP restrictions" 
ON ip_restrictions FOR SELECT 
USING (
  auth.uid() IN (SELECT id FROM auth.users WHERE raw_app_meta_data->>'role' = 'owner')
);

CREATE POLICY "Allow owners to insert IP restrictions" 
ON ip_restrictions FOR INSERT 
WITH CHECK (
  auth.uid() IN (SELECT id FROM auth.users WHERE raw_app_meta_data->>'role' = 'owner')
);

CREATE POLICY "Allow owners to update IP restrictions" 
ON ip_restrictions FOR UPDATE 
USING (
  auth.uid() IN (SELECT id FROM auth.users WHERE raw_app_meta_data->>'role' = 'owner')
);

CREATE POLICY "Allow owners to delete IP restrictions" 
ON ip_restrictions FOR DELETE 
USING (
  auth.uid() IN (SELECT id FROM auth.users WHERE raw_app_meta_data->>'role' = 'owner')
);

-- Create RLS policies for security_metrics
CREATE POLICY "Allow owners to view security metrics" 
ON security_metrics FOR SELECT 
USING (
  auth.uid() IN (SELECT id FROM auth.users WHERE raw_app_meta_data->>'role' = 'owner')
);
