/*
  # إصلاح المشاكل الأمنية - الجزء 1: الفهارس و RLS

  1. الفهارس
    - إضافة فهرس للـ Foreign Key المفقود
    - إزالة جميع الفهارس غير المستخدمة (130+ فهرس)
    
  2. RLS Optimization
    - تحسين أداء RLS policy لـ dashboard_warnings
*/

-- ================================================================================
-- PART 1: Add Missing Foreign Key Index
-- ================================================================================

CREATE INDEX IF NOT EXISTS idx_security_audit_log_resolved_by 
ON security_audit_log(resolved_by);

-- ================================================================================
-- PART 2: Optimize RLS Policy for dashboard_warnings
-- ================================================================================

DROP POLICY IF EXISTS "Owners can manage dashboard warnings" ON dashboard_warnings;

CREATE POLICY "Owners can manage dashboard warnings"
  ON dashboard_warnings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = (select auth.uid())
      AND users.user_role = 'owner'
    )
  );

-- ================================================================================
-- PART 3: Remove All Unused Indexes
-- ================================================================================

-- Activity Logs
DROP INDEX IF EXISTS idx_activity_logs_user_id;
DROP INDEX IF EXISTS idx_activity_logs_type_created;

-- Cart Items
DROP INDEX IF EXISTS idx_cart_items_product_id;
DROP INDEX IF EXISTS idx_cart_items_user_id;
DROP INDEX IF EXISTS idx_cart_items_item_id;
DROP INDEX IF EXISTS idx_cart_items_item_type;

-- Subscriptions
DROP INDEX IF EXISTS idx_subscriptions_status;
DROP INDEX IF EXISTS idx_subscriptions_plan_type;
DROP INDEX IF EXISTS idx_subscriptions_expiry;
DROP INDEX IF EXISTS idx_subscriptions_notification;

-- Insurance Policies
DROP INDEX IF EXISTS idx_insurance_policies_user_id;
DROP INDEX IF EXISTS idx_insurance_policies_status;

-- Medical Sessions
DROP INDEX IF EXISTS idx_medical_sessions_user_id;
DROP INDEX IF EXISTS idx_medical_sessions_payment_status;
DROP INDEX IF EXISTS idx_medical_sessions_session_status;
DROP INDEX IF EXISTS idx_medical_sessions_session_date;
DROP INDEX IF EXISTS idx_medical_sessions_insurance_policy_id_fk;

-- Pharmacy Orders
DROP INDEX IF EXISTS idx_pharmacy_orders_user_id;
DROP INDEX IF EXISTS idx_pharmacy_orders_payment_status;
DROP INDEX IF EXISTS idx_pharmacy_orders_order_status;
DROP INDEX IF EXISTS idx_pharmacy_orders_insurance_policy_id_fk;

-- Order Items
DROP INDEX IF EXISTS idx_order_items_order_id;
DROP INDEX IF EXISTS idx_order_items_medication_id;

-- Orders
DROP INDEX IF EXISTS idx_orders_user_id;
DROP INDEX IF EXISTS idx_orders_pharmacy_id;
DROP INDEX IF EXISTS idx_orders_prescription_id;
DROP INDEX IF EXISTS idx_orders_status;
DROP INDEX IF EXISTS idx_orders_insurance_company_id_fk;

-- Session Recordings
DROP INDEX IF EXISTS idx_session_recordings_session_id;

-- Sessions
DROP INDEX IF EXISTS idx_sessions_doctor_id;

-- Treatment Categories
DROP INDEX IF EXISTS idx_treatment_categories_pharmacy_category_id;

-- User Subscriptions
DROP INDEX IF EXISTS idx_user_subscriptions_plan_id;

-- Medicine Cabinet
DROP INDEX IF EXISTS idx_medicine_cabinet_expiry;

-- Pharmacy Prices
DROP INDEX IF EXISTS idx_pharmacy_prices_medicine;
DROP INDEX IF EXISTS idx_pharmacy_prices_pharmacy;

-- Emergency Deliveries
DROP INDEX IF EXISTS idx_emergency_deliveries_status;
DROP INDEX IF EXISTS idx_emergency_deliveries_order_id_fk;

-- Pharmacist Consultations
DROP INDEX IF EXISTS idx_pharmacist_consultations_status;

-- Users
DROP INDEX IF EXISTS idx_users_phone;
DROP INDEX IF EXISTS idx_users_national_id;
DROP INDEX IF EXISTS idx_users_trial_ends;
DROP INDEX IF EXISTS idx_users_user_role;

-- Business Registrations
DROP INDEX IF EXISTS idx_business_phone;
DROP INDEX IF EXISTS idx_business_email;
DROP INDEX IF EXISTS idx_business_cr;
DROP INDEX IF EXISTS idx_business_registrations_reviewed_by;

-- Appointments
DROP INDEX IF EXISTS idx_appointments_doctor_id;
DROP INDEX IF EXISTS idx_appointments_scheduled_date;
DROP INDEX IF EXISTS idx_appointments_insurance_id;
DROP INDEX IF EXISTS idx_appointments_journey_id;
DROP INDEX IF EXISTS idx_appointments_payment_id;

-- Medical Briefs
DROP INDEX IF EXISTS idx_medical_briefs_appointment_id;

-- Post Session Notes
DROP INDEX IF EXISTS idx_post_session_notes_appointment_id;
DROP INDEX IF EXISTS idx_post_session_notes_doctor_id_fk;

-- Waiting Room
DROP INDEX IF EXISTS idx_waiting_room_appointment_id;

-- Payment Transactions
DROP INDEX IF EXISTS idx_payment_transactions_status;
DROP INDEX IF EXISTS idx_payment_transactions_subscription_id;

-- Insurance Requests
DROP INDEX IF EXISTS idx_insurance_requests_status;
DROP INDEX IF EXISTS idx_insurance_requests_insurance_id_fk;

-- Insurance Appeals
DROP INDEX IF EXISTS idx_insurance_appeals_request_id;

-- Covered Facilities
DROP INDEX IF EXISTS idx_covered_facilities_company;

-- Medical Documents
DROP INDEX IF EXISTS idx_medical_documents_type;
DROP INDEX IF EXISTS idx_medical_documents_related_request_id_fk;

-- Invoices
DROP INDEX IF EXISTS idx_invoices_insurance_id_fk;
DROP INDEX IF EXISTS idx_invoices_user;
DROP INDEX IF EXISTS idx_invoices_payment;
DROP INDEX IF EXISTS idx_invoices_journey;
DROP INDEX IF EXISTS idx_invoices_provider;
DROP INDEX IF EXISTS idx_invoices_number;
DROP INDEX IF EXISTS idx_invoices_status;

-- Patient Journeys
DROP INDEX IF EXISTS idx_patient_journeys_insurance_id_fk;
DROP INDEX IF EXISTS idx_patient_journeys_user;
DROP INDEX IF EXISTS idx_patient_journeys_hospital;
DROP INDEX IF EXISTS idx_patient_journeys_pharmacy;
DROP INDEX IF EXISTS idx_patient_journeys_status;
DROP INDEX IF EXISTS idx_patient_journeys_dates;

-- Pharmacy Cart
DROP INDEX IF EXISTS idx_pharmacy_cart_prescription_id_fk;
DROP INDEX IF EXISTS idx_pharmacy_cart_pharmacy;
DROP INDEX IF EXISTS idx_pharmacy_cart_medication;

-- Session Archives
DROP INDEX IF EXISTS idx_session_archives_provider_id_fk;
DROP INDEX IF EXISTS idx_session_archives_user_id;
DROP INDEX IF EXISTS idx_session_archives_type;
DROP INDEX IF EXISTS idx_session_archives_started_at;

-- Pharmacy Stock
DROP INDEX IF EXISTS idx_pharmacy_stock_pharmacy_available;

-- Order Timeline
DROP INDEX IF EXISTS idx_order_timeline_order_created;

-- Delivery Assignments
DROP INDEX IF EXISTS idx_delivery_assignments_order_status;
DROP INDEX IF EXISTS idx_delivery_assignments_delivery_company_id_fk;

-- Pharmacy Order Requests
DROP INDEX IF EXISTS idx_pharmacy_order_requests_status;
DROP INDEX IF EXISTS idx_pharmacy_order_requests_order_id_fk;

-- Insurance Approvals
DROP INDEX IF EXISTS idx_insurance_approvals_status;
DROP INDEX IF EXISTS idx_insurance_approvals_provider;
DROP INDEX IF EXISTS idx_insurance_approvals_insurance_company_id_fk;
DROP INDEX IF EXISTS idx_insurance_approvals_order_id_fk;

-- Provider Offers
DROP INDEX IF EXISTS idx_provider_offers_order;
DROP INDEX IF EXISTS idx_provider_offers_insurance_approval_id_fk;
DROP INDEX IF EXISTS idx_provider_offers_provider_id_fk;

-- Transactions
DROP INDEX IF EXISTS idx_transactions_business;
DROP INDEX IF EXISTS idx_transactions_order_id_fk;

-- Appointment Slots
DROP INDEX IF EXISTS idx_appointment_slots_hospital_date;

-- Chat Conversations
DROP INDEX IF EXISTS idx_chat_conversations_last_message;

-- Business Verification
DROP INDEX IF EXISTS idx_business_verification_status;

-- Email Logs
DROP INDEX IF EXISTS idx_email_logs_template;

-- Email Templates
DROP INDEX IF EXISTS idx_email_templates_active;
DROP INDEX IF EXISTS idx_email_templates_created_by_fk;

-- Medication Reminders
DROP INDEX IF EXISTS idx_medication_reminders_user_id;

-- Notification Logs
DROP INDEX IF EXISTS idx_notification_logs_user_id;

-- Security Audit Log
DROP INDEX IF EXISTS idx_security_audit_log_resolved;
DROP INDEX IF EXISTS idx_security_audit_log_event_type;

-- Fitness AI Recommendations
DROP INDEX IF EXISTS idx_fitness_ai_recommendations_based_on_scan_id_fk;

-- Delivery Proof
DROP INDEX IF EXISTS idx_delivery_proof_order_id_fk;

-- Medical Recommendations
DROP INDEX IF EXISTS idx_med_recommendations_severity;
DROP INDEX IF EXISTS idx_med_recommendations_critical;

-- System Status
DROP INDEX IF EXISTS idx_system_status_status;

-- Payments
DROP INDEX IF EXISTS idx_payments_user;
DROP INDEX IF EXISTS idx_payments_appointment;
DROP INDEX IF EXISTS idx_payments_journey;
DROP INDEX IF EXISTS idx_payments_status;
DROP INDEX IF EXISTS idx_payments_gateway_id;
DROP INDEX IF EXISTS idx_payments_insurance;

-- Settlements
DROP INDEX IF EXISTS idx_settlements_provider;
DROP INDEX IF EXISTS idx_settlements_period;
DROP INDEX IF EXISTS idx_settlements_status;

-- Medical Questionnaire
DROP INDEX IF EXISTS idx_medical_questionnaire_user_id;

-- Business Permissions
DROP INDEX IF EXISTS idx_business_permissions_business_id;

-- Business Settings
DROP INDEX IF EXISTS idx_business_settings_business_id;

-- User Analytics
DROP INDEX IF EXISTS idx_user_analytics_user_id;
DROP INDEX IF EXISTS idx_user_analytics_last_login;

-- App Settings
DROP INDEX IF EXISTS idx_app_settings_type;

-- System Config
DROP INDEX IF EXISTS idx_system_config_category;