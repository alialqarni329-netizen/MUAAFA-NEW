/*
  # إصلاح مشكلة تسجيل المنشآت الجديدة

  ## المشكلة:
  عند تسجيل منشأة جديدة، يظهر خطأ "Database error saving new user" بسبب:
  1. RLS policy على جدول users تتطلب authenticated لكن الـ trigger ينفذ قبل المصادقة الكاملة
  2. الـ trigger لا يملك صلاحيات كافية لإدخال البيانات

  ## الحل:
  1. تحديث الـ trigger ليكون SECURITY DEFINER مع search_path صحيح
  2. إضافة policy تسمح بـ INSERT من الـ trigger
  3. التأكد من أن الـ function تعمل بصلاحيات postgres

  ## الجداول المتأثرة:
  - users
  - subscriptions
  - auth.users (trigger)
*/

-- حذف الـ Trigger والدالة القديمة
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- إنشاء دالة جديدة محسّنة مع صلاحيات كاملة
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
BEGIN
  -- إنشاء سجل في جدول users (بدون التحقق من RLS)
  INSERT INTO public.users (id, created_at, updated_at)
  VALUES (NEW.id, NOW(), NOW())
  ON CONFLICT (id) DO NOTHING;

  -- إنشاء اشتراك الباقة الأساسية (مجاني ودائم)
  INSERT INTO public.subscriptions (
    user_id,
    plan_type,
    status,
    start_date,
    end_date
  )
  VALUES (
    NEW.id,
    'free',
    'active',
    NOW(),
    NULL
  )
  ON CONFLICT (user_id)
  WHERE status = 'active'
  DO NOTHING;

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- تسجيل الخطأ وإرجاع NEW لعدم إيقاف عملية التسجيل
  RAISE WARNING 'Error in handle_new_user trigger: %', SQLERRM;
  RETURN NEW;
END;
$$;

-- إنشاء Trigger جديد
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- منح صلاحيات للـ function
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres, service_role;

-- إضافة policy للسماح بـ INSERT من service_role (للـ trigger)
DO $$
BEGIN
  -- حذف الـ policy القديمة إن وُجدت
  DROP POLICY IF EXISTS "Service role can insert users" ON users;

  -- إضافة policy جديدة للـ service_role
  CREATE POLICY "Service role can insert users"
    ON users FOR INSERT
    TO service_role
    WITH CHECK (true);
EXCEPTION WHEN OTHERS THEN
  -- تجاهل الأخطاء إذا كانت الـ policy موجودة
  NULL;
END $$;

-- التأكد من أن RLS مفعّل على جدول users
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- التأكد من أن RLS مفعّل على جدول subscriptions
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- إضافة policy للسماح بـ INSERT من service_role على subscriptions
DO $$
BEGIN
  DROP POLICY IF EXISTS "Service role can insert subscriptions" ON subscriptions;

  CREATE POLICY "Service role can insert subscriptions"
    ON subscriptions FOR INSERT
    TO service_role
    WITH CHECK (true);
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;

-- إضافة تعليقات توضيحية
COMMENT ON FUNCTION public.handle_new_user() IS 'Trigger function to create user profile and free subscription when a new user signs up. Uses SECURITY DEFINER to bypass RLS.';