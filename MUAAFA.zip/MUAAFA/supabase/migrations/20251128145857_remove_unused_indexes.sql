/*
  # حذف Indexes غير المستخدمة
  
  1. المشكلة
    - Index idx_uploaded_images_conversation_id غير مستخدم
    - يستهلك مساحة ويبطئ عمليات INSERT/UPDATE
  
  2. الحل
    - حذف الـ index غير المستخدم
*/

-- حذف index غير المستخدم
DROP INDEX IF EXISTS public.idx_uploaded_images_conversation_id;

-- ملاحظة: تم الاحتفاظ بـ idx_uploaded_images_user_id لأنه مستخدم في الاستعلامات
