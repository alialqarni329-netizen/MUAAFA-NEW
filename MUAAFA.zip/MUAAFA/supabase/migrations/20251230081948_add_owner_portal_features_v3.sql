/*
  # إضافة ميزات متقدمة لبوابة المالك v3

  ## الجداول الجديدة
  
  1. business_permissions - صلاحيات الشركات
  2. business_settings - إعدادات الشركات
  3. user_analytics - تحليلات المستخدمين
  4. session_archives - أرشيف الجلسات
  5. legal_pages - الصفحات القانونية
*/

-- 1️⃣ جدول صلاحيات الشركات
CREATE TABLE IF NOT EXISTS business_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES business_registrations(id) ON DELETE CASCADE,
  
  max_employees INT DEFAULT 50,
  max_orders_per_month INT DEFAULT 1000,
  max_storage_mb INT DEFAULT 1024,
  
  can_use_ai_bot BOOLEAN DEFAULT true,
  can_access_analytics BOOLEAN DEFAULT true,
  can_export_data BOOLEAN DEFAULT true,
  can_customize_branding BOOLEAN DEFAULT false,
  can_access_api BOOLEAN DEFAULT false,
  
  priority_support BOOLEAN DEFAULT false,
  dedicated_account_manager BOOLEAN DEFAULT false,
  custom_integrations BOOLEAN DEFAULT false,
  
  permissions_updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_business_permissions_business_id ON business_permissions(business_id);

-- 2️⃣ جدول إعدادات الشركات
CREATE TABLE IF NOT EXISTS business_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES business_registrations(id) ON DELETE CASCADE,
  
  logo_url TEXT,
  brand_color TEXT DEFAULT '#0ea5e9',
  theme TEXT DEFAULT 'light',
  
  contact_email TEXT,
  contact_phone TEXT,
  contact_address TEXT,
  website_url TEXT,
  
  tax_number TEXT,
  tax_name TEXT,
  tax_address TEXT,
  
  email_notifications BOOLEAN DEFAULT true,
  sms_notifications BOOLEAN DEFAULT false,
  push_notifications BOOLEAN DEFAULT true,
  
  invoice_prefix TEXT DEFAULT 'INV',
  invoice_footer TEXT,
  payment_terms TEXT DEFAULT 'Net 30',
  
  working_hours JSONB DEFAULT '{"start": "09:00", "end": "17:00"}',
  working_days TEXT[] DEFAULT ARRAY['Sun', 'Mon', 'Tue', 'Wed', 'Thu'],
  timezone TEXT DEFAULT 'Asia/Riyadh',
  language TEXT DEFAULT 'ar',
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  CONSTRAINT business_settings_business_id_unique UNIQUE(business_id)
);

CREATE INDEX IF NOT EXISTS idx_business_settings_business_id ON business_settings(business_id);

-- 3️⃣ جدول تحليلات المستخدمين
CREATE TABLE IF NOT EXISTS user_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  last_login_at TIMESTAMPTZ,
  total_logins INT DEFAULT 0,
  total_sessions INT DEFAULT 0,
  total_orders INT DEFAULT 0,
  
  total_time_spent_minutes INT DEFAULT 0,
  average_session_duration_minutes DECIMAL DEFAULT 0,
  most_active_time_of_day TEXT,
  most_active_day_of_week TEXT,
  
  ai_bot_interactions INT DEFAULT 0,
  doctor_sessions INT DEFAULT 0,
  pharmacy_orders INT DEFAULT 0,
  reports_submitted INT DEFAULT 0,
  
  chronic_conditions TEXT[],
  common_symptoms TEXT[],
  medication_count INT DEFAULT 0,
  
  preferred_language TEXT DEFAULT 'ar',
  device_type TEXT,
  app_version TEXT,
  
  total_spent DECIMAL DEFAULT 0,
  average_order_value DECIMAL DEFAULT 0,
  
  analytics_updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  CONSTRAINT user_analytics_user_id_unique UNIQUE(user_id)
);

CREATE INDEX IF NOT EXISTS idx_user_analytics_user_id ON user_analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_user_analytics_last_login ON user_analytics(last_login_at);

-- 4️⃣ جدول أرشيف الجلسات
CREATE TABLE IF NOT EXISTS session_archives (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  session_type TEXT NOT NULL CHECK (session_type IN ('ai_bot', 'doctor', 'pharmacy_consultation')),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES users(id) ON DELETE SET NULL,
  
  messages JSONB NOT NULL DEFAULT '[]',
  attachments TEXT[],
  
  session_duration_minutes INT,
  session_rating INT CHECK (session_rating BETWEEN 1 AND 5),
  user_feedback TEXT,
  
  session_status TEXT DEFAULT 'completed' CHECK (session_status IN ('completed', 'cancelled', 'interrupted')),
  session_outcome TEXT,
  follow_up_required BOOLEAN DEFAULT false,
  
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  archived_at TIMESTAMPTZ DEFAULT NOW(),
  
  metadata JSONB DEFAULT '{}',
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_session_archives_user_id ON session_archives(user_id);
CREATE INDEX IF NOT EXISTS idx_session_archives_type ON session_archives(session_type);
CREATE INDEX IF NOT EXISTS idx_session_archives_started_at ON session_archives(started_at);

-- 5️⃣ جدول الصفحات القانونية
CREATE TABLE IF NOT EXISTS legal_pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  page_type TEXT NOT NULL UNIQUE CHECK (page_type IN ('privacy_policy', 'terms_of_service', 'about_us', 'contact_us', 'faq')),
  
  title_ar TEXT NOT NULL,
  title_en TEXT,
  content_ar TEXT NOT NULL,
  content_en TEXT,
  
  version TEXT DEFAULT '1.0',
  is_published BOOLEAN DEFAULT true,
  last_reviewed_at TIMESTAMPTZ,
  
  meta_description_ar TEXT,
  meta_description_en TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO legal_pages (page_type, title_ar, content_ar, version) VALUES
('privacy_policy', 'سياسة الخصوصية', 'سياسة الخصوصية الخاصة بتطبيق معافى', '1.0'),
('terms_of_service', 'شروط الاستخدام', 'شروط وأحكام استخدام تطبيق معافى', '1.0'),
('about_us', 'عن معافى', 'معافى هو تطبيق صحي متكامل', '1.0'),
('contact_us', 'اتصل بنا', 'للتواصل معنا: support@muaafa.com', '1.0'),
('faq', 'الأسئلة الشائعة', 'الأسئلة الشائعة حول تطبيق معافى', '1.0')
ON CONFLICT (page_type) DO NOTHING;

-- 6️⃣ تفعيل RLS
ALTER TABLE business_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_archives ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal_pages ENABLE ROW LEVEL SECURITY;

-- 7️⃣ RLS Policies
CREATE POLICY "Owner full access permissions"
  ON business_permissions FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

CREATE POLICY "Owner full access settings"
  ON business_settings FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

CREATE POLICY "Owner full access analytics"
  ON user_analytics FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

CREATE POLICY "Owner view all archives"
  ON session_archives FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
    OR auth.uid() = user_id 
    OR auth.uid() = provider_id
  );

CREATE POLICY "Anyone view published pages"
  ON legal_pages FOR SELECT
  TO authenticated
  USING (is_published = true);

CREATE POLICY "Owner manage legal pages"
  ON legal_pages FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.user_role = 'owner'
    )
  );

GRANT ALL ON business_permissions TO authenticated;
GRANT ALL ON business_settings TO authenticated;
GRANT ALL ON user_analytics TO authenticated;
GRANT ALL ON session_archives TO authenticated;
GRANT ALL ON legal_pages TO authenticated;
