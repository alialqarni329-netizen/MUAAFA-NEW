/*
  # Add terms acceptance field to users table
  
  1. Changes
    - Add `terms_accepted` boolean field to `users` table
    - Add `terms_accepted_at` timestamp field to track when terms were accepted
    - Default value is false for `terms_accepted`
  
  2. Purpose
    - Track user acceptance of terms and conditions and privacy policy
    - Required for legal compliance and GDPR
*/

DO $$
BEGIN
  -- Add terms_accepted column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'terms_accepted'
  ) THEN
    ALTER TABLE users ADD COLUMN terms_accepted boolean DEFAULT false;
  END IF;

  -- Add terms_accepted_at column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'terms_accepted_at'
  ) THEN
    ALTER TABLE users ADD COLUMN terms_accepted_at timestamptz;
  END IF;
END $$;