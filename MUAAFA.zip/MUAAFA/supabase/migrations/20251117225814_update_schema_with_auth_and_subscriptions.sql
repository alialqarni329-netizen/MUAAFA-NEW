/*
  # تحديث قاعدة بيانات MOODi Health

  ## التعديلات على الجداول

  ### 1. تحديث جدول users
  - إضافة `gender` (text: 'male' or 'female')
  - إضافة `location` (text)

  ### 2. جدول subscriptions
  - `id` (uuid, primary key)
  - `user_id` (uuid, references users)
  - `plan_type` (text: 'trial', 'weekly', 'monthly', 'yearly')
  - `status` (text: 'active', 'expired', 'cancelled')
  - `start_date` (timestamptz)
  - `end_date` (timestamptz)
  - `trial_minutes_used` (integer, default 0)
  - `trial_day` (integer, default 1)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 3. جدول usage_logs
  - `id` (uuid, primary key)
  - `user_id` (uuid, references users)
  - `session_type` (text: 'chat', 'doctor', 'image_analysis')
  - `duration_seconds` (integer)
  - `created_at` (timestamptz)

  ### 4. جدول image_analysis
  - `id` (uuid, primary key)
  - `user_id` (uuid, references users)
  - `image_url` (text)
  - `analysis_result` (text)
  - `body_part` (text)
  - `created_at` (timestamptz)

  ## الأمان
  - RLS على جميع الجداول الجديدة
  - سياسات للوصول الآمن
*/

-- تحديث جدول users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'gender'
  ) THEN
    ALTER TABLE users ADD COLUMN gender text CHECK (gender IN ('male', 'female'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'location'
  ) THEN
    ALTER TABLE users ADD COLUMN location text DEFAULT '';
  END IF;
END $$;

-- إنشاء جدول subscriptions
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_type text NOT NULL CHECK (plan_type IN ('trial', 'weekly', 'monthly', 'yearly')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'cancelled')),
  start_date timestamptz DEFAULT now(),
  end_date timestamptz,
  trial_minutes_used integer DEFAULT 0,
  trial_day integer DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subscriptions"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own subscriptions"
  ON subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own subscriptions"
  ON subscriptions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- إنشاء جدول usage_logs
CREATE TABLE IF NOT EXISTS usage_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_type text NOT NULL CHECK (session_type IN ('chat', 'doctor', 'image_analysis')),
  duration_seconds integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE usage_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own usage logs"
  ON usage_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create usage logs"
  ON usage_logs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- إنشاء جدول image_analysis
CREATE TABLE IF NOT EXISTS image_analysis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  analysis_result text,
  body_part text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE image_analysis ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own image analyses"
  ON image_analysis FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create image analyses"
  ON image_analysis FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own image analyses"
  ON image_analysis FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- إنشاء indexes
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_usage_logs_user_id ON usage_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_image_analysis_user_id ON image_analysis(user_id);
