import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const zoomAccountId = Deno.env.get("ZOOM_ACCOUNT_ID");
    const zoomClientId = Deno.env.get("ZOOM_CLIENT_ID");
    const zoomClientSecret = Deno.env.get("ZOOM_CLIENT_SECRET");

    const results: any = {
      keysConfigured: false,
      keysValid: false,
      connectionSuccess: false,
      errors: [],
      details: {}
    };

    if (!zoomAccountId || !zoomClientId || !zoomClientSecret) {
      results.errors.push("Missing Zoom credentials in environment variables");
      return new Response(
        JSON.stringify(results),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    if (zoomAccountId.includes("your_") || zoomClientId.includes("your_") || zoomClientSecret.includes("your_")) {
      results.errors.push("Zoom credentials contain placeholder values (your_...). Please update with real values.");
      results.details.accountId = zoomAccountId.includes("your_") ? "Placeholder detected" : "OK";
      results.details.clientId = zoomClientId.includes("your_") ? "Placeholder detected" : "OK";
      results.details.clientSecret = zoomClientSecret.includes("your_") ? "Placeholder detected" : "OK";
      return new Response(
        JSON.stringify(results),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    results.keysConfigured = true;
    results.details.accountId = `${zoomAccountId.substring(0, 4)}...${zoomAccountId.substring(zoomAccountId.length - 4)}`;
    results.details.clientId = `${zoomClientId.substring(0, 4)}...${zoomClientId.substring(zoomClientId.length - 4)}`;

    try {
      const tokenResponse = await fetch("https://zoom.us/oauth/token?grant_type=account_credentials&account_id=" + zoomAccountId, {
        method: "POST",
        headers: {
          "Authorization": "Basic " + btoa(`${zoomClientId}:${zoomClientSecret}`),
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });

      if (!tokenResponse.ok) {
        const errorData = await tokenResponse.text();
        results.errors.push(`Zoom OAuth failed: ${errorData}`);
        results.details.oauthError = errorData;
        return new Response(
          JSON.stringify(results),
          {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
          }
        );
      }

      const tokenData = await tokenResponse.json();
      results.keysValid = true;
      results.details.accessToken = "Successfully obtained";

      const testResponse = await fetch("https://api.zoom.us/v2/users/me", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${tokenData.access_token}`,
        },
      });

      if (testResponse.ok) {
        const userData = await testResponse.json();
        results.connectionSuccess = true;
        results.details.userEmail = userData.email;
        results.details.accountType = userData.type;
      } else {
        const errorData = await testResponse.text();
        results.errors.push(`Zoom API test failed: ${errorData}`);
      }
    } catch (error: any) {
      results.errors.push(`Connection error: ${error.message}`);
    }

    return new Response(
      JSON.stringify(results),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({
        keysConfigured: false,
        keysValid: false,
        connectionSuccess: false,
        errors: [error.message],
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});