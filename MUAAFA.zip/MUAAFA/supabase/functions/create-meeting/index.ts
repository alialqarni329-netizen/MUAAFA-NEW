import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface MeetingRequest {
  appointmentId: string;
  platform: "zoom" | "teams";
  scheduledDate: string;
  scheduledTime: string;
  duration: number;
  topic: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data: { user } } = await supabaseClient.auth.getUser(token);

    if (!user) {
      throw new Error("Unauthorized");
    }

    const { appointmentId, platform, scheduledDate, scheduledTime, duration, topic }: MeetingRequest = await req.json();

    let meetingData;

    if (platform === "zoom") {
      meetingData = await createZoomMeeting({
        topic,
        startTime: `${scheduledDate}T${scheduledTime}`,
        duration,
      });
    } else if (platform === "teams") {
      meetingData = await createTeamsMeeting({
        subject: topic,
        startTime: `${scheduledDate}T${scheduledTime}`,
        duration,
      });
    } else {
      throw new Error("Unsupported platform");
    }

    const { error: updateError } = await supabaseClient
      .from("appointments")
      .update({
        meeting_platform: platform,
        meeting_url: meetingData.join_url,
        meeting_id: meetingData.id,
        meeting_password: meetingData.password,
        status: 'scheduled',
        updated_at: new Date().toISOString(),
      })
      .eq("id", appointmentId)
      .eq("user_id", user.id);

    if (updateError) {
      throw updateError;
    }

    return new Response(
      JSON.stringify({
        success: true,
        meeting: meetingData,
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

async function createZoomMeeting(params: { topic: string; startTime: string; duration: number }) {
  const zoomAccountId = Deno.env.get("ZOOM_ACCOUNT_ID");
  const zoomClientId = Deno.env.get("ZOOM_CLIENT_ID");
  const zoomClientSecret = Deno.env.get("ZOOM_CLIENT_SECRET");

  if (!zoomAccountId || !zoomClientId || !zoomClientSecret ||
      zoomAccountId.includes("your_") || zoomClientId.includes("your_") || zoomClientSecret.includes("your_")) {
    console.log("Zoom credentials not configured, returning demo link");
    return {
      join_url: `https://zoom.us/j/demo-meeting-${Date.now()}`,
      id: `demo-${Date.now()}`,
      password: "123456",
    };
  }

  try {
    const tokenResponse = await fetch("https://zoom.us/oauth/token?grant_type=account_credentials&account_id=" + zoomAccountId, {
      method: "POST",
      headers: {
        "Authorization": "Basic " + btoa(`${zoomClientId}:${zoomClientSecret}`),
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });

    if (!tokenResponse.ok) {
      const errorData = await tokenResponse.text();
      console.error("Zoom OAuth Error:", errorData);
      throw new Error("Failed to get Zoom access token");
    }

    const tokenData = await tokenResponse.json();
    const accessToken = tokenData.access_token;

    const response = await fetch("https://api.zoom.us/v2/users/me/meetings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        topic: params.topic,
        type: 2,
        start_time: params.startTime,
        duration: params.duration,
        timezone: "Asia/Riyadh",
        settings: {
          host_video: true,
          participant_video: true,
          join_before_host: true,
          mute_upon_entry: false,
          watermark: false,
          audio: "both",
          auto_recording: "none",
        },
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error("Zoom API Error:", errorData);
      throw new Error(`Failed to create Zoom meeting: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Error creating Zoom meeting:", error);
    return {
      join_url: `https://zoom.us/j/demo-meeting-${Date.now()}`,
      id: `demo-${Date.now()}`,
      password: "123456",
    };
  }
}

async function createTeamsMeeting(params: { subject: string; startTime: string; duration: number }) {
  const teamsAccessToken = Deno.env.get("TEAMS_ACCESS_TOKEN");

  if (!teamsAccessToken) {
    return {
      join_url: `https://teams.microsoft.com/l/meetup-join/demo-${Date.now()}`,
      id: `demo-teams-${Date.now()}`,
      password: "N/A",
    };
  }

  try {
    const endTime = new Date(new Date(params.startTime).getTime() + params.duration * 60000).toISOString();

    const response = await fetch("https://graph.microsoft.com/v1.0/me/onlineMeetings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${teamsAccessToken}`,
      },
      body: JSON.stringify({
        subject: params.subject,
        startDateTime: params.startTime,
        endDateTime: endTime,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error("Teams API Error:", errorData);
      throw new Error(`Failed to create Teams meeting: ${response.status}`);
    }

    const data = await response.json();
    return {
      join_url: data.joinUrl,
      id: data.id,
      password: "N/A",
    };
  } catch (error) {
    console.error("Error creating Teams meeting:", error);
    return {
      join_url: `https://teams.microsoft.com/l/meetup-join/demo-${Date.now()}`,
      id: `demo-teams-${Date.now()}`,
      password: "N/A",
    };
  }
}