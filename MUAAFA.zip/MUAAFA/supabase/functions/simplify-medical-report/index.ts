import 'jsr:@supabase/functions-js/edge-runtime.d.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface SimplifyRequest {
  documentId: string;
  reportText: string;
  reportType?: string;
  language?: 'ar' | 'en';
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { documentId, reportText, reportType = 'general', language = 'ar' }: SimplifyRequest = await req.json();

    if (!reportText) {
      throw new Error('Report text is required');
    }

    const prompt = language === 'ar'
      ? `أنت طبيب متخصص. اقرأ التقرير الطبي التالي واشرحه بلغة بسيطة ومفهومة للمريض العادي. اذكر:
1. ما هي النتائج الرئيسية؟
2. هل النتائج طبيعية أم تحتاج متابعة؟
3. ما هي التوصيات إن وجدت؟
4. اشرح المصطلحات الطبية الصعبة

التقرير الطبي:
${reportText}

الملخص المبسط:`
      : `You are a medical specialist. Read the following medical report and explain it in simple, understandable language for an average patient. Mention:
1. What are the main findings?
2. Are the results normal or do they need follow-up?
3. What are the recommendations if any?
4. Explain difficult medical terms

Medical Report:
${reportText}

Simplified Summary:`;

    // استخدام OpenAI API (يجب إضافة API Key في environment variables)
    const openaiKey = Deno.env.get('OPENAI_API_KEY');
    
    if (!openaiKey) {
      // إذا لم يكن هناك مفتاح، نرجع ملخص بسيط
      const simpleSummary = language === 'ar'
        ? `📋 ملخص التقرير الطبي:\n\nهذا تقرير طبي يحتوي على نتائج فحوصات. للحصول على شرح مفصل، يُرجى استشارة طبيبك المختص.\n\nالمصطلحات الرئيسية في التقرير:\n${extractKeyTerms(reportText)}\n\nملاحظة: يُنصح بمراجعة الطبيب لفهم النتائج بشكل كامل.`
        : `📋 Medical Report Summary:\n\nThis is a medical report containing test results. For detailed explanation, please consult your doctor.\n\nKey terms in the report:\n${extractKeyTerms(reportText)}\n\nNote: It is recommended to consult with your doctor for full understanding.`;
      
      return new Response(
        JSON.stringify({
          documentId,
          summary: simpleSummary,
          keyTerms: extractKeyTerms(reportText),
          timestamp: new Date().toISOString(),
        }),
        {
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    // استدعاء OpenAI API
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: language === 'ar'
              ? 'أنت طبيب متخصص تساعد المرضى على فهم تقاريرهم الطبية بلغة بسيطة ومفهومة.'
              : 'You are a medical specialist helping patients understand their medical reports in simple language.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });

    if (!openaiResponse.ok) {
      throw new Error('Failed to get AI response');
    }

    const aiData = await openaiResponse.json();
    const summary = aiData.choices[0]?.message?.content || 'No summary available';

    return new Response(
      JSON.stringify({
        documentId,
        summary,
        keyTerms: extractKeyTerms(reportText),
        timestamp: new Date().toISOString(),
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error: any) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({
        error: error.message || 'Failed to simplify medical report',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

function extractKeyTerms(text: string): string[] {
  // استخراج المصطلحات الطبية الرئيسية
  const medicalTermsPattern = /\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b/g;
  const terms = text.match(medicalTermsPattern) || [];
  return [...new Set(terms)].slice(0, 10);
}
