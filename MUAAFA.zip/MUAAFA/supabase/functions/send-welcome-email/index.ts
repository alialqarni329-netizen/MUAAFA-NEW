import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface WelcomeEmailRequest {
  userId: string;
  language?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const { userId, language = 'ar' }: WelcomeEmailRequest = await req.json();

    const { data: userData, error: userError } = await supabaseClient.auth.admin.getUserById(userId);

    if (userError || !userData.user) {
      throw new Error("User not found");
    }

    const user = userData.user;
    const userName = user.user_metadata?.full_name || user.email?.split('@')[0] || 'عزيزي المستخدم';
    const userEmail = user.email;

    if (!userEmail) {
      throw new Error("User email not found");
    }

    const { data: template, error: templateError } = await supabaseClient
      .from('email_templates')
      .select('*')
      .eq('template_key', 'welcome_email')
      .eq('is_active', true)
      .maybeSingle();

    if (templateError || !template) {
      throw new Error("Welcome email template not found");
    }

    const subject = language === 'ar' ? template.subject_ar : template.subject_en;
    let body = language === 'ar' ? template.body_ar : template.body_en;

    body = body.replace(/{{user_name}}/g, userName);

    const { error: logError } = await supabaseClient
      .from('email_logs')
      .insert({
        user_id: userId,
        template_key: 'welcome_email',
        recipient_email: userEmail,
        subject: subject,
        body: body,
        status: 'pending',
        metadata: {
          user_name: userName,
          language: language,
          trigger_type: 'manual',
        },
      });

    if (logError) {
      console.error('Error logging email:', logError);
    }

    const { error: notificationError } = await supabaseClient
      .from('app_notifications')
      .insert({
        user_id: userId,
        type: 'welcome',
        title: language === 'ar' ? 'مرحباً بك في مُعافى!' : 'Welcome to Muaafa!',
        body: language === 'ar'
          ? 'نحن سعداء بانضمامك. ابدأ رحلتك الصحية الآن!'
          : 'We are happy to have you. Start your health journey now!',
        data: { screen: 'home' },
      });

    if (notificationError) {
      console.error('Error creating notification:', notificationError);
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Welcome email logged and notification sent',
        email: {
          to: userEmail,
          subject: subject,
        },
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error: any) {
    console.error('Error in send-welcome-email:', error);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
