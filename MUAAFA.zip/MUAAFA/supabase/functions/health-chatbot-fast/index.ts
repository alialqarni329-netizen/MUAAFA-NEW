import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SYSTEM_PROMPT = `أنت "الطبيب الذكي" بتطبيق مُعافى - مساعد صحي تثقيفي.

ممنوع: تشخيص، وصف علاج، جرعات
مسموح: معلومات عامة، نصائح صحية

رد مختصر (2-3 جمل فقط)
تنويه: "⚠️ معلومات عامة. راجع طبيب للحالات الخاصة"
طوارئ: "🚨 اتصل 997 فوراً!"`;

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const startTime = Date.now();

  try {
    const { messages, userId } = await req.json();
    const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!openaiApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'user_id_required', message: 'يجب تسجيل الدخول' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl!, supabaseServiceKey!);
    const userIp = req.headers.get('x-forwarded-for') || '0.0.0.0';

    const rateLimitCheck = await supabase.rpc('check_rate_limit', {
      p_user_id: userId,
      p_ip_address: userIp
    });

    if (rateLimitCheck.data?.allowed === false) {
      return new Response(
        JSON.stringify({ error: 'rate_limit_exceeded', message: 'تجاوزت الحد المسموح' }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const dailyLimitCheck = await supabase.rpc('check_user_daily_limit', {
      p_user_id: userId
    });

    if (dailyLimitCheck.data?.allowed === false) {
      return new Response(
        JSON.stringify({
          error: 'daily_limit_exceeded',
          message: dailyLimitCheck.data.message,
          messages_used: dailyLimitCheck.data.messages_used
        }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const userMessage = messages[messages.length - 1].content;
    const queryHash = await generateHash(userMessage);

    const cachedResponse = await supabase.rpc('get_cached_response', {
      p_query_hash: queryHash
    });

    if (cachedResponse.data?.cached === true) {
      const responseTime = Date.now() - startTime;

      await logBotUsage(supabase, {
        userId,
        userMessage,
        botResponse: cachedResponse.data.response,
        tokensUsed: 0,
        responseTime,
        cached: true,
        ipAddress: userIp
      });

      return new Response(
        JSON.stringify({
          message: cachedResponse.data.response,
          cached: true,
          warning: dailyLimitCheck.data?.warning ? dailyLimitCheck.data.warning_message : null,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let messagesToSend: ChatMessage[] = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...messages
    ];

    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: messagesToSend,
        temperature: 0.3,
        max_tokens: 150,
        top_p: 0.85,
        frequency_penalty: 0.2,
        presence_penalty: 0.2,
      }),
    });

    if (!openaiResponse.ok) {
      throw new Error('OpenAI API error');
    }

    const data = await openaiResponse.json();
    const assistantMessage = data.choices[0].message.content;
    const tokensUsed = data.usage?.total_tokens || 150;

    await supabase.rpc('increment_user_message_count', {
      p_user_id: userId,
      p_tokens_used: tokensUsed
    });

    await supabase.from('bot_response_cache').insert({
      query_hash: queryHash,
      user_query: userMessage,
      bot_response: assistantMessage,
      expires_at: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString()
    });

    const responseTime = Date.now() - startTime;

    await logBotUsage(supabase, {
      userId,
      userMessage,
      botResponse: assistantMessage,
      tokensUsed,
      responseTime,
      cached: false,
      ipAddress: userIp
    });

    return new Response(
      JSON.stringify({
        message: assistantMessage,
        cached: false,
        warning: dailyLimitCheck.data?.warning ? dailyLimitCheck.data.warning_message : null,
        messages_remaining: dailyLimitCheck.data?.messages_remaining,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message, message: 'حدث خطأ، يرجى المحاولة مرة أخرى' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

async function generateHash(text: string): Promise<string> {
  const normalized = text.toLowerCase().trim().replace(/\s+/g, ' ');
  const encoder = new TextEncoder();
  const data = encoder.encode(normalized);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function logBotUsage(
  supabase: any,
  params: {
    userId: string;
    userMessage: string;
    botResponse: string;
    tokensUsed: number;
    responseTime: number;
    cached: boolean;
    ipAddress: string;
  }
) {
  try {
    await supabase.from('bot_usage_logs').insert({
      user_id: params.userId,
      user_message: params.userMessage,
      bot_response: params.botResponse,
      tokens_used: params.tokensUsed,
      response_time_ms: params.responseTime,
      cached: params.cached,
      ip_address: params.ipAddress,
      cost_estimate: params.cached ? 0 : (params.tokensUsed * 0.0001 / 1000)
    });
  } catch (error) {
    console.error('Log error:', error);
  }
}
