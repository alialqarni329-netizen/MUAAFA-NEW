import 'jsr:@supabase/functions-js/edge-runtime.d.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface PrescriptionAnalysisRequest {
  image: string;
}

function getDemoAnalysis() {
  return {
    doctor_name: 'د. أحمد محمد',
    clinic_name: 'عيادة الرعاية الصحية',
    date: new Date().toISOString().split('T')[0],
    medications: [
      {
        name: 'باراسيتامول 500 ملجم',
        dosage: '500 ملجم',
        frequency: '3 مرات يومياً',
        duration: '5 أيام',
      },
      {
        name: 'أموكسيسيلين 500 ملجم',
        dosage: '500 ملجم',
        frequency: 'مرتين يومياً',
        duration: '7 أيام',
      },
    ],
    notes: 'تناول الدواء بعد الأكل. أكمل الكورس العلاجي كاملاً.',
    demo_mode: true,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { image }: PrescriptionAnalysisRequest = await req.json();

    if (!image) {
      return new Response(
        JSON.stringify({
          error: 'MISSING_IMAGE',
          message: 'الصورة مطلوبة',
        }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const openaiKey = Deno.env.get('OPENAI_API_KEY');

    if (!openaiKey) {
      console.log('OpenAI API Key not found, using demo mode');

      return new Response(
        JSON.stringify({
          success: true,
          analysis: getDemoAnalysis(),
          timestamp: new Date().toISOString(),
          mode: 'demo',
          message: 'تم استخدام النظام التجريبي - هذه بيانات تجريبية لعرض كيفية عمل الميزة',
        }),
        {
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `أنت مساعد طبي متخصص في قراءة وتحليل الوصفات الطبية. قم بتحليل الوصفة الطبية المرفقة واستخرج المعلومات التالية بدقة:

1. اسم المريض (إن وجد)
2. اسم الطبيب والتخصص
3. تاريخ الوصفة
4. قائمة الأدوية الموصوفة مع التفاصيل:
   - اسم الدواء
   - الجرعة (Dosage)
   - عدد المرات يومياً
   - المدة (Duration)
   - التعليمات الخاصة

5. ملاحظات إضافية أو تحذيرات

قدم النتيجة بتنسيق JSON واضح ومنظم باللغة العربية.`,
          },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'قم بتحليل هذه الوصفة الطبية واستخراج جميع المعلومات المهمة',
              },
              {
                type: 'image_url',
                image_url: {
                  url: image,
                },
              },
            ],
          },
        ],
        temperature: 0.2,
        max_tokens: 2000,
      }),
    });

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text();
      console.error('OpenAI API Error:', errorText);

      return new Response(
        JSON.stringify({
          error: 'OPENAI_API_ERROR',
          message: `فشل استدعاء OpenAI API: ${openaiResponse.status}`,
          details: errorText,
        }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const aiData = await openaiResponse.json();
    const analysisText = aiData.choices[0]?.message?.content || '';

    let parsedAnalysis;
    try {
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsedAnalysis = JSON.parse(jsonMatch[0]);
      } else {
        parsedAnalysis = {
          rawText: analysisText,
          medications: [],
        };
      }
    } catch (parseError) {
      parsedAnalysis = {
        rawText: analysisText,
        medications: [],
      };
    }

    return new Response(
      JSON.stringify({
        success: true,
        analysis: parsedAnalysis,
        timestamp: new Date().toISOString(),
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error: any) {
    console.error('Error analyzing prescription:', error);

    return new Response(
      JSON.stringify({
        error: 'INTERNAL_ERROR',
        message: 'حدث خطأ أثناء تحليل الوصفة الطبية',
        details: error.message || 'Unknown error',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});