import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BriefRequest {
  appointmentId: string;
  includeChat: boolean;
  includeFitness: boolean;
  includeMedicalHistory: boolean;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data: { user } } = await supabaseClient.auth.getUser(token);

    if (!user) {
      throw new Error("Unauthorized");
    }

    const { appointmentId, includeChat, includeFitness, includeMedicalHistory }: BriefRequest = await req.json();

    const briefData: any = {
      user_id: user.id,
      appointment_id: appointmentId,
      recent_conversations: [],
      main_concerns: [],
      latest_vitals: {},
      current_medications: [],
      allergies: [],
      chronic_conditions: [],
    };

    if (includeChat) {
      const { data: chatData } = await supabaseClient
        .from("chat_messages")
        .select("content, sender_type, created_at")
        .eq("conversation_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (chatData) {
        briefData.recent_conversations = chatData;
        briefData.main_concerns = extractMainConcerns(chatData);
      }
    }

    if (includeFitness) {
      const { data: fitnessData } = await supabaseClient
        .from("fitness_activities")
        .select("*")
        .eq("user_id", user.id)
        .order("activity_date", { ascending: false })
        .limit(7);

      if (fitnessData && fitnessData.length > 0) {
        const latest = fitnessData[0];
        briefData.latest_vitals = {
          steps: latest.steps,
          heart_rate: latest.heart_rate_avg,
          sleep_hours: latest.sleep_hours,
          calories_burned: latest.calories_burned,
        };
        briefData.fitness_summary = generateFitnessSummary(fitnessData);
      }
    }

    if (includeMedicalHistory) {
      const { data: medicalData } = await supabaseClient
        .from("medical_questionnaire")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (medicalData) {
        briefData.current_medications = medicalData.current_medications || [];
        briefData.allergies = medicalData.allergies || [];
        briefData.chronic_conditions = medicalData.chronic_diseases || [];
      }
    }

    briefData.ai_summary = generateAISummary(briefData);
    briefData.summary_generated_at = new Date().toISOString();

    const { data: insertedBrief, error: insertError } = await supabaseClient
      .from("medical_briefs")
      .insert(briefData)
      .select()
      .single();

    if (insertError) {
      throw insertError;
    }

    const { error: updateError } = await supabaseClient
      .from("appointments")
      .update({
        medical_brief_sent: true,
        medical_brief_id: insertedBrief.id,
      })
      .eq("id", appointmentId)
      .eq("user_id", user.id);

    if (updateError) {
      throw updateError;
    }

    return new Response(
      JSON.stringify({
        success: true,
        brief: insertedBrief,
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

function extractMainConcerns(chatData: any[]): string[] {
  const concerns = new Set<string>();
  const keywords = ["ألم", "صداع", "حمى", "سعال", "غثيان", "دوخة", "pain", "headache", "fever", "cough"];

  chatData.forEach((msg) => {
    if (msg.sender_type === "user") {
      keywords.forEach((keyword) => {
        if (msg.content.toLowerCase().includes(keyword)) {
          concerns.add(keyword);
        }
      });
    }
  });

  return Array.from(concerns);
}

function generateFitnessSummary(fitnessData: any[]): string {
  const avgSteps = fitnessData.reduce((sum, d) => sum + (d.steps || 0), 0) / fitnessData.length;
  const avgSleep = fitnessData.reduce((sum, d) => sum + (d.sleep_hours || 0), 0) / fitnessData.length;
  
  return `متوسط الخطوات: ${Math.round(avgSteps)} خطوة/يوم. متوسط النوم: ${avgSleep.toFixed(1)} ساعة/يوم.`;
}

function generateAISummary(briefData: any): string {
  const concerns = briefData.main_concerns.join("، ");
  const meds = briefData.current_medications.length > 0 
    ? `الأدوية الحالية: ${briefData.current_medications.join("، ")}` 
    : "لا يوجد أدوية حالية";
  
  const allergies = briefData.allergies.length > 0
    ? `حساسية: ${briefData.allergies.join("، ")}`
    : "لا توجد حساسية معروفة";

  return `الشكاوى الرئيسية: ${concerns || "لا توجد"}. ${meds}. ${allergies}. ${briefData.fitness_summary || ""}`;
}