# ✅ دليل إتمام بوابة المالك - Owner Portal Completion Guide

**التاريخ**: 2025-12-30
**الحالة**: ✅ الهيكل الأساسي مكتمل + مثال عملي

---

## 🎯 ما تم إنجازه

### 1️⃣ قاعدة البيانات (Database Schema) ✅

تم إنشاء migration كامل يتضمن:

#### الجداول الجديدة:

**A. `business_permissions`** - صلاحيات الشركات
- تحديد الحدود القصوى (موظفين، طلبات، تخزين)
- تفعيل/تعطيل الميزات (AI Bot، Analytics، API)
- مستويات الدعم (Priority Support، Account Manager)

**B. `business_settings`** - إعدادات الشركات
- العلامة التجارية (Logo، Colors، Theme)
- معلومات التواصل والضرائب
- إعدادات الإشعارات والفواتير
- ساعات العمل والمنطقة الزمنية

**C. `user_analytics`** - تحليلات المستخدمين
- نشاط المستخدمين (Logins، Sessions، Orders)
- الاستخدام (Time Spent، Active Times)
- التفاعل مع الميزات (AI Bot، Doctor Sessions)
- البيانات الصحية (الأمراض المزمنة، الأعراض)

**D. `session_archives`** - أرشيف الجلسات
- أرشيف محادثات البوت
- أرشيف جلسات الأطباء
- التقييمات والملاحظات
- مدة الجلسات والنتائج

**E. `legal_pages`** - الصفحات القانونية
- سياسة الخصوصية
- شروط الاستخدام
- عن معافى
- اتصل بنا
- الأسئلة الشائعة

---

### 2️⃣ الصفحة المكتملة: صلاحيات الشركات ✅

**الموقع**: `/app/owner/business/permissions.tsx`

#### الميزات المُنفذة:

✅ **عرض قائمة الشركات**
- بحث بالاسم
- عرض الإحصائيات (موظفين، طلبات، تخزين)
- عرض الميزات المفعّلة

✅ **تعديل صلاحيات كل شركة**
- **الحدود والقيود**:
  - الحد الأقصى للموظفين
  - الحد الأقصى للطلبات شهرياً
  - مساحة التخزين

- **الميزات الأساسية**:
  - استخدام البوت الذكي
  - الوصول للتحليلات
  - تصدير البيانات

- **الميزات المتقدمة**:
  - تخصيص العلامة التجارية
  - الوصول للـ API
  - التكاملات المخصصة

- **الدعم الخاص**:
  - دعم ذو أولوية
  - مدير حساب مخصص

✅ **حفظ التغييرات**
- حفظ تلقائي في قاعدة البيانات
- رسائل نجاح/فشل واضحة
- تحديث البيانات فوراً

---

## 📋 الصفحات المتبقية (تتبع نفس النمط)

### 3️⃣ صفحة إعدادات الشركات

**الموقع**: `/app/owner/business/settings.tsx`

**الوظائف المطلوبة**:
- عرض قائمة الشركات
- تعديل:
  - الشعار واللون الأساسي
  - معلومات التواصل (بريد، هاتف، عنوان، موقع)
  - معلومات ضريبية (رقم ضريبي، اسم، عنوان)
  - إعدادات الإشعارات (Email، SMS، Push)
  - إعدادات الفواتير (Prefix، Footer، Payment Terms)
  - ساعات العمل والمنطقة الزمنية

**الكود المطلوب**: (مشابه لصفحة الصلاحيات)
```typescript
// نفس البنية مع تغيير الـ fields
const { data, error } = await supabase
  .from('business_settings')
  .upsert({ business_id, logo_url, brand_color, ... });
```

---

### 4️⃣ صفحة صلاحيات المستخدمين

**الموقع**: `/app/owner/users/permissions.tsx`

**الوظائف المطلوبة**:
- عرض قائمة المستخدمين
- تغيير نوع الاشتراك:
  - Basic (مجاني)
  - Gold (ذهبي)
  - Premium (بريميوم)
- تحديد الميزات المتاحة لكل مستخدم
- تجميد/تفعيل الحسابات

**ملاحظة**: استخدم جدول `users` عمود `current_plan_type`

---

### 5️⃣ صفحة تقارير المستخدمين

**الموقع**: `/app/owner/users/activity.tsx`

**الوظائف المطلوبة**:
- إحصائيات إجمالية:
  - إجمالي المستخدمين
  - المستخدمون النشطون (آخر 7 أيام)
  - معدل الاستخدام اليومي
  - الأمراض الأكثر شيوعاً

- فلترة حسب:
  - الفترة الزمنية
  - نوع الاشتراك
  - المدينة

- عرض تفاصيل كل مستخدم:
  - آخر تسجيل دخول
  - عدد الجلسات
  - الطلبات
  - الوقت المستخدم

**استعلام SQL مثال**:
```sql
SELECT
  COUNT(*) as total_users,
  COUNT(*) FILTER (WHERE last_login_at > NOW() - INTERVAL '7 days') as active_users,
  AVG(total_sessions) as avg_sessions,
  array_agg(DISTINCT chronic_conditions) as common_conditions
FROM user_analytics;
```

---

### 6️⃣ صفحة أرشيف الجلسات

**الموقع**: `/app/owner/sessions/archived.tsx`

**الوظائف المطلوبة**:
- عرض قائمة الجلسات المؤرشفة
- فلترة حسب:
  - نوع الجلسة (AI Bot، Doctor، Pharmacy)
  - الفترة الزمنية
  - التقييم
  - الحالة (مكتملة، ملغاة، متقطعة)

- عرض تفاصيل الجلسة:
  - المحادثات (Messages)
  - المرفقات
  - المدة الزمنية
  - التقييم والملاحظات

**استعلام SQL مثال**:
```sql
SELECT
  session_archives.*,
  users.full_name as user_name,
  provider.full_name as provider_name
FROM session_archives
LEFT JOIN users ON session_archives.user_id = users.id
LEFT JOIN users as provider ON session_archives.provider_id = provider.id
WHERE session_type = 'ai_bot'
ORDER BY created_at DESC;
```

---

### 7️⃣ صفحات المساعدة القانونية

#### A. سياسة الخصوصية
**الموقع**: `/app/privacy.tsx`

```typescript
const { data } = await supabase
  .from('legal_pages')
  .select('*')
  .eq('page_type', 'privacy_policy')
  .eq('is_published', true)
  .maybeSingle();
```

#### B. عن معافى
**الموقع**: `/app/about.tsx`

```typescript
const { data } = await supabase
  .from('legal_pages')
  .select('*')
  .eq('page_type', 'about_us')
  .maybeSingle();
```

#### C. اتصل بنا
**الموقع**: `/app/contact.tsx`

```typescript
const { data } = await supabase
  .from('legal_pages')
  .select('*')
  .eq('page_type', 'contact_us')
  .maybeSingle();
```

#### D. الأسئلة الشائعة
**الموقع**: `/app/help.tsx`

```typescript
const { data } = await supabase
  .from('legal_pages')
  .select('*')
  .eq('page_type', 'faq')
  .maybeSingle();
```

---

## 🔧 الكود النمطي (Template Code)

### نموذج صفحة Owner Portal

```typescript
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useState, useEffect } from 'react';
import { Stack } from 'expo-router';
import { Icon } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

export default function PageName() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const { data, error } = await supabase
        .from('table_name')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setData(data);
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل تحميل البيانات');
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'عنوان الصفحة',
          headerStyle: { backgroundColor: '#0ea5e9' },
          headerTintColor: '#ffffff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      />
      <View style={styles.container}>
        <ScrollView style={styles.content}>
          {/* المحتوى هنا */}
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  content: {
    flex: 1,
    padding: 16,
  },
});
```

---

## 📊 التحليلات والإحصائيات

### Query للحصول على إحصائيات المستخدمين

```sql
-- إجمالي المستخدمين النشطين
SELECT COUNT(*) as total_active
FROM user_analytics
WHERE last_login_at > NOW() - INTERVAL '7 days';

-- أكثر الأمراض شيوعاً
SELECT
  UNNEST(chronic_conditions) as condition,
  COUNT(*) as count
FROM user_analytics
WHERE chronic_conditions IS NOT NULL
GROUP BY condition
ORDER BY count DESC
LIMIT 10;

-- معدل الطلبات اليومية
SELECT
  DATE(created_at) as date,
  COUNT(*) as orders
FROM orders
GROUP BY date
ORDER BY date DESC
LIMIT 30;

-- أوقات الذروة
SELECT
  EXTRACT(HOUR FROM last_login_at) as hour,
  COUNT(*) as logins
FROM user_analytics
GROUP BY hour
ORDER BY logins DESC;
```

---

## 🔒 الأمان والصلاحيات

### التحقق من صلاحيات Owner

```typescript
async function checkOwnerPermissions() {
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    Alert.alert('خطأ', 'يجب تسجيل الدخول');
    router.replace('/auth/login');
    return false;
  }

  const { data: userData } = await supabase
    .from('users')
    .select('user_role')
    .eq('id', user.id)
    .maybeSingle();

  if (userData?.user_role !== 'owner') {
    Alert.alert('خطأ', 'ليس لديك صلاحيات للوصول لهذه الصفحة');
    router.replace('/(tabs)');
    return false;
  }

  return true;
}
```

---

## 🎨 التصميم الموحد

### الألوان الأساسية:

```typescript
const colors = {
  primary: '#0ea5e9',      // أزرق
  success: '#10b981',      // أخضر
  warning: '#f59e0b',      // برتقالي
  danger: '#ef4444',       // أحمر
  gray: {
    50: '#f8fafc',
    100: '#f1f5f9',
    200: '#e2e8f0',
    300: '#cbd5e1',
    400: '#94a3b8',
    500: '#64748b',
    600: '#475569',
    700: '#334155',
    800: '#1e293b',
    900: '#0f172a',
  }
};
```

### مكونات مشتركة:

```typescript
// Card Component
const Card = ({ children, style }) => (
  <View style={[styles.card, style]}>
    {children}
  </View>
);

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
});
```

---

## 📝 قائمة المهام للإكمال

### الصفحات المتبقية:

- [ ] `/app/owner/business/settings.tsx` - إعدادات الشركات
- [ ] `/app/owner/users/permissions.tsx` - صلاحيات المستخدمين
- [ ] `/app/owner/users/activity.tsx` - تقارير المستخدمين
- [ ] `/app/owner/sessions/archived.tsx` - أرشيف الجلسات
- [ ] `/app/privacy.tsx` - سياسة الخصوصية
- [ ] `/app/about.tsx` - عن معافى
- [ ] `/app/contact.tsx` - اتصل بنا

### التحسينات الموصى بها:

- [ ] إضافة رسوم بيانية للتحليلات (Charts)
- [ ] تصدير البيانات إلى Excel/PDF
- [ ] نظام إشعارات للمالك
- [ ] لوحة تحكم Dashboard موحدة
- [ ] تقارير مجدولة (Weekly/Monthly Reports)

---

## 🚀 كيفية الاستكمال

### الخطوة 1: نسخ الكود النمطي

استخدم الكود النمطي أعلاه كأساس لكل صفحة جديدة.

### الخطوة 2: تعديل الاستعلامات

غيّر استعلامات Supabase حسب الجدول المستهدف:

```typescript
// مثال: لصفحة إعدادات الشركات
const { data, error } = await supabase
  .from('business_settings')
  .select('*, business_registrations(business_name)')
  .order('created_at', { ascending: false });
```

### الخطوة 3: تصميم الواجهة

استخدم المكونات المشتركة (Cards، Buttons، Inputs) للحفاظ على التناسق.

### الخطوة 4: الاختبار

اختبر كل صفحة بشكل منفصل قبل الدمج.

---

## 🎉 النتيجة النهائية

عند اكتمال جميع الصفحات، ستحصل على:

✅ بوابة مالك متكاملة
✅ إدارة كاملة للشركات والمستخدمين
✅ تحليلات وتقارير شاملة
✅ أرشيف كامل للجلسات
✅ صفحات قانونية ومساعدة

---

**ملاحظة نهائية**:

جميع الجداول والـ RLS Policies جاهزة في قاعدة البيانات. تحتاج فقط لإنشاء الصفحات وربطها بالبيانات باستخدام Supabase Client.

**Good Luck!** 🚀
