-- ===================================
-- TEST DATA SETUP FOR QA/UAT TESTING
-- ===================================
-- Run this script to create test data for comprehensive testing

-- 1. Create Test Insurance Policy
INSERT INTO insurance_policies (
  id,
  user_id,
  policy_number,
  provider_name,
  coverage_percentage,
  coverage_limit,
  start_date,
  end_date,
  status
) VALUES (
  'test-insurance-001',
  'USER_ID_HERE', -- Replace with actual user ID
  'TEST-POLICY-001',
  'شركة الراجحي للتأمين (اختبار)',
  80.00,
  50000.00,
  '2025-01-01',
  '2025-12-31',
  'active'
) ON CONFLICT (policy_number) DO NOTHING;

-- 2. Test Medical Session - Pending Payment
INSERT INTO medical_sessions (
  id,
  user_id,
  doctor_name,
  specialty,
  session_date,
  duration_minutes,
  price,
  insurance_policy_id,
  insurance_covered,
  user_payable,
  payment_status,
  session_status,
  notes
) VALUES (
  'test-session-pending-001',
  'USER_ID_HERE', -- Replace with actual user ID
  'د. محمد أحمد',
  'قلب',
  '2025-01-20 10:00:00+00',
  30,
  200.00,
  NULL, -- Without insurance
  0.00,
  200.00,
  'pending',
  'pending',
  'Test session without insurance'
) ON CONFLICT (id) DO NOTHING;

-- 3. Test Medical Session - With Insurance (Pending)
INSERT INTO medical_sessions (
  id,
  user_id,
  doctor_name,
  specialty,
  session_date,
  duration_minutes,
  price,
  insurance_policy_id,
  insurance_covered,
  user_payable,
  payment_status,
  session_status,
  notes
) VALUES (
  'test-session-insured-001',
  'USER_ID_HERE', -- Replace with actual user ID
  'د. فاطمة علي',
  'عظام',
  '2025-01-22 14:00:00+00',
  45,
  300.00,
  'test-insurance-001',
  240.00, -- 80% coverage
  60.00,  -- 20% user pays
  'pending',
  'pending',
  'Test session with insurance'
) ON CONFLICT (id) DO NOTHING;

-- 4. Test Medical Session - Paid and Confirmed
INSERT INTO medical_sessions (
  id,
  user_id,
  doctor_name,
  specialty,
  session_date,
  duration_minutes,
  price,
  insurance_policy_id,
  insurance_covered,
  user_payable,
  payment_status,
  payment_method,
  session_status,
  paid_at,
  confirmed_at,
  notes
) VALUES (
  'test-session-paid-001',
  'USER_ID_HERE', -- Replace with actual user ID
  'د. أحمد سالم',
  'أطفال',
  '2025-01-25 09:00:00+00',
  30,
  150.00,
  NULL,
  0.00,
  150.00,
  'paid',
  'zedpay',
  'confirmed',
  NOW(),
  NOW(),
  'Test completed session'
) ON CONFLICT (id) DO NOTHING;

-- 5. Test Pharmacy Order - Pending
INSERT INTO pharmacy_orders (
  id,
  user_id,
  pharmacy_id,
  pharmacy_name,
  items,
  total_price,
  insurance_policy_id,
  insurance_covered,
  user_payable,
  payment_status,
  order_status,
  delivery_address
) VALUES (
  'test-order-pending-001',
  'USER_ID_HERE', -- Replace with actual user ID
  NULL,
  'صيدلية النهدي (اختبار)',
  '[
    {
      "medication_id": "MED001",
      "medication_name": "باراسيتامول",
      "quantity": 2,
      "unit_price": 15.00,
      "total_price": 30.00
    },
    {
      "medication_id": "MED002",
      "medication_name": "أموكسيسيلين",
      "quantity": 1,
      "unit_price": 45.00,
      "total_price": 45.00
    }
  ]'::jsonb,
  75.00,
  NULL,
  0.00,
  75.00,
  'pending',
  'pending',
  'شارع الملك فهد، الرياض، 12345'
) ON CONFLICT (id) DO NOTHING;

-- 6. Test Pharmacy Order - With Insurance (Pending)
INSERT INTO pharmacy_orders (
  id,
  user_id,
  pharmacy_id,
  pharmacy_name,
  items,
  total_price,
  insurance_policy_id,
  insurance_covered,
  user_payable,
  payment_status,
  order_status,
  delivery_address
) VALUES (
  'test-order-insured-001',
  'USER_ID_HERE', -- Replace with actual user ID
  NULL,
  'صيدلية الدواء (اختبار)',
  '[
    {
      "medication_id": "MED003",
      "medication_name": "إيبوبروفين",
      "quantity": 3,
      "unit_price": 20.00,
      "total_price": 60.00
    }
  ]'::jsonb,
  60.00,
  'test-insurance-001',
  48.00, -- 80% coverage
  12.00, -- 20% user pays
  'pending',
  'pending',
  'حي المروج، جدة، 21564'
) ON CONFLICT (id) DO NOTHING;

-- 7. Test Pharmacy Order - Paid and Confirmed
INSERT INTO pharmacy_orders (
  id,
  user_id,
  pharmacy_id,
  pharmacy_name,
  items,
  total_price,
  insurance_policy_id,
  insurance_covered,
  user_payable,
  payment_status,
  payment_method,
  order_status,
  delivery_address,
  paid_at,
  confirmed_at
) VALUES (
  'test-order-paid-001',
  'USER_ID_HERE', -- Replace with actual user ID
  NULL,
  'صيدلية نجد (اختبار)',
  '[
    {
      "medication_id": "MED004",
      "medication_name": "فيتامين د",
      "quantity": 1,
      "unit_price": 35.00,
      "total_price": 35.00
    }
  ]'::jsonb,
  35.00,
  NULL,
  0.00,
  35.00,
  'paid',
  'zedpay',
  'confirmed',
  'شارع العليا، الرياض، 11564',
  NOW(),
  NOW()
) ON CONFLICT (id) DO NOTHING;

-- 8. Test Payment Transactions
INSERT INTO payment_transactions (
  id,
  user_id,
  reference_type,
  reference_id,
  amount,
  payment_method,
  payment_gateway,
  gateway_transaction_id,
  status,
  completed_at
) VALUES
(
  'test-txn-001',
  'USER_ID_HERE',
  'medical_session',
  'test-session-paid-001',
  150.00,
  'zedpay',
  'zedpay',
  'ZED-TXN-TEST-001',
  'completed',
  NOW()
),
(
  'test-txn-002',
  'USER_ID_HERE',
  'pharmacy_order',
  'test-order-paid-001',
  35.00,
  'zedpay',
  'zedpay',
  'ZED-TXN-TEST-002',
  'completed',
  NOW()
) ON CONFLICT (id) DO NOTHING;

-- ===================================
-- VERIFICATION QUERIES
-- ===================================

-- Check insurance policies
SELECT
  policy_number,
  provider_name,
  coverage_percentage,
  status,
  start_date,
  end_date
FROM insurance_policies
WHERE policy_number LIKE 'TEST-%'
ORDER BY created_at DESC;

-- Check pending sessions (should NOT be confirmed)
SELECT
  doctor_name,
  price,
  insurance_covered,
  user_payable,
  payment_status,
  session_status
FROM medical_sessions
WHERE id LIKE 'test-session-%'
AND payment_status = 'pending'
ORDER BY created_at DESC;

-- Check confirmed sessions (must be paid first)
SELECT
  doctor_name,
  price,
  payment_status,
  session_status,
  paid_at,
  confirmed_at
FROM medical_sessions
WHERE id LIKE 'test-session-%'
AND payment_status = 'paid'
ORDER BY created_at DESC;

-- Check pending orders
SELECT
  pharmacy_name,
  total_price,
  insurance_covered,
  user_payable,
  payment_status,
  order_status
FROM pharmacy_orders
WHERE id LIKE 'test-order-%'
AND payment_status = 'pending'
ORDER BY created_at DESC;

-- Check completed orders
SELECT
  pharmacy_name,
  total_price,
  payment_status,
  order_status,
  paid_at,
  confirmed_at
FROM pharmacy_orders
WHERE id LIKE 'test-order-%'
AND payment_status = 'paid'
ORDER BY created_at DESC;

-- Check payment transactions
SELECT
  reference_type,
  reference_id,
  amount,
  payment_gateway,
  status,
  completed_at
FROM payment_transactions
WHERE id LIKE 'test-txn-%'
ORDER BY created_at DESC;

-- ===================================
-- CRITICAL TESTS
-- ===================================

-- Test 1: Verify payment enforcement
-- This should return 0 rows (cannot update session status without payment)
UPDATE medical_sessions
SET session_status = 'confirmed'
WHERE id = 'test-session-pending-001'
AND payment_status = 'pending';

-- Verify (should still be pending)
SELECT payment_status, session_status
FROM medical_sessions
WHERE id = 'test-session-pending-001';

-- Test 2: Verify trigger auto-confirmation
-- Update payment status to paid
UPDATE medical_sessions
SET payment_status = 'paid'
WHERE id = 'test-session-pending-001';

-- Check if session_status auto-updated to confirmed
SELECT payment_status, session_status, paid_at, confirmed_at
FROM medical_sessions
WHERE id = 'test-session-pending-001';

-- Test 3: Verify insurance calculation function
SELECT * FROM calculate_user_payable(200, 'test-insurance-001');
-- Expected: insurance_covered = 160, user_payable = 40

SELECT * FROM calculate_user_payable(200, NULL);
-- Expected: insurance_covered = 0, user_payable = 200

-- Test 4: Verify invoice number generation
SELECT generate_invoice_number();
SELECT generate_invoice_number();
SELECT generate_invoice_number();
-- Should return 3 unique invoice numbers

-- ===================================
-- CLEANUP (Use with caution!)
-- ===================================

/*
-- Remove all test data
DELETE FROM payment_transactions WHERE id LIKE 'test-txn-%';
DELETE FROM pharmacy_orders WHERE id LIKE 'test-order-%';
DELETE FROM medical_sessions WHERE id LIKE 'test-session-%';
DELETE FROM insurance_policies WHERE policy_number LIKE 'TEST-%';
*/
