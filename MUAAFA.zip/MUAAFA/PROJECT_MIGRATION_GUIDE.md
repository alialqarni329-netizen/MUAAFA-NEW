# 🚀 دليل نقل المشروع الكامل
# Complete Project Migration Guide

## 🎯 الهدف | Goal

دليل شامل لنقل مشروع Muaafa Health بالكامل لمطور آخر أو بيئة جديدة.

---

## 📦 ما تحتاجه قبل البدء | Prerequisites

### للمطور الحالي (أنت):
- [x] وصول كامل لـ GitHub repository
- [x] وصول Owner لـ Supabase project
- [x] ملف `.env` الكامل
- [x] معلومات جميع الـ APIs المستخدمة

### للمطور الجديد:
- [ ] حساب GitHub
- [ ] حساب Supabase (مجاني)
- [ ] Node.js (v18 أو أحدث)
- [ ] Git مثبت
- [ ] محرر كود (VS Code موصى به)

---

## 📋 خطوات النقل الكاملة | Complete Migration Steps

## الجزء 1: إعداد المطور الحالي | Current Developer Setup

### 1.1. تنظيف وتحديث الكود

```bash
# انتقل لمجلد المشروع
cd /path/to/muaafa-health-app

# تأكد من تحديث كل شيء
git status

# أضف أي ملفات معدلة
git add .

# Commit نهائي شامل
git commit -m "🚀 Prepare project for migration - Complete update"

# ادفع لـ GitHub
git push origin main
```

### 1.2. تصدير قاعدة البيانات

```bash
# Schema
pg_dump --schema-only --no-owner --no-privileges \
  "postgresql://postgres:[PASSWORD]@db.tmkkmzrmtjctchfxseoh.supabase.co:5432/postgres" \
  > exports/supabase_schema.sql

# Data (اختياري - إذا أردت نقل البيانات)
pg_dump --data-only --no-owner --no-privileges \
  "postgresql://postgres:[PASSWORD]@db.tmkkmzrmtjctchfxseoh.supabase.co:5432/postgres" \
  > exports/supabase_data.sql

# أو Full backup
pg_dump --no-owner --no-privileges \
  "postgresql://postgres:[PASSWORD]@db.tmkkmzrmtjctchfxseoh.supabase.co:5432/postgres" \
  > exports/supabase_full_backup.sql
```

### 1.3. إنشاء ملف `.env.example`

```bash
# انسخ .env لكن أزل القيم الحقيقية
cat .env | sed 's/=.*/=your_value_here/' > .env.example

# أضفه لـ Git
git add .env.example
git commit -m "📝 Add environment variables template"
git push origin main
```

### 1.4. تجهيز حزمة النقل

أنشئ مجلد `project_transfer_package/`:

```
project_transfer_package/
├── README_TRANSFER.md          (تعليمات النقل)
├── .env                        (الملف الكامل - لا ترفعه لـ Git!)
├── supabase_schema.sql         (بنية قاعدة البيانات)
├── supabase_data.sql           (البيانات - اختياري)
├── api_keys_info.txt           (معلومات الـ APIs)
└── accounts_info.txt           (معلومات الحسابات)
```

محتوى `api_keys_info.txt`:
```
=== Supabase ===
Project URL: https://tmkkmzrmtjctchfxseoh.supabase.co
Project ID: tmkkmzrmtjctchfxseoh
Anon Key: [في ملف .env]
Service Role Key: [في Dashboard > Settings > API]

=== Zoom ===
Marketplace: https://marketplace.zoom.us/
App Name: Muaafa Health App
Account ID: [في ملف .env]
Client ID: [في ملف .env]
Client Secret: [في ملف .env]

=== OpenAI ===
API Key: [في ملف .env]
Organization: [اختياري]

=== GitHub ===
Repository: https://github.com/YOUR_USERNAME/muaafa-health-app
```

---

## الجزء 2: إعداد المطور الجديد | New Developer Setup

### 2.1. استنساخ المشروع من GitHub

```bash
# Clone المشروع
git clone https://github.com/YOUR_USERNAME/muaafa-health-app.git

# انتقل للمجلد
cd muaafa-health-app

# تحقق من الـ branch
git branch
# يجب أن ترى: * main

# تثبيت المكتبات
npm install
```

### 2.2. إعداد ملف `.env`

```bash
# انسخ من المثال
cp .env.example .env

# افتح الملف واملأ القيم الحقيقية
# (احصل عليها من المطور السابق بطريقة آمنة)
nano .env
# أو
code .env
```

محتوى `.env` الكامل:
```env
# Supabase Configuration
EXPO_PUBLIC_SUPABASE_URL=https://[NEW_PROJECT_ID].supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=[YOUR_NEW_ANON_KEY]

# OpenAI API Configuration
OPENAI_API_KEY=[YOUR_OPENAI_KEY]

# Zoom API Configuration
ZOOM_ACCOUNT_ID=[YOUR_ZOOM_ACCOUNT_ID]
ZOOM_CLIENT_ID=[YOUR_ZOOM_CLIENT_ID]
ZOOM_CLIENT_SECRET=[YOUR_ZOOM_CLIENT_SECRET]
```

### 2.3. إعداد Supabase Project جديد

#### خيار A: استخدام المشروع القديم (إذا تم نقل الملكية)
- احصل على دعوة من المالك السابق
- اقبل الدعوة
- احصل على Database password
- تخطى لـ 2.5

#### خيار B: إنشاء مشروع جديد

1. اذهب لـ [Supabase Dashboard](https://supabase.com/dashboard)
2. اضغط **"New project"**
3. املأ التفاصيل:
   - **Name**: `Muaafa Health`
   - **Database Password**: اختر كلمة مرور قوية (احفظها!)
   - **Region**: اختر أقرب منطقة
   - **Pricing Plan**: Free للتطوير، Pro للإنتاج
4. اضغط **"Create new project"**
5. انتظر ~2 دقيقة

### 2.4. استيراد قاعدة البيانات

#### عبر Supabase Dashboard:

1. **SQL Editor** > **"New query"**
2. الصق محتوى `supabase_schema.sql` كاملاً
3. اضغط **"Run"**
4. إذا كانت هناك بيانات، كرر مع `supabase_data.sql`

#### عبر psql:

```bash
# استورد الـ schema
psql "postgresql://postgres:[NEW_PASSWORD]@db.[NEW_PROJECT_ID].supabase.co:5432/postgres" \
  < supabase_schema.sql

# استورد البيانات (اختياري)
psql "postgresql://postgres:[NEW_PASSWORD]@db.[NEW_PROJECT_ID].supabase.co:5432/postgres" \
  < supabase_data.sql
```

### 2.5. رفع Edge Functions

```bash
# تثبيت Supabase CLI
npm install -g supabase

# تسجيل دخول
supabase login

# ربط المشروع
supabase link --project-ref [YOUR_NEW_PROJECT_ID]

# رفع جميع الـ functions
supabase functions deploy create-meeting
supabase functions deploy test-zoom-connection
supabase functions deploy health-chatbot
supabase functions deploy send-welcome-email
supabase functions deploy check-subscriptions
supabase functions deploy generate-medical-brief
supabase functions deploy simplify-medical-report
```

### 2.6. إعداد Secrets في Supabase

1. اذهب لـ **Settings** > **Secrets**
2. أضف:
   - `ZOOM_ACCOUNT_ID`
   - `ZOOM_CLIENT_ID`
   - `ZOOM_CLIENT_SECRET`
   - `OPENAI_API_KEY`

### 2.7. تحديث ملف `.env` المحلي

```env
# حدّث بمعلومات المشروع الجديد
EXPO_PUBLIC_SUPABASE_URL=https://[NEW_PROJECT_ID].supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=[NEW_ANON_KEY]
```

### 2.8. تشغيل المشروع

```bash
# تشغيل
npm run dev

# اختر platform:
# w - Web
# a - Android
# i - iOS
```

---

## الجزء 3: الاختبار والتحقق | Testing & Verification

### 3.1. اختبار قاعدة البيانات

```sql
-- في Supabase SQL Editor

-- 1. عدد الجداول
SELECT count(*) FROM information_schema.tables
WHERE table_schema = 'public';
-- يجب أن يكون ~40 جدول

-- 2. التحقق من RLS
SELECT tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public';
-- rowsecurity يجب أن يكون 't' (true) لكل الجداول

-- 3. عدد الـ Policies
SELECT count(*) FROM pg_policies;
-- يجب أن يكون 100+

-- 4. عدد الـ Functions
SELECT count(*) FROM pg_proc
WHERE pronamespace = 'public'::regnamespace;
```

### 3.2. اختبار التطبيق

#### ✅ Checklist:

**Authentication:**
- [ ] تسجيل مستخدم جديد
- [ ] تسجيل دخول
- [ ] استعادة كلمة المرور
- [ ] تسجيل خروج

**الجلسات:**
- [ ] حجز موعد جديد
- [ ] اختيار Zoom كمنصة
- [ ] التحقق من إنشاء رابط Zoom
- [ ] الدخول لغرفة الانتظار

**الصيدليات:**
- [ ] عرض الصيدليات
- [ ] البحث عن دواء
- [ ] إضافة لسلة التسوق
- [ ] إتمام الطلب

**اللياقة:**
- [ ] إنشاء هدف جديد
- [ ] تسجيل تمرين
- [ ] عرض الإحصائيات

**التقارير:**
- [ ] رفع تقرير طبي
- [ ] عرض التقارير
- [ ] طلب موافقة تأمينية

**AI Chatbot:**
- [ ] بدء محادثة مع الطبيب الذكي
- [ ] إرسال رسالة
- [ ] استلام رد

**Zoom Test:**
- [ ] الإعدادات > اختبار اتصال Zoom
- [ ] التحقق من نجاح الاختبار

### 3.3. اختبار الأداء

```bash
# تشغيل في وضع الإنتاج
npm run build:web

# التحقق من عدم وجود أخطاء
# Build يجب أن ينجح بدون errors
```

---

## الجزء 4: الإعدادات النهائية | Final Configuration

### 4.1. تحديث معلومات المشروع

في `package.json`:
```json
{
  "name": "muaafa-health-app",
  "version": "1.0.0",
  "description": "Muaafa Health - منصة طبية متكاملة",
  "author": "YOUR_NAME <your.email@example.com>",
  "repository": {
    "type": "git",
    "url": "https://github.com/YOUR_USERNAME/muaafa-health-app.git"
  }
}
```

### 4.2. تحديث Expo Config

في `app.json`:
```json
{
  "expo": {
    "name": "Muaafa Health",
    "slug": "muaafa-health-app",
    "owner": "YOUR_EXPO_USERNAME",
    "version": "1.0.0",
    ...
  }
}
```

### 4.3. إعداد Continuous Deployment (اختياري)

#### GitHub Actions للـ Auto-push:

أنشئ `.github/workflows/auto-push.yml`:

```yaml
name: Auto Push to GitHub

on:
  schedule:
    - cron: '0 */6 * * *'  # كل 6 ساعات
  workflow_dispatch:  # يدوي

jobs:
  auto-push:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Configure Git
        run: |
          git config --global user.name 'GitHub Actions Bot'
          git config --global user.email 'bot@example.com'
      - name: Commit and Push
        run: |
          git add .
          git diff --quiet && git diff --staged --quiet || git commit -m "🤖 Auto backup $(date)"
          git push
```

---

## 📊 مقارنة البيئات | Environment Comparison

### البيئة القديمة:
```
Supabase Project: tmkkmzrmtjctchfxseoh
GitHub Repo: github.com/OLD_USERNAME/muaafa-health-app
Owner Email: old.owner@example.com
```

### البيئة الجديدة:
```
Supabase Project: [NEW_PROJECT_ID]
GitHub Repo: github.com/NEW_USERNAME/muaafa-health-app
Owner Email: new.owner@example.com
```

---

## 🔒 الأمان بعد النقل | Post-Migration Security

### للمطور القديم:

1. **إزالة صلاحياتك** (إذا لم تعد تحتاجها):
   - Supabase: Settings > Team > Leave project
   - GitHub: Settings > Collaborators > Remove yourself

2. **تغيير كلمات المرور** (للحسابات المشتركة):
   - Supabase database password
   - GitHub account password

3. **إلغاء API Keys** (إذا كانت مشتركة):
   - OpenAI: أنشئ key جديد للمطور الجديد
   - Zoom: أنشئ app جديد أو انقل الملكية

### للمطور الجديد:

1. **غيّر كل كلمات المرور**
2. **أنشئ API keys جديدة خاصة بك**
3. **راجع RLS policies للتأكد من الأمان**
4. **فعّل 2FA على جميع الحسابات**

---

## 🚨 حل المشاكل الشائعة | Common Issues

### مشكلة: `Module not found`
```bash
# احذف node_modules وأعد التثبيت
rm -rf node_modules package-lock.json
npm install
```

### مشكلة: `Supabase connection failed`
- تحقق من `.env` file
- تأكد من صحة SUPABASE_URL و ANON_KEY
- تحقق من Network access في Supabase

### مشكلة: `RLS policy error`
- راجع SQL Editor logs
- تأكد من استيراد جميع الـ policies
- تحقق من auth.uid() في الـ policies

### مشكلة: `Edge functions not working`
- تأكد من رفعها عبر `supabase functions deploy`
- تحقق من Secrets في Supabase
- راجع Logs في Supabase Dashboard

---

## 📞 جهات الاتصال | Contact Info

### للدعم الفني:
- **GitHub Issues**: https://github.com/YOUR_USERNAME/muaafa-health-app/issues
- **Email**: your.support@example.com
- **التوثيق**: راجع ملفات `*.md` في المشروع

### الموارد المفيدة:
- [Expo Documentation](https://docs.expo.dev/)
- [Supabase Documentation](https://supabase.com/docs)
- [React Native Documentation](https://reactnative.dev/)

---

## ✅ Checklist النقل النهائي | Final Migration Checklist

### للمطور القديم:
- [ ] كل الكود محدث على GitHub
- [ ] قاعدة البيانات مصدّرة
- [ ] `.env` محضّر وآمن
- [ ] حزمة النقل جاهزة
- [ ] التوثيق كامل
- [ ] المطور الجديد حصل على كل شيء

### للمطور الجديد:
- [ ] المشروع مستنسخ من GitHub
- [ ] npm install نجح
- [ ] `.env` مضبوط
- [ ] Supabase project جاهز
- [ ] قاعدة البيانات مستوردة
- [ ] Edge functions مرفوعة
- [ ] Secrets مضبوطة
- [ ] التطبيق يعمل محلياً
- [ ] جميع الاختبارات نجحت
- [ ] الزوم يعمل 100%

---

**تهانينا! 🎉 المشروع منقول بنجاح!**

الآن يمكنك البدء بالتطوير والإضافة على المشروع. حظاً موفقاً!
