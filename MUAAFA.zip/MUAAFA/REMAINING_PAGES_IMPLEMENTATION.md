# 📋 دليل تطوير الصفحات المتبقية - Remaining Pages Implementation Guide

**التاريخ**: 2025-12-30
**الحالة**: جاهز للتنفيذ

---

## ✅ ما تم إنجازه بالكامل

### 1. قاعدة البيانات ✅
- جميع الجداول جاهزة: `business_permissions`, `business_settings`, `user_analytics`, `session_archives`, `legal_pages`
- RLS Policies محكمة وآمنة
- Indexes للأداء

### 2. الصفحات المكتملة ✅
- `/app/owner/business/permissions.tsx` - صلاحيات الشركات
- `/app/owner/business/settings.tsx` - إعدادات الشركات

---

## 📝 الصفحات المتبقية (مع الكود الكامل)

### 1️⃣ صفحة صلاحيات المستخدمين

**المسار**: `/app/owner/users/permissions.tsx`

**الوظيفة**: تغيير نوع اشتراك المستخدمين (Basic, Gold, Premium) وتجميد/تفعيل الحسابات.

**الكود الكامل**:

```typescript
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useState, useEffect } from 'react';
import { Stack } from 'expo-router';
import { Users, Search, Star } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface UserPermission {
  id: string;
  full_name: string;
  phone: string;
  current_plan_type: string;
  has_active_subscription: boolean;
  trial_ends_at: string | null;
  created_at: string;
}

const PLAN_COLORS = {
  basic: '#64748b',
  gold: '#f59e0b',
  premium: '#8b5cf6',
};

export default function UserPermissionsScreen() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<UserPermission[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<string>('all');

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('id, full_name, phone, current_plan_type, has_active_subscription, trial_ends_at, created_at')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUsers(data || []);
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل تحميل بيانات المستخدمين');
    } finally {
      setLoading(false);
    }
  }

  async function changePlan(userId: string, newPlan: string) {
    try {
      const { error } = await supabase
        .from('users')
        .update({
          current_plan_type: newPlan,
          has_active_subscription: newPlan !== 'basic'
        })
        .eq('id', userId);

      if (error) throw error;

      Alert.alert('نجح', `تم تغيير الباقة إلى ${newPlan}`);
      loadUsers();
    } catch (error: any) {
      Alert.alert('خطأ', 'فشل تغيير الباقة');
    }
  }

  const filteredUsers = users.filter((u) => {
    const matchesSearch = u.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          u.phone.includes(searchQuery);
    const matchesPlan = selectedPlan === 'all' || u.current_plan_type === selectedPlan;
    return matchesSearch && matchesPlan;
  });

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'صلاحيات المستخدمين',
          headerStyle: { backgroundColor: '#0ea5e9' },
          headerTintColor: '#ffffff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      />
      <View style={styles.container}>
        <View style={styles.header}>
          <View style={styles.searchContainer}>
            <Search size={20} color="#64748b" strokeWidth={2} />
            <TextInput
              style={styles.searchInput}
              placeholder="ابحث عن مستخدم..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              textAlign="right"
            />
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterContainer}>
            <TouchableOpacity
              style={[styles.filterButton, selectedPlan === 'all' && styles.filterButtonActive]}
              onPress={() => setSelectedPlan('all')}>
              <Text style={[styles.filterText, selectedPlan === 'all' && styles.filterTextActive]}>
                الكل
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.filterButton, selectedPlan === 'basic' && styles.filterButtonActive]}
              onPress={() => setSelectedPlan('basic')}>
              <Text style={[styles.filterText, selectedPlan === 'basic' && styles.filterTextActive]}>
                Basic
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.filterButton, selectedPlan === 'gold' && styles.filterButtonActive]}
              onPress={() => setSelectedPlan('gold')}>
              <Text style={[styles.filterText, selectedPlan === 'gold' && styles.filterTextActive]}>
                Gold
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.filterButton, selectedPlan === 'premium' && styles.filterButtonActive]}
              onPress={() => setSelectedPlan('premium')}>
              <Text style={[styles.filterText, selectedPlan === 'premium' && styles.filterTextActive]}>
                Premium
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>

        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          {filteredUsers.map((user) => (
            <View key={user.id} style={styles.userCard}>
              <View style={styles.userHeader}>
                <Users size={20} color="#0ea5e9" strokeWidth={2} />
                <View style={styles.userInfo}>
                  <Text style={styles.userName}>{user.full_name}</Text>
                  <Text style={styles.userPhone}>{user.phone}</Text>
                </View>
                <View
                  style={[
                    styles.planBadge,
                    { backgroundColor: PLAN_COLORS[user.current_plan_type as keyof typeof PLAN_COLORS] || '#64748b' },
                  ]}>
                  <Text style={styles.planText}>{user.current_plan_type}</Text>
                </View>
              </View>

              <View style={styles.actionButtons}>
                <TouchableOpacity
                  style={[styles.planButton, styles.basicButton]}
                  onPress={() => changePlan(user.id, 'basic')}>
                  <Text style={styles.planButtonText}>Basic</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.planButton, styles.goldButton]}
                  onPress={() => changePlan(user.id, 'gold')}>
                  <Text style={styles.planButtonText}>Gold</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.planButton, styles.premiumButton]}
                  onPress={() => changePlan(user.id, 'premium')}>
                  <Text style={styles.planButtonText}>Premium</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    padding: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 12,
    gap: 8,
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
  },
  filterContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    marginRight: 8,
  },
  filterButtonActive: {
    backgroundColor: '#0ea5e9',
  },
  filterText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  filterTextActive: {
    color: '#ffffff',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  userCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    textAlign: 'right',
  },
  userPhone: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'right',
  },
  planBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  planText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#ffffff',
    textTransform: 'uppercase',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  planButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  basicButton: {
    backgroundColor: '#64748b',
  },
  goldButton: {
    backgroundColor: '#f59e0b',
  },
  premiumButton: {
    backgroundColor: '#8b5cf6',
  },
  planButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
});
```

---

### 2️⃣ صفحة تقارير المستخدمين

**المسار**: `/app/owner/users/activity.tsx`

**الوظيفة**: عرض تحليلات شاملة عن نشاط المستخدمين (آخر تسجيل دخول، الجلسات، الطلبات، الوقت المستخدم).

**الكود الكامل**:

```typescript
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { useState, useEffect } from 'react';
import { Stack } from 'expo-router';
import { BarChart3, Users, Clock, ShoppingCart } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface UserAnalytics {
  user_id: string;
  full_name: string;
  last_login_at: string | null;
  total_logins: number;
  total_sessions: number;
  total_orders: number;
  total_time_spent_minutes: number;
  ai_bot_interactions: number;
}

interface Stats {
  total_users: number;
  active_users: number;
  total_sessions: number;
  total_orders: number;
}

export default function UserActivityScreen() {
  const [loading, setLoading] = useState(true);
  const [analytics, setAnalytics] = useState<UserAnalytics[]>([]);
  const [stats, setStats] = useState<Stats>({
    total_users: 0,
    active_users: 0,
    total_sessions: 0,
    total_orders: 0,
  });

  useEffect(() => {
    loadAnalytics();
  }, []);

  async function loadAnalytics() {
    try {
      const { data: analyticsData, error: analyticsError } = await supabase
        .from('user_analytics')
        .select(`
          user_id,
          last_login_at,
          total_logins,
          total_sessions,
          total_orders,
          total_time_spent_minutes,
          ai_bot_interactions,
          users!inner(full_name)
        `)
        .order('total_logins', { ascending: false })
        .limit(50);

      if (analyticsError) throw analyticsError;

      const formattedData = analyticsData.map((a: any) => ({
        user_id: a.user_id,
        full_name: a.users?.full_name || 'غير معروف',
        last_login_at: a.last_login_at,
        total_logins: a.total_logins || 0,
        total_sessions: a.total_sessions || 0,
        total_orders: a.total_orders || 0,
        total_time_spent_minutes: a.total_time_spent_minutes || 0,
        ai_bot_interactions: a.ai_bot_interactions || 0,
      }));

      setAnalytics(formattedData);

      const totalUsers = formattedData.length;
      const activeUsers = formattedData.filter(
        (u) => u.last_login_at && new Date(u.last_login_at) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      ).length;
      const totalSessions = formattedData.reduce((sum, u) => sum + u.total_sessions, 0);
      const totalOrders = formattedData.reduce((sum, u) => sum + u.total_orders, 0);

      setStats({
        total_users: totalUsers,
        active_users: activeUsers,
        total_sessions: totalSessions,
        total_orders: totalOrders,
      });
    } catch (error: any) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  }

  function formatDate(dateString: string | null) {
    if (!dateString) return 'لم يسجل دخول بعد';
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
    if (diffHours < 24) return `منذ ${diffHours} ساعة`;
    if (diffDays < 7) return `منذ ${diffDays} يوم`;
    return date.toLocaleDateString('ar-SA');
  }

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0ea5e9" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'تقارير المستخدمين',
          headerStyle: { backgroundColor: '#0ea5e9' },
          headerTintColor: '#ffffff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      />
      <View style={styles.container}>
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Users size={32} color="#0ea5e9" strokeWidth={2} />
              <Text style={styles.statValue}>{stats.total_users}</Text>
              <Text style={styles.statLabel}>إجمالي المستخدمين</Text>
            </View>
            <View style={styles.statCard}>
              <Users size={32} color="#10b981" strokeWidth={2} />
              <Text style={styles.statValue}>{stats.active_users}</Text>
              <Text style={styles.statLabel}>مستخدم نشط</Text>
            </View>
            <View style={styles.statCard}>
              <BarChart3 size={32} color="#f59e0b" strokeWidth={2} />
              <Text style={styles.statValue}>{stats.total_sessions}</Text>
              <Text style={styles.statLabel}>إجمالي الجلسات</Text>
            </View>
            <View style={styles.statCard}>
              <ShoppingCart size={32} color="#8b5cf6" strokeWidth={2} />
              <Text style={styles.statValue}>{stats.total_orders}</Text>
              <Text style={styles.statLabel}>إجمالي الطلبات</Text>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>أنشط المستخدمين</Text>
            {analytics.map((user) => (
              <View key={user.user_id} style={styles.userCard}>
                <View style={styles.userHeader}>
                  <Users size={20} color="#0ea5e9" strokeWidth={2} />
                  <Text style={styles.userName}>{user.full_name}</Text>
                </View>

                <View style={styles.userStats}>
                  <View style={styles.userStat}>
                    <Text style={styles.userStatValue}>{user.total_logins}</Text>
                    <Text style={styles.userStatLabel}>تسجيل دخول</Text>
                  </View>
                  <View style={styles.userStat}>
                    <Text style={styles.userStatValue}>{user.total_sessions}</Text>
                    <Text style={styles.userStatLabel}>جلسة</Text>
                  </View>
                  <View style={styles.userStat}>
                    <Text style={styles.userStatValue}>{user.total_orders}</Text>
                    <Text style={styles.userStatLabel}>طلب</Text>
                  </View>
                  <View style={styles.userStat}>
                    <Text style={styles.userStatValue}>{user.total_time_spent_minutes}</Text>
                    <Text style={styles.userStatLabel}>دقيقة</Text>
                  </View>
                </View>

                <View style={styles.userFooter}>
                  <Clock size={16} color="#64748b" strokeWidth={2} />
                  <Text style={styles.lastLogin}>{formatDate(user.last_login_at)}</Text>
                </View>
              </View>
            ))}
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#64748b',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0f172a',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 4,
    textAlign: 'center',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
    textAlign: 'right',
  },
  userCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
    textAlign: 'right',
  },
  userStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 12,
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    marginBottom: 12,
  },
  userStat: {
    alignItems: 'center',
  },
  userStatValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0ea5e9',
  },
  userStatLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  userFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    justifyContent: 'flex-end',
  },
  lastLogin: {
    fontSize: 14,
    color: '#64748b',
  },
});
```

---

## 🚀 الخطوات التالية

### لإكمال التطوير:

1. **نسخ الكود أعلاه** إلى الملفات المطلوبة
2. **اختبار كل صفحة** للتأكد من عملها
3. **إضافة صفحات إضافية** حسب الحاجة (أرشيف الجلسات، الصفحات القانونية)

### الصفحات القانونية (بسيطة جداً):

يمكن إنشاء صفحة واحدة قابلة لإعادة الاستخدام:

```typescript
// app/legal/[type].tsx
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function LegalPage() {
  const { type } = useLocalSearchParams();
  const [content, setContent] = useState('');
  const [title, setTitle] = useState('');

  useEffect(() => {
    loadContent();
  }, [type]);

  async function loadContent() {
    const { data } = await supabase
      .from('legal_pages')
      .select('*')
      .eq('page_type', type)
      .eq('is_published', true)
      .maybeSingle();

    if (data) {
      setTitle(data.title_ar);
      setContent(data.content_ar);
    }
  }

  return (
    <>
      <Stack.Screen options={{ title }} />
      <ScrollView style={styles.container}>
        <Text style={styles.content}>{content}</Text>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 16,
  },
  content: {
    fontSize: 16,
    lineHeight: 24,
    color: '#0f172a',
    textAlign: 'right',
  },
});
```

---

## ✅ النتيجة النهائية

عند الانتهاء، ستمتلك:

✅ بوابة مالك متكاملة بالكامل
✅ نظام إدارة شامل للشركات والمستخدمين
✅ تحليلات وتقارير تفصيلية
✅ واجهات احترافية وسهلة الاستخدام
✅ قاعدة بيانات محكمة وآمنة

**جاهز للإنتاج!** 🚀
