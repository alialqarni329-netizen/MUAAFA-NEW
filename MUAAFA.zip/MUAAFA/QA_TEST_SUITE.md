# 🧪 QA/UAT Test Suite - Muaafa Health App

## Status Overview

| Category | Tests | Status | Critical |
|----------|-------|--------|----------|
| Authentication & Registration | 3 | ⏳ Pending | ✅ Yes |
| Medical Session Booking | 5 | ⏳ Pending | ✅ Yes |
| Pharmacy & Cart | 5 | ⏳ Pending | ✅ Yes |
| Payments & Invoices | 2 | ⏳ Pending | ✅ Yes |
| History & Records | 2 | ⏳ Pending | ⚠️ Medium |
| Role & Access | 2 | ⏳ Pending | ⚠️ Medium |
| Error Handling | 3 | ⏳ Pending | ✅ Yes |
| Performance | 2 | ⏳ Pending | ⚠️ Medium |

---

## 1️⃣ Authentication & Registration Tests

### Test 1.1 – User Registration ✅ IMPLEMENTED

**Test Steps:**
1. Open app
2. Navigate to registration screen
3. Enter phone number: `+966501234567`
4. Verify OTP sent
5. Enter OTP: `123456`
6. Complete registration form
7. Submit

**Expected Result:**
- ✅ User created in `auth.users`
- ✅ User profile created in `public.users`
- ✅ No database errors
- ✅ User redirected to questionnaire

**Database Verification:**
```sql
-- Check user exists
SELECT * FROM auth.users WHERE phone = '+966501234567';

-- Check profile exists
SELECT * FROM public.users WHERE id = 'user-id-from-above';
```

**Status:** ✅ READY TO TEST

**Files Involved:**
- `app/auth/register.tsx`
- `supabase/migrations/20251223012116_add_auth_user_trigger.sql`

---

### Test 1.2 – Medical Questionnaire Flow ✅ IMPLEMENTED

**Test Steps:**
1. After successful registration
2. System redirects to questionnaire
3. Fill in medical history:
   - Height: 175 cm
   - Weight: 75 kg
   - Blood Type: O+
   - Chronic diseases: None
   - Allergies: Penicillin
   - Current medications: None
4. Submit questionnaire

**Expected Result:**
- ✅ Data saved to `medical_questionnaire` table
- ✅ Correct `user_id` foreign key
- ✅ No duplicate submissions
- ✅ User can view/edit later

**Database Verification:**
```sql
SELECT * FROM medical_questionnaire
WHERE user_id = 'user-id';
```

**Status:** ✅ READY TO TEST

**Files Involved:**
- `app/questionnaire.tsx`
- `supabase/migrations/20251117232307_add_medical_questionnaire_and_admin.sql`

---

### Test 1.3 – Access Control ✅ IMPLEMENTED

**Test Steps:**
1. Logout user
2. Try to access `/questionnaire` directly
3. Try to submit questionnaire without auth

**Expected Result:**
- ✅ Redirect to login
- ✅ RLS blocks unauthorized access
- ✅ Cannot submit without valid session

**Database Verification:**
```sql
-- Test RLS policy
SET ROLE anon;
SELECT * FROM medical_questionnaire; -- Should return nothing
```

**Status:** ✅ READY TO TEST

---

## 2️⃣ Medical Session Booking Tests (CRITICAL) 🔥

### Test 2.1 – Booking Without Insurance ✅ IMPLEMENTED

**Test Steps:**
1. Login as user without insurance
2. Navigate to book session screen
3. Fill form:
   - Doctor: د. محمد أحمد
   - Specialty: قلب
   - Date: 2025-01-15 10:00
   - Price: 200 SAR
4. Click "متابعة للدفع"

**Expected Result:**
- ✅ Full amount displayed: 200 SAR
- ✅ Insurance covered: 0 SAR
- ✅ User payable: 200 SAR
- ✅ Session created with `payment_status = 'pending'`
- ✅ Session NOT confirmed (`session_status = 'pending'`)
- ✅ Redirected to payment gateway

**Database Verification:**
```sql
SELECT
  id,
  price,
  insurance_covered,
  user_payable,
  payment_status,
  session_status
FROM medical_sessions
WHERE user_id = 'user-id'
ORDER BY created_at DESC
LIMIT 1;

-- Expected:
-- price: 200
-- insurance_covered: 0
-- user_payable: 200
-- payment_status: 'pending'
-- session_status: 'pending'
```

**Status:** ✅ READY TO TEST

**Files Involved:**
- `app/book-medical-session.tsx`
- `lib/payment-utils.ts`
- `supabase/migrations/add_payment_core_tables.sql`

---

### Test 2.2 – Booking With Insurance ✅ IMPLEMENTED

**Test Steps:**
1. Create insurance policy:
```sql
INSERT INTO insurance_policies (
  user_id,
  policy_number,
  provider_name,
  coverage_percentage,
  start_date,
  end_date,
  status
) VALUES (
  'user-id',
  'TEST-001',
  'شركة الراجحي للتأمين',
  80,
  '2025-01-01',
  '2025-12-31',
  'active'
);
```
2. Login as insured user
3. Book session (200 SAR)
4. Observe calculations

**Expected Result:**
- ✅ Insurance badge shown
- ✅ Coverage: 80%
- ✅ Insurance covered: 160 SAR
- ✅ User payable: 40 SAR
- ✅ Correct amounts in database

**Database Verification:**
```sql
SELECT
  price,
  insurance_covered,
  user_payable,
  insurance_policy_id
FROM medical_sessions
WHERE user_id = 'user-id'
ORDER BY created_at DESC
LIMIT 1;

-- Expected:
-- price: 200
-- insurance_covered: 160
-- user_payable: 40
-- insurance_policy_id: NOT NULL
```

**Status:** ✅ READY TO TEST

---

### Test 2.3 – Payment Enforcement ⚠️ CRITICAL

**Test Steps:**
1. Create session via API
2. Try to update `session_status` to 'confirmed' directly:
```sql
UPDATE medical_sessions
SET session_status = 'confirmed'
WHERE id = 'session-id'
AND payment_status = 'pending';
```
3. Try to access session before payment

**Expected Result:**
- ✅ Direct update blocked by RLS
- ✅ User cannot update sessions with pending payment
- ✅ Only payment triggers can confirm session
- ✅ No bypass possible

**Database Verification:**
```sql
-- RLS should prevent this
UPDATE medical_sessions
SET session_status = 'confirmed'
WHERE payment_status = 'pending';
-- Should return 0 rows updated
```

**Status:** ✅ READY TO TEST

---

### Test 2.4 – Payment Success ✅ IMPLEMENTED

**Test Steps:**
1. Create pending session
2. Simulate payment success:
```typescript
await updatePaymentStatus(
  'medical_session',
  sessionId,
  'paid',
  'zedpay',
  'TXN-TEST-001'
);
```
3. Check session status

**Expected Result:**
- ✅ `payment_status` = 'paid'
- ✅ `session_status` = 'confirmed' (auto-updated by trigger)
- ✅ `paid_at` timestamp set
- ✅ `confirmed_at` timestamp set
- ✅ Payment transaction record created
- ✅ Invoice generated
- ✅ Session visible in history

**Database Verification:**
```sql
-- Check session
SELECT
  payment_status,
  session_status,
  paid_at,
  confirmed_at
FROM medical_sessions
WHERE id = 'session-id';

-- Check transaction
SELECT * FROM payment_transactions
WHERE reference_id = 'session-id'
AND reference_type = 'medical_session';

-- Check invoice (if generated)
SELECT * FROM invoices
WHERE reference_id = 'session-id'
AND reference_type = 'medical_session';
```

**Status:** ✅ READY TO TEST

**Files Involved:**
- `app/payment-success.tsx`
- `lib/payment-utils.ts`
- `supabase/migrations/add_payment_functions_and_triggers.sql`

---

### Test 2.5 – Payment Failure ✅ IMPLEMENTED

**Test Steps:**
1. Create pending session
2. Simulate payment failure:
```typescript
await updatePaymentStatus(
  'medical_session',
  sessionId,
  'failed',
  'zedpay',
  'TXN-FAILED-001'
);
```

**Expected Result:**
- ✅ `payment_status` = 'failed'
- ✅ `session_status` remains 'pending'
- ✅ Session NOT confirmed
- ✅ User can retry payment
- ✅ No invoice created

**Database Verification:**
```sql
SELECT
  payment_status,
  session_status
FROM medical_sessions
WHERE id = 'session-id';

-- Expected:
-- payment_status: 'failed'
-- session_status: 'pending'
```

**Status:** ✅ READY TO TEST

---

## 3️⃣ Pharmacy & Cart Tests (CRITICAL) 🔥

### Test 3.1 – Add to Cart ⚠️ NEEDS VERIFICATION

**Test Steps:**
1. Navigate to pharmacy
2. Select medication
3. Add to cart
4. Refresh app
5. Check cart persists

**Expected Result:**
- ✅ Item appears immediately
- ✅ Cart persists after refresh
- ✅ Quantity updates correctly
- ✅ Total calculated correctly

**Database Verification:**
```sql
SELECT * FROM pharmacy_cart
WHERE user_id = 'user-id';
```

**Status:** ⚠️ VERIFY CART FUNCTIONALITY

**Files Involved:**
- `app/pharmacy-cart.tsx`

---

### Test 3.2 – Pharmacy Order With Insurance ✅ IMPLEMENTED

**Test Steps:**
1. User has active insurance (80% coverage)
2. Add medicines to cart (Total: 150 SAR)
3. Proceed to checkout
4. Observe calculations

**Expected Result:**
- ✅ Total: 150 SAR
- ✅ Insurance covered: 120 SAR
- ✅ User payable: 30 SAR
- ✅ Order created with correct amounts

**Database Verification:**
```sql
SELECT
  total_price,
  insurance_covered,
  user_payable,
  payment_status,
  order_status
FROM pharmacy_orders
WHERE user_id = 'user-id'
ORDER BY created_at DESC
LIMIT 1;
```

**Status:** ✅ READY TO TEST

**Files Involved:**
- `app/pharmacy-checkout.tsx`
- `lib/payment-utils.ts`

---

### Test 3.3 – Pharmacy Order Without Insurance ✅ IMPLEMENTED

**Test Steps:**
1. User without insurance
2. Cart total: 100 SAR
3. Checkout

**Expected Result:**
- ✅ User payable: 100 SAR
- ✅ No insurance discount

**Status:** ✅ READY TO TEST

---

### Test 3.4 – Payment Enforcement ✅ IMPLEMENTED

**Test Steps:**
1. Create pharmacy order
2. Try to update status without payment:
```sql
UPDATE pharmacy_orders
SET order_status = 'confirmed'
WHERE payment_status = 'pending';
```

**Expected Result:**
- ✅ RLS blocks direct update
- ✅ Order remains pending
- ✅ Cannot bypass payment

**Status:** ✅ READY TO TEST

---

### Test 3.5 – Order Confirmation ✅ IMPLEMENTED

**Test Steps:**
1. Complete payment for pharmacy order
2. Check order status
3. Verify notifications sent

**Expected Result:**
- ✅ Order confirmed automatically
- ✅ Invoice generated
- ✅ Cart cleared
- ✅ Order visible in history
- ✅ Pharmacy notified (if webhook exists)

**Database Verification:**
```sql
SELECT
  payment_status,
  order_status,
  paid_at,
  confirmed_at
FROM pharmacy_orders
WHERE id = 'order-id';

-- Cart should be empty
SELECT * FROM pharmacy_cart
WHERE user_id = 'user-id';
-- Should return 0 rows
```

**Status:** ✅ READY TO TEST

---

## 4️⃣ Payments & Invoices

### Test 4.1 – Payment Gateway Integration ⚠️ MOCK IMPLEMENTATION

**Current Status:**
- ✅ Payment URL generation implemented
- ⚠️ Using mock ZedPay URL (needs real integration)
- ✅ Callback handling implemented

**Test Steps:**
1. Initiate payment
2. Verify URL format
3. Test callback handling

**Expected Real Integration:**
```typescript
// Real ZedPay API
const response = await fetch('https://api.zedpay.sa/payments', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${ZEDPAY_API_KEY}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    amount: userPayable,
    currency: 'SAR',
    reference: sessionId,
    callback_url: callbackUrl
  })
});
```

**Status:** ⚠️ REQUIRES REAL ZEDPAY CREDENTIALS

**Action Required:**
1. Obtain ZedPay API credentials
2. Update `lib/payment-utils.ts`
3. Test with real gateway

---

### Test 4.2 – Invoice Generation ⚠️ NEEDS IMPLEMENTATION

**Current Status:**
- ✅ Invoice table exists
- ✅ Invoice number generator exists
- ⚠️ Automatic invoice creation NOT implemented

**Required Implementation:**
```typescript
// After successful payment
const invoiceNumber = await supabase.rpc('generate_invoice_number');

await supabase.from('invoices').insert({
  invoice_number: invoiceNumber,
  user_id: userId,
  reference_type: 'medical_session',
  reference_id: sessionId,
  amount_paid: userPayable,
  insurance_covered: insuranceCovered,
  total_amount: totalPrice,
  payment_method: 'zedpay',
  invoice_date: new Date().toISOString()
});
```

**Status:** ⚠️ NEEDS IMPLEMENTATION

**Action Required:**
1. Add invoice creation to `updatePaymentStatus()`
2. Create invoice viewing screen
3. Add PDF generation (optional)

---

## 5️⃣ History & Records

### Test 5.1 – User History ⚠️ NEEDS VERIFICATION

**Test Steps:**
1. User completes:
   - 2 medical sessions
   - 3 pharmacy orders
2. Navigate to history screen
3. Verify all records shown

**Expected Result:**
- ✅ All sessions displayed
- ✅ All orders displayed
- ✅ Correct dates and amounts
- ✅ Can view details

**Status:** ⚠️ VERIFY HISTORY SCREEN EXISTS

**Action Required:**
- Verify `app/(tabs)/history.tsx` is functional
- Test data loading and display

---

### Test 5.2 – Data Persistence ✅ IMPLEMENTED

**Test Steps:**
1. Complete actions
2. Logout
3. Login again
4. Check history

**Expected Result:**
- ✅ No data loss
- ✅ All records intact
- ✅ RLS properly filters by user

**Status:** ✅ READY TO TEST (RLS implemented)

---

## 6️⃣ Role & Access Tests

### Test 6.1 – User Role ⚠️ NEEDS VERIFICATION

**Test Steps:**
1. Login as regular user
2. Verify access to individual portal only
3. Try to access owner portal

**Expected Result:**
- ✅ Access to `(tabs)` routes
- ✅ No access to `/owner` routes
- ✅ Proper error if trying to access owner area

**Status:** ⚠️ VERIFY ROLE CHECKS IMPLEMENTED

---

### Test 6.2 – Owner Role ✅ IMPLEMENTED

**Test Steps:**
1. Login as owner (role = 'owner')
2. Navigate to owner portal
3. Check all tabs accessible

**Expected Result:**
- ✅ Access to all owner tabs
- ✅ No redirect to individual portal
- ✅ Can view all data

**Database Verification:**
```sql
SELECT * FROM users
WHERE role = 'owner';
```

**Status:** ✅ READY TO TEST

**Files Involved:**
- `app/owner/_layout.tsx`
- `components/OwnerTabLayout.tsx`

---

## 7️⃣ Error Handling & Stability

### Test 7.1 – No 404 Errors ⚠️ CRITICAL TEST

**Test Steps:**
1. Navigate through ALL main tabs
2. Navigate through ALL sub-tabs
3. Click all navigation links
4. Record any 404 errors

**Status:** ⚠️ REQUIRES MANUAL TESTING

**Known Issues to Check:**
- Missing route files
- Incorrect route names
- Unmatched dynamic routes

---

### Test 7.2 – No Data Reversion ✅ IMPLEMENTED

**Test Steps:**
1. Create medical session
2. Complete payment
3. Refresh browser
4. Check session still confirmed

**Expected Result:**
- ✅ Data persists
- ✅ No auto-reversion
- ✅ Triggers maintain state

**Status:** ✅ READY TO TEST (triggers implemented)

---

### Test 7.3 – Security ✅ IMPLEMENTED

**Test Steps:**
1. User A creates session
2. User B tries to access User A's session:
```sql
SELECT * FROM medical_sessions
WHERE user_id != auth.uid();
```

**Expected Result:**
- ✅ RLS blocks access
- ✅ Returns 0 rows
- ✅ Cannot update other users' data

**Status:** ✅ READY TO TEST

---

## 8️⃣ Performance & Launch Readiness

### Test 8.1 – Concurrent Users ⚠️ REQUIRES LOAD TESTING

**Test Steps:**
1. Simulate 10+ users booking simultaneously
2. Monitor database load
3. Check for race conditions

**Expected Result:**
- ✅ No crashes
- ✅ No duplicate payments
- ✅ Correct transaction isolation

**Status:** ⚠️ REQUIRES LOAD TESTING TOOL

---

### Test 8.2 – Logs & Monitoring ⚠️ NEEDS SETUP

**Required:**
- Error logging system
- Payment tracking dashboard
- Failed payment alerts

**Status:** ⚠️ NEEDS IMPLEMENTATION

---

## ✅ FINAL ACCEPTANCE CRITERIA

### Critical Blockers (Must Pass)

- [ ] **Payment enforcement working** (Tests 2.3, 3.4)
- [ ] **Insurance calculations correct** (Tests 2.2, 3.2)
- [ ] **No data loss** (Test 7.2)
- [ ] **RLS security working** (Tests 1.3, 7.3)
- [ ] **Auto-confirmation after payment** (Tests 2.4, 3.5)

### High Priority (Must Pass)

- [ ] **Registration flow complete** (Tests 1.1, 1.2)
- [ ] **Payment success handling** (Test 2.4)
- [ ] **Payment failure handling** (Test 2.5)
- [ ] **Cart functionality** (Test 3.1)
- [ ] **No 404 errors** (Test 7.1)

### Medium Priority (Should Pass)

- [ ] **Invoice generation** (Test 4.2)
- [ ] **History screen** (Test 5.1)
- [ ] **Role-based access** (Tests 6.1, 6.2)

### Launch Blockers

❌ **DO NOT LAUNCH IF:**
1. Payment can be bypassed
2. Insurance calculations are wrong
3. Data reverts after refresh
4. RLS is not enforced
5. Critical 404 errors exist

✅ **READY TO LAUNCH WHEN:**
1. All critical tests pass
2. All high priority tests pass
3. Real payment gateway integrated
4. No mock/placeholder logic remains
5. Load testing completed successfully

---

## 📊 Test Execution Log

| Test ID | Description | Tester | Date | Result | Notes |
|---------|-------------|--------|------|--------|-------|
| 1.1 | User Registration | | | ⏳ | |
| 1.2 | Questionnaire Flow | | | ⏳ | |
| 1.3 | Access Control | | | ⏳ | |
| 2.1 | Booking Without Insurance | | | ⏳ | |
| 2.2 | Booking With Insurance | | | ⏳ | |
| 2.3 | Payment Enforcement | | | ⏳ | CRITICAL |
| 2.4 | Payment Success | | | ⏳ | |
| 2.5 | Payment Failure | | | ⏳ | |
| 3.1 | Add to Cart | | | ⏳ | |
| 3.2 | Order With Insurance | | | ⏳ | |
| 3.3 | Order Without Insurance | | | ⏳ | |
| 3.4 | Order Payment Enforcement | | | ⏳ | CRITICAL |
| 3.5 | Order Confirmation | | | ⏳ | |
| 4.1 | Payment Gateway | | | ⏳ | Needs real API |
| 4.2 | Invoice Generation | | | ⏳ | Needs implementation |
| 5.1 | User History | | | ⏳ | |
| 5.2 | Data Persistence | | | ⏳ | |
| 6.1 | User Role | | | ⏳ | |
| 6.2 | Owner Role | | | ⏳ | |
| 7.1 | No 404 Errors | | | ⏳ | Manual testing |
| 7.2 | No Data Reversion | | | ⏳ | |
| 7.3 | Security | | | ⏳ | |
| 8.1 | Concurrent Users | | | ⏳ | Load testing |
| 8.2 | Logs & Monitoring | | | ⏳ | |

**Legend:**
- ⏳ Pending
- ✅ Passed
- ❌ Failed
- ⚠️ Blocked/Issues Found
