# Owner Portal Subscriptions - Quick Reference Guide

## Overview

All 4 subscription pages are now connected to real database data with automatic stats calculation.

## Pages & Stats

### 1. Overview (`/app/owner/subscriptions/index.tsx`)
**6 Statistics:**
- Total Plans
- Active Plans
- Active Subscriptions
- Monthly Revenue (auto: last 30 days)
- Total Revenue (auto: all-time)
- Expired Subscriptions

**Data Source:** subscription_plans, subscriptions, subscription_payments

---

### 2. Active Subscriptions (`/app/owner/subscriptions/active.tsx`)
**3 Statistics:**
- Total Active (status = 'active')
- Expiring Soon (auto: within 7 days)
- Total Revenue (sum of plan prices)

**Features:**
- User contact info (phone, name)
- Plan details and pricing
- Start/end dates
- Sessions remaining tracker

**Data Source:** subscriptions (active), users, subscription_plans, subscription_payments

---

### 3. Expired Subscriptions (`/app/owner/subscriptions/expired.tsx`)
**4 Statistics:**
- Total Expired (all-time)
- Expired Last Month (auto: 30-day period)
- Expired Last Year (auto: 365-day period)
- Total Lost Revenue (previous payments)

**Features:**
- Historical context (start → end dates)
- User info for re-engagement
- Plan information
- Lost revenue tracking

**Data Source:** subscriptions (expired), users, subscription_plans, subscription_payments

---

### 4. Revenue Analytics (`/app/owner/subscriptions/revenue.tsx`)
**Primary Stats (6 cards):**
- Total Revenue (all-time)
- Monthly Revenue (last 30 days)
- Weekly Revenue (auto: last 7 days)
- Daily Revenue (auto: today)
- Average Transaction (auto: mean)
- Success Rate (auto: % successful)

**Summary Cards (4 cards):**
- Successful Payments (auto: count)
- Failed Payments (auto: count)
- Pending Payments (auto: count)
- Total Transactions (auto: count)

**Recent Payments:**
- Last 50 successful transactions
- User names and plan names

**Data Source:** subscription_payments, users, subscription_plans

---

## Database Schema

### subscription_payments (NEW TABLE)
```
id (UUID, primary key)
user_id (FK → users)
plan_id (FK → subscription_plans)
subscription_id (FK → subscriptions)
amount (numeric)
currency (text, default: 'SAR')
payment_method (text)
payment_status (text: pending, succeeded, failed, cancelled)
transaction_id (unique text)
invoice_url (text)
metadata (JSONB)
notes (text)
created_at (timestamp)
updated_at (timestamp)
paid_at (timestamp, nullable)
```

**Indexes:**
- idx_subscription_payments_user_id
- idx_subscription_payments_plan_id
- idx_subscription_payments_status
- idx_subscription_payments_created_at
- idx_subscription_payments_subscription_id

---

## Filters Applied

### Overview
- Plans: All, ordered by price
- Subscriptions: All statuses
- Payments: Only succeeded

### Active Subscriptions
- Subscriptions: status = 'active'
- Expiration: end_date within 7 days (auto-calculated)

### Expired Subscriptions
- Subscriptions: status = 'expired'
- Period 1: Last 30 days (auto-calculated)
- Period 2: Last 365 days (auto-calculated)

### Revenue
- Payments: All (with status breakdown)
- Time periods: Daily, weekly, monthly, yearly (auto-calculated)
- Success rate: successful / total % (auto-calculated)

---

## Auto-Calculated Statistics

### Time-Based
- Weekly Revenue = sum(payments) where created_at >= 7 days ago
- Daily Revenue = sum(payments) where created_at >= today
- Monthly Revenue = sum(payments) where created_at >= month start
- Yearly Revenue = sum(payments) where created_at >= year start

### Status-Based
- Active Count = count(*) where status = 'active'
- Expired Count = count(*) where status = 'expired'
- Expiring Soon = count(*) where end_date <= now + 7 days

### Transaction-Based
- Success Rate = (successful / total) × 100
- Average Transaction = total revenue / successful count
- Payment Breakdown = count by payment_status

---

## Files Modified

```
/app/owner/subscriptions/index.tsx         → Updated with real queries
/app/owner/subscriptions/active.tsx        → Updated with real queries
/app/owner/subscriptions/expired.tsx       → Updated with real queries
/app/owner/subscriptions/revenue.tsx       → Updated with real queries

/supabase/migrations/
  add_subscription_payments_table.sql       → New migration (DB change)
```

---

## Key Features

✓ Real-time data from database
✓ Automatic stat calculations
✓ Pull-to-refresh functionality
✓ Error handling with alerts
✓ Loading states with spinners
✓ Arabic language support (RTL)
✓ Color-coded status indicators
✓ Responsive mobile layout
✓ Admin-only access via RLS
✓ Performance-optimized queries

---

## Testing Quick Checklist

Database:
- [ ] Migration applied successfully
- [ ] subscription_payments table exists
- [ ] Indexes created
- [ ] RLS policies enabled

Overview Page:
- [ ] 6 stats display
- [ ] Numbers update on refresh
- [ ] Plan listing shows all plans
- [ ] Plan toggle works

Active Subscriptions:
- [ ] Shows active subscriptions
- [ ] 7-day warning highlights correctly
- [ ] User contact info displays
- [ ] Phone numbers visible

Expired Subscriptions:
- [ ] Shows expired subscriptions
- [ ] Month/year breakdowns accurate
- [ ] Lost revenue calculated
- [ ] Historical data preserved

Revenue Page:
- [ ] 6 primary stats display
- [ ] 4 summary cards show breakdown
- [ ] Recent payments list loads
- [ ] Time periods calculated correctly
- [ ] Success rate is accurate

---

## Common Queries

### Check if data is loading
Navigate to any page and look for:
- Loading spinner during initial load
- Stats populate after 2-3 seconds
- No red error alerts

### Verify subscription counts
- Active: Should match count of subscriptions with status='active'
- Expired: Should match count of subscriptions with status='expired'
- Total: Sum of all subscription statuses

### Verify revenue calculations
- Monthly: Sum of subscription_payments.amount where payment_status='succeeded' and created_at >= 30 days ago
- Daily: Sum of subscription_payments.amount where payment_status='succeeded' and created_at >= today

### Check payment status breakdown
- Successful: count where payment_status = 'succeeded'
- Failed: count where payment_status = 'failed'
- Pending: count where payment_status = 'pending'

---

## Troubleshooting

### Stats show 0
- Check if data exists in database
- Verify RLS policies allow access
- Check browser console for errors
- Try pull-to-refresh

### Page won't load
- Check network connection
- Verify Supabase is accessible
- Check if user has admin access (for owner pages)
- Clear app cache and reload

### Wrong numbers
- Verify database queries are using correct filters
- Check date calculations for time periods
- Verify payment_status values are correct
- Check if all records have required fields

### Expiring Soon count incorrect
- Verify subscriptions have valid end_date
- Check if 7-day window calculation is correct (today + 7 days)
- Verify subscription status is 'active'

---

## Performance Notes

- All queries optimized with indexes
- Results limited to 50-100 records for big tables
- Sorted by relevant date fields for speed
- Uses selected columns only (no SELECT *)
- Admin access leverages RLS for security

---

## Future Work

1. Export data to CSV/PDF
2. Advanced filtering options
3. Charts and graphs
4. Subscription management (pause/cancel)
5. Email notifications for expiring subs
6. Revenue forecasting
7. A/B testing reports
8. Custom report builder
9. Webhook integrations
10. Bulk operations

---

## Support Resources

- Implementation Guide: `/OWNER_SUBSCRIPTIONS_IMPLEMENTATION_GUIDE.md`
- Integration Summary: `/OWNER_SUBSCRIPTIONS_INTEGRATION_SUMMARY.md`
- Database Migration: `/supabase/migrations/add_subscription_payments_table.sql`
- Component Files: `/app/owner/subscriptions/*.tsx`

---

## Contact & Questions

For implementation details, see the full guides:
- **OWNER_SUBSCRIPTIONS_IMPLEMENTATION_GUIDE.md** - Complete technical reference
- **OWNER_SUBSCRIPTIONS_INTEGRATION_SUMMARY.md** - Detailed statistics breakdown
