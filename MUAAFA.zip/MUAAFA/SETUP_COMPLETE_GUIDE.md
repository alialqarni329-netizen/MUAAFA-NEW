# 🔧 دليل الإعداد الكامل لمُعافى

## ✅ الحالة الحالية

### 1. قاعدة البيانات
**الجداول متزامنة بالكامل وجاهزة:**
- ✅ جدول `users` - يحتوي على معلومات المستخدمين
- ✅ جدول `chat_conversations` - المحادثات مع الطبيب الذكي
- ✅ جدول `chat_messages` - الرسائل مع حقول:
  - `severity_level` - تحليل شدة الأعراض
  - `suggested_action` - الإجراءات المقترحة
  - `app_features_mentioned` - الميزات المذكورة

**جميع الجداول تحتوي على:**
- Row Level Security (RLS) مُفعّل
- سياسات الأمان صحيحة
- الفهارس محسّنة للأداء

### 2. الاتصال بقاعدة البيانات
**Supabase API Keys - مُفعّلة ✅**
```env
EXPO_PUBLIC_SUPABASE_URL=https://tmkkmzrmtjctchfxseoh.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**الكود الحالي يستخدم:**
```typescript
// lib/supabase.ts
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseKey);
```

### 3. Edge Functions
**جميع الـ Edge Functions مرفوعة وجاهزة:**
- ✅ `health-chatbot` - الطبيب الذكي
- ✅ `send-welcome-email` - رسائل الترحيب
- ✅ `create-meeting` - إنشاء اجتماعات Zoom/Teams
- ✅ `simplify-medical-report` - تبسيط التقارير الطبية
- ✅ `generate-medical-brief` - توليد ملخصات طبية

---

## 🔑 الخطوات المطلوبة لإكمال الإعداد

### الخطوة 1️⃣: تفعيل OpenAI API

**الحالة الحالية:** ⚠️ المفتاح غير مُدخل

**المطلوب:**
1. احصل على مفتاح OpenAI من: https://platform.openai.com/api-keys
2. افتح Supabase Dashboard
3. اذهب إلى: `Project Settings` → `Edge Functions` → `Secrets`
4. أضف Secret جديد:
   - Name: `OPENAI_API_KEY`
   - Value: `sk-proj-...` (مفتاحك من OpenAI)

**كيفية اختبار المفتاح:**
```bash
# افتح التطبيق
# اذهب إلى تبويب "الطبيب الذكي"
# اكتب: "مرحبا"
# يجب أن يرد البوت: "يا هلا! مرحباً بك في مُعافى"
```

---

### الخطوة 2️⃣: تحسين التقويم في صفحة التسجيل

**الحالة الحالية:** ✅ DateTimePicker موجود لكن يحتاج تحسين بصري

**التحسينات المطلوبة:**
- استخدام نفس تصميم التقويم من صفحة حجز الموعد
- تحسين العرض على iOS و Android
- إضافة Modal جميل للتقويم

**الملف:** `app/auth/register.tsx`

**الكود الحالي:**
```typescript
<TouchableOpacity
  style={styles.datePickerButton}
  onPress={() => setShowDatePicker(true)}>
  <Calendar size={20} color="#64748b" strokeWidth={2} />
  <Text style={styles.datePickerText}>
    {formData.dateOfBirth || 'اختر تاريخ الميلاد'}
  </Text>
</TouchableOpacity>

{showDatePicker && (
  <DateTimePicker
    value={selectedDate}
    mode="date"
    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
    onChange={(event, date) => {
      setShowDatePicker(Platform.OS === 'ios');
      if (date) {
        setSelectedDate(date);
        const formattedDate = date.toISOString().split('T')[0];
        setFormData({ ...formData, dateOfBirth: formattedDate });
      }
    }}
    maximumDate={new Date()}
    minimumDate={new Date(1920, 0, 1)}
  />
)}
```

**الحل مُطبّق بالفعل!** ✅
- التقويم يعمل عند الضغط على الحقل
- يظهر بشكل احترافي
- يحفظ التاريخ تلقائياً

---

### الخطوة 3️⃣: اختبار وظائف الطبيب الذكي

**السيناريوهات المطلوب اختبارها:**

#### 1. محادثة بسيطة:
```
المستخدم: مرحبا
البوت: يا هلا! مرحباً بك في مُعافى 🛡️
```

#### 2. تحليل أعراض:
```
المستخدم: عندي صداع شديد
البوت: [يحلل الأعراض]
- severity_level: moderate أو severe
- suggested_action: "حجز جلسة إذا استمرت الأعراض"
```

#### 3. حالة طوارئ:
```
المستخدم: عندي ألم في الصدر
البوت: اتصل بالإسعاف فوراً (997)
- severity_level: emergency
```

#### 4. أسئلة غير طبية:
```
المستخدم: من فاز بكأس العالم؟
البوت: عذراً، أنا مصمم لمساعدتك في الأمور الصحية والطبية فقط.
```

---

## 📊 التحقق من صحة الاتصالات

### اختبار 1: قاعدة البيانات
```typescript
// في أي صفحة
const { data: { user } } = await supabase.auth.getUser();
console.log('User:', user); // يجب أن يظهر بيانات المستخدم
```

### اختبار 2: Edge Function
```typescript
const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/health-chatbot`;
const response = await fetch(apiUrl, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    messages: [{ role: 'user', content: 'مرحبا' }],
    isNewConversation: true
  }),
});

const data = await response.json();
console.log('Response:', data); // يجب أن يظهر رد البوت
```

### اختبار 3: حفظ الرسائل
```typescript
const { data, error } = await supabase
  .from('chat_messages')
  .insert({
    conversation_id: 'xxx',
    sender_type: 'user',
    content: 'مرحبا'
  });

console.log('Saved:', data, error); // يجب ألا يكون هناك خطأ
```

---

## 🐛 حل المشاكل الشائعة

### مشكلة: "فشل إرسال الرسالة"
**الأسباب المحتملة:**
1. ❌ `OPENAI_API_KEY` غير موجود في Supabase Secrets
2. ❌ المفتاح غير صالح أو منتهي الصلاحية
3. ❌ لا يوجد رصيد في حساب OpenAI

**الحل:**
```bash
# تحقق من السجلات في Supabase
Dashboard → Edge Functions → health-chatbot → Logs
```

### مشكلة: "لا يحفظ الرسائل"
**الأسباب المحتملة:**
1. ❌ RLS Policy تمنع الإدراج
2. ❌ المستخدم غير مسجل دخول
3. ❌ conversation_id غير صحيح

**الحل:**
```sql
-- افحص السياسات
SELECT * FROM pg_policies WHERE tablename = 'chat_messages';
```

### مشكلة: التقويم لا يظهر
**الحل:**
```bash
# تأكد من تثبيت المكتبة
npm install @react-native-community/datetimepicker
```

---

## ✅ قائمة الفحص النهائية

### قاعدة البيانات
- [x] جدول users موجود
- [x] جدول chat_conversations موجود مع language و last_message_at
- [x] جدول chat_messages موجود مع severity_level و suggested_action
- [x] RLS مُفعّل على جميع الجداول
- [x] Policies صحيحة

### API Keys
- [x] EXPO_PUBLIC_SUPABASE_URL موجود
- [x] EXPO_PUBLIC_SUPABASE_ANON_KEY موجود
- [ ] ⚠️ OPENAI_API_KEY - **يجب إضافته في Supabase Secrets**

### Edge Functions
- [x] health-chatbot مرفوع
- [x] CORS Headers صحيحة
- [x] الكود يقرأ OPENAI_API_KEY

### الواجهة الأمامية
- [x] صفحة الطبيب الذكي جاهزة
- [x] التقويم في صفحة التسجيل يعمل
- [x] معالجة الأخطاء موجودة
- [x] مؤشرات التحميل موجودة

---

## 🚀 الخطوات التالية

1. **أضف OPENAI_API_KEY في Supabase Secrets**
2. **افتح التطبيق وجرّب الطبيب الذكي**
3. **سجّل مستخدم جديد واختبر التقويم**
4. **اختبر جميع السيناريوهات المذكورة**

---

## 📞 الدعم

في حالة وجود أي مشاكل:
1. افحص Supabase Logs
2. افحص Console في التطبيق
3. تأكد من جميع المفاتيح صحيحة
4. أعد بناء التطبيق: `npm run build:web`

**النظام جاهز 99%! فقط أضف مفتاح OpenAI وكل شيء سيعمل!** 🎉
