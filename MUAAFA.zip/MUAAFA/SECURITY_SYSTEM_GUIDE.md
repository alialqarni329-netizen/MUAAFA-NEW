# 🔒 دليل نظام الأمان الشامل - تطبيق معافى

## نظرة عامة

تم تطبيق نظام أمان متقدم يمنع التسجيل المكرر ويحمي البيانات الحساسة في التطبيق. النظام يتكامل مع قاعدة البيانات Supabase ويعمل على مستويين:

1. **المستوى الأول:** التحقق على مستوى التطبيق (Client-side validation)
2. **المستوى الثاني:** القيود والتحقق على مستوى قاعدة البيانات (Database constraints)

---

## 🛡️ الحماية المطبقة

### للمستخدمين الأفراد (Individual Users)

| البيان | الحقل | القيد | الرسالة |
|--------|-------|-------|---------|
| رقم الهاتف | `phone` | UNIQUE | "رقم الهاتف مسجل مسبقاً في النظام" |
| الهوية الوطنية | `national_id` | UNIQUE | "رقم الهوية مسجل مسبقاً في النظام" |
| البريد الإلكتروني | `email` (في auth.users) | UNIQUE | "البريد الإلكتروني مسجل مسبقاً في النظام" |

### للمنشآت التجارية (Business Accounts)

| البيان | الحقل | القيد | الرسالة |
|--------|-------|-------|---------|
| رقم الهاتف | `phone` | UNIQUE | "رقم الهاتف مسجل مسبقاً" |
| البريد الإلكتروني | `email` | UNIQUE | "البريد الإلكتروني مسجل مسبقاً" |
| السجل التجاري | `commercial_registration` | UNIQUE | "رقم السجل التجاري مسجل مسبقاً" |

---

## 🔧 المكونات التقنية

### 1. القيود على مستوى قاعدة البيانات

#### جدول `users`
```sql
ALTER TABLE users ADD CONSTRAINT users_phone_unique UNIQUE (phone);
ALTER TABLE users ADD CONSTRAINT users_national_id_unique UNIQUE (national_id);
```

#### جدول `business_registrations`
```sql
ALTER TABLE business_registrations ADD CONSTRAINT business_registrations_phone_unique UNIQUE (phone);
ALTER TABLE business_registrations ADD CONSTRAINT business_registrations_email_unique UNIQUE (email);
ALTER TABLE business_registrations ADD CONSTRAINT business_registrations_cr_unique UNIQUE (commercial_registration);
```

### 2. الفهارس (Indexes) للأداء

```sql
-- لتسريع البحث
CREATE INDEX idx_users_phone ON users (phone) WHERE phone IS NOT NULL;
CREATE INDEX idx_users_national_id ON users (national_id) WHERE national_id IS NOT NULL;
CREATE INDEX idx_business_phone ON business_registrations (phone) WHERE phone IS NOT NULL;
CREATE INDEX idx_business_email ON business_registrations (lower(email)) WHERE email IS NOT NULL;
CREATE INDEX idx_business_cr ON business_registrations (commercial_registration) WHERE commercial_registration IS NOT NULL;
```

### 3. دوال التحقق من التكرار

#### دالة للمستخدمين الأفراد

```sql
CREATE FUNCTION check_duplicate_user_data(
  p_phone TEXT DEFAULT NULL,
  p_national_id TEXT DEFAULT NULL,
  p_email TEXT DEFAULT NULL
)
RETURNS TABLE (
  is_duplicate BOOLEAN,
  duplicate_field TEXT,
  error_message TEXT
)
```

**الاستخدام في التطبيق:**
```typescript
const { data: duplicateCheck, error } = await supabase
  .rpc('check_duplicate_user_data', {
    p_phone: '+966501234567',
    p_national_id: '1234567890',
    p_email: 'user@example.com',
  });

if (duplicateCheck[0].is_duplicate) {
  // البيانات مكررة
  console.log(duplicateCheck[0].duplicate_field); // 'phone', 'national_id', or 'email'
  console.log(duplicateCheck[0].error_message); // رسالة الخطأ بالعربي
}
```

#### دالة للمنشآت التجارية

```sql
CREATE FUNCTION check_duplicate_business_data(
  p_phone TEXT DEFAULT NULL,
  p_email TEXT DEFAULT NULL,
  p_commercial_registration TEXT DEFAULT NULL
)
RETURNS TABLE (
  is_duplicate BOOLEAN,
  duplicate_field TEXT,
  error_message TEXT
)
```

**الاستخدام:**
```typescript
const { data: duplicateCheck, error } = await supabase
  .rpc('check_duplicate_business_data', {
    p_phone: '0501234567',
    p_email: 'business@example.com',
    p_commercial_registration: '1234567890',
  });

if (duplicateCheck[0].is_duplicate) {
  // عرض رسالة خطأ
  Alert.alert('خطأ', duplicateCheck[0].error_message);
}
```

---

## 📱 التكامل مع التطبيق

### صفحة تسجيل الأفراد (`app/auth/register.tsx`)

**قبل إنشاء الحساب:**
```typescript
// 1. التحقق من الصيغة والتنسيق (Validation)
const phoneValidation = validatePhone(formData.phone);
const idValidation = validateNationalId(formData.nationalId);
const emailValidation = validateEmail(formData.email);

// 2. التحقق من التكرار في قاعدة البيانات
const { data: duplicateCheck } = await supabase
  .rpc('check_duplicate_user_data', {
    p_phone: normalizedPhone,
    p_national_id: formData.nationalId.trim(),
    p_email: trimmedEmail.toLowerCase(),
  });

// 3. إيقاف التسجيل إذا وجد تكرار
if (duplicateCheck[0].is_duplicate) {
  Alert.alert('لا يمكن التسجيل', errorMessage);
  return;
}

// 4. إنشاء الحساب
const { data: authData } = await supabase.auth.signUp({ ... });
```

### صفحة تسجيل الأعمال (`app/business/register.tsx`)

**نفس المنطق:**
```typescript
const { data: duplicateCheck } = await supabase
  .rpc('check_duplicate_business_data', {
    p_phone: formData.phone.trim(),
    p_email: formData.email.toLowerCase().trim(),
    p_commercial_registration: formData.commercialRegistration.trim(),
  });

if (duplicateCheck[0].is_duplicate) {
  // عرض رسالة خطأ مفصلة حسب الحقل المكرر
  Alert.alert('لا يمكن التسجيل', errorMessage);
  return;
}
```

---

## 🔍 أمثلة على الاختبار

### Test 1: محاولة تسجيل برقم هاتف مكرر

```typescript
// المستخدم الأول
await register({
  phone: '+966501234567',
  national_id: '1234567890',
  email: 'user1@example.com'
});
// ✅ نجح

// المستخدم الثاني (نفس الهاتف)
await register({
  phone: '+966501234567', // مكرر!
  national_id: '9876543210',
  email: 'user2@example.com'
});
// ❌ فشل: "رقم الهاتف مسجل مسبقاً في النظام"
```

### Test 2: محاولة تسجيل بهوية وطنية مكررة

```typescript
await register({
  phone: '+966509999999',
  national_id: '1234567890', // نفس الهوية من Test 1
  email: 'user3@example.com'
});
// ❌ فشل: "رقم الهوية مسجل مسبقاً في النظام"
```

### Test 3: محاولة تسجيل ببريد إلكتروني مكرر

```typescript
await register({
  phone: '+966508888888',
  national_id: '5555555555',
  email: 'user1@example.com' // نفس البريد من Test 1
});
// ❌ فشل: "البريد الإلكتروني مسجل مسبقاً في النظام"
```

### Test 4: محاولة تسجيل منشأة بسجل تجاري مكرر

```typescript
// المنشأة الأولى
await registerBusiness({
  phone: '0501234567',
  email: 'business1@example.com',
  commercial_registration: '1234567890'
});
// ✅ نجح

// المنشأة الثانية (نفس السجل التجاري)
await registerBusiness({
  phone: '0509999999',
  email: 'business2@example.com',
  commercial_registration: '1234567890' // مكرر!
});
// ❌ فشل: "رقم السجل التجاري مسجل مسبقاً في النظام"
```

---

## 🚨 معالجة الأخطاء

### على مستوى التطبيق

```typescript
try {
  const { data: duplicateCheck, error: checkError } = await supabase
    .rpc('check_duplicate_user_data', { ... });

  if (checkError) {
    // خطأ في الاتصال أو تنفيذ الدالة
    Alert.alert('خطأ', 'حدث خطأ أثناء التحقق من البيانات');
    return;
  }

  if (duplicateCheck[0].is_duplicate) {
    // البيانات مكررة - عرض رسالة مفصلة
    const field = duplicateCheck[0].duplicate_field;
    const message = duplicateCheck[0].error_message;

    if (field === 'phone') {
      Alert.alert('رقم الهاتف مكرر', 'الرقم مسجل مسبقاً...');
    }
    // ... إلخ
  }
} catch (error) {
  console.error('Unexpected error:', error);
  Alert.alert('خطأ غير متوقع', 'يرجى المحاولة مرة أخرى');
}
```

### على مستوى قاعدة البيانات

إذا حاول أحد تجاوز التطبيق والإدخال مباشرة في قاعدة البيانات:

```sql
-- محاولة إدخال رقم هاتف مكرر
INSERT INTO users (id, phone, ...)
VALUES ('...', '+966501234567', ...);

-- PostgreSQL سيرفض العملية:
-- ERROR: duplicate key value violates unique constraint "users_phone_unique"
-- DETAIL: Key (phone)=(+966501234567) already exists.
```

---

## 🔧 الصيانة والتحديث

### إضافة حقول جديدة للفحص

إذا أردت منع تكرار حقل جديد:

**1. إضافة UNIQUE constraint:**
```sql
ALTER TABLE users
ADD CONSTRAINT users_new_field_unique
UNIQUE (new_field);
```

**2. تحديث الدالة:**
```sql
CREATE OR REPLACE FUNCTION check_duplicate_user_data(
  p_phone TEXT DEFAULT NULL,
  p_national_id TEXT DEFAULT NULL,
  p_email TEXT DEFAULT NULL,
  p_new_field TEXT DEFAULT NULL  -- الحقل الجديد
)
RETURNS TABLE (...) AS $$
BEGIN
  -- ... الكود السابق

  -- إضافة فحص الحقل الجديد
  IF p_new_field IS NOT NULL THEN
    IF EXISTS (SELECT 1 FROM users WHERE new_field = p_new_field) THEN
      RETURN QUERY SELECT TRUE, 'new_field', 'الحقل الجديد مسجل مسبقاً';
      RETURN;
    END IF;
  END IF;

  RETURN QUERY SELECT FALSE, NULL::TEXT, NULL::TEXT;
END;
$$ LANGUAGE plpgsql;
```

**3. تحديث التطبيق:**
```typescript
const { data: duplicateCheck } = await supabase
  .rpc('check_duplicate_user_data', {
    p_phone: phone,
    p_national_id: nationalId,
    p_email: email,
    p_new_field: newField  // إضافة
  });
```

---

## 📊 إحصائيات وتقارير

### التحقق من البيانات المكررة القديمة

```sql
-- عرض الأرقام المعلمة كـ "مكررة قديمة"
SELECT id, phone, created_at
FROM users
WHERE phone LIKE '%-old%'
ORDER BY created_at DESC;

-- عرض الهويات المعلمة كمكررة
SELECT id, national_id, created_at
FROM users
WHERE national_id LIKE '%-old%'
ORDER BY created_at DESC;
```

### إحصائيات التسجيل

```sql
-- عدد المستخدمين حسب اليوم
SELECT
  DATE(created_at) as registration_date,
  COUNT(*) as total_users
FROM users
WHERE phone NOT LIKE '%-old%'
GROUP BY DATE(created_at)
ORDER BY registration_date DESC;

-- عدد المنشآت المسجلة
SELECT COUNT(*) as total_businesses
FROM business_registrations
WHERE phone NOT LIKE '%-old%';
```

---

## ✅ قائمة التحقق للمطورين

عند إضافة ميزة تسجيل جديدة:

- [ ] إضافة validation على مستوى التطبيق (Client-side)
- [ ] إضافة UNIQUE constraints على مستوى قاعدة البيانات
- [ ] تحديث أو إنشاء دالة check_duplicate
- [ ] إضافة Indexes للأداء
- [ ] اختبار جميع سيناريوهات التكرار
- [ ] اختبار رسائل الخطأ بالعربي
- [ ] التأكد من معالجة الأخطاء بشكل صحيح
- [ ] توثيق التغييرات

---

## 🔐 أفضل الممارسات الأمنية

1. **لا تثق أبداً في بيانات المستخدم**
   - دائماً تحقق على مستوى التطبيق وقاعدة البيانات

2. **استخدم Normalization للبيانات**
   - رقم الهاتف: تحويله دائماً إلى صيغة +966...
   - البريد الإلكتروني: تحويله إلى lowercase

3. **رسائل خطأ واضحة**
   - أخبر المستخدم بوضوح ما هي المشكلة
   - اقترح حلول (مثل: "يمكنك تسجيل الدخول أو استعادة كلمة المرور")

4. **Logging**
   - سجل محاولات التسجيل المكررة
   - راقب الأنماط المشبوهة

5. **Rate Limiting**
   - حدد عدد محاولات التسجيل من نفس IP
   - استخدم Supabase Auth rate limiting

---

## 📞 الدعم الفني

إذا واجهت مشاكل:

1. تحقق من logs في Supabase Dashboard
2. تأكد من تطبيق جميع migrations
3. راجع الدوال في SQL Editor
4. اختبر الدوال مباشرة في قاعدة البيانات

**اختبار سريع للدالة:**
```sql
SELECT * FROM check_duplicate_user_data(
  p_phone := '+966501234567',
  p_national_id := NULL,
  p_email := NULL
);
```

---

**آخر تحديث:** 30 ديسمبر 2025
**الإصدار:** 1.0.0
**الحالة:** ✅ مطبق ومفعّل
