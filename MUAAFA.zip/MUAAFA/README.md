# 🏥 Muaafa Health - مُعافى الصحة

<div align="center">

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Platform](https://img.shields.io/badge/platform-iOS%20%7C%20Android%20%7C%20Web-lightgrey.svg)
![React Native](https://img.shields.io/badge/React_Native-0.81.4-61DAFB.svg?logo=react)
![Expo](https://img.shields.io/badge/Expo-54.0.10-000020.svg?logo=expo)

**منصة طبية متكاملة توفر خدمات الرعاية الصحية عن بُعد**

**A comprehensive healthcare platform providing remote medical services**

[التوثيق العربي](#التوثيق-العربي) • [English Documentation](#english-documentation) • [Demo](#demo) • [تواصل معنا](#contact)

</div>

---

## 📋 جدول المحتويات | Table of Contents

### العربية:
- [نظرة عامة](#نظرة-عامة)
- [الميزات الرئيسية](#الميزات-الرئيسية)
- [التقنيات المستخدمة](#التقنيات-المستخدمة)
- [البدء السريع](#البدء-السريع)
- [البنية والهيكلة](#البنية-والهيكلة)
- [التوثيق](#التوثيق)

### English:
- [Overview](#overview)
- [Key Features](#key-features)
- [Technologies](#technologies)
- [Quick Start](#quick-start)
- [Project Structure](#project-structure)
- [Documentation](#documentation)

---

# التوثيق العربي

## 🎯 نظرة عامة

**مُعافى** هي منصة طبية شاملة تجمع بين الرعاية الصحية عن بُعد، إدارة الصيدليات، متابعة اللياقة البدنية، والتأمين الصحي في تطبيق واحد سهل الاستخدام.

### لماذا مُعافى؟

- ✅ **استشارات طبية فورية** عبر الفيديو أو المحادثة
- ✅ **طبيب ذكي** مدعوم بالذكاء الاصطناعي متاح 24/7
- ✅ **إدارة كاملة للأدوية** والصيدليات
- ✅ **متابعة اللياقة البدنية** والصحة العامة
- ✅ **نظام اشتراكات** مرن مع خطط متنوعة
- ✅ **التأمين الصحي** وإدارة المطالبات

---

## ✨ الميزات الرئيسية

### 1. 🩺 نظام الاستشارات الطبية

#### الجلسات الحية:
- **جلسات فيديو** عبر Zoom مع أطباء معتمدين
- **محادثات نصية** مباشرة مع الأطباء
- **غرفة انتظار** تفاعلية قبل الجلسة
- **تسجيل الجلسات** للرجوع إليها لاحقاً
- **إشعارات تلقائية** قبل الموعد بساعة

#### المواعيد:
- حجز مواعيد مع تحديد التاريخ والوقت
- اختيار نوع الجلسة (فيديو/نص)
- اختيار المنصة (Zoom/Teams)
- فلترة المواعيد (قادمة، جارية، مكتملة)
- إحصائيات شاملة للمواعيد

### 2. 🤖 الطبيب الذكي (AI Health Assistant)

- محادثات ذكية مدعومة بـ OpenAI GPT-4
- فهم الأعراض وتقديم نصائح أولية
- متاح 24/7 بدون انتظار
- يحفظ تاريخ المحادثات
- استجابات فورية وشخصية

### 3. 💊 نظام الصيدليات

#### إدارة الأدوية:
- **بحث متقدم** عن الأدوية
- **مسح الباركود** للأدوية
- **خزانة الأدوية** الشخصية
- **تذكيرات الدواء** في المواعيد المحددة
- **فحص التفاعلات** الدوائية

#### الطلبات:
- **سلة تسوق** ذكية
- **توصيل سريع** أو **استلام من الفرع**
- **تتبع الطلبات** المباشر
- **مقارنة الأسعار** بين الصيدليات
- **برنامج ولاء** ونقاط مكافآت

### 4. 💪 نظام اللياقة البدنية

- **تحديد أهداف** اللياقة الشخصية
- **تسجيل التمارين** اليومية
- **متابعة المقاييس** (وزن، BMI، ضغط الدم، إلخ)
- **إحصائيات تفصيلية** وتقارير التقدم
- **توصيات ذكية** بناءً على البيانات

### 5. 📄 التقارير الطبية

- **رفع التقارير** بصيغ متعددة (PDF, صور)
- **تبسيط التقارير** بالذكاء الاصطناعي
- **ملخصات طبية** سهلة الفهم
- **مشاركة آمنة** مع الأطباء
- **أرشفة منظمة** للتقارير

### 6. 🏢 التأمين الصحي

- **ربط بوالص التأمين**
- **طلبات الموافقة** الفورية
- **تتبع المطالبات**
- **شبكة موسعة** من شركات التأمين
- **إشعارات الموافقات** الفورية

### 7. 💳 نظام الاشتراكات

#### خطط متنوعة:
- **خطة أساسية** (مجانية): ميزات أساسية
- **خطة برونزية** (29 ر.س/شهر): ميزات محسّنة
- **خطة فضية** (49 ر.س/شهر): أولوية في الخدمات
- **خطة ذهبية** (99 ر.س/شهر): وصول كامل غير محدود

#### مميزات النظام:
- فترة تجريبية مجانية
- إلغاء في أي وقت
- ترقية/تخفيض مرنة
- دفع آمن

### 8. 🏪 حسابات الأعمال

#### للصيدليات:
- إدارة المخزون
- استقبال الطلبات
- معالجة الدفعات
- إحصائيات المبيعات

#### لشركات التوصيل:
- إدارة السائقين
- تتبع الطلبات
- تحسين المسارات
- لوحة تحكم متقدمة

#### لشركات التأمين:
- معالجة المطالبات
- إدارة البوالص
- شبكة مقدمي الخدمة
- تقارير شاملة

---

## 🛠️ التقنيات المستخدمة

### Frontend:
- **React Native** 0.81.4 - إطار العمل الرئيسي
- **Expo** 54.0.10 - أدوات التطوير والبناء
- **Expo Router** - نظام التنقل File-based
- **TypeScript** - للأمان والوضوح
- **Lucide React Native** - مكتبة الأيقونات

### Backend & Database:
- **Supabase** - قاعدة البيانات والمصادقة
  - PostgreSQL Database
  - Authentication & Authorization
  - Row Level Security (RLS)
  - Edge Functions (Serverless)
  - Real-time Subscriptions

### APIs & Services:
- **OpenAI GPT-4** - الطبيب الذكي
- **Zoom API** - جلسات الفيديو
- **Expo Notifications** - الإشعارات Push

### Development Tools:
- **Git** - إدارة النسخ
- **GitHub** - استضافة الكود
- **npm** - إدارة المكتبات
- **ESLint** - فحص الكود
- **Prettier** - تنسيق الكود

---

## 🚀 البدء السريع

### المتطلبات الأساسية:

```bash
# Node.js (v18 أو أحدث)
node --version

# npm أو yarn
npm --version

# Git
git --version
```

### 1. استنساخ المشروع

```bash
git clone https://github.com/YOUR_USERNAME/muaafa-health-app.git
cd muaafa-health-app
```

### 2. تثبيت المكتبات

```bash
npm install
```

### 3. إعداد متغيرات البيئة

```bash
# انسخ من المثال
cp .env.example .env

# حرر الملف وأضف المفاتيح الحقيقية
nano .env
```

محتوى `.env`:
```env
EXPO_PUBLIC_SUPABASE_URL=your_supabase_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
OPENAI_API_KEY=your_openai_key
ZOOM_ACCOUNT_ID=your_zoom_account_id
ZOOM_CLIENT_ID=your_zoom_client_id
ZOOM_CLIENT_SECRET=your_zoom_client_secret
```

### 4. إعداد قاعدة البيانات

راجع [DATABASE_EXPORT_GUIDE.md](DATABASE_EXPORT_GUIDE.md) للتفاصيل:

```bash
# استورد الـ schema
psql "your_connection_string" < supabase_schema.sql
```

### 5. رفع Edge Functions

```bash
# تثبيت Supabase CLI
npm install -g supabase

# تسجيل دخول
supabase login

# ربط المشروع
supabase link --project-ref YOUR_PROJECT_ID

# رفع الـ functions
supabase functions deploy create-meeting
supabase functions deploy health-chatbot
# ... الخ
```

### 6. تشغيل التطبيق

```bash
# للتطوير
npm run dev

# للويب فقط
npm run dev -- --web

# بناء للإنتاج
npm run build:web
```

---

## 📁 البنية والهيكلة

```
muaafa-health-app/
├── app/                          # صفحات التطبيق (Expo Router)
│   ├── (tabs)/                  # التنقل بالـ Tabs
│   │   ├── index.tsx           # الصفحة الرئيسية
│   │   ├── sessions.tsx        # الجلسات والمواعيد
│   │   ├── pharmacies.tsx      # الصيدليات
│   │   ├── fitness.tsx         # اللياقة
│   │   ├── reports.tsx         # التقارير الطبية
│   │   └── settings.tsx        # الإعدادات
│   ├── auth/                    # صفحات المصادقة
│   │   ├── login.tsx
│   │   ├── register.tsx
│   │   └── forgot-password.tsx
│   ├── business/                # حسابات الأعمال
│   ├── telehealth/              # الاستشارات الطبية
│   ├── pharmacy/                # نظام الصيدليات
│   ├── fitness/                 # نظام اللياقة
│   └── admin/                   # لوحة الإدارة
├── components/                   # المكونات القابلة لإعادة الاستخدام
│   ├── GlobalFAB.tsx           # زر الإجراءات العائم
│   ├── FloatingCartButton.tsx  # زر سلة التسوق
│   ├── LanguageSelector.tsx    # محدد اللغة
│   └── SubscriptionBanner.tsx  # بانر الاشتراكات
├── lib/                         # المكتبات والأدوات المساعدة
│   ├── supabase.ts             # إعداد Supabase
│   ├── ai-agent.ts             # AI Chatbot
│   ├── notifications.ts         # الإشعارات
│   ├── subscription.ts          # نظام الاشتراكات
│   ├── cart-utils.ts           # أدوات السلة
│   └── i18n/                   # الترجمات
│       ├── LanguageContext.tsx
│       └── translations.ts
├── supabase/                    # ملفات Supabase
│   ├── migrations/             # هجرات قاعدة البيانات
│   └── functions/              # Edge Functions
│       ├── create-meeting/
│       ├── health-chatbot/
│       ├── send-welcome-email/
│       └── test-zoom-connection/
├── types/                       # تعريفات TypeScript
│   └── database.ts
├── .env                         # متغيرات البيئة (لا تُرفع لـ Git!)
├── .env.example                # مثال لمتغيرات البيئة
├── .gitignore                  # ملفات مستثناة من Git
├── app.json                    # إعدادات Expo
├── package.json                # مكتبات npm
├── tsconfig.json               # إعدادات TypeScript
└── README.md                   # هذا الملف
```

---

## 📚 التوثيق

### الأدلة الشاملة:

| الملف | الوصف |
|------|------|
| [START_HERE.md](START_HERE.md) | نقطة البداية للمطورين الجدد |
| [GIT_SETUP_GUIDE.md](GIT_SETUP_GUIDE.md) | إعداد Git و GitHub |
| [DATABASE_EXPORT_GUIDE.md](DATABASE_EXPORT_GUIDE.md) | تصدير ونقل قاعدة البيانات |
| [PROJECT_MIGRATION_GUIDE.md](PROJECT_MIGRATION_GUIDE.md) | نقل المشروع الكامل |
| [ZOOM_SETUP_GUIDE.md](ZOOM_SETUP_GUIDE.md) | إعداد واختبار Zoom |
| [ZOOM_INTEGRATION_COMPLETE.md](ZOOM_INTEGRATION_COMPLETE.md) | تقرير تكامل Zoom |

### الأدلة الفنية:

| الملف | الوصف |
|------|------|
| [SUBSCRIPTION_SYSTEM_GUIDE.md](SUBSCRIPTION_SYSTEM_GUIDE.md) | نظام الاشتراكات |
| [AI_HEALTH_ASSISTANT_GUIDE.md](AI_HEALTH_ASSISTANT_GUIDE.md) | الطبيب الذكي |
| [PHARMACY_AI_INTEGRATION_GUIDE.md](PHARMACY_AI_INTEGRATION_GUIDE.md) | تكامل AI بالصيدليات |
| [TELEHEALTH_SYSTEM.md](TELEHEALTH_SYSTEM.md) | نظام الاستشارات |
| [SMART_FITNESS_SYSTEM.md](SMART_FITNESS_SYSTEM.md) | نظام اللياقة |
| [NOTIFICATIONS_SYSTEM_GUIDE.md](NOTIFICATIONS_SYSTEM_GUIDE.md) | نظام الإشعارات |

---

## 🔐 الأمان

### Row Level Security (RLS):
- ✅ مفعّل على جميع الجداول
- ✅ سياسات محددة لكل عملية (SELECT, INSERT, UPDATE, DELETE)
- ✅ فحص الهوية والصلاحيات
- ✅ عزل كامل للبيانات بين المستخدمين

### تشفير البيانات:
- ✅ HTTPS لجميع الاتصالات
- ✅ تشفير قاعدة البيانات
- ✅ تشفير الملفات المرفوعة
- ✅ حماية المفاتيح السرية

### المصادقة:
- ✅ Supabase Auth
- ✅ OAuth (Google - قيد التطوير)
- ✅ إعادة تعيين كلمة المرور الآمنة
- ✅ جلسات محدودة بوقت

---

## 🧪 الاختبار

### اختبار محلي:

```bash
# تشغيل التطبيق
npm run dev

# اختبار البناء
npm run build:web
```

### اختبار الميزات:

راجع [QA_COMPREHENSIVE_REPORT.md](QA_COMPREHENSIVE_REPORT.md) للحصول على قائمة اختبار شاملة.

---

## 🚢 النشر

### Expo:
```bash
# Build للأندرويد
eas build --platform android

# Build لـ iOS
eas build --platform ios

# Build للويب
npm run build:web
```

### Vercel (Web):
```bash
npm install -g vercel
vercel --prod
```

راجع [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) للتفاصيل.

---

## 🤝 المساهمة

نرحب بالمساهمات! اتبع الخطوات:

1. Fork المشروع
2. أنشئ branch للميزة (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push للـ branch (`git push origin feature/amazing-feature`)
5. افتح Pull Request

---

## 📄 الترخيص

هذا المشروع مرخص تحت [MIT License](LICENSE).

---

## 📞 التواصل

- **GitHub**: [YOUR_USERNAME](https://github.com/YOUR_USERNAME)
- **Email**: your.email@example.com
- **الموقع**: https://muaafa-health.com (قريباً)

---

## 🙏 شكر وتقدير

- [Expo](https://expo.dev/) - إطار عمل رائع
- [Supabase](https://supabase.com/) - Backend قوي ومرن
- [OpenAI](https://openai.com/) - AI مذهل
- [Zoom](https://zoom.us/) - جلسات فيديو موثوقة
- جميع المساهمين في المشروع

---

<div align="center">

**صُنع بـ ❤️ في السعودية 🇸🇦**

**Made with ❤️ in Saudi Arabia 🇸🇦**

⭐ إذا أعجبك المشروع، لا تنسى وضع نجمة!

</div>
