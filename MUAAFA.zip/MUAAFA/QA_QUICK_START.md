# 🚀 دليل البدء السريع - اختبار تطبيق معافى

## 📁 ملفات الاختبار المتوفرة

لقد تم إنشاء مجموعة شاملة من أدوات وتوثيق الاختبار:

### 1. 📊 **QA_TEST_SUITE.md**
**الأهم - ابدأ هنا!**
- قائمة شاملة بجميع الاختبارات (24 اختبار)
- حالة كل اختبار
- الأولويات والتصنيفات
- جدول تنفيذ الاختبارات

### 2. 📖 **QA_TESTING_MANUAL.md**
**دليل الاختبار اليدوي خطوة بخطوة**
- تعليمات مفصلة لكل اختبار
- الخطوات المطلوبة
- النتائج المتوقعة
- كيفية التحقق من قاعدة البيانات
- نموذج تقرير يمكن طباعته

### 3. 🗄️ **TEST_DATA_SETUP.sql**
**بيانات اختبار جاهزة**
- سكريبت SQL لإنشاء بيانات اختبار
- حسابات مستخدمين
- جلسات طبية
- طلبات صيدلية
- بوليصات تأمين
- أوامر التحقق

### 4. 🔧 **lib/test-helpers.ts**
**أدوات الاختبار التلقائي**
- دوال مساعدة للاختبار
- TestRunner class
- اختبارات تلقائية للوظائف الحرجة

### 5. 📋 **LAUNCH_READINESS_REPORT.md**
**تقرير الجاهزية للإطلاق**
- ملخص تنفيذي
- المكونات المنفذة
- المكونات الناقصة
- الجدول الزمني المقترح
- قرار الإطلاق

### 6. 💳 **PAYMENT_SYSTEM_GUIDE.md**
**دليل نظام الدفع الشامل**
- شرح معماري كامل
- أمثلة على الاستخدام
- دليل الأمان
- كود الاختبار

---

## ⚡ البدء السريع (5 دقائق)

### الخطوة 1: افتح QA_TEST_SUITE.md
```bash
# في VS Code أو أي محرر نصوص
code QA_TEST_SUITE.md
```

### الخطوة 2: راجع الاختبارات الحرجة
ركز على هذه الاختبارات **أولاً**:
- ✅ Test 2.3: منع التأكيد بدون دفع 🔥
- ✅ Test 2.4: نجاح الدفع والتأكيد التلقائي 🔥
- ✅ Test 3.4: منع تأكيد طلب بدون دفع 🔥
- ✅ Test 7.3: أمان RLS 🔥

### الخطوة 3: أنشئ بيانات اختبار
```sql
-- افتح Supabase Dashboard → SQL Editor
-- الصق محتويات TEST_DATA_SETUP.sql
-- استبدل 'USER_ID_HERE' بمعرف مستخدم حقيقي
-- نفّذ السكريبت
```

### الخطوة 4: ابدأ الاختبار اليدوي
```bash
# افتح الدليل اليدوي
code QA_TESTING_MANUAL.md

# ابدأ من Test 2.3 (الأهم!)
```

---

## 🔥 الاختبارات الحرجة (لا تطلق بدونها!)

### Test 2.3: منع التأكيد بدون دفع

**لماذا حرج؟**
إذا فشل هذا الاختبار، يمكن للمستخدمين حجز جلسات بدون دفع!

**كيف تختبره:**
```sql
-- أنشئ جلسة
INSERT INTO medical_sessions (...) VALUES (...);

-- حاول تأكيدها بدون دفع (يجب أن يفشل!)
UPDATE medical_sessions
SET session_status = 'confirmed'
WHERE payment_status = 'pending';

-- تحقق: يجب أن تبقى pending
SELECT payment_status, session_status FROM medical_sessions WHERE id = 'session-id';
```

**النتيجة المتوقعة:**
- ✅ لا يتم تحديث الحالة
- ✅ تبقى الجلسة pending

**إذا فشل:** ❌ **لا تطلق التطبيق!**

---

### Test 2.4: التأكيد التلقائي بعد الدفع

**لماذا حرج؟**
هذا هو جوهر نظام الدفع الإلزامي!

**كيف تختبره:**
```sql
-- دفع للجلسة
UPDATE medical_sessions
SET payment_status = 'paid'
WHERE id = 'session-id';

-- انتظر ثانية، ثم تحقق
SELECT
  payment_status,  -- يجب أن تكون 'paid'
  session_status,  -- يجب أن تكون 'confirmed' (تلقائي!)
  paid_at,         -- يجب أن يحتوي timestamp
  confirmed_at     -- يجب أن يحتوي timestamp
FROM medical_sessions
WHERE id = 'session-id';
```

**النتيجة المتوقعة:**
- ✅ session_status = 'confirmed' تلقائياً
- ✅ paid_at و confirmed_at محددان

**إذا فشل:** ❌ **لا تطلق التطبيق!**

---

### Test 7.3: أمان RLS

**لماذا حرج؟**
خطر أمني! المستخدمون لا يجب أن يروا بيانات بعضهم.

**كيف تختبره:**
```sql
-- سجل دخول كمستخدم A
-- أنشئ جلسة

-- سجل دخول كمستخدم B
-- حاول الوصول لجلسة A
SELECT * FROM medical_sessions WHERE user_id = 'user-a-id';

-- يجب أن يرجع 0 صفوف
```

**النتيجة المتوقعة:**
- ✅ لا توجد نتائج
- ✅ RLS يمنع الوصول

**إذا فشل:** ❌ **خطر أمني - لا تطلق!**

---

## 📋 قائمة مراجعة سريعة

قبل الإطلاق، تأكد من:

### 🔥 حرج (MUST)
- [ ] Test 2.3 نجح (منع التأكيد بدون دفع)
- [ ] Test 2.4 نجح (التأكيد التلقائي)
- [ ] Test 2.5 نجح (فشل الدفع)
- [ ] Test 3.4 نجح (منع تأكيد طلب صيدلية)
- [ ] Test 7.3 نجح (أمان RLS)
- [ ] ZedPay متكامل فعلياً (ليس mock)
- [ ] لا أخطاء 404

### ⚠️ مهم (SHOULD)
- [ ] Test 2.2 نجح (حسابات التأمين)
- [ ] Test 3.2 نجح (طلب مع تأمين)
- [ ] الفواتير تُنشأ تلقائياً
- [ ] صفحة السجل تعمل
- [ ] اختبار أداء أساسي

### 📝 جيد (NICE TO HAVE)
- [ ] نظام السجلات (Logging)
- [ ] عرض الفواتير بصيغة PDF
- [ ] تحسينات UI/UX

---

## 🎯 الأولويات

### اليوم 1: الاختبارات الحرجة
1. ✅ Test 2.3 (منع التأكيد بدون دفع)
2. ✅ Test 2.4 (التأكيد التلقائي)
3. ✅ Test 3.4 (منع تأكيد طلب)
4. ✅ Test 7.3 (أمان RLS)

**إذا فشل أي منها → أصلح فوراً!**

### اليوم 2: التكاملات
1. ✅ تكامل ZedPay الحقيقي
2. ✅ الفواتير التلقائية
3. ✅ اختبار التأمين

### اليوم 3: المراجعة النهائية
1. ✅ اختبار شامل لجميع المسارات
2. ✅ فحص 404
3. ✅ اختبار الأداء

---

## 🆘 في حالة فشل اختبار حرج

### إذا فشل Test 2.3 (منع التأكيد)

**المشكلة:** يمكن تأكيد جلسات بدون دفع

**الحل:**
1. تحقق من RLS Policy:
```sql
-- يجب أن تكون موجودة
SELECT * FROM pg_policies
WHERE tablename = 'medical_sessions'
AND policyname = 'Users can update own pending sessions';
```

2. أعد إنشاء Policy:
```sql
DROP POLICY IF EXISTS "Users can update own pending sessions" ON medical_sessions;

CREATE POLICY "Users can update own pending sessions"
  ON medical_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND payment_status = 'pending')
  WITH CHECK (auth.uid() = user_id);
```

3. اختبر مرة أخرى

---

### إذا فشل Test 2.4 (التأكيد التلقائي)

**المشكلة:** الجلسة لا تتأكد تلقائياً بعد الدفع

**الحل:**
1. تحقق من Trigger:
```sql
SELECT * FROM pg_trigger
WHERE tgname = 'medical_session_payment_trigger';
```

2. أعد إنشاء Trigger:
```sql
DROP TRIGGER IF EXISTS medical_session_payment_trigger ON medical_sessions;

CREATE TRIGGER medical_session_payment_trigger
  BEFORE UPDATE ON medical_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_session_after_payment();
```

3. اختبر مرة أخرى

---

## 📞 الدعم

إذا واجهت مشاكل:

1. **راجع الأدلة:**
   - `PAYMENT_SYSTEM_GUIDE.md` - دليل النظام الكامل
   - `QA_TESTING_MANUAL.md` - تعليمات مفصلة

2. **تحقق من قاعدة البيانات:**
   - استخدم queries في `TEST_DATA_SETUP.sql`
   - تحقق من RLS policies
   - تحقق من Triggers

3. **راجع الكود:**
   - `lib/payment-utils.ts` - منطق الدفع
   - `supabase/migrations/` - هيكل قاعدة البيانات

---

## ✅ النجاح = الإطلاق

عندما تنجح **جميع** الاختبارات الحرجة:

```
✅ Test 2.3 PASSED
✅ Test 2.4 PASSED
✅ Test 2.5 PASSED
✅ Test 3.4 PASSED
✅ Test 7.3 PASSED
✅ ZedPay INTEGRATED
✅ No 404 Errors
```

**يمكنك الإطلاق! 🚀**

---

**آخر تحديث:** 30 ديسمبر 2025
**الإصدار:** 1.0.0
