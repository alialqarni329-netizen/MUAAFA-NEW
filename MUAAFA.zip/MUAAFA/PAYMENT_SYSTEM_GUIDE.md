# نظام الدفع الإلزامي - دليل شامل

## نظرة عامة

تم تنفيذ نظام دفع إلزامي شامل يضمن عدم إمكانية تأكيد أي جلسة طبية أو طلب صيدلية بدون إتمام الدفع. النظام يدعم التأمين الصحي ويولد فواتير إلكترونية تلقائياً.

## 🎯 القواعد الأساسية

### قاعدة الدفع الإلزامي
- ❌ **لا يمكن** تأكيد جلسة طبية بدون دفع
- ❌ **لا يمكن** تأكيد طلب صيدلية بدون دفع
- ✅ **يجب** إتمام الدفع أولاً ثم التأكيد التلقائي
- ✅ **يتم** تطبيق التأمين تلقائياً إذا كان متوفراً

### التدفق العام
```
إنشاء الحجز/الطلب (pending)
    ↓
حساب التأمين (إن وجد)
    ↓
توجيه المستخدم لبوابة الدفع
    ↓
إتمام الدفع
    ↓
تحديث الحالة إلى (paid)
    ↓
تأكيد تلقائي (confirmed)
    ↓
إنشاء فاتورة إلكترونية
```

---

## 📊 قاعدة البيانات

### الجداول الرئيسية

#### 1. insurance_policies
بوليصات التأمين للمستخدمين

```sql
CREATE TABLE insurance_policies (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  policy_number TEXT UNIQUE NOT NULL,
  provider_name TEXT NOT NULL,
  coverage_percentage NUMERIC(5,2) NOT NULL, -- 0-100
  coverage_limit NUMERIC(10,2),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT CHECK (status IN ('active', 'expired', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

**مثال:**
```json
{
  "policy_number": "INS-2025-001",
  "provider_name": "شركة الراجحي للتأمين",
  "coverage_percentage": 80,
  "status": "active"
}
```

#### 2. medical_sessions
الجلسات الطبية

```sql
CREATE TABLE medical_sessions (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  doctor_name TEXT NOT NULL,
  specialty TEXT NOT NULL,
  session_date TIMESTAMPTZ NOT NULL,
  price NUMERIC(10,2) NOT NULL,
  insurance_policy_id UUID REFERENCES insurance_policies(id),
  insurance_covered NUMERIC(10,2) DEFAULT 0,
  user_payable NUMERIC(10,2) NOT NULL,
  payment_status TEXT CHECK (status IN ('pending', 'paid', 'failed', 'refunded')),
  session_status TEXT CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  paid_at TIMESTAMPTZ,
  confirmed_at TIMESTAMPTZ
);
```

**حالات الجلسة:**
- `pending` → في انتظار الدفع
- `confirmed` → مؤكدة بعد الدفع
- `completed` → منتهية
- `cancelled` → ملغاة

#### 3. pharmacy_orders
طلبات الصيدلية

```sql
CREATE TABLE pharmacy_orders (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  pharmacy_id UUID,
  pharmacy_name TEXT NOT NULL,
  items JSONB NOT NULL,
  total_price NUMERIC(10,2) NOT NULL,
  insurance_policy_id UUID REFERENCES insurance_policies(id),
  insurance_covered NUMERIC(10,2) DEFAULT 0,
  user_payable NUMERIC(10,2) NOT NULL,
  payment_status TEXT CHECK (status IN ('pending', 'paid', 'failed', 'refunded')),
  order_status TEXT CHECK (status IN ('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled')),
  delivery_address TEXT,
  paid_at TIMESTAMPTZ,
  confirmed_at TIMESTAMPTZ
);
```

#### 4. invoices
الفواتير الإلكترونية

```sql
CREATE TABLE invoices (
  id UUID PRIMARY KEY,
  invoice_number TEXT UNIQUE NOT NULL,
  user_id UUID REFERENCES users(id),
  reference_type TEXT CHECK (type IN ('medical_session', 'pharmacy_order')),
  reference_id UUID NOT NULL,
  amount_paid NUMERIC(10,2) NOT NULL,
  insurance_covered NUMERIC(10,2) DEFAULT 0,
  total_amount NUMERIC(10,2) NOT NULL,
  payment_method TEXT NOT NULL,
  invoice_date TIMESTAMPTZ DEFAULT NOW()
);
```

#### 5. payment_transactions
سجل المعاملات المالية

```sql
CREATE TABLE payment_transactions (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  reference_type TEXT CHECK (type IN ('medical_session', 'pharmacy_order')),
  reference_id UUID NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  payment_method TEXT NOT NULL,
  payment_gateway TEXT CHECK (gateway IN ('zedpay', 'stripe', 'paypal')),
  gateway_transaction_id TEXT,
  status TEXT CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'refunded')),
  completed_at TIMESTAMPTZ
);
```

---

## 🔧 الدوال المساعدة

### 1. حساب المبلغ بعد التأمين

```typescript
// lib/payment-utils.ts

export function calculatePayment(
  price: number,
  insuranceCoverage?: number
): PaymentCalculation {
  if (!insuranceCoverage || insuranceCoverage <= 0) {
    return {
      insuranceCovered: 0,
      userPayable: price,
    };
  }

  const coveredAmount = price * (insuranceCoverage / 100);
  return {
    insuranceCovered: Math.round(coveredAmount * 100) / 100,
    userPayable: Math.round((price - coveredAmount) * 100) / 100,
  };
}
```

**مثال:**
```typescript
const result = calculatePayment(200, 80);
// نتيجة: { insuranceCovered: 160, userPayable: 40 }
```

### 2. إنشاء جلسة طبية

```typescript
export async function createMedicalSession(
  userId: string,
  doctorName: string,
  specialty: string,
  sessionDate: Date,
  price: number,
  insurancePolicyId?: string
) {
  // حساب التأمين تلقائياً
  let insuranceCovered = 0;
  let userPayable = price;

  if (insurancePolicyId) {
    const { data: calcResult } = await supabase.rpc('calculate_user_payable', {
      total_price: price,
      insurance_policy_id: insurancePolicyId,
    });

    if (calcResult && calcResult.length > 0) {
      insuranceCovered = calcResult[0].insurance_covered || 0;
      userPayable = calcResult[0].user_payable || price;
    }
  }

  // إنشاء الجلسة في حالة pending
  const { data, error } = await supabase
    .from('medical_sessions')
    .insert({
      user_id: userId,
      doctor_name: doctorName,
      specialty: specialty,
      session_date: sessionDate.toISOString(),
      price: price,
      insurance_policy_id: insurancePolicyId || null,
      insurance_covered: insuranceCovered,
      user_payable: userPayable,
      payment_status: 'pending',
      session_status: 'pending',
    })
    .select()
    .single();

  return data;
}
```

### 3. تحديث حالة الدفع

```typescript
export async function updatePaymentStatus(
  type: 'medical_session' | 'pharmacy_order',
  id: string,
  status: 'paid' | 'failed' | 'refunded',
  paymentMethod?: string,
  gatewayTransactionId?: string
) {
  const tableName = type === 'medical_session' ? 'medical_sessions' : 'pharmacy_orders';

  // تحديث حالة الدفع
  const { data, error } = await supabase
    .from(tableName)
    .update({
      payment_status: status,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .single();

  // إنشاء سجل المعاملة
  if (status === 'paid') {
    await supabase.from('payment_transactions').insert({
      user_id: data.user_id,
      reference_type: type,
      reference_id: id,
      amount: data.user_payable,
      payment_method: paymentMethod || 'zedpay',
      payment_gateway: 'zedpay',
      gateway_transaction_id: gatewayTransactionId || null,
      status: 'completed',
      completed_at: new Date().toISOString(),
    });
  }

  return data;
}
```

---

## 🎨 الواجهات

### 1. صفحة حجز جلسة طبية

**الملف:** `app/book-medical-session.tsx`

**الميزات:**
- ✅ عرض التأمين الفعال إن وجد
- ✅ حساب المبلغ بعد التأمين تلقائياً
- ✅ منع التأكيد بدون دفع
- ✅ تحويل لبوابة الدفع

**الاستخدام:**
```typescript
// المستخدم يملأ النموذج
const session = await createMedicalSession(
  userId,
  'د. أحمد محمد',
  'قلب',
  new Date('2025-01-15 10:00'),
  200,
  insuranceId // اختياري
);

// تحويل لبوابة الدفع
const paymentUrl = generatePaymentUrl(
  session.id,
  session.user_payable,
  'medical_session'
);

Linking.openURL(paymentUrl);
```

### 2. صفحة إتمام طلب الصيدلية

**الملف:** `app/pharmacy-checkout.tsx`

**الميزات:**
- ✅ عرض ملخص الطلب
- ✅ حساب التأمين على الأدوية
- ✅ إدخال عنوان التوصيل
- ✅ تحويل لبوابة الدفع

**الاستخدام:**
```typescript
const order = await createPharmacyOrder(
  userId,
  pharmacyId,
  'صيدلية النهدي',
  cartItems,
  totalPrice,
  insuranceId,
  deliveryAddress
);

const paymentUrl = generatePaymentUrl(
  order.id,
  order.user_payable,
  'pharmacy_order'
);

Linking.openURL(paymentUrl);
```

### 3. صفحة نتيجة الدفع

**الملف:** `app/payment-success.tsx`

**المعاملات:**
- `type`: نوع العملية (medical_session أو pharmacy_order)
- `id`: معرف الجلسة أو الطلب
- `status`: حالة الدفع (success أو failed)
- `transaction_id`: رقم المعاملة من بوابة الدفع

**مثال URL:**
```
myapp://payment/success?type=medical_session&id=xxx&status=success&transaction_id=TXN123
```

---

## 🔒 الأمان

### Row Level Security (RLS)

#### 1. الجلسات الطبية

```sql
-- المستخدم يرى فقط جلساته
CREATE POLICY "Users can view own sessions"
  ON medical_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- المستخدم يمكنه تعديل الجلسات المعلقة فقط
CREATE POLICY "Users can update own pending sessions"
  ON medical_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND payment_status = 'pending')
  WITH CHECK (auth.uid() = user_id);
```

#### 2. طلبات الصيدلية

```sql
-- نفس السياسات مع pharmacy_orders
CREATE POLICY "Users can update own pending orders"
  ON pharmacy_orders FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND payment_status = 'pending')
  WITH CHECK (auth.uid() = user_id);
```

### التريجرز (Triggers)

#### تأكيد تلقائي بعد الدفع

```sql
CREATE OR REPLACE FUNCTION update_session_after_payment()
RETURNS TRIGGER AS $$
BEGIN
  -- عندما يتغير payment_status إلى paid
  IF NEW.payment_status = 'paid' AND OLD.payment_status != 'paid' THEN
    -- تأكيد الجلسة تلقائياً
    NEW.session_status := 'confirmed';
    NEW.paid_at := NOW();
    NEW.confirmed_at := NOW();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER medical_session_payment_trigger
  BEFORE UPDATE ON medical_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_session_after_payment();
```

---

## 🧪 الاختبار

### 1. اختبار حجز جلسة مع تأمين

```typescript
// 1. إنشاء بوليصة تأمين
const { data: insurance } = await supabase
  .from('insurance_policies')
  .insert({
    user_id: userId,
    policy_number: 'TEST-001',
    provider_name: 'تأمين تجريبي',
    coverage_percentage: 80,
    start_date: '2025-01-01',
    end_date: '2025-12-31',
    status: 'active',
  })
  .select()
  .single();

// 2. إنشاء جلسة
const session = await createMedicalSession(
  userId,
  'د. محمد',
  'عام',
  new Date(),
  200,
  insurance.id
);

// تحقق
expect(session.insurance_covered).toBe(160); // 80% من 200
expect(session.user_payable).toBe(40); // 20% من 200
expect(session.payment_status).toBe('pending');
expect(session.session_status).toBe('pending');

// 3. محاكاة دفع ناجح
await updatePaymentStatus('medical_session', session.id, 'paid', 'zedpay', 'TXN123');

// 4. التحقق من التأكيد التلقائي
const { data: updatedSession } = await supabase
  .from('medical_sessions')
  .select()
  .eq('id', session.id)
  .single();

expect(updatedSession.payment_status).toBe('paid');
expect(updatedSession.session_status).toBe('confirmed');
expect(updatedSession.paid_at).not.toBeNull();
```

### 2. اختبار طلب صيدلية بدون تأمين

```typescript
const order = await createPharmacyOrder(
  userId,
  null,
  'صيدلية النهدي',
  [
    { medication_id: 'MED1', name: 'باراسيتامول', quantity: 2, unit_price: 15 }
  ],
  30,
  null // بدون تأمين
);

expect(order.insurance_covered).toBe(0);
expect(order.user_payable).toBe(30);
expect(order.payment_status).toBe('pending');
```

---

## 📱 التكامل مع ZedPay

### إعداد بوابة الدفع

```typescript
export function generatePaymentUrl(
  orderId: string,
  amount: number,
  type: 'medical_session' | 'pharmacy_order'
): string {
  const callbackUrl = `myapp://payment/success?type=${type}&id=${orderId}`;

  return `https://zedpay.example.com/payment?` +
    `amount=${amount}&` +
    `reference=${orderId}&` +
    `callback=${encodeURIComponent(callbackUrl)}`;
}
```

### معالجة Callback

```typescript
// app/payment-success.tsx

useEffect(() => {
  async function processPayment() {
    const { type, id, status, transaction_id } = params;

    if (status === 'success') {
      await updatePaymentStatus(
        type as 'medical_session' | 'pharmacy_order',
        id as string,
        'paid',
        'zedpay',
        transaction_id as string
      );

      // عرض رسالة نجاح
      setSuccess(true);
    } else {
      // عرض رسالة فشل
      setSuccess(false);
    }
  }

  processPayment();
}, []);
```

---

## 📝 ملاحظات هامة

### ✅ الأفضليات

1. **دائماً** تحقق من التأمين قبل الدفع
2. **دائماً** حدّث حالة الدفع بعد النجاح
3. **دائماً** أنشئ سجل معاملة
4. **دائماً** اعرض رسائل واضحة للمستخدم

### ❌ تجنب

1. **لا تسمح** بتأكيد بدون دفع
2. **لا تعدّل** حالة الجلسة يدوياً - استخدم الترجرز
3. **لا تتجاوز** فحص RLS
4. **لا تحذف** سجلات الدفع

### 🔄 التدفقات البديلة

#### فشل الدفع
```typescript
if (paymentFailed) {
  await updatePaymentStatus(type, id, 'failed');
  // الجلسة تبقى pending
  // يمكن للمستخدم المحاولة مرة أخرى
}
```

#### استرجاع الأموال
```typescript
await updatePaymentStatus(type, id, 'refunded');
// تحديث حالة الجلسة/الطلب إلى cancelled
await supabase
  .from('medical_sessions')
  .update({ session_status: 'cancelled' })
  .eq('id', sessionId);
```

---

## 🎯 المستقبل

### تحسينات مقترحة

1. **فواتير PDF تلقائية**
   - توليد PDF بعد كل دفع
   - إرسال عبر البريد الإلكتروني

2. **محفظة رقمية**
   - رصيد قابل لإعادة التعبئة
   - دفع فوري بدون بوابة خارجية

3. **نظام أقساط**
   - تقسيط المبالغ الكبيرة
   - خطط دفع مرنة

4. **إشعارات Webhook**
   - إشعار فوري للصيدليات/العيادات
   - تحديثات في الوقت الفعلي

---

## 📞 الدعم

إذا واجهت أي مشاكل:
1. تحقق من RLS policies
2. راجع سجل payment_transactions
3. تأكد من صحة حسابات التأمين
4. تحقق من التريجرز

**ملف الدوال المساعدة:** `lib/payment-utils.ts`
**Migration الرئيسية:** `supabase/migrations/add_payment_core_tables.sql`
