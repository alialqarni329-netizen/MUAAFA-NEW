# دليل تنفيذ بوابة المالك - تحديث جميع الصفحات

## ما تم إنجازه ✅

### 1. لوحة التحكم (Dashboard) - مكتملة 100%
- ✅ `/app/owner/dashboard/index.tsx` - نظرة عامة مع بيانات حقيقية
- ✅ `/app/owner/dashboard/activity.tsx` - النشاط اليومي
- ✅ `/app/owner/dashboard/operations.tsx` - آخر العمليات
- ✅ `/app/owner/dashboard/alerts.tsx` - تنبيهات النظام
- ✅ `/app/owner/dashboard/services.tsx` - حالة الخدمات

### 2. إدارة الشركات (Business) - جارٍ العمل
- ✅ `/app/owner/business/index.tsx` - جميع الشركات مع بيانات حقيقية

## النمط المستخدم في جميع الصفحات

### 1. البنية الأساسية

```typescript
import { ScrollView, View, Text, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import OwnerTabLayout from '@/components/OwnerTabLayout';
import { Icon } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

const TABS = [
  // قائمة التبويبات الفرعية
];

export default function PageName() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [data, setData] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    // ... other stats
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      // جلب البيانات من Supabase
      const result = await supabase.from('table_name').select('*');
      setData(result.data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }

  if (loading) {
    return (
      <OwnerTabLayout title="العنوان" tabs={TABS}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>جاري التحميل...</Text>
        </View>
      </OwnerTabLayout>
    );
  }

  return (
    <OwnerTabLayout title="العنوان" tabs={TABS}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Stats Cards */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>الإجمالي</Text>
          </View>
        </View>

        {/* Data List or Empty State */}
        {data.length > 0 ? (
          data.map((item) => (
            <View key={item.id} style={styles.card}>
              {/* عرض البيانات */}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Icon size={48} color="#cbd5e1" strokeWidth={2} />
            <Text style={styles.emptyTitle}>لا توجد بيانات بعد</Text>
            <Text style={styles.emptyText}>عدد العناصر: 0</Text>
          </View>
        )}
      </ScrollView>
    </OwnerTabLayout>
  );
}
```

### 2. قواعد إلزامية

#### ✅ ممنوع منعاً باتاً:
- ❌ عرض كلمة "قريبًا" أو "Coming Soon"
- ❌ استخدام بيانات وهمية أو ثابتة
- ❌ ترك صفحات فارغة
- ❌ استخدام `UnderDevelopmentOwner` component

#### ✅ مطلوب في كل صفحة:
- ✅ جلب بيانات حقيقية من Supabase
- ✅ Loading state أثناء التحميل
- ✅ Refresh functionality
- ✅ Empty state إذا لم تكن هناك بيانات (مع عداد = 0)
- ✅ إحصائيات حقيقية من قاعدة البيانات
- ✅ معالجة الأخطاء بـ try/catch

### 3. جداول قاعدة البيانات المستخدمة

| القسم | الجدول الرئيسي | الجداول المرتبطة |
|-------|----------------|-------------------|
| Users | `users` | `subscriptions`, `user_permissions` |
| Business | `business_registrations` | `business_employees`, `pharmacies`, `covered_facilities` |
| Subscriptions | `subscriptions` | `subscription_plans`, `subscription_payments` |
| Payments | `subscription_payments` | `users`, `subscriptions` |
| Content | `medical_questionnaires` | `chat_messages` |
| Sessions | `sessions` | `users` |
| Pharmacy | `pharmacies` | `pharmacy_orders`, `pharmacy_inventory` |
| Notifications | `notifications` | `users` |

## الصفحات المتبقية التي تحتاج تحديث

### إدارة الشركات (Business) - 9 صفحات متبقية

1. **pharmacies.tsx** - عرض الصيدليات فقط
   ```typescript
   // فلترة من جدول pharmacies
   const { data } = await supabase.from('pharmacies').select('*');
   ```

2. **hospitals.tsx** - عرض المستشفيات
   ```typescript
   // فلترة من covered_facilities where facility_type = 'hospital'
   const { data } = await supabase
     .from('covered_facilities')
     .select('*')
     .eq('facility_type', 'hospital');
   ```

3. **insurance.tsx** - عرض شركات التأمين
   ```typescript
   // تجميع من covered_facilities حسب insurance_company
   const { data } = await supabase
     .from('covered_facilities')
     .select('insurance_company');
   ```

4. **requests.tsx** - طلبات التسجيل المعلقة
   ```typescript
   // فلترة business_registrations where status = 'pending'
   const { data } = await supabase
     .from('business_registrations')
     .select('*')
     .eq('status', 'pending');
   ```

5. **status.tsx** - تجميع الشركات حسب الحالة
   ```typescript
   // عد الشركات حسب status
   const [approved, pending, rejected] = await Promise.all([
     supabase.from('business_registrations').select('*', { count: 'exact' }).eq('status', 'approved'),
     supabase.from('business_registrations').select('*', { count: 'exact' }).eq('status', 'pending'),
     supabase.from('business_registrations').select('*', { count: 'exact' }).eq('status', 'rejected'),
   ]);
   ```

6. **employees.tsx** - عرض موظفي الشركات
   ```typescript
   // من business_employees مع join على users
   const { data } = await supabase
     .from('business_employees')
     .select('*, users(*), business_registrations(business_name)');
   ```

7. **activity.tsx** - سجل نشاط الشركات
8. **permissions.tsx** - إدارة صلاحيات الشركات
9. **settings.tsx** - إعدادات الشركات

### إدارة المستخدمين (Users) - 8 صفحات متبقية

1. **individuals.tsx** - فلترة users حسب user_role='individual_user'
2. **owners.tsx** - فلترة users حسب user_role='business_owner'
3. **employees.tsx** - فلترة users حسب user_role='business_employee'
4. **suspended.tsx** - المستخدمون الموقوفون
5. **permissions.tsx** - صلاحيات المستخدمين
6. **activity.tsx** - سجل نشاط المستخدمين
7. **reset.tsx** - إعادة تعيين كلمات المرور
8. **actions.tsx** - إجراءات على المستخدمين

### الاشتراكات (Subscriptions) - 9 صفحات

1. **index.tsx** - نظرة عامة على الاشتراكات
2. **active.tsx** - الاشتراكات النشطة
3. **trial.tsx** - الاشتراكات التجريبية
4. **expired.tsx** - الاشتراكات المنتهية
5. **cancelled.tsx** - الاشتراكات الملغاة
6. **individual.tsx** - اشتراكات الأفراد
7. **business.tsx** - اشتراكات الشركات
8. **pricing.tsx** - إدارة الباقات
9. **create.tsx** - إنشاء باقة جديدة

### المدفوعات (Payments) - 9 صفحات

1. **index.tsx** - نظرة عامة
2. **successful.tsx** - المدفوعات الناجحة
3. **failed.tsx** - المدفوعات الفاشلة
4. **invoices.tsx** - الفواتير
5. **refunds.tsx** - المرتجعات
6. **gateways.tsx** - بوابات الدفع
7. **subscriptions.tsx** - مدفوعات الاشتراكات
8. **logs.tsx** - سجلات الدفع
9. **tax.tsx** - الضرائب

### باقي الأقسام (50+ صفحة)

- Content (8 صفحات)
- Analytics (7 صفحات)
- Sessions (7 صفحات)
- Pharmacy (8 صفحات)
- Notifications (6 صفحات)
- Settings (9 صفحات)
- Security (6 صفحات)

## أمثلة على الاستعلامات المطلوبة

### جلب البيانات مع الإحصائيات

```typescript
async function loadData() {
  try {
    const [totalRes, activeRes, data] = await Promise.all([
      supabase.from('table').select('*', { count: 'exact', head: true }),
      supabase.from('table').select('*', { count: 'exact', head: true }).eq('status', 'active'),
      supabase.from('table').select('*').order('created_at', { ascending: false }).limit(20),
    ]);

    setStats({
      total: totalRes.count || 0,
      active: activeRes.count || 0,
    });

    setData(data.data || []);
  } catch (error) {
    console.error('Error:', error);
  } finally {
    setLoading(false);
  }
}
```

### عرض حالة فارغة

```typescript
{data.length > 0 ? (
  data.map((item) => (
    <View key={item.id}>
      {/* عرض البيانات */}
    </View>
  ))
) : (
  <View style={styles.emptyState}>
    <Icon size={48} color="#cbd5e1" />
    <Text style={styles.emptyTitle}>لا توجد بيانات بعد</Text>
    <Text style={styles.emptyText}>عدد العناصر: 0</Text>
  </View>
)}
```

## الخطوات التالية

1. **إكمال صفحات Business** (9 صفحات متبقية)
2. **تحديث صفحات Users** (8 صفحات)
3. **تحديث صفحات Subscriptions** (9 صفحات)
4. **تحديث صفحات Payments** (9 صفحات)
5. **إكمال باقي الأقسام** (50+ صفحة)

## ملاحظات مهمة

- ⚡ جميع الصفحات تستخدم نفس النمط للتوحيد
- ⚡ كل صفحة مستقلة ولها بياناتها الخاصة
- ⚡ لا يوجد mock data أو hardcoded values
- ⚡ كل الأرقام والإحصائيات من قاعدة البيانات
- ⚡ معالجة الأخطاء في كل صفحة
- ⚡ Empty states واضحة مع عداد = 0

## الخلاصة

تم تصميم النظام ليكون:
- ✅ قابل للاستخدام الفوري
- ✅ يعرض بيانات حقيقية فقط
- ✅ لا يحتوي على رسائل "قريبًا"
- ✅ يعمل مع أي حجم من البيانات (0 أو أكثر)
- ✅ يوفر تجربة مستخدم ممتازة
