# دليل سريع - ربط الصفحات بقاعدة البيانات

**للمطورين:** هذا دليل سريع لإكمال ربط الصفحات المتبقية

---

## 📋 النمط الأساسي للربط

### 1. استيراد Supabase
```typescript
import { supabase } from '@/lib/supabase';
```

### 2. تعريف الواجهة (Interface)
```typescript
interface MyData {
  id: string;
  name: string;
  created_at: string;
  // ... الحقول الأخرى
}
```

### 3. State Management
```typescript
const [loading, setLoading] = useState(true);
const [data, setData] = useState<MyData[]>([]);
const [refreshing, setRefreshing] = useState(false);
```

### 4. تحميل البيانات
```typescript
async function loadData() {
  try {
    setLoading(true);

    const { data, error } = await supabase
      .from('table_name')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;

    setData(data || []);
  } catch (error: any) {
    console.error('Error:', error);
    Alert.alert('خطأ', error.message);
  } finally {
    setLoading(false);
  }
}

useEffect(() => {
  loadData();
}, []);
```

### 5. التحديث
```typescript
async function updateData(id: string, updates: Partial<MyData>) {
  try {
    const { error } = await supabase
      .from('table_name')
      .update(updates)
      .eq('id', id);

    if (error) throw error;

    Alert.alert('نجح', 'تم التحديث بنجاح');
    await loadData();
  } catch (error: any) {
    Alert.alert('خطأ', error.message);
  }
}
```

### 6. الحذف
```typescript
async function deleteData(id: string) {
  Alert.alert(
    'تأكيد الحذف',
    'هل أنت متأكد؟',
    [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'حذف',
        style: 'destructive',
        onPress: async () => {
          try {
            const { error } = await supabase
              .from('table_name')
              .delete()
              .eq('id', id);

            if (error) throw error;

            Alert.alert('نجح', 'تم الحذف بنجاح');
            await loadData();
          } catch (error: any) {
            Alert.alert('خطأ', error.message);
          }
        }
      }
    ]
  );
}
```

---

## 🎯 أمثلة محددة حسب الصفحة

### A. صفحات Owner - Hospitals
```typescript
// app/owner/business/hospitals.tsx

interface Hospital {
  id: string;
  business_name: string;
  commercial_registration: string;
  phone: string;
  email: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

async function loadHospitals() {
  const { data, error } = await supabase
    .from('business_registrations')
    .select('*')
    .eq('business_type', 'hospital')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error loading hospitals:', error);
    return [];
  }

  return data;
}
```

### B. صفحات Owner - Pharmacy Orders
```typescript
// app/owner/pharmacy/orders.tsx

interface PharmacyOrder {
  id: string;
  user_id: string;
  pharmacy_id: string;
  status: string;
  total_amount: number;
  created_at: string;
  users: { full_name: string; phone: string };
  pharmacies: { name: string };
}

async function loadOrders() {
  const { data, error } = await supabase
    .from('pharmacy_orders')
    .select(`
      *,
      users(full_name, phone),
      pharmacies(name)
    `)
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) {
    console.error('Error:', error);
    return [];
  }

  return data;
}
```

### C. صفحات Owner - Payments
```typescript
// app/owner/payments/successful.tsx

interface Payment {
  id: string;
  amount: number;
  status: 'completed' | 'paid';
  payment_method: string;
  created_at: string;
  users: { full_name: string };
}

async function loadSuccessfulPayments() {
  const { data, error } = await supabase
    .from('payments')
    .select(`
      *,
      users(full_name, phone)
    `)
    .in('status', ['completed', 'paid'])
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error:', error);
    return [];
  }

  // حساب عمولة المنصة 10%
  const paymentsWithCommission = data.map(payment => ({
    ...payment,
    platform_commission: payment.amount * 0.10,
    business_amount: payment.amount * 0.90
  }));

  return paymentsWithCommission;
}
```

### D. صفحات Owner - Sessions
```typescript
// app/owner/sessions/active.tsx

interface Session {
  id: string;
  user_id: string;
  doctor_id: string;
  status: 'scheduled' | 'in_progress';
  appointment_date: string;
  users: { full_name: string };
  doctors: { name: string };
}

async function loadActiveSessions() {
  const { data, error } = await supabase
    .from('appointments')
    .select(`
      *,
      users(full_name, phone),
      doctors(name, specialty)
    `)
    .in('status', ['scheduled', 'in_progress'])
    .order('appointment_date', { ascending: true });

  if (error) {
    console.error('Error:', error);
    return [];
  }

  return data;
}
```

### E. صفحات Business - Analytics
```typescript
// app/business/analytics.tsx

async function loadBusinessAnalytics() {
  const { data: userData } = await supabase.auth.getUser();
  const userId = userData?.user?.id;

  // Get business info
  const { data: business } = await supabase
    .from('business_registrations')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (!business) return null;

  // Get payments count
  const { count: paymentsCount } = await supabase
    .from('payments')
    .select('*', { count: 'exact', head: true })
    .eq('business_id', business.id);

  // Get total revenue
  const { data: payments } = await supabase
    .from('payments')
    .select('amount')
    .eq('business_id', business.id)
    .eq('status', 'completed');

  const totalRevenue = payments?.reduce((sum, p) => sum + p.amount, 0) || 0;

  return {
    business,
    paymentsCount,
    totalRevenue
  };
}
```

### F. صفحات Business - Claims
```typescript
// app/business/claims.tsx

interface InsuranceClaim {
  id: string;
  user_id: string;
  policy_id: string;
  claim_amount: number;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  users: { full_name: string };
}

async function loadClaims() {
  const { data: userData } = await supabase.auth.getUser();
  const userId = userData?.user?.id;

  // Get business
  const { data: business } = await supabase
    .from('business_registrations')
    .select('id')
    .eq('user_id', userId)
    .single();

  if (!business) return [];

  // Get claims for this insurance company
  const { data, error } = await supabase
    .from('insurance_requests')
    .select(`
      *,
      users(full_name, phone),
      insurance_policies(policy_number)
    `)
    .eq('insurance_company_id', business.id)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error:', error);
    return [];
  }

  return data;
}
```

---

## 🔒 أمان RLS

### تحقق من الصلاحيات
```typescript
// للمالك فقط
const { data: adminData } = await supabase
  .from('admin_users')
  .select('role')
  .eq('id', userId)
  .single();

if (adminData?.role !== 'owner') {
  Alert.alert('خطأ', 'ليس لديك صلاحية');
  return;
}
```

### للشركات فقط
```typescript
// Get current business
const { data: business } = await supabase
  .from('business_registrations')
  .select('*')
  .eq('user_id', userId)
  .single();

if (!business) {
  Alert.alert('خطأ', 'لم يتم العثور على الشركة');
  return;
}
```

---

## 📊 الإحصائيات

### مثال: عد الصفوف
```typescript
const { count } = await supabase
  .from('table_name')
  .select('*', { count: 'exact', head: true })
  .eq('status', 'active');
```

### مثال: جمع الأرقام
```typescript
const { data } = await supabase
  .from('payments')
  .select('amount')
  .eq('status', 'completed');

const total = data?.reduce((sum, item) => sum + item.amount, 0) || 0;
```

### مثال: الفلترة بالتاريخ
```typescript
const today = new Date().toISOString().split('T')[0];

const { data } = await supabase
  .from('table_name')
  .select('*')
  .gte('created_at', `${today}T00:00:00`)
  .lte('created_at', `${today}T23:59:59`);
```

---

## 🎨 UI Guidelines

### Loading State
```tsx
{loading ? (
  <ActivityIndicator size="large" color="#3b82f6" />
) : (
  <ScrollView>
    {/* content */}
  </ScrollView>
)}
```

### Empty State
```tsx
{data.length === 0 ? (
  <View style={styles.emptyState}>
    <Icon size={48} color="#cbd5e1" />
    <Text style={styles.emptyText}>لا توجد بيانات</Text>
  </View>
) : (
  data.map(item => (
    <View key={item.id}>
      {/* item content */}
    </View>
  ))
)}
```

### Error Handling
```tsx
try {
  // operation
  Alert.alert('نجح', 'تمت العملية بنجاح');
} catch (error: any) {
  Alert.alert('خطأ', error.message);
  console.error('Error:', error);
}
```

---

## ✅ Checklist قبل الانتهاء

- [ ] البيانات تُحمّل من قاعدة البيانات الحقيقية
- [ ] لا توجد بيانات وهمية (mock data)
- [ ] معالجة الأخطاء موجودة
- [ ] Loading state موجودة
- [ ] Empty state موجودة
- [ ] Pull to refresh يعمل
- [ ] البحث والفلترة تعمل
- [ ] الأكشن (تعديل/حذف) تعمل
- [ ] RLS آمن
- [ ] تم الاختبار

---

## 🚀 الخطوات التالية

1. **اختر صفحة** من القائمة في `DATABASE_INTEGRATION_COMPLETE_REPORT.md`
2. **اتبع النمط** الموضح أعلاه
3. **اختبر** التغييرات
4. **اعمل build** للتأكد من عدم وجود أخطاء
5. **انتقل للصفحة التالية**

---

## 📚 مراجع

### ملفات للمراجعة
- `app/owner/users/individuals.tsx` - مثال كامل
- `app/owner/users/suspended.tsx` - مثال كامل
- `app/owner/business/requests.tsx` - مثال مع أكشن

### Supabase Docs
- https://supabase.com/docs/reference/javascript/select
- https://supabase.com/docs/reference/javascript/update
- https://supabase.com/docs/reference/javascript/delete

---

**تاريخ الإنشاء:** 30 ديسمبر 2025
**الحالة:** جاهز للاستخدام
